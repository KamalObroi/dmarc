jQuery('.welcomeblock').click(function() {
   if(jQuery('.welcombacklinks').is(':visible')){
	  jQuery('.welcombacklinks').hide();		
	  jQuery(this).find('i').removeClass('fa-angle-double-down').addClass('fa-angle-double-right');
   }else{
	  jQuery('.welcombacklinks').show();
	  jQuery(this).find('i').removeClass('fa-angle-double-right').addClass('fa-angle-double-down');
   }
   
});
jQuery(document).on('click','#dmarc_check',function(){
	var domainname = jQuery('#domainname').val();
	
	if(domainname == null || domainname == ""){
		jQuery('#domainname').addClass('error');
		return false;
	}
	jQuery.ajax({
		url: SITE_URL + '/home/checkdns',
		data:{'domainname':domainname},
		type:'post',
		dataType:'json',
		success:function(responseJson){	
		    if(responseJson.dmarc !="")
		    {
		    	jQuery('#domainmodal .modal-body .dmarc').text('DMarc Value :' + responseJson.dmarc).addClass('alert-success');
		    }else{
		    	jQuery('#domainmodal .modal-body .dmarc').text('DMarc Not there.').addClass('alert-danger');	
		    }
		    if(responseJson.skim !="")
		    {
		    	jQuery('#domainmodal .modal-body .skim').text('SPF Value :' + responseJson.skim).addClass('alert-success');
		    }else{
		    	jQuery('#domainmodal .modal-body .skim').text('SPF Not there.').addClass('alert-danger');	
		    }
		    if(responseJson.dkim !="")
		    {
		    	jQuery('#domainmodal .modal-body .dkim').text('DKIM  Value :' + responseJson.dkim).addClass('alert-success');
		    }else{
		    	jQuery('#domainmodal .modal-body .dkim').text('DKIM Not there.').addClass('alert-danger');	
		    }
			jQuery('#domainmodal').modal('show');				
		}
	});
});