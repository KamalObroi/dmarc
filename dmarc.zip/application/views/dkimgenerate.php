<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
<link rel="shortcut icon" type="image/x-icon" href="<?php echo site_url();?>resources/img/lg11.png"/>
    <title>DmarcForce</title>    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.<?php echo base_url(JS); ?>/1.4.2/respond.min.js"></script>
    <![endif]-->
<!--<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">-->
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link href="<?php echo base_url(VENDOR); ?>/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url(VENDOR); ?>/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
    <link href="<?php echo base_url(CSS); ?>/agency.min.css" rel="stylesheet">
    <style type="text/css">
	.navbar-custom.affix-top {
    /*! background-color:#222; */
      padding:10px 0;
	  background-image: url('resources/img/menuimage.PNG') !important; 
	  background-repeat: no-repeat;
	  background-size: 100%;
    
  }
	.navbar-inverse .navbar-brand {
	    color: #052729;
	}
	.navbar-inverse .navbar-nav > li > a {
	    color: #052729;
	}
	.navbar-inverse .navbar-nav > li > a:hover {
	    color: #052729;
	}
	.navbar-inverse .navbar-nav > .open > a, .navbar-inverse .navbar-nav > .open > a:focus, .navbar-inverse .navbar-nav > .open > a:hover {
    color: #fff;
    background-color: #046E96;
}
</style>
</head>

<!------ Include the above in your HEAD tag ---------->
<body>
    <nav id="mainNav" class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
              
                <a href="<?php echo site_url();?>"><img src="<?php echo site_url();?>resources/img/lg11.png" style="float:left;"/>
                <span class="navbar-brand page-scroll" style="line-height: 30px;">DmarcForce</span></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <?php $this->load->view('main_menu'); ?>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>	
    <br/>
    <br/>
    <br/>
    <br/>
    <div class="container cntr" style="min-height:450px;border-bottom:1px solid;">
    	<?php $this->load->view('innermenu.php'); ?>		
    	
    	<div class="col-md-6" style="margin-bottom: 22px;">
    		<h3>DKIM Record Generator</h3>
			<p>Use this tool to generate your DKIM record.</p>
			<br/>	
			<form action="<?php echo site_url();?>dkimgenerate" method="post" enctype="multipart/form-data">		
			<div class="form-group">
				<div class="col-md-4" style="padding-left:0;padding-right:0;">
					<input class="form-control" name="selector" id="selector" type="text" placeholder="exp: s1"/>
				</div>					
				<div class="col-md-2" style="padding:0;margin:0;line-height: 35px;"><label>._domainkey.</label></div>
				<div class="col-md-4" style="padding-left:0;padding-right:0;"><input class="form-control" name="domainname" id="domainname" type="text" placeholder="exp: yourdomain.com"/></div>
			</div>		
			<br/><br/>				
			<div class="col-md-12" style="padding-left:0;">
				<button type="submit" class="btn btn-primary">Generate DKIM Record</button>
			</div>
			</form>
			<br/>
			<br/>
			<br/>
    	</div>
    	<div class="col-md-6">
    		<h2 class="title">What is DKIM?</h2><div class="content-small px-0">DKIM (DomainKeys Identified Mail) allows senders to associate a domain name with an email message, thus vouching for its authenticity. This is done by "signing" the email with a digital signature, a field that is added to the message's header. The recipient MTA can verify the DKIM signature, which gives users some security knowing that the email did actually originate from the listed domain, and that it has not been modified since it was sent.</div>
    	</div>
    	<div class="col-md-12 dmarcgenerateorstring" style="display:flex;">
    		
    			<?php
	    		if(isset($keys) && sizeof($keys)>0){
	    			?>
	    			<div class="col-md-6" style="border-right: 1px solid #fff !important;padding: 18px;word-wrap: break-word;min-height: 400px;border: 1px solid #cecece;background: #cecece;margin-bottom: 23px;">
	    			<a style='float: right;margin: 7px;padding: 3px;' class='c-copy btn btn-default btn-sm float-right' class='c-copy btn btn-default btn-sm float-right' href='javascript:void(0)' data-clipboard-target='#generated-dmarc-record'><i class='icon-copy'></i>&nbsp;Copy</a>
	    			<h2>Private key</h2>
	    			<span>
You must enter this key in your DKIM signer. It must be kept secret, as anyone with access to it can stamp tokens pretending to be you</span><br/>
	    			<?php
	    			echo '<p id="generated-dmarc-record">'.$keys['privatekey'].'</p>';
	    			?>
	    			</div>
	    			<?php
	    		}
	    		 ?>
    		
    		
    			<?php
	    		if(isset($keys) && sizeof($keys)>0){
	    			?>
	    			
	    			<div class="col-md-6" style="padding: 18px;word-wrap: break-word;min-height: 400px;border: 1px solid #cecece;background: #cecece;margin-bottom: 23px;">
	    			<a style='float: right;margin: 7px;padding: 3px;' class='c-copy1 btn btn-default btn-sm float-right' class='c-copy btn btn-default btn-sm float-right' href='javascript:void(0)' data-clipboard-target='#generated-dmarc-record1'><i class='icon-copy'></i>&nbsp;Copy</a>
	    				<h2>Public key</h2>
	    			<span>This is the public key in the original raw "X509" format. It's not usable in DNS directly, but it might be useful for something else.</span>
	    			<br/>
	    			<?php
	    			echo '<p id="generated-dmarc-record1">'.$keys['publickey'].'</p>';
	    			?>
	    			</div>
	    			<?php
	    		}
	    		 ?>
    		  		
    	</div>
    </div>    
    <footer style="border-top:1px solid #cecece;">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <span class="copyright">Copyright &copy; DmarcForce 2020</span>
                </div>
                <div class="col-md-4">
                    <ul class="list-inline social-buttons">
                        <li><a href="#"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="list-inline quicklinks">
                        <li><a href="#">Privacy Policy</a>
                        </li>
                        <li><a href="#">Terms of Use</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    
    <script src="<?php echo base_url(VENDOR); ?>/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(VENDOR); ?>/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="<?php echo base_url(JS); ?>/jqBootstrapValidation.js"></script>
    <script src="<?php echo base_url(JS); ?>/contact_me.js"></script>

    <!-- Theme JavaScript -->
    <script src="<?php echo base_url(JS); ?>/agency.min.js"></script>
	<script src="<?php echo base_url(JS); ?>/custom.js"></script>
	<script type="text/javascript">		
		jQuery(document).on('click','.c-copy',function(){
			 var aux = document.createElement("input");
			  // Assign it the value of the specified element
			  aux.setAttribute("value", document.getElementById("generated-dmarc-record").innerHTML);
			  // Append it to the body
			  document.body.appendChild(aux);
			  // Highlight its content
			  aux.select();
			  // Copy the highlighted text
			  document.execCommand("copy");
			  // Remove it from the body
			  document.body.removeChild(aux);
		});
		jQuery(document).on('click','.c-copy1',function(){
			 var aux = document.createElement("input");
			  // Assign it the value of the specified element
			  aux.setAttribute("value", document.getElementById("generated-dmarc-record1").innerHTML);
			  // Append it to the body
			  document.body.appendChild(aux);
			  // Highlight its content
			  aux.select();
			  // Copy the highlighted text
			  document.execCommand("copy");
			  // Remove it from the body
			  document.body.removeChild(aux);
		});		
	</script>
</body>
</html>
