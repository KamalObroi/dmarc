<!DOCTYPE html><html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
<div id='card' class="animated fadeIn" style="position: relative;width: 100%;display: block;margin: 40px auto;text-align: center;font-family: 'Source Sans Pro', sans-serif;">
      <div id='upper-side' style="padding: 2em;background-color: #05536A;display: block;color: #fff;border-top-right-radius: 8px;border-top-left-radius: 8px;">        
          <h3 id='status' style="font-weight: lighter;text-transform: uppercase;letter-spacing: 2px;font-size: 1em;margin-top: -.2em;margin-bottom: 0;">
          Success
        </h3>
      </div>
      <div id='lower-side' style="padding: 2em 2em 5em 2em;background:#B3DCE0;display: block;border-bottom-right-radius: 8px;border-bottom-left-radius: 8px;">
        <p id='message' style="margin-top: -.5em;color: #757575;letter-spacing: 1px;">
          you have created alert with DmarcForce.
          <br/>         
        </p>       
      </div>
    </div>
   </body>
   </html> 