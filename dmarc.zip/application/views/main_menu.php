<ul class="nav navbar-nav navbar-right">
<li class="hidden"><a href="#page-top"></a></li>
<li><a class="page-scroll" href="#services">SPF</a></li>
<li><a class="page-scroll" href="<?php echo site_url();?>dashboard">Tools</a></li>
<li><a class="page-scroll" href="#team">Report</a></li>                   
<li><a class="page-scroll" href="#contact">Contact</a></li>
<?php
if($this->session->userdata('fullname') && !empty($this->session->userdata('fullname')))						{
?>
	<li><a class="welcomeblock" href="javascript:void(0);">Welcome  <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
		<ul class="welcombacklinks">
			<li><?php echo $this->session->userdata('fullname'); ?></li>	
			<li><a class="_logout" href="<?php echo site_url();?>dashboard">Dashboard</a></li>				
			<li><a class="_logout" href="<?php echo site_url();?>logout">Logout</a></li>
		</ul>                    	
	</li>	
<?php
}else{
?>
<li><a class="page-scroll" href="<?php echo site_url();?>login">Login</a></li>
<li><a class="page-scroll" href="<?php echo site_url();?>signup">SignUp</a></li>
<?php
}
?>                    
</ul>