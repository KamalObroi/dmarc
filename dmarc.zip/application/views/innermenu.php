<nav class="navbar navbar-inverse" style="background: #F6E86C;margin-top: 2px;">
<div class="container-fluid">		   
<ul class="nav navbar-nav">
<li><a href="<?php echo site_url();?>dashboard">Dashboard</a></li>	
  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">DMARC Reports <span class="caret"></span></a>
    <ul class="dropdown-menu">
      <li><a href="#">DMARC Failur Reports</a></li>
      <li><a href="#">DMARC Agreegate Reports</a></li>
    </ul>
  </li>
  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">DMARC<span class="caret"></span></a>
    <ul class="dropdown-menu">
      <li><a href="<?php echo site_url();?>dmarclookup">DMARC Record Lookup</a></li>
      <li><a href="<?php echo site_url();?>dmarcrecordgenerator">DMARC Record Generator</a></li>
    </ul>
  </li>
  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">SPF <span class="caret"></span></a>
    <ul class="dropdown-menu">
      <li><a href="<?php echo site_url();?>spflookup">SPF Record Lookup</a></li>
      <li><a href="<?php echo site_url();?>spfrecordgenerator">SPF Record Generator</a></li>
      <li><a href="<?php echo site_url();?>spfrawchecker">SPF Record Raw Checker</a></li>
    </ul>
  </li>
 <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">DKIM <span class="caret"></span></a>
    <ul class="dropdown-menu">
      <li><a href="<?php echo site_url();?>dkimlookup">DKIM Record Lookup</a></li>
      <li><a href="<?php echo site_url();?>dkimgenerate">DKIM Record Generator</a></li>
    </ul>
  </li>
  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">BIMI <span class="caret"></span></a>
    <ul class="dropdown-menu">
      <li><a href="<?php echo site_url();?>bimilookup">BIMI Record Lookup</a></li>
      <li><a href="<?php echo site_url();?>bimirecordgenerator">BIMI Record Generator</a></li>
    </ul>
  </li>
  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Alerting <span class="caret"></span></a>
    <ul class="dropdown-menu">
      <li><a href="<?php echo site_url();?>alertevents">Alert Events</a></li>
      <li><a href="<?php echo site_url();?>alertconfig">Alert Configuration</a></li>
      <li><a href="<?php echo site_url();?>createalert">Create Alert</a></li>
    </ul>
  </li>
  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Domains <span class="caret"></span></a>
    <ul class="dropdown-menu">
     <li><a href="<?php echo site_url();?>adddomain">Add Domain</a></li>
      <li><a href="<?php echo site_url();?>domains">Domains</a></li>
      <li><a href="<?php echo site_url();?>domainscanner">Domain Scanner</a></li>
      <li><a href="<?php echo site_url();?>domainreputaiton">Reputaion Check</a></li>
    </ul>
  </li>
</ul>

</div>
</nav>