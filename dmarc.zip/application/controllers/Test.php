<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	class Test extends CI_Controller 
	{
		
		public function __construct()
		{
			parent::__construct();
			$this->load->helper('url');
			$this->load->helper('form');
			$this->load->helper('security');
			//$this->load->helper('common');
			$this->load->library('form_validation');
			$this->load->library('session');
			
			$this->load->library('user_agent');
			
			$this->config->load('config');
			$user_data = $this->session->userdata('user_data');
			//session_destroy();
		}
		
		/*public function sendSMS()
			{
			$mobile = 9999739313;
			$numbers = mt_rand(1000, 9999);
			$message = 'Your OTP is : '.$numbers;
			
			$response = send_sms($mobile,$message);
			echo "<pre>";print_r($response);die;
			echo $response;
		}*/
		public function adhar()
		{
			//$ci = '20210929';//date('Ymd');
			$path=$_SERVER['DOCUMENT_ROOT'];
			$publickeypath=$path."/dmarc/resources/uidai_auth_encrypt_preprod.cer";
			
			//die;
			define("UIDAI_PUBLIC_CERTIFICATE", $publickeypath);
			
			//$ci=$this->getExpiryDate(UIDAI_PUBLIC_CERTIFICATE);
			$ci = "";
			date_default_timezone_set("Asia/Calcutta");
			//echo $date2= gmdate("Y-m-d\Thh:i:s"); die;
			$date1 = date('Y-m-d\Th:i:s', time());
			$ts='"'.$date1.'"';//date('Y-m-d\TH:i:s');
			
			$randkey = $this->generateRandomString();
			$SESSION_ID = $randkey;
			
			//Skey creation code start
			$skey1=$this->encryptMcrypt($SESSION_ID);
	
			$skey=base64_encode($skey1);

			//PID creation code start
			$pid_1='<Pid ts='.$ts.' ver="2.0"></Pid>';
			
			$pid=$this->encryptPID($pid_1,$randkey);
			
			//hmac creation code start
			$hash=hash("SHA256",$pid_1,true);
			$hmac=$this->encryptPID($hash,$randkey);
			
			$txn = $this->generateTxn();
			
			$xml_data = '<?xml version="1.0" encoding="UTF-8"?><Auth uid="488818847619" rc="Y" tid="" ac="public" sa="ZZ1095GSTC" ver="2.5" txn="'.$txn.'" lk="GSTCzxTEZ9lB0jJnVC7" xmlns="http://www.uidai.gov.in/authentication/uid-auth-request/2.0"><Uses pi="y" pa="n" pfa="n" bio="n" pin="n" otp="n" /><Meta udc="UIDAIADGYASH" rdsId="" rdsVer="" dpId="" dc="" mi="" mc="" /><Skey ci="'.$ci.'">'.$skey.'</Skey><Data type="X">'.$pid.'</Data><Hmac>'.$hmac.'</Hmac></Auth>';
			
			echo $xml_data;
			$curl = curl_init();
			curl_setopt_array($curl, array(
			//CURLOPT_PORT => "8080",
			CURLOPT_URL => "http://10.249.34.231:8080/NicASAServer/ASAMain",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => $xml_data,
			CURLOPT_HTTPHEADER => array(
			"Cache-Control: no-cache",
			"Content-Type: application/xml"
			),
			));
			$response = curl_exec($curl);
			echo "<pre>";print_r(simplexml_load_string($response));die;
		}
		function generateTxn() 
		{
			$randNumber = rand(100000000000,999999999999);
			$texNumber = "NIC".$randNumber.date('Ymd').date('hms')."GSTC";
			return $texNumber;
		}   
		function encryptPID($data,$skey) 
		{
			//echo "----".$skey;die;
			$result=openssl_encrypt($data,'AES-256-ECB',$skey);
			return ($result);
		}
		function getExpiryDate($_CERTIFICATE)
		{
			$_CERT_DATA = openssl_x509_parse(file_get_contents($_CERTIFICATE));
			//echo "<pre>";print_r($_CERT_DATA['validTo_time_t']);die;
			return date('Ymd', $_CERT_DATA['validTo_time_t']);
		}
		function encryptMcrypt($data) 
		{
			$fp=fopen(UIDAI_PUBLIC_CERTIFICATE,"r");
			$pub_key_string=fread($fp,8192);
			//echo $data;
			openssl_public_encrypt($data, $encrypted_data, $pub_key_string, OPENSSL_PKCS1_PADDING);
			return $encrypted_data;
		}
		function generateRandomString($length = 32) 
		{
			$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$charactersLength = strlen($characters);
			$randomString = '';
			for ($i = 0; $i < $length; $i++) {
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
			return $randomString;
		} 
		
		
		
		public function TestUDID()
		{
			echo "Kailash";
			$headers = array("Content-Type:multipart/form-data"); // cURL headers for file uploading
			$postfields = array('udid' => 'WB0820419800002352');
			$ch = curl_init();
			$url = 'http://www.swavlambancard.gov.in/api/getApplicationInformation';
			$options = array(
			CURLOPT_URL => $url,
			CURLOPT_HEADER => true,
			CURLOPT_POST => 1,
			CURLOPT_HTTPHEADER => $headers,
			CURLOPT_POSTFIELDS => $postfields,
			CURLOPT_INFILESIZE => $filesize,
			CURLOPT_RETURNTRANSFER => true
			); // cURL options
			curl_setopt_array($ch, $options);
			$result = curl_exec($ch);
			$info = curl_getinfo($ch);
			if(curl_errno($ch))
			{
				print_r(curl_error(($ch))); 
			}
			print_r($result);
			print_r($info); die;
			if(!curl_errno($ch))
			{
				$info = curl_getinfo($ch);
				if ($info['http_code'] == 200)
				$errmsg = "File uploaded successfully";
			}
			else
			{
				$errmsg = curl_error($ch);
			}
			curl_close($ch);	
			
			/*
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL,"http://www.swavlambancard.gov.in/api/getApplicationInformation");
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_POST, true);
				
				$data = array('udid' => 'WB0820419800002352');
				
				curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
				$output = curl_exec($ch);
				$info = curl_getinfo($ch);
				echo "<pre>";print_r($info);die;
				curl_close($ch);
			*/
		}
		function index()
		{
			$data['captcha'] = $this->createCaptcha( array(
			'min_length' => 5,
			'max_length' => 5,
			'backgrounds' => array(FCPATH.'assets/site/main/images/captcha_bg/white-carbon.png'),
			'fonts' => array(FCPATH.'assets/site/main/fonts/captcha_fonts/times_new_yorker.ttf'),
			'characters' => 'ABCDEFGHJKLMNPRSTUVWXYZabcdefghjkmnprstuvwxyz23456789',
			'min_font_size' => 28,
			'max_font_size' => 28,
			'color' => '#666',
			'angle_min' => 0,
			'angle_max' => 10,
			'shadow' => true,
			'shadow_color' => '#fff',
			'shadow_offset_x' => -1,
			'shadow_offset_y' => 1
			));	
			
			$this->session->set_userdata('captcha_code',$data['captcha']); 
			$data['salt'] = $this->random_string();
			$this->load->view('site/header');
			$this->load->view('site/login',$data);
			$this->load->view('site/footer');
		}
		public function userRegistration()
		{
			$data['captcha'] = $this->createCaptcha( array(
			'min_length' => 5,
			'max_length' => 5,
			'backgrounds' => array(FCPATH.'assets/site/main/images/captcha_bg/white-carbon.png'),
			'fonts' => array(FCPATH.'assets/site/main/fonts/captcha_fonts/times_new_yorker.ttf'),
			'characters' => 'ABCDEFGHJKLMNPRSTUVWXYZabcdefghjkmnprstuvwxyz23456789',
			'min_font_size' => 28,
			'max_font_size' => 28,
			'color' => '#666',
			'angle_min' => 0,
			'angle_max' => 10,
			'shadow' => true,
			'shadow_color' => '#fff',
			'shadow_offset_x' => -1,
			'shadow_offset_y' => 1
			));		
			$data['encriptKey'] = 'Key-123';
			$this->session->set_userdata('captcha_code',$data['captcha']);
			$user_data = $this->session->userdata('user_data');
			
			$data['salt'] = $this->random_string();
			$this->load->view('site/header');
			$this->load->view('site/userRegistration',$data);
			$this->load->view('site/footer');
		}
		public function createUserAccount()
		{
			try
			{
				$this->form_validation->set_rules('fname', 'Name', 'required|trim|xss_clean|strip_tags');
				$this->form_validation->set_rules('email', 'Email Id', 'required|trim|xss_clean|strip_tags');
				$this->form_validation->set_rules('mobile_number', 'Mobile Number', 'required|trim|xss_clean|strip_tags');
				$this->form_validation->set_rules('aadhar_number', 'Aadhar Number', 'required|trim|xss_clean|strip_tags');
				$this->form_validation->set_rules('udid_check', 'UDID Number', 'required|trim|xss_clean|strip_tags');
				$this->form_validation->set_rules('udidnumber', 'UDID Number', 'trim|xss_clean|strip_tags');
				$this->form_validation->set_rules('password', 'password', 'required|trim|xss_clean|strip_tags');
				if ($this->form_validation->run() == FALSE) 
				{ 
					$this->session->set_flashdata('error', 'Wrong Data!');
					redirect('home/userRegistration');
				} 
				else 
				{
					$post = $this->input->post(null,true);
					//echo "<pre>";print_r($post);
					$post['aadhar_number'] = cryptoJsAesDecrypt('Key-123',$post['aadhar_number']);
					$post = $this->security->xss_clean($post);
					if($this->isValidCaptch($post['captchatext']))
					{
						$checkUserExist = $this->user_model->checkUserExist($post['email']);
						if($checkUserExist > 0)
						{
							$this->session->set_flashdata('error', 'User Already Exists !.');
							redirect('home/userRegistration');
						}
						else
						{
							$user_id = $this->user_model->insertUserDetails($post);
							if(isset($user_id) && !empty($user_id))
							{
								$encode_user_id = $this->encrypt->encode($user_id);
								//echo $encode;
								//echo "-----".$this->encrypt->decode($encode);die;
								$otp_number = mt_rand(1000, 9999);
								$url = site_url().'home/accountVerification/'.$encode_user_id;
								$message='';
								$message.='Dear '.$post['fname'].',<br><br>Thanks, Your account has been created successfully.<br><br>Your OTP is : '.$otp_number.'<br><br><a href="'.$url.'" style="background: #333;font-size: 17px; border-radius: 3px;color: #ffffff; padding: 6px 14px;text-decoration: block;">Please click here to activate your account.</a><br><br><p>With Regards</p><br><p>AEI Division, DHI</p><br><br>';
								//echo $message;die;
								$config = $this->config->item('mailconfig');
								$from_email = $this->config->item('from_email_id');	
								
								/* Load email library */
								$this->load->library('email',$config);			   
								$this->email->from($from_email, 'Department of Heavy Industry');
								$to_email = isset($post['email'])?$post['email']:'';
								$this->email->to($to_email);
								$subject = 'DHI account verification of ('.$post['fname'].')';
								$this->email->subject($subject); 
								$this->email->message($message);
								if($this->email->send())
								{
									$this->user_model->updateMobileVerificationOTP($user_id,$otp_number);
									$this->session->set_flashdata('success', 'Your account has been created successfully. Please check your email and activate your account.');
									redirect('/');
								}
							}
							else
							{
								$this->session->set_flashdata('error', 'Your account has not been created!. Please try again.');
								redirect('home/userRegistration');
							}
						}
					}
					else
					{
						$this->session->set_flashdata('error', 'Wrong Captcha. Please try again');
						redirect('home/userRegistration');
					}
				}
			}
			catch(Exception $e)
			{
				$this->session->set_flashdata('error', 'Some Exception are there? Please try again?.');
				redirect('home/userRegistration');
			}
		}
		public function accountVerification()
		{
			/*$userId = $this->uri->segment(3);
				$success = $this->user_model->accountVerification($userId);
				if($success)
				{
				$this->session->set_flashdata('success', 'Thanks, Your account has been activated. Now you can login.');
				redirect('/');
				}
				else
				{
				$this->session->set_flashdata('error', 'Your account has not been actived. Please try again.');
				redirect('/');
			}*/
			//$userId = $this->uri->segment(3);
			//$this->session->set_userdata('captcha_code',$data['captcha']);
			$user_data = $this->session->userdata('user_data');
			$post = $this->input->post();
			$userId = isset($post['id'])?$post['id']:'';
			$userId = $this->encrypt->decode($userId);
			if(isset($post) && !empty($post))
			{
				$this->form_validation->set_rules('otp_number', 'OTP Number', 'required|trim|xss_clean|strip_tags');
				if ($this->form_validation->run() == FALSE) 
				{ 
					$this->session->set_flashdata('error', 'Wrong Data!');
					redirect('home/accountVerification/'.$post['id']);
				} 
				else
				{
					
					$getuserDataById = $this->user_model->getuserDataById($userId);
					//print_r($getuserDataById);die;
					if(isset($getuserDataById[0]['otp_number']) && $getuserDataById[0]['otp_number'] == $post['otp_number'])
					{
						$success = $this->user_model->accountVerification($userId);
						if($success)
						{
							$this->session->set_flashdata('success', 'Thanks, Your account has been activated. Now you can login.');
							redirect('home');
							/*if (isset($getuserDataById) && !empty($getuserDataById)) 
								{	            	
								$datas = array(
								'userid'=>$getuserDataById[0]['id'],
								'fname'=>$getuserDataById[0]['fname'],
								'mobile_number'=>$getuserDataById[0]['mobile_number'],
								'aadhar_number'=>$getuserDataById[0]['aadhar_number'],
								'email'=> $getuserDataById[0]['email'],
								'user_type'=>$getuserDataById[0]['user_type'],
								'status'=>$getuserDataById[0]['status'],
								'udidnumber'=>$getuserDataById[0]['udidnumber'],
								'udid_check'=>$getuserDataById[0]['udid_check']
								);
								//echo ",pre>";print_r($datas);die;
								$lastLogin = $this->user_model->updateLogin($getuserDataById[0]['email']);
								$this->session->set_userdata('user_data',$datas);
								session_regenerate_id(true);
								$role = $getuserDataById[0]['user_type'];
								switch($role)
								{
								case "1":
								redirect(site_url() . 'applicant');
								break;
								
								default:
								$this->session->set_flashdata('error', 'Wrong OTP!');
								redirect('home/accountVerification/'.$post['id']);
								}         
								}
								$this->session->set_flashdata('success', 'Thanks, Your account has been activated. Now you can login.');
							redirect('/');*/
						}
						else
						{
							$this->session->set_flashdata('error', 'Your account has not been actived. Please try again.');
							redirect('/');
						}
					}
					else
					{
						$this->session->set_flashdata('error', 'Your are entered wrong OTP. Please try again.');
						redirect('home/accountVerification/'.$post['id']);
					}
				}
			}
			else
			{
				$encript_segment_user_id = $this->uri->segment(3);
				$segment_user_id = $this->encrypt->decode($encript_segment_user_id);
				if(isset($segment_user_id) && !empty($segment_user_id) && is_numeric($segment_user_id))
				{
					$checkUserExistById = $this->user_model->checkUserExistById($segment_user_id);
					//print_r($checkUserExistById);die;
					if($checkUserExistById)
					{
						$this->session->set_flashdata('success', 'Thanks, Your account already activated. Now you can login.');
						redirect('/');
					}
					else
					{
						$this->load->view('site/header');
						$this->load->view('site/otp_verification_form',$data);
						$this->load->view('site/footer');
					}
				}
				else
				{
					$this->session->set_flashdata('error', 'Wrong url entered. Please try again.');
					redirect('/');
				}
			}
			
		}
		public function userLogin()
		{
			try
			{
				$this->form_validation->set_rules('email', 'Email', 'required|trim|xss_clean|strip_tags');
				$this->form_validation->set_rules('password', 'Password', 'required|trim|xss_clean|strip_tags');  
				if ($this->form_validation->run() == FALSE) 
				{ 	
					$this->session->set_flashdata('error', 'Wrong data!');
					redirect('home');
				} 
				else 
				{
					$post     = $this->input->post();
					$clean    = $this->security->xss_clean($post);
					
					if($this->isValidCaptch($clean['captchatext']))
					{
						//echo "<pre>";print_r($_SESSION['salt']);die;
						$password = $this->input->post('password');
						$userInfo= $this->user_model->checkPass($clean);
						//$Pass = sha1($userInfo->password.$_SESSION['salt']);
						$Pass = hash('sha256', $userInfo->password.$_SESSION['salt']);
						//echo $password."----------------".$Pass; die;
						
						if($userInfo->status == 0)
						{
							$this->session->set_flashdata('error', 'Your account has not been activated.Please try again');
							redirect('home');
						}
						//echo "<pre>"; print_r($_SESSION['salt'].'=='.$password.'=='.$Pass); die;
						if($password != $Pass)
						{
							//insert into audit trails
							$audit_trails = array('login_id' => $userInfo->id,'login_username'=>$userInfo->fname, 'login_ip_address' => $this->input->ip_address(), 'login_browser' => $this->agent->agent_string(), 'user_role' => $userInfo->user_type, 'updated_on' => date('Y-m-d h:i:s'),'user_activity'=>'Logging Failed');
							//echo "<pre>"; print_r($audit_trails); die;
							$this->user_model->createAuditTrails($audit_trails);
							$this->session->set_flashdata('error', 'Wrong Username/Password!');
							redirect('home');
						}
						
						if (is_object($userInfo) && property_exists($userInfo,"email")) 
						{	            	
							$datas = array(
							'userid'=> $userInfo->id,
							'fname'=> $userInfo->fname,
							'mobile_number'=> $userInfo->mobile_number,
							'aadhar_number'=> $userInfo->aadhar_number,
							'email'=> $userInfo->email,
							'user_type'=> $userInfo->user_type,
							'status'=> $userInfo->status,
							'udidnumber'=>$userInfo->udidnumber,
							'udid_check'=>$userInfo->udid_check
							);
							//echo ",pre>";print_r($datas);die;
							$audit_trails = array('login_id' => $userInfo->id,'login_username'=>$userInfo->fname, 'login_ip_address' => $this->input->ip_address(), 'login_browser' => $this->agent->agent_string(), 'user_role' => $userInfo->user_type, 'updated_on' => date('Y-m-d h:i:s'),'user_activity'=>'Logging Successfully');
							//echo "<pre>"; print_r($audit_trails); die;
							$this->user_model->createAuditTrails($audit_trails);
							$lastLogin = $this->user_model->updateLogin($clean['email']);
							$this->session->set_userdata('user_data',$datas);
							session_regenerate_id(true);
							$role = $userInfo->user_type;
							switch($role)
							{
								case "1":
								redirect(site_url() . 'applicant');
								break;
								case "2":
								redirect(site_url() . 'verifier');
								break;
								case "3":
								redirect(site_url() . 'approver');
								break;
								case "4":
								redirect(site_url() . 'admin');
								break;
								
								default:
								$this->session->set_flashdata('error', 'Wrong Username/Password!');
								redirect('home');
							}         
						}
						else
						{
							$this->session->set_flashdata('error', 'Wrong Username/Password!');
							redirect('home');
						}
					}
					else
					{
						$this->session->set_flashdata('error', 'Wrong Captcha entered. Please try again.');
						redirect('home');
					}
				}
				
			}
			catch(Exception $e)
			{
				$this->session->set_flashdata('error', 'Some Technical Error are there!');
				redirect('home');
			}
		}
		public function forgotPassword()
		{
			$data['captcha'] = $this->createCaptcha( array(
			'min_length' => 5,
			'max_length' => 5,
			'backgrounds' => array(FCPATH.'assets/site/main/images/captcha_bg/white-carbon.png'),
			'fonts' => array(FCPATH.'assets/site/main/fonts/captcha_fonts/times_new_yorker.ttf'),
			'characters' => 'ABCDEFGHJKLMNPRSTUVWXYZabcdefghjkmnprstuvwxyz23456789',
			'min_font_size' => 28,
			'max_font_size' => 28,
			'color' => '#666',
			'angle_min' => 0,
			'angle_max' => 10,
			'shadow' => true,
			'shadow_color' => '#fff',
			'shadow_offset_x' => -1,
			'shadow_offset_y' => 1
			));		
			$this->session->set_userdata('captcha_code',$data['captcha']);
			$user_data = $this->session->userdata('user_data');
			
			$data['salt'] = $this->random_string();
			$this->load->view('site/header');
			$this->load->view('site/forgotPassword',$data);
			$this->load->view('site/footer');
		}
		public function userForgotPassSubmitForm()
		{
			try
			{
				$this->form_validation->set_rules('email', 'UserEmail', 'required|trim|xss_clean|strip_tags');
				
				if ($this->form_validation->run() == FALSE) {
					
					$this->session->set_flashdata('error', 'Enter Valid Email');
					redirect('home/forgotPassword');
					
					} else {
					
					$post     = $this->input->post();
					$clean    = $this->security->xss_clean($post);
					
					if($this->isValidCaptch($clean['captchatext']))
					{
						//echo '<pre>';print_r($clean);die;
						$user_email =trim($clean['email']);
						
						//check email exits in db
						
						$checkUserExist = $this->user_model->checkUserEmailExist($user_email);
						//echo '<pre>';print_r($checkUserExist);die;
						if(is_object($checkUserExist))
						{
							
							$user_id = isset($checkUserExist->id)?$checkUserExist->id:"";
							
							//insert user token
							$user_token = $this->random_string();
							$this->user_model->insertUserToken($user_id,$user_token);
							
							//send mail
							$url = site_url() . 'home/resetpassword/' . $user_token;
							
							$message='';
							$message.='<td colspan="6" height="0" bgcolor="#fff" valign="top" style="padding:20px;color:#333;border-bottom:1px solid #1b1818">Dear User,<br><br>
							You recently requested to set your password for Department of Heavy Industry. This password reset is only valid for next 15 minutes.<br><br><br>
							<a href="'.$url.'" style="background: #333;font-size: 17px; border-radius: 3px;color: #ffffff; padding: 6px 14px;text-decoration: none;">Reset Your Password</a>
							<br><br>';
							
							$config = $this->config->item('mailconfig');
							$from_email = $this->config->item('from_email_id');	
							//echo '<pre>';print_r($content);die;
							
							/* Load email library */
							$this->load->library('email',$config);			   
							$this->email->from($from_email, 'Department of Heavy Industry'); 
							$this->email->to($user_email);
							$this->email->subject('Forgot Password: Department of Heavy Industry'); 
							$this->email->message($message); 
							//update change password datetime
							if($this->email->send()){
								$this->session->set_flashdata('success', 'Forgot password link has been sent to you email.');
								redirect('');
								}else{
								$this->session->set_flashdata('error', 'Entered wrong email.');
								redirect('home/forgotPassword');
							}
							
						}
						else
						{
							$this->session->set_flashdata('error', 'Entered wrong email.');
							redirect('home/forgotPassword');
							return false;
						}
					}
					else
					{
						$this->session->set_flashdata('error', 'You Entered Wrong Captcha.');
						redirect('home/forgotPassword');
						return false;
					}
				}
			}
			catch(Exception $e)
			{
				$this->session->set_flashdata('error', 'Some Exception are there? Please try again!');
				redirect('home/forgotPassword');
				return false;
			}
		}
		public function resetpassword(){
			
			$gettoken = $this->uri->segment(3);
			$getdata = $this->user_model->getUserDataByToken($gettoken);
			//echo '<pre>';print_r($getdata);die;
			//$change_pass_status = isset($getdata[0]['change_pass_status'])?$getdata[0]['change_pass_status']:0;
			
			$change_pass_date_time = isset($getdata[0]['token_date'])?$getdata[0]['token_date']:'';
			
			$expiry_date = strtotime('+15 minutes', $change_pass_date_time);//date('Y-m-d',strtotime('+15 minutes',strtotime($change_pass_date_time)));
			$current_date  = time();
			
			//echo $change_pass_date_time.'--'.($expiry_date) .'--'. ($current_date).'<br>';die;
			//echo strtotime($expiry_date) .'--'. strtotime($current_date);die;
			
			if($expiry_date > $current_date)
			{
				//echo "frj";die;
				$user_id = isset($getdata[0]['id'])?$getdata[0]['id']:"";
				$email_id = isset($getdata[0]['email'])?$getdata[0]['email']:"";
				$data = array('id'=>$user_id,'email'=>$email_id);
				$this->session->set_userdata('forgot_user_data',$data);
				redirect(site_url().'home/changepassword');
			}
			else
			{
				$this->session->set_flashdata('error', 'Forgot password time has been expire.Please try again');
				redirect('home/forgotPassword');
			}
		}
		public function changepassword(){
			$data['captcha'] = $this->createCaptcha( array(
			'min_length' => 5,
			'max_length' => 5,
			'backgrounds' => array(FCPATH.'assets/site/main/images/captcha_bg/white-carbon.png'),
			'fonts' => array(FCPATH.'assets/site/main/fonts/captcha_fonts/times_new_yorker.ttf'),
			'characters' => 'ABCDEFGHJKLMNPRSTUVWXYZabcdefghjkmnprstuvwxyz23456789',
			'min_font_size' => 28,
			'max_font_size' => 28,
			'color' => '#666',
			'angle_min' => 0,
			'angle_max' => 10,
			'shadow' => true,
			'shadow_color' => '#fff',
			'shadow_offset_x' => -1,
			'shadow_offset_y' => 1
			));	
			
			$this->session->set_userdata('captcha_code',$data['captcha']); 
			$data['salt'] = $this->random_string();
			$this->load->view('site/header');
			$this->load->view('site/change_forgot_password',$data);
			$this->load->view('site/footer');
		}
		public function userChangePassSubmitForm(){
			//echo '<pre>';print_r($_SESSION);
			//echo '<pre>';print_r($_POST);die;
			
			try
			{
				$post     = $this->input->post();
				$clean    = $this->security->xss_clean($post);
				//echo '<pre>';print_r($clean);die;
				if($this->isValidCaptch($clean['captchatext']))
				{
					
					
					unset($clean['cpassword']);
					unset($clean['captchatext']);
					$change = $this->user_model->updatePassword($clean);
					
					if($change){
						$this->session->set_flashdata('success', 'Password has been changed successfully, now you can login.');
						$this->session->unset_userdata('forgot_user_data');
						redirect('');
						return false;
					}
					
				}
				else
				{
					$this->session->set_flashdata('error', 'You Entered Wrong Captcha.');
					redirect('home/changepassword');
					return false;
				}
			}
			catch(Exception $e)
			{
				$this->session->set_flashdata('error', 'Some Exception are there? Please try again!');
				redirect('home/changepassword');
				return false;
			}
			
		}
		function refreshCaptcha()
		{
			$data['captcha'] = $this->createCaptcha( array(
			'min_length' => 5,
			'max_length' => 5,
			'backgrounds' => array(FCPATH.'assets/site/main/images/captcha_bg/white-carbon.png'),
			'fonts' => array(FCPATH.'assets/site/main/fonts/captcha_fonts/times_new_yorker.ttf'),
			'characters' => 'ABCDEFGHJKLMNPRSTUVWXYZabcdefghjkmnprstuvwxyz23456789',
			'min_font_size' => 28,
			'max_font_size' => 28,
			'color' => '#666',
			'angle_min' => 0,
			'angle_max' => 10,
			'shadow' => true,
			'shadow_color' => '#fff',
			'shadow_offset_x' => -1,
			'shadow_offset_y' => 1
			));			
			$this->session->set_userdata('captcha_code',$data['captcha']); 
			echo $data['captcha']['image_src']; exit;
		}
		public function getSelectedDistrictBySearch()
		{ 
			$response = array('status'=>FALSE,'data'=>array());	
			try
			{			
				$state_id=$this->input->post('state');
				//echo $id;die;
				$stateData = $this->common_model->getSelectedDistrict($state_id);
				//echo "<pre>";print_r($stateData);die;
				if(sizeof($stateData) > 0)
				{
					$response['status'] = TRUE;
					foreach($stateData as $row)
					{
						$response['data'][] = $row;
					}
				}
			}
			catch(Exception $e)
			{
				echo json_encode($response);
			}
			echo json_encode($response);	
		}
		/***************************download certificate**************************/	
		public function GSTCertificate()
		{
			$user_data = $this->session->userdata('user_data');
			$data['userdetails'] = $user_data;
			$form_one_id = $this->uri->segment(3);
			$form_one_id = $this->encrypt->decode($form_one_id);
			if(isset($form_one_id) && !empty($form_one_id) && is_numeric($form_one_id))
			{
				$data['appList'] = $this->applicant_model->getCertificateApplicationInfo($form_one_id);
				//echo "<pre>";print_r($data['appList']);die;
				if(isset($data['appList'][0]['user_id']) && !empty($data['appList'][0]['user_id']))
				{
					$application_number = isset($data['appList'][0]['application_no'])?$data['appList'][0]['application_no']:'';
					
					$cc = isset($data['appList'][0]['aadhar_number'])?$data['appList'][0]['aadhar_number']:'';
					$ccMaskingAadhar = aadharNumberCCMasking($cc);
					$data['form_one_id'] = $form_one_id;
					$data['appList'][0]['aadhar_number'] = isset($ccMaskingAadhar)?$ccMaskingAadhar:'';
					//$this->load->view('applicant/header');
					$this->load->view('site/view_gst_certificate',$data);
					//$this->load->view('applicant/footer');	
				}
				else
				{
					$data['appList'] =array();
					//$this->load->view('applicant/header');
					$this->load->view('site/view_gst_certificate',$data);
					//$this->load->view('applicant/footer');
				}
			}
			else
			{
				$this->session->set_flashdata('error', 'Some internal error. Please try again');
				redirect('home');
			}
		}
		
		
		public function downloadPdf() {
			error_reporting(0);
			//$mpdf = new mPDF('c', 'A4', '', '', 10, 10, 05, 10, 10, 10);
			
			$user_data = $this->session->userdata('user_data');
			
			$data['userdetails'] = $user_data;
			$form_one_id = isset($_SESSION["formOneID"])?$_SESSION["formOneID"]:'';
			$form_one_id = $this->encrypt->decode($form_one_id);
			//echo $form_one_id." ------------ ".$form_one_id1;die;
			if(isset($form_one_id) && !empty($form_one_id) && is_numeric($form_one_id))
			{
				//echo $form_one_id;
				$data['appList'] = $this->applicant_model->getApplicationInfo($form_one_id);
				//echo "<pre>";print_r($data['appList']);die;
				$application_number = isset($data['appList'][0]['application_no'])?$data['appList'][0]['application_no']:'';
				//$post = $this->input->post();
				$pdfName = $application_number."-".".pdf";
				$mpdf = new mPDF();
				//hindi or other lang
				$mpdf->autoScriptToLang = true;
				$mpdf->baseScript = 1;
				$mpdf->autoVietnamese = true;
				$mpdf->autoArabic = true;
				$mpdf->autoLangToFont = true;
				$html2 = $this->input->post("myHTML");
				$post = $this->input->post();
				//echo "<pre>";print($_SESSION['downloadGSTCertificate']);die;
				$mpdf->SetFontSize(10, TRUE);
				$mpdf->SetDisplayMode('fullpage');
				
				$mpdf->list_indent_first_level = 0; // 1 or 0 - whether to indent the first level of a list
				$mpdf->SetTitle($pdfName);
				$mpdf->WriteHTML($html2, 2);
				if($post['Download'] == 'Download')
				{
					$mpdf->Output($pdfName, 'D');
				}
				else
				{
					$mpdf->Output($pdfName, 'I');
				}
				
			}
			else
			{
				$this->session->set_flashdata('error', 'Some internal error. Please try again');
				redirect('home');
			}
			
		}
		public function resendOTP()
		{
			
			if(isset($_POST['user_id']) && !empty($_POST['user_id']))
			{
				$userId = $this->encrypt->decode($_POST['user_id']);
				if(is_numeric($userId))
				{
					$getUserDetails = $this->user_model->getuserDataById($userId);
					$userEmail = isset($getUserDetails[0]['email'])?$getUserDetails[0]['email']:'';
					$otp_number = mt_rand(1000, 9999);
					$message2='Your OTP is : '.$otp_number;
					$message='';
					$message.='Dear '.$getUserDetails[0]['fname'].',<br><br>Your OTP is : '.$otp_number.'<br><br><p>With Regards</p><br><p>AEI Division, DHI</p><br><br>';
					//echo $message;die;
					$config = $this->config->item('mailconfig');
					$from_email = $this->config->item('from_email_id');	
					
					/* Load email library */
					$this->load->library('email',$config);			   
					$this->email->from($from_email, 'Department of Heavy Industry');
					$to_email = isset($userEmail)?$userEmail:'';
					$this->email->to($to_email);
					$subject = 'DHI account verification of ('.$getUserDetails[0]['fname'].')';
					$this->email->subject($subject); 
					$this->email->message($message);
					if($this->email->send())
					{
						$mobile = isset($getUserDetails[0]['mobile_number'])?$getUserDetails[0]['mobile_number']:0;
						$success = $this->user_model->updateMobileVerificationOTP($userId,$otp_number);
						//$msg_response = $this->send_sms($mobile,$message2);
						if($success)
						$response = array('status'=>true,'msg'=>'OTP has been send your email id.Please check your email id.');
						else
						$response = array('status'=>false,'msg'=>'OTP has not been send your email id.Please try again.');
					}
					else
					{
						$response = array('status'=>false,'msg'=>'OTP has not been send your email id.Please try again.');
					}
					
				}
				else
				{
					$response = array('status'=>false,'msg'=>'Wrong user details.Please try again.');	
				}
			}
			else
			{
				$response = array('status'=>false,'msg'=>'Wrong user details.Please try again.');
			}
			echo json_encode($response);
			die;		
		}
		/***************************end**************************/
		
		
		
		
		
		
		
		function random_string()
		{
			$character_set_array = array();
			$character_set_array[] = array('count' => 4, 'characters' => 'abcdefghijklmnopqrstuvwxyz');
			$character_set_array[] = array('count' => 4, 'characters' => '0123456789');
			$temp_array = array();
			foreach ($character_set_array as $character_set) {
				for ($i = 0; $i < $character_set['count']; $i++) {
					$temp_array[] = $character_set['characters'][rand(0, strlen($character_set['characters']) - 1)];
				}
			}
			shuffle($temp_array);
			return implode('', $temp_array);
		}
		
		function createCaptcha($config = array())
		{
			if( !function_exists('gd_info') ) {
				throw new Exception('Required GD library is missing');
			}
			
			$bg_path = dirname(__FILE__) . 'assets/site/main/images/captcha_bg/backgrounds/';
			$font_path = dirname(__FILE__) . 'assets/site/main/fonts/captcha_fonts/';
			
			// Default values
			$captcha_config = array(
			'code' => '',
			'min_length' => 5,
			'max_length' => 5,
			'backgrounds' => array(
			$bg_path . '45-degree-fabric.png',
			$bg_path . 'cloth-alike.png',
			$bg_path . 'grey-sandbag.png',
			$bg_path . 'kinda-jean.png',
			$bg_path . 'polyester-lite.png',
			$bg_path . 'stitched-wool.png',
			$bg_path . 'white-carbon.png',
			$bg_path . 'white-wave.png'
			),
			'fonts' => array(
			$font_path . 'times_new_yorker.ttf'
			),
			'characters' => 'ABCDEFGHJKLMNPRSTUVWXYZabcdefghjkmnprstuvwxyz23456789',
			'min_font_size' => 28,
			'max_font_size' => 28,
			'color' => '#666',
			'angle_min' => 0,
			'angle_max' => 10,
			'shadow' => true,
			'shadow_color' => '#fff',
			'shadow_offset_x' => -1,
			'shadow_offset_y' => 1
			);
			
			// Overwrite defaults with custom config values
			if( is_array($config) ) {
				foreach( $config as $key => $value ) $captcha_config[$key] = $value;
			}
			
			// Restrict certain values
			if( $captcha_config['min_length'] < 1 ) $captcha_config['min_length'] = 1;
			if( $captcha_config['angle_min'] < 0 ) $captcha_config['angle_min'] = 0;
			if( $captcha_config['angle_max'] > 10 ) $captcha_config['angle_max'] = 10;
			if( $captcha_config['angle_max'] < $captcha_config['angle_min'] ) $captcha_config['angle_max'] = $captcha_config['angle_min'];
			if( $captcha_config['min_font_size'] < 10 ) $captcha_config['min_font_size'] = 10;
			if( $captcha_config['max_font_size'] < $captcha_config['min_font_size'] ) $captcha_config['max_font_size'] = $captcha_config['min_font_size'];
			
			// Generate CAPTCHA code if not set by user
			if( empty($captcha_config['code']) ) {
				$captcha_config['code'] = '';
				$length = mt_rand($captcha_config['min_length'], $captcha_config['max_length']);
				while( strlen($captcha_config['code']) < $length ) {
					$captcha_config['code'] .= substr($captcha_config['characters'], mt_rand() % (strlen($captcha_config['characters'])), 1);
				}
			}
			$image_src = site_url().'home/getCaptcha?_CAPTCHA&amp;t=' . urlencode(microtime());
			
			$cnfg = array('config'=>serialize($captcha_config));
			$this->session->set_userdata('captcha',$cnfg);	
			return array(
			'code' => $captcha_config['code'],
			'image_src' => $image_src
			);
		}
		function getCaptcha()
		{	
			
			$captcha_cnf = array();		
			$cnf = $this->session->userdata('captcha');	
			//echo "<pre>";print_r($cnf);die;
			$captcha_config = unserialize($cnf['config']);			
			
			if( !$captcha_config ) exit();
			
			//$this->session->unset_userdata('captcha');	    
			
			// Pick random background, get info, and start captcha
			$background = $captcha_config['backgrounds'][mt_rand(0, count($captcha_config['backgrounds']) -1)];
			list($bg_width, $bg_height, $bg_type, $bg_attr) = getimagesize($background);
			
			$captcha = imagecreatefrompng($background);
			
			$color = $this->hex2rgb($captcha_config['color']);
			$color = imagecolorallocate($captcha, $color['r'], $color['g'], $color['b']);
			
			// Determine text angle
			$angle = mt_rand( $captcha_config['angle_min'], $captcha_config['angle_max'] ) * (mt_rand(0, 1) == 1 ? -1 : 1);
			
			// Select font randomly
			$font = $captcha_config['fonts'][mt_rand(0, count($captcha_config['fonts']) - 1)];
			
			// Verify font file exists
			if( !file_exists($font) ) throw new Exception('Font file not found: ' . $font);
			
			//Set the font size.
			$font_size = mt_rand($captcha_config['min_font_size'], $captcha_config['max_font_size']);
			$text_box_size = imagettfbbox($font_size, $angle, $font, $captcha_config['code']);
			
			// Determine text position
			$box_width = abs($text_box_size[6] - $text_box_size[2]);
			$box_height = abs($text_box_size[5] - $text_box_size[1]);
			$text_pos_x_min = 0;
			$text_pos_x_max = ($bg_width) - ($box_width);
			$text_pos_x = mt_rand($text_pos_x_min, $text_pos_x_max);
			$text_pos_y_min = $box_height;
			$text_pos_y_max = ($bg_height) - ($box_height / 2);
			if ($text_pos_y_min > $text_pos_y_max) {
				$temp_text_pos_y = $text_pos_y_min;
				$text_pos_y_min = $text_pos_y_max;
				$text_pos_y_max = $temp_text_pos_y;
			}
			$text_pos_y = mt_rand($text_pos_y_min, $text_pos_y_max);
			
			// Draw shadow
			if( $captcha_config['shadow'] ){
				$shadow_color = $this->hex2rgb($captcha_config['shadow_color']);
				$shadow_color = imagecolorallocate($captcha, $shadow_color['r'], $shadow_color['g'], $shadow_color['b']);
				imagettftext($captcha, $font_size, $angle, $text_pos_x + $captcha_config['shadow_offset_x'], $text_pos_y + $captcha_config['shadow_offset_y'], $shadow_color, $font, $captcha_config['code']);
			}
			
			// Draw text
			imagettftext($captcha, $font_size, $angle, $text_pos_x, $text_pos_y, $color, $font, $captcha_config['code']);
			
			// Output image
			header("Content-type: image/png");
			imagepng($captcha);
		}
		function hex2rgb($hex_str, $return_string = false, $separator = ',') {
			$hex_str = preg_replace("/[^0-9A-Fa-f]/", '', $hex_str); // Gets a proper hex string
			$rgb_array = array();
			if( strlen($hex_str) == 6 ) {
				$color_val = hexdec($hex_str);
				$rgb_array['r'] = 0xFF & ($color_val >> 0x10);
				$rgb_array['g'] = 0xFF & ($color_val >> 0x8);
				$rgb_array['b'] = 0xFF & $color_val;
				} elseif( strlen($hex_str) == 3 ) {
				$rgb_array['r'] = hexdec(str_repeat(substr($hex_str, 0, 1), 2));
				$rgb_array['g'] = hexdec(str_repeat(substr($hex_str, 1, 1), 2));
				$rgb_array['b'] = hexdec(str_repeat(substr($hex_str, 2, 1), 2));
				} else {
				return false;
			}
			return $return_string ? implode($separator, $rgb_array) : $rgb_array;
		}
		function base64url_encode($data)
		{
			return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
		}
		function base64url_decode($data)
		{
			return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
		}
		function isValidCaptch($captchText)
		{
			$sessionData = $this->session->userdata('captcha_code');
			$sessionText = $sessionData['code'];
			return ($captchText == $sessionText) ? TRUE : FALSE;
		}
		/*public function importOEMData()
			{
			$targetPath = 'assets/site/main/model_details.xls';
			
			$excel = new Spreadsheet_Excel_Reader($targetPath,FALSE);
			$x=2; 
			echo "<pre>";print_r($excel->sheets);die;
			while($x <= $excel->sheets[0]['numRows'])
			{	 
			if(!empty($excel->sheets[0]['cells'][$x][1]))
			{
			$code = $excel->sheets[0]['cells'][$x][1];
			}
			if(!empty($excel->sheets[0]['cells'][$x][2]))
			{
			$company_name = $excel->sheets[0]['cells'][$x][2];
			}
			$this->db->select('id,code');
			$this->db->from('ref_oem_details');
			$this->db->where('code',$code);
			$getOEMID = $this->db->get()->result_array();
			$data = array(
			'ref_oem_details_id'=>isset($getOEMID[0]['id'])?$getOEMID[0]['id']:0,
			'ref_code'=>$code,
			'company_name'=>$company_name,
			'status'=>1,
			'created_date'=>date('Y-m-d h:i:s a')
			);					
			$q = $this->db->insert_string('ref_oem_details',$data);             
			$this->db->query($q);
			$this->db->insert_id();
			$x++;
			}
			}
			public function importModelData()
			{
			$targetPath = 'assets/site/main/model_details.xls';
			
			$excel = new Spreadsheet_Excel_Reader($targetPath,FALSE);
			$x=2; 
			echo "<pre>";print_r($excel->sheets);die;
			while($x <= $excel->sheets[0]['numRows'])
			{	 
			if(!empty($excel->sheets[0]['cells'][$x][1]))
			{
			$code = $excel->sheets[0]['cells'][$x][1];
			}
			if(!empty($excel->sheets[0]['cells'][$x][2]))
			{
			$company_name = $excel->sheets[0]['cells'][$x][2];
			}
			if(!empty($excel->sheets[0]['cells'][$x][3]))
			{
			$model_name = $excel->sheets[0]['cells'][$x][3];
			}
			if(!empty($excel->sheets[0]['cells'][$x][4]))
			{
			$fuel = $excel->sheets[0]['cells'][$x][4];
			}
			if(!empty($excel->sheets[0]['cells'][$x][5]))
			{
			$cubic_capcity = $excel->sheets[0]['cells'][$x][5];
			}
			$this->db->select('id,code');
			$this->db->from('ref_oem_details');
			$this->db->where('code',$code);
			$getOEMID = $this->db->get()->result_array();
			$data = array(
			'ref_oem_details_id'=>isset($getOEMID[0]['id'])?$getOEMID[0]['id']:0,
			'ref_code'=>$code,
			'company_name'=>$company_name,
			'model_name'=>$model_name,
			'fuel'=>$fuel,
			'cubic_capcity'=>$cubic_capcity,
			'status'=>1,
			'created_date'=>date('Y-m-d h:i:s a')
			);					
			$q = $this->db->insert_string('ref_model_details',$data);             
			$this->db->query($q);
			$this->db->insert_id();
			$x++;
			}
		}*/
	}
