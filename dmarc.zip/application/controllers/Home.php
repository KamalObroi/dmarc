<?php
//error_reporting(E_ALL);
//ini_set('display_errors',1);
defined('BASEPATH') OR exit('No direct script access allowed');
include('application/libraries/phpseclib/Crypt/RSA.php');
class Home extends CI_Controller {
	public function __construct(){
     parent::__construct();
     $this->load->model('Main_model');    
     
    }
    function flush_buffers()
	{ 
		ini_set('output_buffering','on');	   
	    ini_set('implicit_flush',1);
	    ob_implicit_flush();
	    for($i=0;$i<20;$i++) {	       
	        ob_flush();
	        flush();
	    }
	}
	public function domainscanner(){
		$data = array('status'=>FALSE);
    	if(isset($_POST['domainname'])){
    		$domain = $_POST['domainname'];
    		$dMarc = dns_get_record("_dmarc.".$domain,DNS_TXT);    		
    		$data['status'] = TRUE;
    		$data['domain'] = $domain;
    		$data['dmarc'] = $dMarc;
    		
    		$skim = dns_get_record($domain,DNS_TXT);	
    		if(sizeof($skim)>0){
    			foreach($skim as $skm){
    				$txt = $skm['txt'];
    				if (strpos($txt, 'v=spf') !== false) {
					   $data['spf'] = $skm;
					}
    			}
    		}
    		$bimi = dns_get_record("default._bimi.".$domain,DNS_TXT);
    		$data['bimi'] = $bimi;
			$this->load->view('domainscanner',$data);
    	}
    	else{
    		$this->load->view('domainscanner',$data);
    	}
	}
    public function domainreputaiton(){
  		$returnarray = array('status'=>FALSE,'data'=>array());
    	if(isset($_POST['domainname'])){
    		$ip = $_POST['domainname'];
    	
    		$dnsbl_lookup = array("0spam.org","0spam.fusionzero.com","zeustracker.abuse.ch","www.abuse.ro","ecm.netcore.co.in","www.spamhaus.org");
    		$returnarray['status'] = TRUE;
			    $AllCount = count($dnsbl_lookup);
			    $BadCount = 0;
			   	$ifip = filter_var($ip, FILTER_VALIDATE_IP);
			    if($ip)
			    {
			    	if($ifip){
			    		$reverse_ip = implode(".", array_reverse(explode(".", $ip)));
			    	}
			    	else{
			    		$reverse_ip = $ip;
			    	}			        
			       
			        foreach($dnsbl_lookup as $host){
			        	if(array_key_exists($host,$returnarray['data'])){
			        		$returnarray['data'][$host] = array("status"=>FALSE);
			        	}
			            if(checkdnsrr($reverse_ip.".".$host.".", "A")){			               
			                $this->flush_buffers();
			                $returnarray['data'][$host]["status"] = '<span style="color:red;">Listed</span>';
			                $BadCount++;
			            }else{
			                 $this->flush_buffers();
			                 $returnarray['data'][$host]["status"] = 'Not Listed';
			            }
			        }
			    }else{
			         $this->flush_buffers();
			    }
			    $this->flush_buffers();
			    $this->load->view('domainreputaiton',$returnarray);
    	}
    	else{
    		$this->load->view('domainreputaiton',$returnarray);
    	}
    }
    public function alertconfig(){
    	if($this->session->userdata('fullname')) {
    		$uid = $this->session->userdata('uid');
	        $data['domains'] = $this->Main_model->getUserDomains($uid);
	        $data['alerts'] = $this->Main_model->getAlertDomains($uid);
	    	$this->load->view('alertconfig',$data);
    	}
    	else{
    		redirect('login');
    	}
    }
    public function alertevents(){
    	if($this->session->userdata('fullname')) {
    		$uid = $this->session->userdata('uid');
	        $data['domains'] = $this->Main_model->getAlertDomains($uid);
	    	$this->load->view('alertevents',$data);
    	}
    	else{
    		redirect('login');
    	}
    }
    public function createalert(){
    	if($this->session->userdata('fullname')) { 
    		$data = array();
    		$uid = $this->session->userdata('uid');
    		$useremail = $this->session->userdata('email'); 
    		$data_return['domains'] = $this->Main_model->getUserDomains($uid);  
    		if(isset($_POST['domainame'])){
				$domain = $_POST['domainame'];	
				$data['domainname'] = $domain;
				$data['severity'] =  $_POST['severity'];
				$data['category'] =  $_POST['category'];
				if($_POST['category'] == "emails"){
					$data['condition_no'] =  $_POST['mailcount'];
					$data['condition_day'] =  $_POST['period'];
					$data['condition_text'] =  $_POST['mailtype'];
				}
				else if($_POST['category'] == "spf_record"){
					$data['condition_text'] =  "SPF record changed";
				}
				else if($_POST['category'] == "mx_record"){
					$data['condition_text'] =  "MX record changed";
				}
				
				$data['uid'] = $this->session->userdata('uid');
				$data['created_at'] = date('Y-m-d H:i:s');
				$return = $this->Main_model->insertUserAlert($data);
				if($return){
				
					$this->load->library('email');				
					$this->email->set_mailtype("html");
					$this->email->set_newline("\r\n");

					$this->email->from('dmarcforce@gmail.com', 'DmarcForce');
			        $this->email->to($useremail); 

			        $this->email->subject('DmarcForce Alert Created');			        
			       
					$message = $this->load->view('mailTemplates/alertthanks',  TRUE);  
			        
			        $this->email->message($message);  

			        $this->email->send();
				
					$this->session->set_flashdata('message', 'Saved Successfully!');
    				redirect(site_url().'createalert',$data_return);
				}					
			}
			else{
				
				$data['status'] = FALSE;
				$this->load->view('create_alert',$data_return);	
			}	    	
    	}
    	else{
    		redirect('login');
    	}
    }
    public function adddomain(){
    	if($this->session->userdata('fullname')) {
    		if(isset($_POST['domainname'])){
				$domain = $_POST['domainname'];				
				$data = array();				
				$uid = $this->session->userdata('uid');
				$data['domain'] = $domain;
				$data['uid'] = $this->session->userdata('uid');
				$data['created_at'] = date('Y-m-d H:i:s');
				$isDomainExists = $this->Main_model->isUserDomainExists($domain,$uid);
				if($isDomainExists){
					$this->session->set_flashdata('error', 'Already Exists!');
	    			redirect(site_url().'adddomain');
				}
				else{
					$return = $this->Main_model->insertDomain($data);
					if($return){
						$this->session->set_flashdata('message', 'Saved Successfully!');
	    				redirect(site_url().'adddomain');
					}
				}
					
			}
			else{
				$data = array();
				$data['status'] = FALSE;
				$this->load->view('adddomain',$data);	
			}
		}
		else{
			redirect('login');
		}	        	
    }
    public function domains(){
    	if($this->session->userdata('fullname')) {
    		$uid = $this->session->userdata('uid');
	        $data['domains'] = $this->Main_model->getUserDomains($uid);
	    	$this->load->view('domains',$data);
    	}
    	else{
    		redirect('login');
    	}
    }
    public function bimilookup(){    	
    	if(isset($_POST['domainname']) && isset($_POST['selector'])){
    		$domain = $_POST['domainname'];
    		$selector = $_POST['selector'];
    		$bimi = dns_get_record($selector."._bimi.".$domain,DNS_TXT);
    		$data = array();
    		$data['status'] = TRUE;
    		$data['domain'] = $domain;
    		$data['dmarc'] = $bimi;
    		$data['selector'] = $selector;    	   
    		$this->load->view('bimi_lookup',$data);	
    	}
    	else{
    		$data = array();
    		$data['status'] = FALSE;
    		$this->load->view('bimi_lookup',$data);	
    	}
    	
    }
    public function dkimlookup(){    	
    	if(isset($_POST['domainname']) && isset($_POST['selector'])){
    		$domain = $_POST['domainname'];
    		$selector = $_POST['selector'];
    		$dkim = dns_get_record($selector."._domainkey.".$domain,DNS_TXT);
    		$data = array();
    		$data['status'] = TRUE;
    		$data['domain'] = $domain;
    		$data['dmarc'] = $dkim;
    	
    		$this->load->view('dkim_lookup',$data);	
    	}
    	else{
    		$data = array();
    		$data['status'] = FALSE;
    		$this->load->view('dkim_lookup',$data);	
    	}
    	
    }
    public function dmarclookup(){    	
    	if(isset($_POST['domainname'])){
    		$domain = $_POST['domainname'];
    		$dMarc = dns_get_record("_dmarc.".$domain,DNS_TXT);
    		$data = array();
    		$data['status'] = TRUE;
    		$data['domain'] = $domain;
    		$data['dmarc'] =$dMarc;
    		$this->load->view('dmarc_lookup',$data);	
    	}
    	else{
    		$data = array();
    		$data['status'] = FALSE;
    		$this->load->view('dmarc_lookup',$data);	
    	}
    	
    }
    public function dmarcrecordgenerator(){
    	$this->load->view('dmarcrecordgenerator');
    }
    public function bimirecordgenerator(){
    	$this->load->view('bimirecordgenerator');
    }
    public function dkimgenerate(){
	    if(isset($_POST['domainname'])){
			$rsa = new Crypt_RSA();
			$rsa->setPublicKeyFormat(CRYPT_RSA_PUBLIC_FORMAT_OPENSSH);
			$result['keys'] = $rsa->createKey();
	    	$this->load->view('dkimgenerate',$result);	
    	}
    	else{    			
    		$result = array('keys'=>array());
		    $this->load->view('dkimgenerate',$result);
    	}
	  
    }
    public function spfrecordgenerator(){
    	$this->load->view('spfrecordgenerator');
    }
    public function spfrawchecker(){
    	if(isset($_POST['domainname'])){
    		$domain = $_POST['domainname'];    		
    		$rawvalue = $_POST['rawvalue'];
    		$rawvaluearray = explode(" ",$rawvalue);
    		$spf = array(); 
    	
    		if(sizeof($rawvaluearray)>0){
    			foreach($rawvaluearray as $rawval){    			
    				if($rawval != "-all" && $rawval!="v=spf1"){    					
    					$spf_record =NULL;
    					if(trim(strtolower($rawval)) == "a"){    					
    						$spf_record = dns_get_record($domain,DNS_A); 
    						if($spf_record != NULL){
    							if(sizeof($spf_record)>0){
    								foreach($spf_record as $record){
    									$spf[] = "<span class='lblgray'>A</span> ".$record['ip'];
    								}
    							}	    						
	    					}
	    					else{
	    						$spf[] = "'".$domain."' domain doesn't have 'a' record" ;
	    					}
    					}
    					if(trim(strtolower($rawval)) == "mx"){
    						$spf_record = dns_get_record($domain,DNS_MX);
    						if($spf_record != NULL){
    							if(sizeof($spf_record)>0){
    								foreach($spf_record as $record){
    									$spf[] = "<span class='lblgray'>MX</span> ".$record['target'];
    								}
    							}	    						
	    					}
	    					$spf[] = "'".$domain."' domain doesn't have 'mx' record" ;
    					}
    					if(trim(strtolower($rawval)) == "cname"){
    						$spf_record = dns_get_record($domain,DNS_CNAME);
    						if($spf_record != NULL){
    							if(sizeof($spf_record)>0){
    								foreach($spf_record as $record){
    									$spf[] = "<span class='lblgray'>NS</span> ".$record['target'];
    								}
    							}	    						
	    					}
	    					$spf[] = "'".$domain."' domain doesn't have 'cname' record" ;
    					}
    					if(trim(strtolower($rawval)) == "ns"){
    						$spf_record = dns_get_record($domain,DNS_NS);
    						if($spf_record != NULL){
    							if(sizeof($spf_record)>0){
    								foreach($spf_record as $record){
    									$spf[] = "<span class='lblgray'>NS</span> ".$record['target'];
    								}
    							}	    						
	    					}
	    					$spf[] = "'".$domain."' domain doesn't have 'ns' record" ;
    					}    
    					
    				}
    			}
    		}
    		$data = array();
    		$data['status'] = TRUE;
    		$data['domain'] = $domain;
    		$data['spf'] =$spf;
    		$this->load->view('spfrawchecker',$data);	
    	}
    	else{
    		$data = array();
    		$data['status'] = FALSE;
    		$this->load->view('spfrawchecker',$data);	
    	}
    }
    public function spflookup(){
    	if(isset($_POST['domainname'])){
    		$domain = $_POST['domainname'];    		
    		$spf = array();
    		$skim = dns_get_record($domain,DNS_TXT);	
    		if(sizeof($skim)>0){
    			foreach($skim as $skm){
    				$txt = $skm['txt'];
    				if (strpos($txt, 'v=spf') !== false) {
					   $spf[] = $skm;
					}
    			}
    		}
    		
    		for($i=1;$i<=10;$i++){
    			$spf_record = dns_get_record('_spf'.$i.'.'.$domain,DNS_TXT);
    			if(sizeof($spf_record)>0){
    				$spf[] = $spf_record[0];
    			}    			
    		}  
    		$data = array();
    		$data['status'] = TRUE;
    		$data['domain'] = $domain;
    		$data['spf'] =$spf;
    		$this->load->view('spf_lookup',$data);	
    	}
    	else{
    		$data = array();
    		$data['status'] = FALSE;
    		$this->load->view('spf_lookup',$data);	
    	}
    }
    public function verify(){
    	$this->load->view('mailTemplates/verify');
    }
	public function index(){
		$this->load->view('home');
	}
    public function login(){
    	$this->load->view('login');
    }
    public function loginsubmit(){    	
    	try{
    		$isExists = $this->Main_model->isUserExists($_POST['username'],$_POST['password']);
    		if(is_array($isExists)){    			
    			$this->session->set_userdata('fullname',$isExists['fullname']);
    			$this->session->set_userdata('email',$isExists['email']);
    			$this->session->set_userdata('uid',$isExists['id']);
    			redirect(site_url().'dashboard');
    		}
    		else{
    			$this->session->set_flashdata('error', 'Invalid EmailId or Password');
    			redirect(site_url().'login');
    		}
    	}
    	catch(Exception $e){
    		$this->session->set_flashdata('error', $e->getMessage());
    	}
    }
    public function signup(){
    	$this->load->view('signup');
    }
    public function register(){    	
    	try{
    		$userArray = array();	
	    	$userArray['fullname'] = $_POST['fullname'];
	    	$userArray['email'] = $_POST['email'];
	    	$userArray['password'] = sha1($_POST['password']);
	    	$userArray['phone'] = $_POST['phone'];
	    	$userArray['status'] = 1;
	    	$userArray['created_at'] = time();
	    	
	    	$isExists = $this->Main_model->isEmailExists($_POST['email']);
	    	
			if($isExists){    			
				$this->session->set_flashdata('error', 'Email Id Already Exists.');
				redirect(site_url().'signup');
			}
			else{
				$data = $this->Main_model->insertUser($userArray);
				$this->load->library('email');				
				$this->email->set_mailtype("html");
				$this->email->set_newline("\r\n");

				$this->email->from('dmarcforce@gmail.com', 'DmarcForce');
		        $this->email->to($userArray['email']); 

		        $this->email->subject('DmarcForce Account Created');
		        
		        $d['token'] = base64_encode($userArray['email']);
				$message = $this->load->view('mailTemplates/register', $d, TRUE);  
		        
		        $this->email->message($message);  

		        $this->email->send();

		        //echo $this->email->print_debugger();

		    	$this->session->set_flashdata('message', 'Saved Successfully');
		    	redirect("signup");
			}	    	
    	}
    	catch(Exception $e){
    		$this->session->set_flashdata('error', 'Server');
			redirect(site_url().'signup');
    	}
    }
    function logout(){
    	$this->session->unset_userdata('fullname');
    	$this->session->sess_destroy();
    	redirect(site_url());
    }	
    function checkdns(){
    	$returnArray = array('dmarc'=>'','skim'=>'','dkim'=>'');
    	$domain = $_POST['domainname'];
		$dMarc = dns_get_record("_dmarc.".$domain,DNS_TXT);
		
		$skim = dns_get_record($domain,DNS_TXT);		
		
		$dkim = dns_get_record("selector._domainkey.".$domain,DNS_TXT);
		
		if(sizeof($dMarc)>0){
			$returnArray['dmarc'] = $dMarc[0]['txt'];
		}
		if(sizeof($skim)>0){
			$returnArray['skim'] = $skim[0]['txt'];
		}
		if(sizeof($dkim)>0){
			$returnArray['dkim'] = $dkim[0]['txt'];
		}
		echo json_encode($returnArray);
    }
    function dashboard(){
    	$this->load->view('dashboard');
    }
}
