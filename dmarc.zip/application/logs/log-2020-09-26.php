<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-26 19:37:00 --> Config Class Initialized
INFO - 2020-09-26 19:37:00 --> Hooks Class Initialized
DEBUG - 2020-09-26 19:37:00 --> UTF-8 Support Enabled
INFO - 2020-09-26 19:37:00 --> Utf8 Class Initialized
INFO - 2020-09-26 19:37:00 --> URI Class Initialized
INFO - 2020-09-26 19:37:00 --> Router Class Initialized
INFO - 2020-09-26 19:37:00 --> Output Class Initialized
INFO - 2020-09-26 19:37:00 --> Security Class Initialized
DEBUG - 2020-09-26 19:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 19:37:00 --> Input Class Initialized
INFO - 2020-09-26 19:37:00 --> Language Class Initialized
INFO - 2020-09-26 19:37:00 --> Loader Class Initialized
INFO - 2020-09-26 19:37:01 --> Helper loaded: url_helper
INFO - 2020-09-26 19:37:01 --> Helper loaded: file_helper
INFO - 2020-09-26 19:37:01 --> Database Driver Class Initialized
INFO - 2020-09-26 19:37:01 --> Email Class Initialized
DEBUG - 2020-09-26 19:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 19:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 19:37:01 --> Controller Class Initialized
INFO - 2020-09-26 19:37:01 --> Model "Main_model" initialized
INFO - 2020-09-26 19:37:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 19:37:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-26 19:37:01 --> Final output sent to browser
DEBUG - 2020-09-26 19:37:01 --> Total execution time: 1.5801
INFO - 2020-09-26 20:24:34 --> Config Class Initialized
INFO - 2020-09-26 20:24:34 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:24:34 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:24:34 --> Utf8 Class Initialized
INFO - 2020-09-26 20:24:34 --> URI Class Initialized
INFO - 2020-09-26 20:24:34 --> Router Class Initialized
INFO - 2020-09-26 20:24:34 --> Output Class Initialized
INFO - 2020-09-26 20:24:34 --> Security Class Initialized
DEBUG - 2020-09-26 20:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:24:34 --> Input Class Initialized
INFO - 2020-09-26 20:24:34 --> Language Class Initialized
INFO - 2020-09-26 20:24:35 --> Loader Class Initialized
INFO - 2020-09-26 20:24:35 --> Helper loaded: url_helper
INFO - 2020-09-26 20:24:35 --> Helper loaded: file_helper
INFO - 2020-09-26 20:24:35 --> Database Driver Class Initialized
INFO - 2020-09-26 20:24:35 --> Email Class Initialized
DEBUG - 2020-09-26 20:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:24:35 --> Controller Class Initialized
INFO - 2020-09-26 20:24:35 --> Model "Main_model" initialized
INFO - 2020-09-26 20:24:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:24:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-26 20:24:35 --> Final output sent to browser
DEBUG - 2020-09-26 20:24:35 --> Total execution time: 0.6716
INFO - 2020-09-26 20:25:11 --> Config Class Initialized
INFO - 2020-09-26 20:25:11 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:25:11 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:25:11 --> Utf8 Class Initialized
INFO - 2020-09-26 20:25:11 --> URI Class Initialized
INFO - 2020-09-26 20:25:11 --> Router Class Initialized
INFO - 2020-09-26 20:25:11 --> Output Class Initialized
INFO - 2020-09-26 20:25:11 --> Security Class Initialized
DEBUG - 2020-09-26 20:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:25:12 --> Input Class Initialized
INFO - 2020-09-26 20:25:12 --> Language Class Initialized
ERROR - 2020-09-26 20:25:12 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 20:26:38 --> Config Class Initialized
INFO - 2020-09-26 20:26:38 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:26:38 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:26:38 --> Utf8 Class Initialized
INFO - 2020-09-26 20:26:38 --> URI Class Initialized
INFO - 2020-09-26 20:26:38 --> Router Class Initialized
INFO - 2020-09-26 20:26:38 --> Output Class Initialized
INFO - 2020-09-26 20:26:38 --> Security Class Initialized
DEBUG - 2020-09-26 20:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:26:38 --> Input Class Initialized
INFO - 2020-09-26 20:26:38 --> Language Class Initialized
ERROR - 2020-09-26 20:26:38 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 20:28:39 --> Config Class Initialized
INFO - 2020-09-26 20:28:39 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:28:39 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:28:39 --> Utf8 Class Initialized
INFO - 2020-09-26 20:28:39 --> URI Class Initialized
INFO - 2020-09-26 20:28:39 --> Router Class Initialized
INFO - 2020-09-26 20:28:39 --> Output Class Initialized
INFO - 2020-09-26 20:28:39 --> Security Class Initialized
DEBUG - 2020-09-26 20:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:28:39 --> Input Class Initialized
INFO - 2020-09-26 20:28:39 --> Language Class Initialized
INFO - 2020-09-26 20:28:39 --> Loader Class Initialized
INFO - 2020-09-26 20:28:39 --> Helper loaded: url_helper
INFO - 2020-09-26 20:28:39 --> Helper loaded: file_helper
INFO - 2020-09-26 20:28:39 --> Database Driver Class Initialized
INFO - 2020-09-26 20:28:39 --> Email Class Initialized
DEBUG - 2020-09-26 20:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:28:39 --> Controller Class Initialized
INFO - 2020-09-26 20:28:39 --> Model "Main_model" initialized
INFO - 2020-09-26 20:28:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:28:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-26 20:28:39 --> Final output sent to browser
DEBUG - 2020-09-26 20:28:39 --> Total execution time: 0.3322
INFO - 2020-09-26 20:28:41 --> Config Class Initialized
INFO - 2020-09-26 20:28:41 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:28:41 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:28:41 --> Utf8 Class Initialized
INFO - 2020-09-26 20:28:41 --> URI Class Initialized
INFO - 2020-09-26 20:28:41 --> Router Class Initialized
INFO - 2020-09-26 20:28:41 --> Output Class Initialized
INFO - 2020-09-26 20:28:41 --> Security Class Initialized
DEBUG - 2020-09-26 20:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:28:41 --> Input Class Initialized
INFO - 2020-09-26 20:28:41 --> Language Class Initialized
ERROR - 2020-09-26 20:28:41 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 20:29:03 --> Config Class Initialized
INFO - 2020-09-26 20:29:03 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:29:03 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:29:03 --> Utf8 Class Initialized
INFO - 2020-09-26 20:29:03 --> URI Class Initialized
INFO - 2020-09-26 20:29:03 --> Router Class Initialized
INFO - 2020-09-26 20:29:03 --> Output Class Initialized
INFO - 2020-09-26 20:29:03 --> Security Class Initialized
DEBUG - 2020-09-26 20:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:29:03 --> Input Class Initialized
INFO - 2020-09-26 20:29:03 --> Language Class Initialized
ERROR - 2020-09-26 20:29:03 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 20:29:44 --> Config Class Initialized
INFO - 2020-09-26 20:29:44 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:29:44 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:29:44 --> Utf8 Class Initialized
INFO - 2020-09-26 20:29:44 --> URI Class Initialized
INFO - 2020-09-26 20:29:44 --> Router Class Initialized
INFO - 2020-09-26 20:29:44 --> Output Class Initialized
INFO - 2020-09-26 20:29:44 --> Security Class Initialized
DEBUG - 2020-09-26 20:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:29:44 --> Input Class Initialized
INFO - 2020-09-26 20:29:44 --> Language Class Initialized
INFO - 2020-09-26 20:29:44 --> Loader Class Initialized
INFO - 2020-09-26 20:29:44 --> Helper loaded: url_helper
INFO - 2020-09-26 20:29:44 --> Helper loaded: file_helper
INFO - 2020-09-26 20:29:44 --> Database Driver Class Initialized
INFO - 2020-09-26 20:29:44 --> Email Class Initialized
DEBUG - 2020-09-26 20:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:29:44 --> Controller Class Initialized
INFO - 2020-09-26 20:29:44 --> Model "Main_model" initialized
INFO - 2020-09-26 20:29:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:29:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-26 20:29:44 --> Final output sent to browser
DEBUG - 2020-09-26 20:29:44 --> Total execution time: 0.3560
INFO - 2020-09-26 20:29:45 --> Config Class Initialized
INFO - 2020-09-26 20:29:45 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:29:45 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:29:45 --> Utf8 Class Initialized
INFO - 2020-09-26 20:29:45 --> URI Class Initialized
INFO - 2020-09-26 20:29:45 --> Router Class Initialized
INFO - 2020-09-26 20:29:45 --> Output Class Initialized
INFO - 2020-09-26 20:29:45 --> Security Class Initialized
DEBUG - 2020-09-26 20:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:29:45 --> Input Class Initialized
INFO - 2020-09-26 20:29:45 --> Language Class Initialized
ERROR - 2020-09-26 20:29:45 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 20:29:57 --> Config Class Initialized
INFO - 2020-09-26 20:29:57 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:29:57 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:29:57 --> Utf8 Class Initialized
INFO - 2020-09-26 20:29:57 --> URI Class Initialized
INFO - 2020-09-26 20:29:57 --> Router Class Initialized
INFO - 2020-09-26 20:29:57 --> Output Class Initialized
INFO - 2020-09-26 20:29:57 --> Security Class Initialized
DEBUG - 2020-09-26 20:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:29:57 --> Input Class Initialized
INFO - 2020-09-26 20:29:57 --> Language Class Initialized
ERROR - 2020-09-26 20:29:57 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 20:30:54 --> Config Class Initialized
INFO - 2020-09-26 20:30:54 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:30:54 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:30:54 --> Utf8 Class Initialized
INFO - 2020-09-26 20:30:54 --> URI Class Initialized
INFO - 2020-09-26 20:30:54 --> Router Class Initialized
INFO - 2020-09-26 20:30:54 --> Output Class Initialized
INFO - 2020-09-26 20:30:54 --> Security Class Initialized
DEBUG - 2020-09-26 20:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:30:54 --> Input Class Initialized
INFO - 2020-09-26 20:30:54 --> Language Class Initialized
INFO - 2020-09-26 20:30:54 --> Loader Class Initialized
INFO - 2020-09-26 20:30:54 --> Helper loaded: url_helper
INFO - 2020-09-26 20:30:54 --> Helper loaded: file_helper
INFO - 2020-09-26 20:30:54 --> Database Driver Class Initialized
INFO - 2020-09-26 20:30:54 --> Email Class Initialized
DEBUG - 2020-09-26 20:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:30:54 --> Controller Class Initialized
INFO - 2020-09-26 20:30:54 --> Model "Main_model" initialized
INFO - 2020-09-26 20:30:54 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:30:54 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-26 20:30:54 --> Final output sent to browser
DEBUG - 2020-09-26 20:30:54 --> Total execution time: 0.3855
INFO - 2020-09-26 20:30:55 --> Config Class Initialized
INFO - 2020-09-26 20:30:55 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:30:55 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:30:55 --> Utf8 Class Initialized
INFO - 2020-09-26 20:30:55 --> URI Class Initialized
INFO - 2020-09-26 20:30:55 --> Router Class Initialized
INFO - 2020-09-26 20:30:55 --> Output Class Initialized
INFO - 2020-09-26 20:30:55 --> Security Class Initialized
DEBUG - 2020-09-26 20:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:30:55 --> Input Class Initialized
INFO - 2020-09-26 20:30:55 --> Language Class Initialized
ERROR - 2020-09-26 20:30:55 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 20:31:43 --> Config Class Initialized
INFO - 2020-09-26 20:31:43 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:31:43 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:31:43 --> Utf8 Class Initialized
INFO - 2020-09-26 20:31:43 --> URI Class Initialized
INFO - 2020-09-26 20:31:43 --> Router Class Initialized
INFO - 2020-09-26 20:31:43 --> Output Class Initialized
INFO - 2020-09-26 20:31:43 --> Security Class Initialized
DEBUG - 2020-09-26 20:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:31:43 --> Input Class Initialized
INFO - 2020-09-26 20:31:43 --> Language Class Initialized
INFO - 2020-09-26 20:31:43 --> Loader Class Initialized
INFO - 2020-09-26 20:31:43 --> Helper loaded: url_helper
INFO - 2020-09-26 20:31:43 --> Helper loaded: file_helper
INFO - 2020-09-26 20:31:43 --> Database Driver Class Initialized
INFO - 2020-09-26 20:31:43 --> Email Class Initialized
DEBUG - 2020-09-26 20:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:31:43 --> Controller Class Initialized
INFO - 2020-09-26 20:31:43 --> Model "Main_model" initialized
INFO - 2020-09-26 20:31:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:31:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-26 20:31:43 --> Final output sent to browser
DEBUG - 2020-09-26 20:31:43 --> Total execution time: 0.3457
INFO - 2020-09-26 20:31:44 --> Config Class Initialized
INFO - 2020-09-26 20:31:44 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:31:44 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:31:44 --> Utf8 Class Initialized
INFO - 2020-09-26 20:31:44 --> URI Class Initialized
INFO - 2020-09-26 20:31:44 --> Router Class Initialized
INFO - 2020-09-26 20:31:44 --> Output Class Initialized
INFO - 2020-09-26 20:31:44 --> Security Class Initialized
DEBUG - 2020-09-26 20:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:31:44 --> Input Class Initialized
INFO - 2020-09-26 20:31:44 --> Language Class Initialized
ERROR - 2020-09-26 20:31:44 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 20:32:16 --> Config Class Initialized
INFO - 2020-09-26 20:32:16 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:32:16 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:32:16 --> Utf8 Class Initialized
INFO - 2020-09-26 20:32:16 --> URI Class Initialized
INFO - 2020-09-26 20:32:16 --> Router Class Initialized
INFO - 2020-09-26 20:32:16 --> Output Class Initialized
INFO - 2020-09-26 20:32:16 --> Security Class Initialized
DEBUG - 2020-09-26 20:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:32:16 --> Input Class Initialized
INFO - 2020-09-26 20:32:16 --> Language Class Initialized
INFO - 2020-09-26 20:32:16 --> Loader Class Initialized
INFO - 2020-09-26 20:32:16 --> Helper loaded: url_helper
INFO - 2020-09-26 20:32:16 --> Helper loaded: file_helper
INFO - 2020-09-26 20:32:16 --> Database Driver Class Initialized
INFO - 2020-09-26 20:32:16 --> Email Class Initialized
DEBUG - 2020-09-26 20:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:32:16 --> Controller Class Initialized
INFO - 2020-09-26 20:32:16 --> Model "Main_model" initialized
INFO - 2020-09-26 20:32:16 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:32:16 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-26 20:32:16 --> Final output sent to browser
DEBUG - 2020-09-26 20:32:16 --> Total execution time: 0.3332
INFO - 2020-09-26 20:32:25 --> Config Class Initialized
INFO - 2020-09-26 20:32:25 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:32:25 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:32:25 --> Utf8 Class Initialized
INFO - 2020-09-26 20:32:25 --> URI Class Initialized
INFO - 2020-09-26 20:32:25 --> Router Class Initialized
INFO - 2020-09-26 20:32:25 --> Output Class Initialized
INFO - 2020-09-26 20:32:25 --> Security Class Initialized
DEBUG - 2020-09-26 20:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:32:25 --> Input Class Initialized
INFO - 2020-09-26 20:32:25 --> Language Class Initialized
INFO - 2020-09-26 20:32:25 --> Loader Class Initialized
INFO - 2020-09-26 20:32:25 --> Helper loaded: url_helper
INFO - 2020-09-26 20:32:25 --> Helper loaded: file_helper
INFO - 2020-09-26 20:32:25 --> Database Driver Class Initialized
INFO - 2020-09-26 20:32:25 --> Email Class Initialized
DEBUG - 2020-09-26 20:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:32:25 --> Controller Class Initialized
INFO - 2020-09-26 20:32:25 --> Model "Main_model" initialized
INFO - 2020-09-26 20:32:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:32:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-26 20:32:25 --> Final output sent to browser
DEBUG - 2020-09-26 20:32:25 --> Total execution time: 0.3271
INFO - 2020-09-26 20:32:56 --> Config Class Initialized
INFO - 2020-09-26 20:32:56 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:32:56 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:32:56 --> Utf8 Class Initialized
INFO - 2020-09-26 20:32:56 --> URI Class Initialized
INFO - 2020-09-26 20:32:56 --> Router Class Initialized
INFO - 2020-09-26 20:32:56 --> Output Class Initialized
INFO - 2020-09-26 20:32:56 --> Security Class Initialized
DEBUG - 2020-09-26 20:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:32:56 --> Input Class Initialized
INFO - 2020-09-26 20:32:56 --> Language Class Initialized
INFO - 2020-09-26 20:32:56 --> Loader Class Initialized
INFO - 2020-09-26 20:32:56 --> Helper loaded: url_helper
INFO - 2020-09-26 20:32:56 --> Helper loaded: file_helper
INFO - 2020-09-26 20:32:56 --> Database Driver Class Initialized
INFO - 2020-09-26 20:32:56 --> Email Class Initialized
DEBUG - 2020-09-26 20:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:32:56 --> Controller Class Initialized
INFO - 2020-09-26 20:32:56 --> Model "Main_model" initialized
INFO - 2020-09-26 20:32:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:32:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-26 20:32:56 --> Final output sent to browser
DEBUG - 2020-09-26 20:32:56 --> Total execution time: 0.3073
INFO - 2020-09-26 20:33:24 --> Config Class Initialized
INFO - 2020-09-26 20:33:24 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:33:24 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:33:24 --> Utf8 Class Initialized
INFO - 2020-09-26 20:33:24 --> URI Class Initialized
INFO - 2020-09-26 20:33:24 --> Router Class Initialized
INFO - 2020-09-26 20:33:24 --> Output Class Initialized
INFO - 2020-09-26 20:33:24 --> Security Class Initialized
DEBUG - 2020-09-26 20:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:33:24 --> Input Class Initialized
INFO - 2020-09-26 20:33:24 --> Language Class Initialized
ERROR - 2020-09-26 20:33:24 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 20:34:14 --> Config Class Initialized
INFO - 2020-09-26 20:34:14 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:34:14 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:34:14 --> Utf8 Class Initialized
INFO - 2020-09-26 20:34:14 --> URI Class Initialized
INFO - 2020-09-26 20:34:14 --> Router Class Initialized
INFO - 2020-09-26 20:34:14 --> Output Class Initialized
INFO - 2020-09-26 20:34:14 --> Security Class Initialized
DEBUG - 2020-09-26 20:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:34:14 --> Input Class Initialized
INFO - 2020-09-26 20:34:14 --> Language Class Initialized
INFO - 2020-09-26 20:34:14 --> Loader Class Initialized
INFO - 2020-09-26 20:34:14 --> Helper loaded: url_helper
INFO - 2020-09-26 20:34:14 --> Helper loaded: file_helper
INFO - 2020-09-26 20:34:14 --> Database Driver Class Initialized
INFO - 2020-09-26 20:34:14 --> Email Class Initialized
DEBUG - 2020-09-26 20:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:34:14 --> Controller Class Initialized
INFO - 2020-09-26 20:34:14 --> Model "Main_model" initialized
INFO - 2020-09-26 20:34:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:34:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-26 20:34:14 --> Final output sent to browser
DEBUG - 2020-09-26 20:34:14 --> Total execution time: 0.3523
INFO - 2020-09-26 20:34:16 --> Config Class Initialized
INFO - 2020-09-26 20:34:16 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:34:16 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:34:16 --> Utf8 Class Initialized
INFO - 2020-09-26 20:34:16 --> URI Class Initialized
INFO - 2020-09-26 20:34:16 --> Router Class Initialized
INFO - 2020-09-26 20:34:16 --> Output Class Initialized
INFO - 2020-09-26 20:34:16 --> Security Class Initialized
DEBUG - 2020-09-26 20:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:34:16 --> Input Class Initialized
INFO - 2020-09-26 20:34:16 --> Language Class Initialized
ERROR - 2020-09-26 20:34:16 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 20:56:18 --> Config Class Initialized
INFO - 2020-09-26 20:56:18 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:56:18 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:56:18 --> Utf8 Class Initialized
INFO - 2020-09-26 20:56:18 --> URI Class Initialized
INFO - 2020-09-26 20:56:18 --> Router Class Initialized
INFO - 2020-09-26 20:56:18 --> Output Class Initialized
INFO - 2020-09-26 20:56:18 --> Security Class Initialized
DEBUG - 2020-09-26 20:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:56:18 --> Input Class Initialized
INFO - 2020-09-26 20:56:18 --> Language Class Initialized
INFO - 2020-09-26 20:56:18 --> Loader Class Initialized
INFO - 2020-09-26 20:56:18 --> Helper loaded: url_helper
INFO - 2020-09-26 20:56:18 --> Helper loaded: file_helper
INFO - 2020-09-26 20:56:19 --> Database Driver Class Initialized
INFO - 2020-09-26 20:56:19 --> Email Class Initialized
DEBUG - 2020-09-26 20:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:56:19 --> Controller Class Initialized
INFO - 2020-09-26 20:56:19 --> Model "Main_model" initialized
INFO - 2020-09-26 20:56:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:56:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-26 20:56:19 --> Final output sent to browser
DEBUG - 2020-09-26 20:56:19 --> Total execution time: 0.3215
INFO - 2020-09-26 20:56:22 --> Config Class Initialized
INFO - 2020-09-26 20:56:22 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:56:22 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:56:22 --> Utf8 Class Initialized
INFO - 2020-09-26 20:56:22 --> URI Class Initialized
INFO - 2020-09-26 20:56:22 --> Router Class Initialized
INFO - 2020-09-26 20:56:22 --> Output Class Initialized
INFO - 2020-09-26 20:56:22 --> Security Class Initialized
DEBUG - 2020-09-26 20:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:56:22 --> Input Class Initialized
INFO - 2020-09-26 20:56:22 --> Language Class Initialized
INFO - 2020-09-26 20:56:22 --> Loader Class Initialized
INFO - 2020-09-26 20:56:22 --> Helper loaded: url_helper
INFO - 2020-09-26 20:56:22 --> Helper loaded: file_helper
INFO - 2020-09-26 20:56:22 --> Database Driver Class Initialized
INFO - 2020-09-26 20:56:22 --> Email Class Initialized
DEBUG - 2020-09-26 20:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:56:22 --> Controller Class Initialized
INFO - 2020-09-26 20:56:22 --> Model "Main_model" initialized
INFO - 2020-09-26 20:56:22 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:56:22 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 20:56:22 --> Final output sent to browser
DEBUG - 2020-09-26 20:56:22 --> Total execution time: 0.2942
INFO - 2020-09-26 20:57:09 --> Config Class Initialized
INFO - 2020-09-26 20:57:09 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:57:09 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:57:09 --> Utf8 Class Initialized
INFO - 2020-09-26 20:57:09 --> URI Class Initialized
INFO - 2020-09-26 20:57:09 --> Router Class Initialized
INFO - 2020-09-26 20:57:09 --> Output Class Initialized
INFO - 2020-09-26 20:57:09 --> Security Class Initialized
DEBUG - 2020-09-26 20:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:57:09 --> Input Class Initialized
INFO - 2020-09-26 20:57:09 --> Language Class Initialized
INFO - 2020-09-26 20:57:09 --> Loader Class Initialized
INFO - 2020-09-26 20:57:09 --> Helper loaded: url_helper
INFO - 2020-09-26 20:57:09 --> Helper loaded: file_helper
INFO - 2020-09-26 20:57:09 --> Database Driver Class Initialized
INFO - 2020-09-26 20:57:09 --> Email Class Initialized
DEBUG - 2020-09-26 20:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:57:09 --> Controller Class Initialized
INFO - 2020-09-26 20:57:09 --> Model "Main_model" initialized
INFO - 2020-09-26 20:57:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:57:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 20:57:09 --> Final output sent to browser
DEBUG - 2020-09-26 20:57:09 --> Total execution time: 0.3044
INFO - 2020-09-26 20:57:21 --> Config Class Initialized
INFO - 2020-09-26 20:57:21 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:57:21 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:57:21 --> Utf8 Class Initialized
INFO - 2020-09-26 20:57:21 --> URI Class Initialized
INFO - 2020-09-26 20:57:21 --> Router Class Initialized
INFO - 2020-09-26 20:57:21 --> Output Class Initialized
INFO - 2020-09-26 20:57:21 --> Security Class Initialized
DEBUG - 2020-09-26 20:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:57:21 --> Input Class Initialized
INFO - 2020-09-26 20:57:21 --> Language Class Initialized
INFO - 2020-09-26 20:57:21 --> Loader Class Initialized
INFO - 2020-09-26 20:57:21 --> Helper loaded: url_helper
INFO - 2020-09-26 20:57:21 --> Helper loaded: file_helper
INFO - 2020-09-26 20:57:21 --> Database Driver Class Initialized
INFO - 2020-09-26 20:57:21 --> Email Class Initialized
DEBUG - 2020-09-26 20:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:57:21 --> Controller Class Initialized
INFO - 2020-09-26 20:57:21 --> Model "Main_model" initialized
INFO - 2020-09-26 20:57:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:57:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 20:57:21 --> Final output sent to browser
DEBUG - 2020-09-26 20:57:21 --> Total execution time: 0.3283
INFO - 2020-09-26 20:57:30 --> Config Class Initialized
INFO - 2020-09-26 20:57:30 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:57:30 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:57:30 --> Utf8 Class Initialized
INFO - 2020-09-26 20:57:30 --> URI Class Initialized
INFO - 2020-09-26 20:57:30 --> Router Class Initialized
INFO - 2020-09-26 20:57:30 --> Output Class Initialized
INFO - 2020-09-26 20:57:30 --> Security Class Initialized
DEBUG - 2020-09-26 20:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:57:30 --> Input Class Initialized
INFO - 2020-09-26 20:57:30 --> Language Class Initialized
INFO - 2020-09-26 20:57:30 --> Loader Class Initialized
INFO - 2020-09-26 20:57:30 --> Helper loaded: url_helper
INFO - 2020-09-26 20:57:30 --> Helper loaded: file_helper
INFO - 2020-09-26 20:57:30 --> Database Driver Class Initialized
INFO - 2020-09-26 20:57:30 --> Email Class Initialized
DEBUG - 2020-09-26 20:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:57:30 --> Controller Class Initialized
INFO - 2020-09-26 20:57:30 --> Model "Main_model" initialized
INFO - 2020-09-26 20:57:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:57:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 20:57:30 --> Final output sent to browser
DEBUG - 2020-09-26 20:57:30 --> Total execution time: 0.3337
INFO - 2020-09-26 20:57:35 --> Config Class Initialized
INFO - 2020-09-26 20:57:35 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:57:35 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:57:35 --> Utf8 Class Initialized
INFO - 2020-09-26 20:57:35 --> URI Class Initialized
INFO - 2020-09-26 20:57:35 --> Router Class Initialized
INFO - 2020-09-26 20:57:35 --> Output Class Initialized
INFO - 2020-09-26 20:57:35 --> Security Class Initialized
DEBUG - 2020-09-26 20:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:57:35 --> Input Class Initialized
INFO - 2020-09-26 20:57:35 --> Language Class Initialized
INFO - 2020-09-26 20:57:35 --> Loader Class Initialized
INFO - 2020-09-26 20:57:35 --> Helper loaded: url_helper
INFO - 2020-09-26 20:57:35 --> Helper loaded: file_helper
INFO - 2020-09-26 20:57:35 --> Database Driver Class Initialized
INFO - 2020-09-26 20:57:35 --> Email Class Initialized
DEBUG - 2020-09-26 20:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:57:35 --> Controller Class Initialized
INFO - 2020-09-26 20:57:35 --> Model "Main_model" initialized
INFO - 2020-09-26 20:57:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:57:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 20:57:35 --> Final output sent to browser
DEBUG - 2020-09-26 20:57:35 --> Total execution time: 0.3227
INFO - 2020-09-26 20:57:48 --> Config Class Initialized
INFO - 2020-09-26 20:57:48 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:57:48 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:57:48 --> Utf8 Class Initialized
INFO - 2020-09-26 20:57:48 --> URI Class Initialized
INFO - 2020-09-26 20:57:48 --> Router Class Initialized
INFO - 2020-09-26 20:57:48 --> Output Class Initialized
INFO - 2020-09-26 20:57:48 --> Security Class Initialized
DEBUG - 2020-09-26 20:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:57:48 --> Input Class Initialized
INFO - 2020-09-26 20:57:48 --> Language Class Initialized
INFO - 2020-09-26 20:57:48 --> Loader Class Initialized
INFO - 2020-09-26 20:57:48 --> Helper loaded: url_helper
INFO - 2020-09-26 20:57:48 --> Helper loaded: file_helper
INFO - 2020-09-26 20:57:48 --> Database Driver Class Initialized
INFO - 2020-09-26 20:57:48 --> Email Class Initialized
DEBUG - 2020-09-26 20:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:57:48 --> Controller Class Initialized
INFO - 2020-09-26 20:57:48 --> Model "Main_model" initialized
INFO - 2020-09-26 20:57:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:57:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 20:57:48 --> Final output sent to browser
DEBUG - 2020-09-26 20:57:48 --> Total execution time: 0.3301
INFO - 2020-09-26 20:58:16 --> Config Class Initialized
INFO - 2020-09-26 20:58:16 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:58:16 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:58:16 --> Utf8 Class Initialized
INFO - 2020-09-26 20:58:16 --> URI Class Initialized
INFO - 2020-09-26 20:58:16 --> Router Class Initialized
INFO - 2020-09-26 20:58:16 --> Output Class Initialized
INFO - 2020-09-26 20:58:16 --> Security Class Initialized
DEBUG - 2020-09-26 20:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:58:16 --> Input Class Initialized
INFO - 2020-09-26 20:58:16 --> Language Class Initialized
INFO - 2020-09-26 20:58:16 --> Loader Class Initialized
INFO - 2020-09-26 20:58:16 --> Helper loaded: url_helper
INFO - 2020-09-26 20:58:16 --> Helper loaded: file_helper
INFO - 2020-09-26 20:58:16 --> Database Driver Class Initialized
INFO - 2020-09-26 20:58:16 --> Email Class Initialized
DEBUG - 2020-09-26 20:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:58:16 --> Controller Class Initialized
INFO - 2020-09-26 20:58:16 --> Model "Main_model" initialized
INFO - 2020-09-26 20:58:16 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:58:16 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 20:58:17 --> Final output sent to browser
DEBUG - 2020-09-26 20:58:17 --> Total execution time: 0.3768
INFO - 2020-09-26 20:58:24 --> Config Class Initialized
INFO - 2020-09-26 20:58:24 --> Hooks Class Initialized
DEBUG - 2020-09-26 20:58:24 --> UTF-8 Support Enabled
INFO - 2020-09-26 20:58:24 --> Utf8 Class Initialized
INFO - 2020-09-26 20:58:24 --> URI Class Initialized
INFO - 2020-09-26 20:58:24 --> Router Class Initialized
INFO - 2020-09-26 20:58:24 --> Output Class Initialized
INFO - 2020-09-26 20:58:24 --> Security Class Initialized
DEBUG - 2020-09-26 20:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 20:58:24 --> Input Class Initialized
INFO - 2020-09-26 20:58:24 --> Language Class Initialized
INFO - 2020-09-26 20:58:24 --> Loader Class Initialized
INFO - 2020-09-26 20:58:24 --> Helper loaded: url_helper
INFO - 2020-09-26 20:58:24 --> Helper loaded: file_helper
INFO - 2020-09-26 20:58:24 --> Database Driver Class Initialized
INFO - 2020-09-26 20:58:24 --> Email Class Initialized
DEBUG - 2020-09-26 20:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 20:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 20:58:24 --> Controller Class Initialized
INFO - 2020-09-26 20:58:24 --> Model "Main_model" initialized
INFO - 2020-09-26 20:58:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 20:58:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 20:58:24 --> Final output sent to browser
DEBUG - 2020-09-26 20:58:24 --> Total execution time: 0.3546
INFO - 2020-09-26 21:27:29 --> Config Class Initialized
INFO - 2020-09-26 21:27:29 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:27:29 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:27:29 --> Utf8 Class Initialized
INFO - 2020-09-26 21:27:29 --> URI Class Initialized
INFO - 2020-09-26 21:27:29 --> Router Class Initialized
INFO - 2020-09-26 21:27:29 --> Output Class Initialized
INFO - 2020-09-26 21:27:29 --> Security Class Initialized
DEBUG - 2020-09-26 21:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:27:29 --> Input Class Initialized
INFO - 2020-09-26 21:27:29 --> Language Class Initialized
INFO - 2020-09-26 21:27:29 --> Loader Class Initialized
INFO - 2020-09-26 21:27:29 --> Helper loaded: url_helper
INFO - 2020-09-26 21:27:29 --> Helper loaded: file_helper
INFO - 2020-09-26 21:27:29 --> Database Driver Class Initialized
INFO - 2020-09-26 21:27:29 --> Email Class Initialized
DEBUG - 2020-09-26 21:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:27:29 --> Controller Class Initialized
INFO - 2020-09-26 21:27:29 --> Model "Main_model" initialized
INFO - 2020-09-26 21:27:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:27:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 21:27:29 --> Final output sent to browser
DEBUG - 2020-09-26 21:27:29 --> Total execution time: 0.4914
INFO - 2020-09-26 21:27:34 --> Config Class Initialized
INFO - 2020-09-26 21:27:34 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:27:34 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:27:34 --> Utf8 Class Initialized
INFO - 2020-09-26 21:27:34 --> URI Class Initialized
INFO - 2020-09-26 21:27:34 --> Router Class Initialized
INFO - 2020-09-26 21:27:34 --> Output Class Initialized
INFO - 2020-09-26 21:27:34 --> Security Class Initialized
DEBUG - 2020-09-26 21:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:27:34 --> Input Class Initialized
INFO - 2020-09-26 21:27:34 --> Language Class Initialized
ERROR - 2020-09-26 21:27:34 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 21:28:11 --> Config Class Initialized
INFO - 2020-09-26 21:28:11 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:28:11 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:28:11 --> Utf8 Class Initialized
INFO - 2020-09-26 21:28:11 --> URI Class Initialized
INFO - 2020-09-26 21:28:11 --> Router Class Initialized
INFO - 2020-09-26 21:28:11 --> Output Class Initialized
INFO - 2020-09-26 21:28:11 --> Security Class Initialized
DEBUG - 2020-09-26 21:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:28:11 --> Input Class Initialized
INFO - 2020-09-26 21:28:11 --> Language Class Initialized
INFO - 2020-09-26 21:28:11 --> Loader Class Initialized
INFO - 2020-09-26 21:28:11 --> Helper loaded: url_helper
INFO - 2020-09-26 21:28:11 --> Helper loaded: file_helper
INFO - 2020-09-26 21:28:11 --> Database Driver Class Initialized
INFO - 2020-09-26 21:28:11 --> Email Class Initialized
DEBUG - 2020-09-26 21:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:28:11 --> Controller Class Initialized
INFO - 2020-09-26 21:28:11 --> Model "Main_model" initialized
INFO - 2020-09-26 21:28:11 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:28:11 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 21:28:11 --> Final output sent to browser
DEBUG - 2020-09-26 21:28:11 --> Total execution time: 0.3445
INFO - 2020-09-26 21:29:33 --> Config Class Initialized
INFO - 2020-09-26 21:29:33 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:29:33 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:29:33 --> Utf8 Class Initialized
INFO - 2020-09-26 21:29:33 --> URI Class Initialized
INFO - 2020-09-26 21:29:33 --> Router Class Initialized
INFO - 2020-09-26 21:29:33 --> Output Class Initialized
INFO - 2020-09-26 21:29:33 --> Security Class Initialized
DEBUG - 2020-09-26 21:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:29:33 --> Input Class Initialized
INFO - 2020-09-26 21:29:33 --> Language Class Initialized
INFO - 2020-09-26 21:29:33 --> Loader Class Initialized
INFO - 2020-09-26 21:29:33 --> Helper loaded: url_helper
INFO - 2020-09-26 21:29:33 --> Helper loaded: file_helper
INFO - 2020-09-26 21:29:33 --> Database Driver Class Initialized
INFO - 2020-09-26 21:29:33 --> Email Class Initialized
DEBUG - 2020-09-26 21:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:29:33 --> Controller Class Initialized
INFO - 2020-09-26 21:29:33 --> Model "Main_model" initialized
INFO - 2020-09-26 21:29:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:29:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 21:29:33 --> Final output sent to browser
DEBUG - 2020-09-26 21:29:33 --> Total execution time: 0.3586
INFO - 2020-09-26 21:29:41 --> Config Class Initialized
INFO - 2020-09-26 21:29:41 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:29:41 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:29:41 --> Utf8 Class Initialized
INFO - 2020-09-26 21:29:41 --> URI Class Initialized
INFO - 2020-09-26 21:29:41 --> Router Class Initialized
INFO - 2020-09-26 21:29:41 --> Output Class Initialized
INFO - 2020-09-26 21:29:41 --> Security Class Initialized
DEBUG - 2020-09-26 21:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:29:41 --> Input Class Initialized
INFO - 2020-09-26 21:29:41 --> Language Class Initialized
INFO - 2020-09-26 21:29:41 --> Loader Class Initialized
INFO - 2020-09-26 21:29:41 --> Helper loaded: url_helper
INFO - 2020-09-26 21:29:41 --> Helper loaded: file_helper
INFO - 2020-09-26 21:29:41 --> Database Driver Class Initialized
INFO - 2020-09-26 21:29:41 --> Email Class Initialized
DEBUG - 2020-09-26 21:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:29:41 --> Controller Class Initialized
INFO - 2020-09-26 21:29:41 --> Model "Main_model" initialized
INFO - 2020-09-26 21:29:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:29:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-26 21:29:41 --> Final output sent to browser
DEBUG - 2020-09-26 21:29:41 --> Total execution time: 0.3937
INFO - 2020-09-26 21:30:39 --> Config Class Initialized
INFO - 2020-09-26 21:30:39 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:30:39 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:30:39 --> Utf8 Class Initialized
INFO - 2020-09-26 21:30:39 --> URI Class Initialized
INFO - 2020-09-26 21:30:39 --> Router Class Initialized
INFO - 2020-09-26 21:30:39 --> Output Class Initialized
INFO - 2020-09-26 21:30:39 --> Security Class Initialized
DEBUG - 2020-09-26 21:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:30:39 --> Input Class Initialized
INFO - 2020-09-26 21:30:39 --> Language Class Initialized
INFO - 2020-09-26 21:30:39 --> Loader Class Initialized
INFO - 2020-09-26 21:30:39 --> Helper loaded: url_helper
INFO - 2020-09-26 21:30:39 --> Helper loaded: file_helper
INFO - 2020-09-26 21:30:39 --> Database Driver Class Initialized
INFO - 2020-09-26 21:30:39 --> Email Class Initialized
DEBUG - 2020-09-26 21:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:30:39 --> Controller Class Initialized
INFO - 2020-09-26 21:30:39 --> Model "Main_model" initialized
INFO - 2020-09-26 21:30:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:30:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 21:30:39 --> Final output sent to browser
DEBUG - 2020-09-26 21:30:39 --> Total execution time: 0.3759
INFO - 2020-09-26 21:30:41 --> Config Class Initialized
INFO - 2020-09-26 21:30:41 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:30:41 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:30:41 --> Utf8 Class Initialized
INFO - 2020-09-26 21:30:41 --> URI Class Initialized
INFO - 2020-09-26 21:30:41 --> Router Class Initialized
INFO - 2020-09-26 21:30:41 --> Output Class Initialized
INFO - 2020-09-26 21:30:41 --> Security Class Initialized
DEBUG - 2020-09-26 21:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:30:41 --> Input Class Initialized
INFO - 2020-09-26 21:30:41 --> Language Class Initialized
INFO - 2020-09-26 21:30:41 --> Loader Class Initialized
INFO - 2020-09-26 21:30:41 --> Helper loaded: url_helper
INFO - 2020-09-26 21:30:41 --> Helper loaded: file_helper
INFO - 2020-09-26 21:30:41 --> Database Driver Class Initialized
INFO - 2020-09-26 21:30:41 --> Email Class Initialized
DEBUG - 2020-09-26 21:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:30:41 --> Controller Class Initialized
INFO - 2020-09-26 21:30:41 --> Model "Main_model" initialized
INFO - 2020-09-26 21:30:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:30:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 21:30:41 --> Final output sent to browser
DEBUG - 2020-09-26 21:30:41 --> Total execution time: 0.3310
INFO - 2020-09-26 21:30:59 --> Config Class Initialized
INFO - 2020-09-26 21:30:59 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:30:59 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:30:59 --> Utf8 Class Initialized
INFO - 2020-09-26 21:30:59 --> URI Class Initialized
INFO - 2020-09-26 21:30:59 --> Router Class Initialized
INFO - 2020-09-26 21:30:59 --> Output Class Initialized
INFO - 2020-09-26 21:30:59 --> Security Class Initialized
DEBUG - 2020-09-26 21:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:30:59 --> Input Class Initialized
INFO - 2020-09-26 21:30:59 --> Language Class Initialized
INFO - 2020-09-26 21:30:59 --> Loader Class Initialized
INFO - 2020-09-26 21:30:59 --> Helper loaded: url_helper
INFO - 2020-09-26 21:30:59 --> Helper loaded: file_helper
INFO - 2020-09-26 21:30:59 --> Database Driver Class Initialized
INFO - 2020-09-26 21:30:59 --> Email Class Initialized
DEBUG - 2020-09-26 21:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:30:59 --> Controller Class Initialized
INFO - 2020-09-26 21:30:59 --> Model "Main_model" initialized
INFO - 2020-09-26 21:30:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:30:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 21:30:59 --> Final output sent to browser
DEBUG - 2020-09-26 21:30:59 --> Total execution time: 0.3456
INFO - 2020-09-26 21:31:03 --> Config Class Initialized
INFO - 2020-09-26 21:31:03 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:31:03 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:31:03 --> Utf8 Class Initialized
INFO - 2020-09-26 21:31:03 --> URI Class Initialized
INFO - 2020-09-26 21:31:03 --> Router Class Initialized
INFO - 2020-09-26 21:31:03 --> Output Class Initialized
INFO - 2020-09-26 21:31:03 --> Security Class Initialized
DEBUG - 2020-09-26 21:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:31:03 --> Input Class Initialized
INFO - 2020-09-26 21:31:03 --> Language Class Initialized
INFO - 2020-09-26 21:31:03 --> Loader Class Initialized
INFO - 2020-09-26 21:31:03 --> Helper loaded: url_helper
INFO - 2020-09-26 21:31:03 --> Helper loaded: file_helper
INFO - 2020-09-26 21:31:03 --> Database Driver Class Initialized
INFO - 2020-09-26 21:31:03 --> Email Class Initialized
DEBUG - 2020-09-26 21:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:31:03 --> Controller Class Initialized
INFO - 2020-09-26 21:31:03 --> Model "Main_model" initialized
INFO - 2020-09-26 21:31:22 --> Config Class Initialized
INFO - 2020-09-26 21:31:22 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:31:22 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:31:22 --> Utf8 Class Initialized
INFO - 2020-09-26 21:31:22 --> URI Class Initialized
INFO - 2020-09-26 21:31:22 --> Router Class Initialized
INFO - 2020-09-26 21:31:22 --> Output Class Initialized
INFO - 2020-09-26 21:31:22 --> Security Class Initialized
DEBUG - 2020-09-26 21:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:31:22 --> Input Class Initialized
INFO - 2020-09-26 21:31:22 --> Language Class Initialized
INFO - 2020-09-26 21:31:22 --> Loader Class Initialized
INFO - 2020-09-26 21:31:22 --> Helper loaded: url_helper
INFO - 2020-09-26 21:31:22 --> Helper loaded: file_helper
INFO - 2020-09-26 21:31:22 --> Database Driver Class Initialized
INFO - 2020-09-26 21:31:22 --> Email Class Initialized
DEBUG - 2020-09-26 21:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:31:22 --> Controller Class Initialized
INFO - 2020-09-26 21:31:22 --> Model "Main_model" initialized
INFO - 2020-09-26 21:31:22 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:31:22 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 21:31:22 --> Final output sent to browser
DEBUG - 2020-09-26 21:31:22 --> Total execution time: 0.3520
INFO - 2020-09-26 21:31:27 --> Config Class Initialized
INFO - 2020-09-26 21:31:27 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:31:27 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:31:27 --> Utf8 Class Initialized
INFO - 2020-09-26 21:31:27 --> URI Class Initialized
INFO - 2020-09-26 21:31:27 --> Router Class Initialized
INFO - 2020-09-26 21:31:27 --> Output Class Initialized
INFO - 2020-09-26 21:31:27 --> Security Class Initialized
DEBUG - 2020-09-26 21:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:31:27 --> Input Class Initialized
INFO - 2020-09-26 21:31:27 --> Language Class Initialized
INFO - 2020-09-26 21:31:27 --> Loader Class Initialized
INFO - 2020-09-26 21:31:27 --> Helper loaded: url_helper
INFO - 2020-09-26 21:31:27 --> Helper loaded: file_helper
INFO - 2020-09-26 21:31:27 --> Database Driver Class Initialized
INFO - 2020-09-26 21:31:27 --> Email Class Initialized
DEBUG - 2020-09-26 21:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:31:27 --> Controller Class Initialized
INFO - 2020-09-26 21:31:27 --> Model "Main_model" initialized
INFO - 2020-09-26 21:31:27 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:31:27 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 21:31:27 --> Final output sent to browser
DEBUG - 2020-09-26 21:31:27 --> Total execution time: 0.3651
INFO - 2020-09-26 21:31:32 --> Config Class Initialized
INFO - 2020-09-26 21:31:32 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:31:32 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:31:32 --> Utf8 Class Initialized
INFO - 2020-09-26 21:31:32 --> URI Class Initialized
INFO - 2020-09-26 21:31:32 --> Router Class Initialized
INFO - 2020-09-26 21:31:32 --> Output Class Initialized
INFO - 2020-09-26 21:31:32 --> Security Class Initialized
DEBUG - 2020-09-26 21:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:31:32 --> Input Class Initialized
INFO - 2020-09-26 21:31:32 --> Language Class Initialized
INFO - 2020-09-26 21:31:32 --> Loader Class Initialized
INFO - 2020-09-26 21:31:32 --> Helper loaded: url_helper
INFO - 2020-09-26 21:31:32 --> Helper loaded: file_helper
INFO - 2020-09-26 21:31:32 --> Database Driver Class Initialized
INFO - 2020-09-26 21:31:32 --> Email Class Initialized
DEBUG - 2020-09-26 21:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:31:32 --> Controller Class Initialized
INFO - 2020-09-26 21:31:32 --> Model "Main_model" initialized
INFO - 2020-09-26 21:31:32 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:31:32 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 21:31:32 --> Final output sent to browser
DEBUG - 2020-09-26 21:31:32 --> Total execution time: 0.3809
INFO - 2020-09-26 21:31:40 --> Config Class Initialized
INFO - 2020-09-26 21:31:40 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:31:40 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:31:40 --> Utf8 Class Initialized
INFO - 2020-09-26 21:31:40 --> URI Class Initialized
INFO - 2020-09-26 21:31:40 --> Router Class Initialized
INFO - 2020-09-26 21:31:40 --> Output Class Initialized
INFO - 2020-09-26 21:31:40 --> Security Class Initialized
DEBUG - 2020-09-26 21:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:31:40 --> Input Class Initialized
INFO - 2020-09-26 21:31:40 --> Language Class Initialized
ERROR - 2020-09-26 21:31:40 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 21:32:57 --> Config Class Initialized
INFO - 2020-09-26 21:32:57 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:32:57 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:32:57 --> Utf8 Class Initialized
INFO - 2020-09-26 21:32:57 --> URI Class Initialized
INFO - 2020-09-26 21:32:57 --> Router Class Initialized
INFO - 2020-09-26 21:32:57 --> Output Class Initialized
INFO - 2020-09-26 21:32:57 --> Security Class Initialized
DEBUG - 2020-09-26 21:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:32:57 --> Input Class Initialized
INFO - 2020-09-26 21:32:57 --> Language Class Initialized
INFO - 2020-09-26 21:32:57 --> Loader Class Initialized
INFO - 2020-09-26 21:32:57 --> Helper loaded: url_helper
INFO - 2020-09-26 21:32:57 --> Helper loaded: file_helper
INFO - 2020-09-26 21:32:57 --> Database Driver Class Initialized
INFO - 2020-09-26 21:32:57 --> Email Class Initialized
DEBUG - 2020-09-26 21:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:32:57 --> Controller Class Initialized
INFO - 2020-09-26 21:32:57 --> Model "Main_model" initialized
INFO - 2020-09-26 21:32:57 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:32:57 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 21:32:57 --> Final output sent to browser
DEBUG - 2020-09-26 21:32:57 --> Total execution time: 0.4570
INFO - 2020-09-26 21:33:06 --> Config Class Initialized
INFO - 2020-09-26 21:33:06 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:33:06 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:33:06 --> Utf8 Class Initialized
INFO - 2020-09-26 21:33:06 --> URI Class Initialized
INFO - 2020-09-26 21:33:06 --> Router Class Initialized
INFO - 2020-09-26 21:33:06 --> Output Class Initialized
INFO - 2020-09-26 21:33:06 --> Security Class Initialized
DEBUG - 2020-09-26 21:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:33:06 --> Input Class Initialized
INFO - 2020-09-26 21:33:06 --> Language Class Initialized
INFO - 2020-09-26 21:33:06 --> Loader Class Initialized
INFO - 2020-09-26 21:33:06 --> Helper loaded: url_helper
INFO - 2020-09-26 21:33:06 --> Helper loaded: file_helper
INFO - 2020-09-26 21:33:06 --> Database Driver Class Initialized
INFO - 2020-09-26 21:33:06 --> Email Class Initialized
DEBUG - 2020-09-26 21:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:33:06 --> Controller Class Initialized
INFO - 2020-09-26 21:33:06 --> Model "Main_model" initialized
INFO - 2020-09-26 21:33:06 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:33:06 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 21:33:06 --> Final output sent to browser
DEBUG - 2020-09-26 21:33:06 --> Total execution time: 0.3714
INFO - 2020-09-26 21:37:35 --> Config Class Initialized
INFO - 2020-09-26 21:37:35 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:37:35 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:37:35 --> Utf8 Class Initialized
INFO - 2020-09-26 21:37:35 --> URI Class Initialized
INFO - 2020-09-26 21:37:35 --> Router Class Initialized
INFO - 2020-09-26 21:37:35 --> Output Class Initialized
INFO - 2020-09-26 21:37:35 --> Security Class Initialized
DEBUG - 2020-09-26 21:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:37:35 --> Input Class Initialized
INFO - 2020-09-26 21:37:35 --> Language Class Initialized
INFO - 2020-09-26 21:37:35 --> Loader Class Initialized
INFO - 2020-09-26 21:37:35 --> Helper loaded: url_helper
INFO - 2020-09-26 21:37:35 --> Helper loaded: file_helper
INFO - 2020-09-26 21:37:35 --> Database Driver Class Initialized
INFO - 2020-09-26 21:37:35 --> Email Class Initialized
DEBUG - 2020-09-26 21:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:37:35 --> Controller Class Initialized
INFO - 2020-09-26 21:37:35 --> Model "Main_model" initialized
INFO - 2020-09-26 21:37:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:37:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 21:37:35 --> Final output sent to browser
DEBUG - 2020-09-26 21:37:35 --> Total execution time: 0.3906
INFO - 2020-09-26 21:37:39 --> Config Class Initialized
INFO - 2020-09-26 21:37:39 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:37:39 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:37:39 --> Utf8 Class Initialized
INFO - 2020-09-26 21:37:39 --> URI Class Initialized
INFO - 2020-09-26 21:37:39 --> Router Class Initialized
INFO - 2020-09-26 21:37:39 --> Output Class Initialized
INFO - 2020-09-26 21:37:39 --> Security Class Initialized
DEBUG - 2020-09-26 21:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:37:39 --> Input Class Initialized
INFO - 2020-09-26 21:37:39 --> Language Class Initialized
INFO - 2020-09-26 21:37:39 --> Loader Class Initialized
INFO - 2020-09-26 21:37:39 --> Helper loaded: url_helper
INFO - 2020-09-26 21:37:39 --> Helper loaded: file_helper
INFO - 2020-09-26 21:37:39 --> Database Driver Class Initialized
INFO - 2020-09-26 21:37:39 --> Email Class Initialized
DEBUG - 2020-09-26 21:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:37:39 --> Controller Class Initialized
INFO - 2020-09-26 21:37:39 --> Model "Main_model" initialized
INFO - 2020-09-26 21:37:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:37:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-26 21:37:39 --> Final output sent to browser
DEBUG - 2020-09-26 21:37:39 --> Total execution time: 0.3884
INFO - 2020-09-26 21:37:47 --> Config Class Initialized
INFO - 2020-09-26 21:37:47 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:37:47 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:37:47 --> Utf8 Class Initialized
INFO - 2020-09-26 21:37:47 --> URI Class Initialized
INFO - 2020-09-26 21:37:47 --> Router Class Initialized
INFO - 2020-09-26 21:37:47 --> Output Class Initialized
INFO - 2020-09-26 21:37:47 --> Security Class Initialized
DEBUG - 2020-09-26 21:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:37:47 --> Input Class Initialized
INFO - 2020-09-26 21:37:47 --> Language Class Initialized
INFO - 2020-09-26 21:37:47 --> Loader Class Initialized
INFO - 2020-09-26 21:37:47 --> Helper loaded: url_helper
INFO - 2020-09-26 21:37:47 --> Helper loaded: file_helper
INFO - 2020-09-26 21:37:47 --> Database Driver Class Initialized
INFO - 2020-09-26 21:37:47 --> Email Class Initialized
DEBUG - 2020-09-26 21:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:37:47 --> Controller Class Initialized
INFO - 2020-09-26 21:37:47 --> Model "Main_model" initialized
INFO - 2020-09-26 21:37:47 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:37:47 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-26 21:37:47 --> Final output sent to browser
DEBUG - 2020-09-26 21:37:47 --> Total execution time: 0.3145
INFO - 2020-09-26 21:38:02 --> Config Class Initialized
INFO - 2020-09-26 21:38:02 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:38:02 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:38:02 --> Utf8 Class Initialized
INFO - 2020-09-26 21:38:02 --> URI Class Initialized
INFO - 2020-09-26 21:38:02 --> Router Class Initialized
INFO - 2020-09-26 21:38:02 --> Output Class Initialized
INFO - 2020-09-26 21:38:02 --> Security Class Initialized
DEBUG - 2020-09-26 21:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:38:02 --> Input Class Initialized
INFO - 2020-09-26 21:38:02 --> Language Class Initialized
INFO - 2020-09-26 21:38:02 --> Loader Class Initialized
INFO - 2020-09-26 21:38:02 --> Helper loaded: url_helper
INFO - 2020-09-26 21:38:02 --> Helper loaded: file_helper
INFO - 2020-09-26 21:38:02 --> Database Driver Class Initialized
INFO - 2020-09-26 21:38:02 --> Email Class Initialized
DEBUG - 2020-09-26 21:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:38:02 --> Controller Class Initialized
INFO - 2020-09-26 21:38:02 --> Model "Main_model" initialized
INFO - 2020-09-26 21:38:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:38:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-26 21:38:02 --> Final output sent to browser
DEBUG - 2020-09-26 21:38:02 --> Total execution time: 0.3553
INFO - 2020-09-26 21:38:24 --> Config Class Initialized
INFO - 2020-09-26 21:38:24 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:38:24 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:38:25 --> Utf8 Class Initialized
INFO - 2020-09-26 21:38:25 --> URI Class Initialized
INFO - 2020-09-26 21:38:25 --> Router Class Initialized
INFO - 2020-09-26 21:38:25 --> Output Class Initialized
INFO - 2020-09-26 21:38:25 --> Security Class Initialized
DEBUG - 2020-09-26 21:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:38:25 --> Input Class Initialized
INFO - 2020-09-26 21:38:25 --> Language Class Initialized
INFO - 2020-09-26 21:38:25 --> Loader Class Initialized
INFO - 2020-09-26 21:38:25 --> Helper loaded: url_helper
INFO - 2020-09-26 21:38:25 --> Helper loaded: file_helper
INFO - 2020-09-26 21:38:25 --> Database Driver Class Initialized
INFO - 2020-09-26 21:38:25 --> Email Class Initialized
DEBUG - 2020-09-26 21:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:38:25 --> Controller Class Initialized
INFO - 2020-09-26 21:38:25 --> Model "Main_model" initialized
INFO - 2020-09-26 21:38:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:38:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 21:38:25 --> Final output sent to browser
DEBUG - 2020-09-26 21:38:25 --> Total execution time: 0.3956
INFO - 2020-09-26 21:38:32 --> Config Class Initialized
INFO - 2020-09-26 21:38:32 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:38:32 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:38:32 --> Utf8 Class Initialized
INFO - 2020-09-26 21:38:32 --> URI Class Initialized
INFO - 2020-09-26 21:38:32 --> Router Class Initialized
INFO - 2020-09-26 21:38:32 --> Output Class Initialized
INFO - 2020-09-26 21:38:32 --> Security Class Initialized
DEBUG - 2020-09-26 21:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:38:32 --> Input Class Initialized
INFO - 2020-09-26 21:38:32 --> Language Class Initialized
ERROR - 2020-09-26 21:38:32 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 21:40:09 --> Config Class Initialized
INFO - 2020-09-26 21:40:09 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:40:09 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:40:09 --> Utf8 Class Initialized
INFO - 2020-09-26 21:40:09 --> URI Class Initialized
INFO - 2020-09-26 21:40:09 --> Router Class Initialized
INFO - 2020-09-26 21:40:09 --> Output Class Initialized
INFO - 2020-09-26 21:40:09 --> Security Class Initialized
DEBUG - 2020-09-26 21:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:40:09 --> Input Class Initialized
INFO - 2020-09-26 21:40:09 --> Language Class Initialized
INFO - 2020-09-26 21:40:09 --> Loader Class Initialized
INFO - 2020-09-26 21:40:09 --> Helper loaded: url_helper
INFO - 2020-09-26 21:40:09 --> Helper loaded: file_helper
INFO - 2020-09-26 21:40:09 --> Database Driver Class Initialized
INFO - 2020-09-26 21:40:09 --> Email Class Initialized
DEBUG - 2020-09-26 21:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:40:09 --> Controller Class Initialized
INFO - 2020-09-26 21:40:09 --> Model "Main_model" initialized
INFO - 2020-09-26 21:40:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:40:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 21:40:09 --> Final output sent to browser
DEBUG - 2020-09-26 21:40:09 --> Total execution time: 0.3981
INFO - 2020-09-26 21:40:11 --> Config Class Initialized
INFO - 2020-09-26 21:40:11 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:40:11 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:40:11 --> Utf8 Class Initialized
INFO - 2020-09-26 21:40:11 --> URI Class Initialized
INFO - 2020-09-26 21:40:11 --> Router Class Initialized
INFO - 2020-09-26 21:40:11 --> Output Class Initialized
INFO - 2020-09-26 21:40:11 --> Security Class Initialized
DEBUG - 2020-09-26 21:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:40:11 --> Input Class Initialized
INFO - 2020-09-26 21:40:11 --> Language Class Initialized
ERROR - 2020-09-26 21:40:11 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 21:43:11 --> Config Class Initialized
INFO - 2020-09-26 21:43:11 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:43:11 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:43:11 --> Utf8 Class Initialized
INFO - 2020-09-26 21:43:11 --> URI Class Initialized
INFO - 2020-09-26 21:43:11 --> Router Class Initialized
INFO - 2020-09-26 21:43:11 --> Output Class Initialized
INFO - 2020-09-26 21:43:11 --> Security Class Initialized
DEBUG - 2020-09-26 21:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:43:11 --> Input Class Initialized
INFO - 2020-09-26 21:43:11 --> Language Class Initialized
INFO - 2020-09-26 21:43:11 --> Loader Class Initialized
INFO - 2020-09-26 21:43:11 --> Helper loaded: url_helper
INFO - 2020-09-26 21:43:11 --> Helper loaded: file_helper
INFO - 2020-09-26 21:43:12 --> Database Driver Class Initialized
INFO - 2020-09-26 21:43:12 --> Email Class Initialized
DEBUG - 2020-09-26 21:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:43:12 --> Controller Class Initialized
INFO - 2020-09-26 21:43:12 --> Model "Main_model" initialized
INFO - 2020-09-26 21:43:12 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:43:12 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 21:43:12 --> Final output sent to browser
DEBUG - 2020-09-26 21:43:12 --> Total execution time: 1.0101
INFO - 2020-09-26 21:43:13 --> Config Class Initialized
INFO - 2020-09-26 21:43:13 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:43:13 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:43:13 --> Utf8 Class Initialized
INFO - 2020-09-26 21:43:13 --> URI Class Initialized
INFO - 2020-09-26 21:43:13 --> Router Class Initialized
INFO - 2020-09-26 21:43:13 --> Output Class Initialized
INFO - 2020-09-26 21:43:13 --> Security Class Initialized
DEBUG - 2020-09-26 21:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:43:13 --> Input Class Initialized
INFO - 2020-09-26 21:43:13 --> Language Class Initialized
ERROR - 2020-09-26 21:43:13 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 21:43:55 --> Config Class Initialized
INFO - 2020-09-26 21:43:55 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:43:55 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:43:55 --> Utf8 Class Initialized
INFO - 2020-09-26 21:43:55 --> URI Class Initialized
INFO - 2020-09-26 21:43:55 --> Router Class Initialized
INFO - 2020-09-26 21:43:55 --> Output Class Initialized
INFO - 2020-09-26 21:43:55 --> Security Class Initialized
DEBUG - 2020-09-26 21:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:43:55 --> Input Class Initialized
INFO - 2020-09-26 21:43:55 --> Language Class Initialized
INFO - 2020-09-26 21:43:55 --> Loader Class Initialized
INFO - 2020-09-26 21:43:55 --> Helper loaded: url_helper
INFO - 2020-09-26 21:43:55 --> Helper loaded: file_helper
INFO - 2020-09-26 21:43:55 --> Database Driver Class Initialized
INFO - 2020-09-26 21:43:55 --> Email Class Initialized
DEBUG - 2020-09-26 21:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:43:55 --> Controller Class Initialized
INFO - 2020-09-26 21:43:55 --> Model "Main_model" initialized
INFO - 2020-09-26 21:43:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:43:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 21:43:55 --> Final output sent to browser
DEBUG - 2020-09-26 21:43:55 --> Total execution time: 0.3737
INFO - 2020-09-26 21:43:56 --> Config Class Initialized
INFO - 2020-09-26 21:43:56 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:43:56 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:43:56 --> Utf8 Class Initialized
INFO - 2020-09-26 21:43:56 --> URI Class Initialized
INFO - 2020-09-26 21:43:56 --> Router Class Initialized
INFO - 2020-09-26 21:43:56 --> Output Class Initialized
INFO - 2020-09-26 21:43:56 --> Security Class Initialized
DEBUG - 2020-09-26 21:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:43:56 --> Input Class Initialized
INFO - 2020-09-26 21:43:56 --> Language Class Initialized
ERROR - 2020-09-26 21:43:56 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 21:45:57 --> Config Class Initialized
INFO - 2020-09-26 21:45:58 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:45:58 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:45:58 --> Utf8 Class Initialized
INFO - 2020-09-26 21:45:58 --> URI Class Initialized
INFO - 2020-09-26 21:45:58 --> Router Class Initialized
INFO - 2020-09-26 21:45:58 --> Output Class Initialized
INFO - 2020-09-26 21:45:58 --> Security Class Initialized
DEBUG - 2020-09-26 21:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:45:58 --> Input Class Initialized
INFO - 2020-09-26 21:45:58 --> Language Class Initialized
INFO - 2020-09-26 21:45:58 --> Loader Class Initialized
INFO - 2020-09-26 21:45:58 --> Helper loaded: url_helper
INFO - 2020-09-26 21:45:58 --> Helper loaded: file_helper
INFO - 2020-09-26 21:45:58 --> Database Driver Class Initialized
INFO - 2020-09-26 21:45:58 --> Email Class Initialized
DEBUG - 2020-09-26 21:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:45:58 --> Controller Class Initialized
INFO - 2020-09-26 21:45:58 --> Model "Main_model" initialized
INFO - 2020-09-26 21:45:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:45:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 21:45:58 --> Final output sent to browser
DEBUG - 2020-09-26 21:45:58 --> Total execution time: 0.4121
INFO - 2020-09-26 21:45:59 --> Config Class Initialized
INFO - 2020-09-26 21:45:59 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:45:59 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:45:59 --> Utf8 Class Initialized
INFO - 2020-09-26 21:45:59 --> URI Class Initialized
INFO - 2020-09-26 21:45:59 --> Router Class Initialized
INFO - 2020-09-26 21:45:59 --> Output Class Initialized
INFO - 2020-09-26 21:45:59 --> Security Class Initialized
DEBUG - 2020-09-26 21:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:45:59 --> Input Class Initialized
INFO - 2020-09-26 21:45:59 --> Language Class Initialized
ERROR - 2020-09-26 21:45:59 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 21:46:25 --> Config Class Initialized
INFO - 2020-09-26 21:46:25 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:46:25 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:46:25 --> Utf8 Class Initialized
INFO - 2020-09-26 21:46:25 --> URI Class Initialized
INFO - 2020-09-26 21:46:25 --> Router Class Initialized
INFO - 2020-09-26 21:46:25 --> Output Class Initialized
INFO - 2020-09-26 21:46:25 --> Security Class Initialized
DEBUG - 2020-09-26 21:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:46:25 --> Input Class Initialized
INFO - 2020-09-26 21:46:25 --> Language Class Initialized
INFO - 2020-09-26 21:46:25 --> Loader Class Initialized
INFO - 2020-09-26 21:46:25 --> Helper loaded: url_helper
INFO - 2020-09-26 21:46:25 --> Helper loaded: file_helper
INFO - 2020-09-26 21:46:25 --> Database Driver Class Initialized
INFO - 2020-09-26 21:46:25 --> Email Class Initialized
DEBUG - 2020-09-26 21:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:46:25 --> Controller Class Initialized
INFO - 2020-09-26 21:46:25 --> Model "Main_model" initialized
INFO - 2020-09-26 21:46:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:46:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 21:46:25 --> Final output sent to browser
DEBUG - 2020-09-26 21:46:25 --> Total execution time: 0.3918
INFO - 2020-09-26 21:46:26 --> Config Class Initialized
INFO - 2020-09-26 21:46:26 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:46:26 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:46:26 --> Utf8 Class Initialized
INFO - 2020-09-26 21:46:26 --> URI Class Initialized
INFO - 2020-09-26 21:46:26 --> Router Class Initialized
INFO - 2020-09-26 21:46:26 --> Output Class Initialized
INFO - 2020-09-26 21:46:26 --> Security Class Initialized
DEBUG - 2020-09-26 21:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:46:26 --> Input Class Initialized
INFO - 2020-09-26 21:46:26 --> Language Class Initialized
ERROR - 2020-09-26 21:46:26 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 21:46:32 --> Config Class Initialized
INFO - 2020-09-26 21:46:32 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:46:32 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:46:32 --> Utf8 Class Initialized
INFO - 2020-09-26 21:46:32 --> URI Class Initialized
INFO - 2020-09-26 21:46:32 --> Router Class Initialized
INFO - 2020-09-26 21:46:32 --> Output Class Initialized
INFO - 2020-09-26 21:46:32 --> Security Class Initialized
DEBUG - 2020-09-26 21:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:46:32 --> Input Class Initialized
INFO - 2020-09-26 21:46:32 --> Language Class Initialized
INFO - 2020-09-26 21:46:32 --> Loader Class Initialized
INFO - 2020-09-26 21:46:32 --> Helper loaded: url_helper
INFO - 2020-09-26 21:46:32 --> Helper loaded: file_helper
INFO - 2020-09-26 21:46:33 --> Database Driver Class Initialized
INFO - 2020-09-26 21:46:33 --> Email Class Initialized
DEBUG - 2020-09-26 21:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:46:33 --> Controller Class Initialized
INFO - 2020-09-26 21:46:33 --> Model "Main_model" initialized
INFO - 2020-09-26 21:46:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:46:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 21:46:33 --> Final output sent to browser
DEBUG - 2020-09-26 21:46:33 --> Total execution time: 0.4254
INFO - 2020-09-26 21:46:34 --> Config Class Initialized
INFO - 2020-09-26 21:46:34 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:46:34 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:46:34 --> Utf8 Class Initialized
INFO - 2020-09-26 21:46:34 --> URI Class Initialized
INFO - 2020-09-26 21:46:34 --> Router Class Initialized
INFO - 2020-09-26 21:46:34 --> Output Class Initialized
INFO - 2020-09-26 21:46:34 --> Security Class Initialized
DEBUG - 2020-09-26 21:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:46:34 --> Input Class Initialized
INFO - 2020-09-26 21:46:34 --> Language Class Initialized
ERROR - 2020-09-26 21:46:34 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 21:47:08 --> Config Class Initialized
INFO - 2020-09-26 21:47:08 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:47:08 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:47:09 --> Utf8 Class Initialized
INFO - 2020-09-26 21:47:09 --> URI Class Initialized
INFO - 2020-09-26 21:47:09 --> Router Class Initialized
INFO - 2020-09-26 21:47:09 --> Output Class Initialized
INFO - 2020-09-26 21:47:09 --> Security Class Initialized
DEBUG - 2020-09-26 21:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:47:09 --> Input Class Initialized
INFO - 2020-09-26 21:47:09 --> Language Class Initialized
INFO - 2020-09-26 21:47:09 --> Loader Class Initialized
INFO - 2020-09-26 21:47:09 --> Helper loaded: url_helper
INFO - 2020-09-26 21:47:09 --> Helper loaded: file_helper
INFO - 2020-09-26 21:47:09 --> Database Driver Class Initialized
INFO - 2020-09-26 21:47:09 --> Email Class Initialized
DEBUG - 2020-09-26 21:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:47:09 --> Controller Class Initialized
INFO - 2020-09-26 21:47:09 --> Model "Main_model" initialized
INFO - 2020-09-26 21:47:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 21:47:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 21:47:09 --> Final output sent to browser
DEBUG - 2020-09-26 21:47:09 --> Total execution time: 0.4169
INFO - 2020-09-26 21:59:20 --> Config Class Initialized
INFO - 2020-09-26 21:59:20 --> Hooks Class Initialized
DEBUG - 2020-09-26 21:59:20 --> UTF-8 Support Enabled
INFO - 2020-09-26 21:59:20 --> Utf8 Class Initialized
INFO - 2020-09-26 21:59:20 --> URI Class Initialized
INFO - 2020-09-26 21:59:20 --> Router Class Initialized
INFO - 2020-09-26 21:59:20 --> Output Class Initialized
INFO - 2020-09-26 21:59:20 --> Security Class Initialized
DEBUG - 2020-09-26 21:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 21:59:20 --> Input Class Initialized
INFO - 2020-09-26 21:59:20 --> Language Class Initialized
ERROR - 2020-09-26 21:59:20 --> Severity: Warning --> include(phpseclib/Crypt/RSA.php): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\controllers\Home.php 5
ERROR - 2020-09-26 21:59:20 --> Severity: Warning --> include(): Failed opening 'phpseclib/Crypt/RSA.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dmarc\application\controllers\Home.php 5
INFO - 2020-09-26 21:59:20 --> Loader Class Initialized
INFO - 2020-09-26 21:59:20 --> Helper loaded: url_helper
INFO - 2020-09-26 21:59:20 --> Helper loaded: file_helper
INFO - 2020-09-26 21:59:20 --> Database Driver Class Initialized
INFO - 2020-09-26 21:59:20 --> Email Class Initialized
DEBUG - 2020-09-26 21:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 21:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 21:59:20 --> Controller Class Initialized
INFO - 2020-09-26 21:59:20 --> Model "Main_model" initialized
ERROR - 2020-09-26 21:59:20 --> Severity: error --> Exception: Class 'Crypt_RSA' not found C:\xampp\htdocs\dmarc\application\controllers\Home.php 90
INFO - 2020-09-26 22:00:01 --> Config Class Initialized
INFO - 2020-09-26 22:00:01 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:00:01 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:00:01 --> Utf8 Class Initialized
INFO - 2020-09-26 22:00:01 --> URI Class Initialized
INFO - 2020-09-26 22:00:01 --> Router Class Initialized
INFO - 2020-09-26 22:00:01 --> Output Class Initialized
INFO - 2020-09-26 22:00:01 --> Security Class Initialized
DEBUG - 2020-09-26 22:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:00:01 --> Input Class Initialized
INFO - 2020-09-26 22:00:01 --> Language Class Initialized
ERROR - 2020-09-26 22:00:01 --> Severity: Error --> Class 'phpseclib3\Crypt\Common\AsymmetricKey' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 73
INFO - 2020-09-26 22:03:14 --> Config Class Initialized
INFO - 2020-09-26 22:03:14 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:03:14 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:03:14 --> Utf8 Class Initialized
INFO - 2020-09-26 22:03:14 --> URI Class Initialized
INFO - 2020-09-26 22:03:14 --> Router Class Initialized
INFO - 2020-09-26 22:03:14 --> Output Class Initialized
INFO - 2020-09-26 22:03:14 --> Security Class Initialized
DEBUG - 2020-09-26 22:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:03:14 --> Input Class Initialized
INFO - 2020-09-26 22:03:14 --> Language Class Initialized
ERROR - 2020-09-26 22:03:14 --> Severity: Error --> Class 'phpseclib\Crypt\Common\AsymmetricKey' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 73
INFO - 2020-09-26 22:04:01 --> Config Class Initialized
INFO - 2020-09-26 22:04:01 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:04:01 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:04:01 --> Utf8 Class Initialized
INFO - 2020-09-26 22:04:01 --> URI Class Initialized
INFO - 2020-09-26 22:04:01 --> Router Class Initialized
INFO - 2020-09-26 22:04:01 --> Output Class Initialized
INFO - 2020-09-26 22:04:01 --> Security Class Initialized
DEBUG - 2020-09-26 22:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:04:01 --> Input Class Initialized
INFO - 2020-09-26 22:04:01 --> Language Class Initialized
ERROR - 2020-09-26 22:04:01 --> Severity: Error --> Class 'Common\AsymmetricKey' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 73
INFO - 2020-09-26 22:04:26 --> Config Class Initialized
INFO - 2020-09-26 22:04:26 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:04:26 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:04:26 --> Utf8 Class Initialized
INFO - 2020-09-26 22:04:26 --> URI Class Initialized
INFO - 2020-09-26 22:04:26 --> Router Class Initialized
INFO - 2020-09-26 22:04:27 --> Output Class Initialized
INFO - 2020-09-26 22:04:27 --> Security Class Initialized
DEBUG - 2020-09-26 22:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:04:27 --> Input Class Initialized
INFO - 2020-09-26 22:04:27 --> Language Class Initialized
ERROR - 2020-09-26 22:04:27 --> Severity: Error --> Class 'phpseclib\Crypt\Common\AsymmetricKey' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 73
INFO - 2020-09-26 22:09:04 --> Config Class Initialized
INFO - 2020-09-26 22:09:04 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:09:04 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:09:04 --> Utf8 Class Initialized
INFO - 2020-09-26 22:09:04 --> URI Class Initialized
INFO - 2020-09-26 22:09:04 --> Router Class Initialized
INFO - 2020-09-26 22:09:04 --> Output Class Initialized
INFO - 2020-09-26 22:09:04 --> Security Class Initialized
DEBUG - 2020-09-26 22:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:09:04 --> Input Class Initialized
INFO - 2020-09-26 22:09:04 --> Language Class Initialized
INFO - 2020-09-26 22:09:04 --> Loader Class Initialized
INFO - 2020-09-26 22:09:04 --> Helper loaded: url_helper
INFO - 2020-09-26 22:09:04 --> Helper loaded: file_helper
INFO - 2020-09-26 22:09:04 --> Database Driver Class Initialized
INFO - 2020-09-26 22:09:04 --> Email Class Initialized
DEBUG - 2020-09-26 22:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:09:04 --> Controller Class Initialized
INFO - 2020-09-26 22:09:04 --> Model "Main_model" initialized
ERROR - 2020-09-26 22:09:04 --> Severity: Warning --> include_once(Math/BigInteger.php): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:09:04 --> Severity: Warning --> include_once(): Failed opening 'Math/BigInteger.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:09:05 --> Severity: error --> Exception: Class 'Math_BigInteger' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 559
INFO - 2020-09-26 22:10:05 --> Config Class Initialized
INFO - 2020-09-26 22:10:05 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:10:05 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:10:05 --> Utf8 Class Initialized
INFO - 2020-09-26 22:10:05 --> URI Class Initialized
INFO - 2020-09-26 22:10:05 --> Router Class Initialized
INFO - 2020-09-26 22:10:05 --> Output Class Initialized
INFO - 2020-09-26 22:10:05 --> Security Class Initialized
DEBUG - 2020-09-26 22:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:10:05 --> Input Class Initialized
INFO - 2020-09-26 22:10:05 --> Language Class Initialized
INFO - 2020-09-26 22:10:05 --> Loader Class Initialized
INFO - 2020-09-26 22:10:05 --> Helper loaded: url_helper
INFO - 2020-09-26 22:10:05 --> Helper loaded: file_helper
INFO - 2020-09-26 22:10:05 --> Database Driver Class Initialized
INFO - 2020-09-26 22:10:05 --> Email Class Initialized
DEBUG - 2020-09-26 22:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:10:05 --> Controller Class Initialized
INFO - 2020-09-26 22:10:05 --> Model "Main_model" initialized
ERROR - 2020-09-26 22:10:05 --> Severity: Warning --> include_once(../Math/BigInteger.php): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:10:05 --> Severity: Warning --> include_once(): Failed opening '../Math/BigInteger.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:10:05 --> Severity: error --> Exception: Class 'Math_BigInteger' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 559
INFO - 2020-09-26 22:10:24 --> Config Class Initialized
INFO - 2020-09-26 22:10:24 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:10:24 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:10:25 --> Utf8 Class Initialized
INFO - 2020-09-26 22:10:25 --> URI Class Initialized
INFO - 2020-09-26 22:10:25 --> Router Class Initialized
INFO - 2020-09-26 22:10:25 --> Output Class Initialized
INFO - 2020-09-26 22:10:25 --> Security Class Initialized
DEBUG - 2020-09-26 22:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:10:25 --> Input Class Initialized
INFO - 2020-09-26 22:10:25 --> Language Class Initialized
INFO - 2020-09-26 22:10:25 --> Loader Class Initialized
INFO - 2020-09-26 22:10:25 --> Helper loaded: url_helper
INFO - 2020-09-26 22:10:25 --> Helper loaded: file_helper
INFO - 2020-09-26 22:10:25 --> Database Driver Class Initialized
INFO - 2020-09-26 22:10:25 --> Email Class Initialized
DEBUG - 2020-09-26 22:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:10:25 --> Controller Class Initialized
INFO - 2020-09-26 22:10:25 --> Model "Main_model" initialized
ERROR - 2020-09-26 22:10:25 --> Severity: Warning --> include_once(../Math/BigInteger.php): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:10:25 --> Severity: Warning --> include_once(): Failed opening '../Math/BigInteger.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:10:25 --> Severity: error --> Exception: Class 'Math_BigInteger' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 559
INFO - 2020-09-26 22:10:37 --> Config Class Initialized
INFO - 2020-09-26 22:10:37 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:10:37 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:10:37 --> Utf8 Class Initialized
INFO - 2020-09-26 22:10:37 --> URI Class Initialized
INFO - 2020-09-26 22:10:37 --> Router Class Initialized
INFO - 2020-09-26 22:10:37 --> Output Class Initialized
INFO - 2020-09-26 22:10:37 --> Security Class Initialized
DEBUG - 2020-09-26 22:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:10:37 --> Input Class Initialized
INFO - 2020-09-26 22:10:37 --> Language Class Initialized
INFO - 2020-09-26 22:10:38 --> Loader Class Initialized
INFO - 2020-09-26 22:10:38 --> Helper loaded: url_helper
INFO - 2020-09-26 22:10:38 --> Helper loaded: file_helper
INFO - 2020-09-26 22:10:38 --> Database Driver Class Initialized
INFO - 2020-09-26 22:10:38 --> Email Class Initialized
DEBUG - 2020-09-26 22:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:10:38 --> Controller Class Initialized
INFO - 2020-09-26 22:10:38 --> Model "Main_model" initialized
ERROR - 2020-09-26 22:10:38 --> Severity: Warning --> include_once(/Math/BigInteger.php): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:10:38 --> Severity: Warning --> include_once(): Failed opening '/Math/BigInteger.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:10:38 --> Severity: error --> Exception: Class 'Math_BigInteger' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 559
INFO - 2020-09-26 22:10:58 --> Config Class Initialized
INFO - 2020-09-26 22:10:58 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:10:58 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:10:58 --> Utf8 Class Initialized
INFO - 2020-09-26 22:10:58 --> URI Class Initialized
INFO - 2020-09-26 22:10:58 --> Router Class Initialized
INFO - 2020-09-26 22:10:58 --> Output Class Initialized
INFO - 2020-09-26 22:10:58 --> Security Class Initialized
DEBUG - 2020-09-26 22:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:10:59 --> Input Class Initialized
INFO - 2020-09-26 22:10:59 --> Language Class Initialized
INFO - 2020-09-26 22:10:59 --> Loader Class Initialized
INFO - 2020-09-26 22:10:59 --> Helper loaded: url_helper
INFO - 2020-09-26 22:10:59 --> Helper loaded: file_helper
INFO - 2020-09-26 22:10:59 --> Database Driver Class Initialized
INFO - 2020-09-26 22:10:59 --> Email Class Initialized
DEBUG - 2020-09-26 22:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:10:59 --> Controller Class Initialized
INFO - 2020-09-26 22:10:59 --> Model "Main_model" initialized
ERROR - 2020-09-26 22:10:59 --> Severity: Warning --> include_once(../../Math/BigInteger.php): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:10:59 --> Severity: Warning --> include_once(): Failed opening '../../Math/BigInteger.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:10:59 --> Severity: error --> Exception: Class 'Math_BigInteger' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 559
INFO - 2020-09-26 22:11:19 --> Config Class Initialized
INFO - 2020-09-26 22:11:19 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:11:20 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:11:20 --> Utf8 Class Initialized
INFO - 2020-09-26 22:11:20 --> URI Class Initialized
INFO - 2020-09-26 22:11:20 --> Router Class Initialized
INFO - 2020-09-26 22:11:20 --> Output Class Initialized
INFO - 2020-09-26 22:11:20 --> Security Class Initialized
DEBUG - 2020-09-26 22:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:11:20 --> Input Class Initialized
INFO - 2020-09-26 22:11:20 --> Language Class Initialized
INFO - 2020-09-26 22:11:20 --> Loader Class Initialized
INFO - 2020-09-26 22:11:20 --> Helper loaded: url_helper
INFO - 2020-09-26 22:11:20 --> Helper loaded: file_helper
INFO - 2020-09-26 22:11:20 --> Database Driver Class Initialized
INFO - 2020-09-26 22:11:20 --> Email Class Initialized
DEBUG - 2020-09-26 22:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:11:20 --> Controller Class Initialized
INFO - 2020-09-26 22:11:20 --> Model "Main_model" initialized
ERROR - 2020-09-26 22:11:20 --> Severity: Warning --> include_once(../../../Math/BigInteger.php): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:11:20 --> Severity: Warning --> include_once(): Failed opening '../../../Math/BigInteger.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:11:20 --> Severity: error --> Exception: Class 'Math_BigInteger' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 559
INFO - 2020-09-26 22:11:21 --> Config Class Initialized
INFO - 2020-09-26 22:11:21 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:11:21 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:11:21 --> Utf8 Class Initialized
INFO - 2020-09-26 22:11:21 --> URI Class Initialized
INFO - 2020-09-26 22:11:21 --> Router Class Initialized
INFO - 2020-09-26 22:11:21 --> Output Class Initialized
INFO - 2020-09-26 22:11:21 --> Security Class Initialized
DEBUG - 2020-09-26 22:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:11:21 --> Input Class Initialized
INFO - 2020-09-26 22:11:21 --> Language Class Initialized
INFO - 2020-09-26 22:11:22 --> Loader Class Initialized
INFO - 2020-09-26 22:11:22 --> Helper loaded: url_helper
INFO - 2020-09-26 22:11:22 --> Helper loaded: file_helper
INFO - 2020-09-26 22:11:22 --> Database Driver Class Initialized
INFO - 2020-09-26 22:11:22 --> Email Class Initialized
DEBUG - 2020-09-26 22:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:11:22 --> Controller Class Initialized
INFO - 2020-09-26 22:11:22 --> Model "Main_model" initialized
ERROR - 2020-09-26 22:11:22 --> Severity: Warning --> include_once(../../../Math/BigInteger.php): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:11:22 --> Severity: Warning --> include_once(): Failed opening '../../../Math/BigInteger.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:11:22 --> Severity: error --> Exception: Class 'Math_BigInteger' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 559
INFO - 2020-09-26 22:11:31 --> Config Class Initialized
INFO - 2020-09-26 22:11:31 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:11:31 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:11:31 --> Utf8 Class Initialized
INFO - 2020-09-26 22:11:31 --> URI Class Initialized
INFO - 2020-09-26 22:11:31 --> Router Class Initialized
INFO - 2020-09-26 22:11:31 --> Output Class Initialized
INFO - 2020-09-26 22:11:31 --> Security Class Initialized
DEBUG - 2020-09-26 22:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:11:31 --> Input Class Initialized
INFO - 2020-09-26 22:11:32 --> Language Class Initialized
INFO - 2020-09-26 22:11:32 --> Loader Class Initialized
INFO - 2020-09-26 22:11:32 --> Helper loaded: url_helper
INFO - 2020-09-26 22:11:32 --> Helper loaded: file_helper
INFO - 2020-09-26 22:11:32 --> Database Driver Class Initialized
INFO - 2020-09-26 22:11:32 --> Email Class Initialized
DEBUG - 2020-09-26 22:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:11:32 --> Controller Class Initialized
INFO - 2020-09-26 22:11:32 --> Model "Main_model" initialized
ERROR - 2020-09-26 22:11:32 --> Severity: Warning --> include_once(/../Math/BigInteger.php): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:11:32 --> Severity: Warning --> include_once(): Failed opening '/../Math/BigInteger.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:11:32 --> Severity: error --> Exception: Class 'Math_BigInteger' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 559
INFO - 2020-09-26 22:12:32 --> Config Class Initialized
INFO - 2020-09-26 22:12:32 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:12:32 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:12:32 --> Utf8 Class Initialized
INFO - 2020-09-26 22:12:32 --> URI Class Initialized
INFO - 2020-09-26 22:12:32 --> Router Class Initialized
INFO - 2020-09-26 22:12:32 --> Output Class Initialized
INFO - 2020-09-26 22:12:32 --> Security Class Initialized
DEBUG - 2020-09-26 22:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:12:32 --> Input Class Initialized
INFO - 2020-09-26 22:12:32 --> Language Class Initialized
INFO - 2020-09-26 22:12:32 --> Loader Class Initialized
INFO - 2020-09-26 22:12:32 --> Helper loaded: url_helper
INFO - 2020-09-26 22:12:32 --> Helper loaded: file_helper
INFO - 2020-09-26 22:12:32 --> Database Driver Class Initialized
INFO - 2020-09-26 22:12:33 --> Email Class Initialized
DEBUG - 2020-09-26 22:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:12:33 --> Controller Class Initialized
INFO - 2020-09-26 22:12:33 --> Model "Main_model" initialized
ERROR - 2020-09-26 22:12:33 --> Severity: Warning --> include_once(../Math/BigInteger.php): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:12:33 --> Severity: Warning --> include_once(): Failed opening '../Math/BigInteger.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:12:33 --> Severity: error --> Exception: Class 'Math_BigInteger' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 559
INFO - 2020-09-26 22:13:44 --> Config Class Initialized
INFO - 2020-09-26 22:13:44 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:13:44 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:13:44 --> Utf8 Class Initialized
INFO - 2020-09-26 22:13:44 --> URI Class Initialized
INFO - 2020-09-26 22:13:44 --> Router Class Initialized
INFO - 2020-09-26 22:13:44 --> Output Class Initialized
INFO - 2020-09-26 22:13:44 --> Security Class Initialized
DEBUG - 2020-09-26 22:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:13:44 --> Input Class Initialized
INFO - 2020-09-26 22:13:44 --> Language Class Initialized
INFO - 2020-09-26 22:13:44 --> Loader Class Initialized
INFO - 2020-09-26 22:13:44 --> Helper loaded: url_helper
INFO - 2020-09-26 22:13:44 --> Helper loaded: file_helper
INFO - 2020-09-26 22:13:44 --> Database Driver Class Initialized
INFO - 2020-09-26 22:13:44 --> Email Class Initialized
DEBUG - 2020-09-26 22:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:13:44 --> Controller Class Initialized
INFO - 2020-09-26 22:13:44 --> Model "Main_model" initialized
ERROR - 2020-09-26 22:13:44 --> Severity: Warning --> include_once(../Math/BigInteger.php): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:13:44 --> Severity: Warning --> include_once(): Failed opening '../Math/BigInteger.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:13:44 --> Severity: error --> Exception: Class 'Math_BigInteger' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 559
INFO - 2020-09-26 22:13:46 --> Config Class Initialized
INFO - 2020-09-26 22:13:46 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:13:46 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:13:46 --> Utf8 Class Initialized
INFO - 2020-09-26 22:13:46 --> URI Class Initialized
INFO - 2020-09-26 22:13:46 --> Router Class Initialized
INFO - 2020-09-26 22:13:46 --> Output Class Initialized
INFO - 2020-09-26 22:13:46 --> Security Class Initialized
DEBUG - 2020-09-26 22:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:13:46 --> Input Class Initialized
INFO - 2020-09-26 22:13:46 --> Language Class Initialized
INFO - 2020-09-26 22:13:46 --> Loader Class Initialized
INFO - 2020-09-26 22:13:46 --> Helper loaded: url_helper
INFO - 2020-09-26 22:13:46 --> Helper loaded: file_helper
INFO - 2020-09-26 22:13:46 --> Database Driver Class Initialized
INFO - 2020-09-26 22:13:46 --> Email Class Initialized
DEBUG - 2020-09-26 22:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:13:46 --> Controller Class Initialized
INFO - 2020-09-26 22:13:46 --> Model "Main_model" initialized
ERROR - 2020-09-26 22:13:46 --> Severity: Warning --> include_once(../Math/BigInteger.php): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:13:46 --> Severity: Warning --> include_once(): Failed opening '../Math/BigInteger.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 501
ERROR - 2020-09-26 22:13:46 --> Severity: error --> Exception: Class 'Math_BigInteger' not found C:\xampp\htdocs\dmarc\application\libraries\phpseclib\Crypt\RSA.php 559
INFO - 2020-09-26 22:13:53 --> Config Class Initialized
INFO - 2020-09-26 22:13:53 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:13:53 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:13:53 --> Utf8 Class Initialized
INFO - 2020-09-26 22:13:53 --> URI Class Initialized
INFO - 2020-09-26 22:13:53 --> Router Class Initialized
INFO - 2020-09-26 22:13:53 --> Output Class Initialized
INFO - 2020-09-26 22:13:53 --> Security Class Initialized
DEBUG - 2020-09-26 22:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:13:53 --> Input Class Initialized
INFO - 2020-09-26 22:13:53 --> Language Class Initialized
INFO - 2020-09-26 22:13:53 --> Loader Class Initialized
INFO - 2020-09-26 22:13:53 --> Helper loaded: url_helper
INFO - 2020-09-26 22:13:53 --> Helper loaded: file_helper
INFO - 2020-09-26 22:13:53 --> Database Driver Class Initialized
INFO - 2020-09-26 22:13:53 --> Email Class Initialized
DEBUG - 2020-09-26 22:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:13:53 --> Controller Class Initialized
INFO - 2020-09-26 22:13:53 --> Model "Main_model" initialized
INFO - 2020-09-26 22:13:53 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:13:53 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:13:53 --> Final output sent to browser
DEBUG - 2020-09-26 22:13:53 --> Total execution time: 0.6325
INFO - 2020-09-26 22:15:28 --> Config Class Initialized
INFO - 2020-09-26 22:15:28 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:15:28 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:15:28 --> Utf8 Class Initialized
INFO - 2020-09-26 22:15:28 --> URI Class Initialized
INFO - 2020-09-26 22:15:28 --> Router Class Initialized
INFO - 2020-09-26 22:15:28 --> Output Class Initialized
INFO - 2020-09-26 22:15:28 --> Security Class Initialized
DEBUG - 2020-09-26 22:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:15:28 --> Input Class Initialized
INFO - 2020-09-26 22:15:28 --> Language Class Initialized
INFO - 2020-09-26 22:15:28 --> Loader Class Initialized
INFO - 2020-09-26 22:15:28 --> Helper loaded: url_helper
INFO - 2020-09-26 22:15:28 --> Helper loaded: file_helper
INFO - 2020-09-26 22:15:28 --> Database Driver Class Initialized
INFO - 2020-09-26 22:15:28 --> Email Class Initialized
DEBUG - 2020-09-26 22:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:15:29 --> Controller Class Initialized
INFO - 2020-09-26 22:15:29 --> Model "Main_model" initialized
INFO - 2020-09-26 22:20:18 --> Config Class Initialized
INFO - 2020-09-26 22:20:18 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:20:18 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:20:18 --> Utf8 Class Initialized
INFO - 2020-09-26 22:20:18 --> URI Class Initialized
INFO - 2020-09-26 22:20:18 --> Router Class Initialized
INFO - 2020-09-26 22:20:18 --> Output Class Initialized
INFO - 2020-09-26 22:20:18 --> Security Class Initialized
DEBUG - 2020-09-26 22:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:20:18 --> Input Class Initialized
INFO - 2020-09-26 22:20:18 --> Language Class Initialized
INFO - 2020-09-26 22:20:18 --> Loader Class Initialized
INFO - 2020-09-26 22:20:18 --> Helper loaded: url_helper
INFO - 2020-09-26 22:20:18 --> Helper loaded: file_helper
INFO - 2020-09-26 22:20:18 --> Database Driver Class Initialized
INFO - 2020-09-26 22:20:18 --> Email Class Initialized
DEBUG - 2020-09-26 22:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:20:18 --> Controller Class Initialized
INFO - 2020-09-26 22:20:18 --> Model "Main_model" initialized
INFO - 2020-09-26 22:20:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:20:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 22:20:18 --> Final output sent to browser
DEBUG - 2020-09-26 22:20:18 --> Total execution time: 0.7032
INFO - 2020-09-26 22:20:23 --> Config Class Initialized
INFO - 2020-09-26 22:20:23 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:20:23 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:20:23 --> Utf8 Class Initialized
INFO - 2020-09-26 22:20:23 --> URI Class Initialized
INFO - 2020-09-26 22:20:23 --> Router Class Initialized
INFO - 2020-09-26 22:20:23 --> Output Class Initialized
INFO - 2020-09-26 22:20:23 --> Security Class Initialized
DEBUG - 2020-09-26 22:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:20:23 --> Input Class Initialized
INFO - 2020-09-26 22:20:23 --> Language Class Initialized
INFO - 2020-09-26 22:20:23 --> Loader Class Initialized
INFO - 2020-09-26 22:20:23 --> Helper loaded: url_helper
INFO - 2020-09-26 22:20:23 --> Helper loaded: file_helper
INFO - 2020-09-26 22:20:23 --> Database Driver Class Initialized
INFO - 2020-09-26 22:20:23 --> Email Class Initialized
DEBUG - 2020-09-26 22:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:20:23 --> Controller Class Initialized
INFO - 2020-09-26 22:20:23 --> Model "Main_model" initialized
ERROR - 2020-09-26 22:20:23 --> Severity: Warning --> openssl_pkey_export_to_file(): cannot get key from parameter 1 C:\xampp\htdocs\dmarc\application\controllers\Home.php 116
ERROR - 2020-09-26 22:20:23 --> Severity: Warning --> openssl_pkey_get_details() expects parameter 1 to be resource, boolean given C:\xampp\htdocs\dmarc\application\controllers\Home.php 118
ERROR - 2020-09-26 22:20:23 --> Severity: Warning --> file_get_contents(s1_dkim_private.pem): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\controllers\Home.php 121
ERROR - 2020-09-26 22:20:23 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\dmarc\application\controllers\Home.php 152
INFO - 2020-09-26 22:20:23 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:20:23 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:20:23 --> Final output sent to browser
DEBUG - 2020-09-26 22:20:23 --> Total execution time: 0.4885
INFO - 2020-09-26 22:41:41 --> Config Class Initialized
INFO - 2020-09-26 22:41:41 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:41:41 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:41:41 --> Utf8 Class Initialized
INFO - 2020-09-26 22:41:41 --> URI Class Initialized
INFO - 2020-09-26 22:41:41 --> Router Class Initialized
INFO - 2020-09-26 22:41:41 --> Output Class Initialized
INFO - 2020-09-26 22:41:41 --> Security Class Initialized
DEBUG - 2020-09-26 22:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:41:42 --> Input Class Initialized
INFO - 2020-09-26 22:41:42 --> Language Class Initialized
INFO - 2020-09-26 22:41:42 --> Loader Class Initialized
INFO - 2020-09-26 22:41:42 --> Helper loaded: url_helper
INFO - 2020-09-26 22:41:42 --> Helper loaded: file_helper
INFO - 2020-09-26 22:41:42 --> Database Driver Class Initialized
INFO - 2020-09-26 22:41:42 --> Email Class Initialized
DEBUG - 2020-09-26 22:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:41:42 --> Controller Class Initialized
INFO - 2020-09-26 22:41:42 --> Model "Main_model" initialized
INFO - 2020-09-26 22:41:42 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:41:42 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:41:42 --> Final output sent to browser
DEBUG - 2020-09-26 22:41:42 --> Total execution time: 0.4257
INFO - 2020-09-26 22:44:43 --> Config Class Initialized
INFO - 2020-09-26 22:44:43 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:44:43 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:44:43 --> Utf8 Class Initialized
INFO - 2020-09-26 22:44:43 --> URI Class Initialized
INFO - 2020-09-26 22:44:43 --> Router Class Initialized
INFO - 2020-09-26 22:44:43 --> Output Class Initialized
INFO - 2020-09-26 22:44:43 --> Security Class Initialized
DEBUG - 2020-09-26 22:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:44:43 --> Input Class Initialized
INFO - 2020-09-26 22:44:43 --> Language Class Initialized
INFO - 2020-09-26 22:44:43 --> Loader Class Initialized
INFO - 2020-09-26 22:44:43 --> Helper loaded: url_helper
INFO - 2020-09-26 22:44:43 --> Helper loaded: file_helper
INFO - 2020-09-26 22:44:44 --> Database Driver Class Initialized
INFO - 2020-09-26 22:44:44 --> Email Class Initialized
DEBUG - 2020-09-26 22:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:44:44 --> Controller Class Initialized
INFO - 2020-09-26 22:44:44 --> Model "Main_model" initialized
INFO - 2020-09-26 22:44:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:44:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:44:44 --> Final output sent to browser
DEBUG - 2020-09-26 22:44:44 --> Total execution time: 0.4450
INFO - 2020-09-26 22:44:53 --> Config Class Initialized
INFO - 2020-09-26 22:44:53 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:44:53 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:44:53 --> Utf8 Class Initialized
INFO - 2020-09-26 22:44:53 --> URI Class Initialized
INFO - 2020-09-26 22:44:53 --> Router Class Initialized
INFO - 2020-09-26 22:44:53 --> Output Class Initialized
INFO - 2020-09-26 22:44:53 --> Security Class Initialized
DEBUG - 2020-09-26 22:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:44:53 --> Input Class Initialized
INFO - 2020-09-26 22:44:53 --> Language Class Initialized
INFO - 2020-09-26 22:44:53 --> Loader Class Initialized
INFO - 2020-09-26 22:44:53 --> Helper loaded: url_helper
INFO - 2020-09-26 22:44:53 --> Helper loaded: file_helper
INFO - 2020-09-26 22:44:53 --> Database Driver Class Initialized
INFO - 2020-09-26 22:44:53 --> Email Class Initialized
DEBUG - 2020-09-26 22:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:44:53 --> Controller Class Initialized
INFO - 2020-09-26 22:44:53 --> Model "Main_model" initialized
INFO - 2020-09-26 22:44:53 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:44:53 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:44:53 --> Final output sent to browser
DEBUG - 2020-09-26 22:44:53 --> Total execution time: 0.4455
INFO - 2020-09-26 22:44:57 --> Config Class Initialized
INFO - 2020-09-26 22:44:57 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:44:57 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:44:57 --> Utf8 Class Initialized
INFO - 2020-09-26 22:44:57 --> URI Class Initialized
INFO - 2020-09-26 22:44:57 --> Router Class Initialized
INFO - 2020-09-26 22:44:57 --> Output Class Initialized
INFO - 2020-09-26 22:44:57 --> Security Class Initialized
DEBUG - 2020-09-26 22:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:44:57 --> Input Class Initialized
INFO - 2020-09-26 22:44:57 --> Language Class Initialized
INFO - 2020-09-26 22:44:57 --> Loader Class Initialized
INFO - 2020-09-26 22:44:57 --> Helper loaded: url_helper
INFO - 2020-09-26 22:44:57 --> Helper loaded: file_helper
INFO - 2020-09-26 22:44:57 --> Database Driver Class Initialized
INFO - 2020-09-26 22:44:57 --> Email Class Initialized
DEBUG - 2020-09-26 22:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:44:58 --> Controller Class Initialized
INFO - 2020-09-26 22:44:58 --> Model "Main_model" initialized
INFO - 2020-09-26 22:44:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:44:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:44:58 --> Final output sent to browser
DEBUG - 2020-09-26 22:44:58 --> Total execution time: 0.5073
INFO - 2020-09-26 22:45:08 --> Config Class Initialized
INFO - 2020-09-26 22:45:08 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:45:08 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:45:09 --> Utf8 Class Initialized
INFO - 2020-09-26 22:45:09 --> URI Class Initialized
INFO - 2020-09-26 22:45:09 --> Router Class Initialized
INFO - 2020-09-26 22:45:09 --> Output Class Initialized
INFO - 2020-09-26 22:45:09 --> Security Class Initialized
DEBUG - 2020-09-26 22:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:45:09 --> Input Class Initialized
INFO - 2020-09-26 22:45:09 --> Language Class Initialized
ERROR - 2020-09-26 22:45:09 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 22:46:21 --> Config Class Initialized
INFO - 2020-09-26 22:46:21 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:46:21 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:46:21 --> Utf8 Class Initialized
INFO - 2020-09-26 22:46:21 --> URI Class Initialized
INFO - 2020-09-26 22:46:21 --> Router Class Initialized
INFO - 2020-09-26 22:46:21 --> Output Class Initialized
INFO - 2020-09-26 22:46:21 --> Security Class Initialized
DEBUG - 2020-09-26 22:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:46:21 --> Input Class Initialized
INFO - 2020-09-26 22:46:21 --> Language Class Initialized
INFO - 2020-09-26 22:46:21 --> Loader Class Initialized
INFO - 2020-09-26 22:46:21 --> Helper loaded: url_helper
INFO - 2020-09-26 22:46:21 --> Helper loaded: file_helper
INFO - 2020-09-26 22:46:21 --> Database Driver Class Initialized
INFO - 2020-09-26 22:46:21 --> Email Class Initialized
DEBUG - 2020-09-26 22:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:46:21 --> Controller Class Initialized
INFO - 2020-09-26 22:46:21 --> Model "Main_model" initialized
INFO - 2020-09-26 22:46:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-26 22:46:21 --> Severity: Notice --> Undefined index: private_key C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php 153
ERROR - 2020-09-26 22:46:21 --> Severity: Notice --> Undefined index: public_key C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php 160
INFO - 2020-09-26 22:46:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:46:21 --> Final output sent to browser
DEBUG - 2020-09-26 22:46:21 --> Total execution time: 0.5973
INFO - 2020-09-26 22:46:22 --> Config Class Initialized
INFO - 2020-09-26 22:46:22 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:46:23 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:46:23 --> Utf8 Class Initialized
INFO - 2020-09-26 22:46:23 --> URI Class Initialized
INFO - 2020-09-26 22:46:23 --> Router Class Initialized
INFO - 2020-09-26 22:46:23 --> Output Class Initialized
INFO - 2020-09-26 22:46:23 --> Security Class Initialized
DEBUG - 2020-09-26 22:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:46:23 --> Input Class Initialized
INFO - 2020-09-26 22:46:23 --> Language Class Initialized
ERROR - 2020-09-26 22:46:23 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 22:46:27 --> Config Class Initialized
INFO - 2020-09-26 22:46:27 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:46:28 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:46:28 --> Utf8 Class Initialized
INFO - 2020-09-26 22:46:28 --> URI Class Initialized
INFO - 2020-09-26 22:46:28 --> Router Class Initialized
INFO - 2020-09-26 22:46:28 --> Output Class Initialized
INFO - 2020-09-26 22:46:28 --> Security Class Initialized
DEBUG - 2020-09-26 22:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:46:28 --> Input Class Initialized
INFO - 2020-09-26 22:46:28 --> Language Class Initialized
INFO - 2020-09-26 22:46:28 --> Loader Class Initialized
INFO - 2020-09-26 22:46:28 --> Helper loaded: url_helper
INFO - 2020-09-26 22:46:28 --> Helper loaded: file_helper
INFO - 2020-09-26 22:46:28 --> Database Driver Class Initialized
INFO - 2020-09-26 22:46:28 --> Email Class Initialized
DEBUG - 2020-09-26 22:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:46:28 --> Controller Class Initialized
INFO - 2020-09-26 22:46:28 --> Model "Main_model" initialized
INFO - 2020-09-26 22:46:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-26 22:46:28 --> Severity: Notice --> Undefined index: private_key C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php 153
ERROR - 2020-09-26 22:46:28 --> Severity: Notice --> Undefined index: public_key C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php 160
INFO - 2020-09-26 22:46:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:46:28 --> Final output sent to browser
DEBUG - 2020-09-26 22:46:28 --> Total execution time: 0.6141
INFO - 2020-09-26 22:46:29 --> Config Class Initialized
INFO - 2020-09-26 22:46:29 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:46:29 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:46:29 --> Utf8 Class Initialized
INFO - 2020-09-26 22:46:29 --> URI Class Initialized
INFO - 2020-09-26 22:46:29 --> Router Class Initialized
INFO - 2020-09-26 22:46:29 --> Output Class Initialized
INFO - 2020-09-26 22:46:29 --> Security Class Initialized
DEBUG - 2020-09-26 22:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:46:29 --> Input Class Initialized
INFO - 2020-09-26 22:46:29 --> Language Class Initialized
ERROR - 2020-09-26 22:46:29 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 22:46:47 --> Config Class Initialized
INFO - 2020-09-26 22:46:47 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:46:47 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:46:48 --> Utf8 Class Initialized
INFO - 2020-09-26 22:46:48 --> URI Class Initialized
INFO - 2020-09-26 22:46:48 --> Router Class Initialized
INFO - 2020-09-26 22:46:48 --> Output Class Initialized
INFO - 2020-09-26 22:46:48 --> Security Class Initialized
DEBUG - 2020-09-26 22:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:46:48 --> Input Class Initialized
INFO - 2020-09-26 22:46:48 --> Language Class Initialized
INFO - 2020-09-26 22:46:48 --> Loader Class Initialized
INFO - 2020-09-26 22:46:48 --> Helper loaded: url_helper
INFO - 2020-09-26 22:46:48 --> Helper loaded: file_helper
INFO - 2020-09-26 22:46:48 --> Database Driver Class Initialized
INFO - 2020-09-26 22:46:48 --> Email Class Initialized
DEBUG - 2020-09-26 22:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:46:48 --> Controller Class Initialized
INFO - 2020-09-26 22:46:48 --> Model "Main_model" initialized
INFO - 2020-09-26 22:46:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:46:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:46:48 --> Final output sent to browser
DEBUG - 2020-09-26 22:46:48 --> Total execution time: 0.4523
INFO - 2020-09-26 22:46:49 --> Config Class Initialized
INFO - 2020-09-26 22:46:49 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:46:49 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:46:49 --> Utf8 Class Initialized
INFO - 2020-09-26 22:46:49 --> URI Class Initialized
INFO - 2020-09-26 22:46:49 --> Router Class Initialized
INFO - 2020-09-26 22:46:49 --> Output Class Initialized
INFO - 2020-09-26 22:46:49 --> Security Class Initialized
DEBUG - 2020-09-26 22:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:46:49 --> Input Class Initialized
INFO - 2020-09-26 22:46:49 --> Language Class Initialized
ERROR - 2020-09-26 22:46:49 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 22:46:53 --> Config Class Initialized
INFO - 2020-09-26 22:46:53 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:46:53 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:46:53 --> Utf8 Class Initialized
INFO - 2020-09-26 22:46:53 --> URI Class Initialized
INFO - 2020-09-26 22:46:53 --> Router Class Initialized
INFO - 2020-09-26 22:46:53 --> Output Class Initialized
INFO - 2020-09-26 22:46:53 --> Security Class Initialized
DEBUG - 2020-09-26 22:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:46:53 --> Input Class Initialized
INFO - 2020-09-26 22:46:53 --> Language Class Initialized
INFO - 2020-09-26 22:46:53 --> Loader Class Initialized
INFO - 2020-09-26 22:46:53 --> Helper loaded: url_helper
INFO - 2020-09-26 22:46:53 --> Helper loaded: file_helper
INFO - 2020-09-26 22:46:53 --> Database Driver Class Initialized
INFO - 2020-09-26 22:46:53 --> Email Class Initialized
DEBUG - 2020-09-26 22:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:46:53 --> Controller Class Initialized
INFO - 2020-09-26 22:46:53 --> Model "Main_model" initialized
INFO - 2020-09-26 22:46:53 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-26 22:46:53 --> Severity: Notice --> Undefined index: private_key C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php 154
ERROR - 2020-09-26 22:46:53 --> Severity: Notice --> Undefined index: public_key C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php 161
INFO - 2020-09-26 22:46:53 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:46:53 --> Final output sent to browser
DEBUG - 2020-09-26 22:46:53 --> Total execution time: 0.5466
INFO - 2020-09-26 22:46:54 --> Config Class Initialized
INFO - 2020-09-26 22:46:54 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:46:54 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:46:54 --> Utf8 Class Initialized
INFO - 2020-09-26 22:46:54 --> URI Class Initialized
INFO - 2020-09-26 22:46:54 --> Router Class Initialized
INFO - 2020-09-26 22:46:54 --> Output Class Initialized
INFO - 2020-09-26 22:46:54 --> Security Class Initialized
DEBUG - 2020-09-26 22:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:46:54 --> Input Class Initialized
INFO - 2020-09-26 22:46:54 --> Language Class Initialized
ERROR - 2020-09-26 22:46:54 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 22:47:18 --> Config Class Initialized
INFO - 2020-09-26 22:47:18 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:47:18 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:47:18 --> Utf8 Class Initialized
INFO - 2020-09-26 22:47:18 --> URI Class Initialized
INFO - 2020-09-26 22:47:18 --> Router Class Initialized
INFO - 2020-09-26 22:47:18 --> Output Class Initialized
INFO - 2020-09-26 22:47:18 --> Security Class Initialized
DEBUG - 2020-09-26 22:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:47:18 --> Input Class Initialized
INFO - 2020-09-26 22:47:18 --> Language Class Initialized
INFO - 2020-09-26 22:47:18 --> Loader Class Initialized
INFO - 2020-09-26 22:47:18 --> Helper loaded: url_helper
INFO - 2020-09-26 22:47:18 --> Helper loaded: file_helper
INFO - 2020-09-26 22:47:18 --> Database Driver Class Initialized
INFO - 2020-09-26 22:47:18 --> Email Class Initialized
DEBUG - 2020-09-26 22:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:47:18 --> Controller Class Initialized
INFO - 2020-09-26 22:47:18 --> Model "Main_model" initialized
INFO - 2020-09-26 22:47:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:47:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:47:18 --> Final output sent to browser
DEBUG - 2020-09-26 22:47:18 --> Total execution time: 0.4170
INFO - 2020-09-26 22:47:22 --> Config Class Initialized
INFO - 2020-09-26 22:47:22 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:47:23 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:47:23 --> Utf8 Class Initialized
INFO - 2020-09-26 22:47:23 --> URI Class Initialized
INFO - 2020-09-26 22:47:23 --> Router Class Initialized
INFO - 2020-09-26 22:47:23 --> Output Class Initialized
INFO - 2020-09-26 22:47:23 --> Security Class Initialized
DEBUG - 2020-09-26 22:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:47:23 --> Input Class Initialized
INFO - 2020-09-26 22:47:23 --> Language Class Initialized
INFO - 2020-09-26 22:47:23 --> Loader Class Initialized
INFO - 2020-09-26 22:47:23 --> Helper loaded: url_helper
INFO - 2020-09-26 22:47:23 --> Helper loaded: file_helper
INFO - 2020-09-26 22:47:23 --> Database Driver Class Initialized
INFO - 2020-09-26 22:47:23 --> Email Class Initialized
DEBUG - 2020-09-26 22:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:47:23 --> Controller Class Initialized
INFO - 2020-09-26 22:47:23 --> Model "Main_model" initialized
INFO - 2020-09-26 22:47:23 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:47:23 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:47:23 --> Final output sent to browser
DEBUG - 2020-09-26 22:47:23 --> Total execution time: 0.5254
INFO - 2020-09-26 22:47:46 --> Config Class Initialized
INFO - 2020-09-26 22:47:46 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:47:46 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:47:46 --> Utf8 Class Initialized
INFO - 2020-09-26 22:47:46 --> URI Class Initialized
INFO - 2020-09-26 22:47:46 --> Router Class Initialized
INFO - 2020-09-26 22:47:46 --> Output Class Initialized
INFO - 2020-09-26 22:47:46 --> Security Class Initialized
DEBUG - 2020-09-26 22:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:47:46 --> Input Class Initialized
INFO - 2020-09-26 22:47:46 --> Language Class Initialized
ERROR - 2020-09-26 22:47:46 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 22:50:30 --> Config Class Initialized
INFO - 2020-09-26 22:50:30 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:50:30 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:50:30 --> Utf8 Class Initialized
INFO - 2020-09-26 22:50:30 --> URI Class Initialized
INFO - 2020-09-26 22:50:30 --> Router Class Initialized
INFO - 2020-09-26 22:50:30 --> Output Class Initialized
INFO - 2020-09-26 22:50:30 --> Security Class Initialized
DEBUG - 2020-09-26 22:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:50:30 --> Input Class Initialized
INFO - 2020-09-26 22:50:30 --> Language Class Initialized
INFO - 2020-09-26 22:50:30 --> Loader Class Initialized
INFO - 2020-09-26 22:50:30 --> Helper loaded: url_helper
INFO - 2020-09-26 22:50:30 --> Helper loaded: file_helper
INFO - 2020-09-26 22:50:30 --> Database Driver Class Initialized
INFO - 2020-09-26 22:50:30 --> Email Class Initialized
DEBUG - 2020-09-26 22:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:50:30 --> Controller Class Initialized
INFO - 2020-09-26 22:50:30 --> Model "Main_model" initialized
INFO - 2020-09-26 22:50:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:50:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:50:30 --> Final output sent to browser
DEBUG - 2020-09-26 22:50:30 --> Total execution time: 0.5717
INFO - 2020-09-26 22:51:20 --> Config Class Initialized
INFO - 2020-09-26 22:51:20 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:51:20 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:51:20 --> Utf8 Class Initialized
INFO - 2020-09-26 22:51:20 --> URI Class Initialized
INFO - 2020-09-26 22:51:20 --> Router Class Initialized
INFO - 2020-09-26 22:51:20 --> Output Class Initialized
INFO - 2020-09-26 22:51:20 --> Security Class Initialized
DEBUG - 2020-09-26 22:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:51:20 --> Input Class Initialized
INFO - 2020-09-26 22:51:20 --> Language Class Initialized
ERROR - 2020-09-26 22:51:20 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 22:51:49 --> Config Class Initialized
INFO - 2020-09-26 22:51:49 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:51:49 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:51:49 --> Utf8 Class Initialized
INFO - 2020-09-26 22:51:49 --> URI Class Initialized
INFO - 2020-09-26 22:51:49 --> Router Class Initialized
INFO - 2020-09-26 22:51:49 --> Output Class Initialized
INFO - 2020-09-26 22:51:49 --> Security Class Initialized
DEBUG - 2020-09-26 22:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:51:49 --> Input Class Initialized
INFO - 2020-09-26 22:51:49 --> Language Class Initialized
ERROR - 2020-09-26 22:51:49 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 22:52:44 --> Config Class Initialized
INFO - 2020-09-26 22:52:44 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:52:44 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:52:44 --> Utf8 Class Initialized
INFO - 2020-09-26 22:52:44 --> URI Class Initialized
INFO - 2020-09-26 22:52:44 --> Router Class Initialized
INFO - 2020-09-26 22:52:44 --> Output Class Initialized
INFO - 2020-09-26 22:52:44 --> Security Class Initialized
DEBUG - 2020-09-26 22:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:52:44 --> Input Class Initialized
INFO - 2020-09-26 22:52:44 --> Language Class Initialized
INFO - 2020-09-26 22:52:44 --> Loader Class Initialized
INFO - 2020-09-26 22:52:44 --> Helper loaded: url_helper
INFO - 2020-09-26 22:52:44 --> Helper loaded: file_helper
INFO - 2020-09-26 22:52:44 --> Database Driver Class Initialized
INFO - 2020-09-26 22:52:44 --> Email Class Initialized
DEBUG - 2020-09-26 22:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:52:44 --> Controller Class Initialized
INFO - 2020-09-26 22:52:44 --> Model "Main_model" initialized
INFO - 2020-09-26 22:52:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:52:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:52:44 --> Final output sent to browser
DEBUG - 2020-09-26 22:52:44 --> Total execution time: 0.5563
INFO - 2020-09-26 22:52:49 --> Config Class Initialized
INFO - 2020-09-26 22:52:49 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:52:49 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:52:49 --> Utf8 Class Initialized
INFO - 2020-09-26 22:52:49 --> URI Class Initialized
INFO - 2020-09-26 22:52:49 --> Router Class Initialized
INFO - 2020-09-26 22:52:49 --> Output Class Initialized
INFO - 2020-09-26 22:52:49 --> Security Class Initialized
DEBUG - 2020-09-26 22:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:52:49 --> Input Class Initialized
INFO - 2020-09-26 22:52:49 --> Language Class Initialized
ERROR - 2020-09-26 22:52:49 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 22:53:16 --> Config Class Initialized
INFO - 2020-09-26 22:53:16 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:53:16 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:53:16 --> Utf8 Class Initialized
INFO - 2020-09-26 22:53:16 --> URI Class Initialized
INFO - 2020-09-26 22:53:16 --> Router Class Initialized
INFO - 2020-09-26 22:53:16 --> Output Class Initialized
INFO - 2020-09-26 22:53:16 --> Security Class Initialized
DEBUG - 2020-09-26 22:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:53:16 --> Input Class Initialized
INFO - 2020-09-26 22:53:16 --> Language Class Initialized
INFO - 2020-09-26 22:53:16 --> Loader Class Initialized
INFO - 2020-09-26 22:53:16 --> Helper loaded: url_helper
INFO - 2020-09-26 22:53:16 --> Helper loaded: file_helper
INFO - 2020-09-26 22:53:16 --> Database Driver Class Initialized
INFO - 2020-09-26 22:53:16 --> Email Class Initialized
DEBUG - 2020-09-26 22:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:53:16 --> Controller Class Initialized
INFO - 2020-09-26 22:53:16 --> Model "Main_model" initialized
INFO - 2020-09-26 22:53:16 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:53:16 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:53:16 --> Final output sent to browser
DEBUG - 2020-09-26 22:53:16 --> Total execution time: 0.5073
INFO - 2020-09-26 22:53:17 --> Config Class Initialized
INFO - 2020-09-26 22:53:17 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:53:17 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:53:17 --> Utf8 Class Initialized
INFO - 2020-09-26 22:53:17 --> URI Class Initialized
INFO - 2020-09-26 22:53:17 --> Router Class Initialized
INFO - 2020-09-26 22:53:17 --> Output Class Initialized
INFO - 2020-09-26 22:53:17 --> Security Class Initialized
DEBUG - 2020-09-26 22:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:53:17 --> Input Class Initialized
INFO - 2020-09-26 22:53:17 --> Language Class Initialized
ERROR - 2020-09-26 22:53:18 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 22:54:08 --> Config Class Initialized
INFO - 2020-09-26 22:54:08 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:54:08 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:54:08 --> Utf8 Class Initialized
INFO - 2020-09-26 22:54:08 --> URI Class Initialized
INFO - 2020-09-26 22:54:08 --> Router Class Initialized
INFO - 2020-09-26 22:54:08 --> Output Class Initialized
INFO - 2020-09-26 22:54:08 --> Security Class Initialized
DEBUG - 2020-09-26 22:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:54:08 --> Input Class Initialized
INFO - 2020-09-26 22:54:08 --> Language Class Initialized
INFO - 2020-09-26 22:54:08 --> Loader Class Initialized
INFO - 2020-09-26 22:54:08 --> Helper loaded: url_helper
INFO - 2020-09-26 22:54:08 --> Helper loaded: file_helper
INFO - 2020-09-26 22:54:08 --> Database Driver Class Initialized
INFO - 2020-09-26 22:54:08 --> Email Class Initialized
DEBUG - 2020-09-26 22:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:54:08 --> Controller Class Initialized
INFO - 2020-09-26 22:54:08 --> Model "Main_model" initialized
INFO - 2020-09-26 22:54:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:54:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:54:08 --> Final output sent to browser
DEBUG - 2020-09-26 22:54:08 --> Total execution time: 0.5162
INFO - 2020-09-26 22:54:22 --> Config Class Initialized
INFO - 2020-09-26 22:54:22 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:54:22 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:54:22 --> Utf8 Class Initialized
INFO - 2020-09-26 22:54:22 --> URI Class Initialized
INFO - 2020-09-26 22:54:22 --> Router Class Initialized
INFO - 2020-09-26 22:54:22 --> Output Class Initialized
INFO - 2020-09-26 22:54:22 --> Security Class Initialized
DEBUG - 2020-09-26 22:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:54:22 --> Input Class Initialized
INFO - 2020-09-26 22:54:22 --> Language Class Initialized
ERROR - 2020-09-26 22:54:22 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-26 22:54:43 --> Config Class Initialized
INFO - 2020-09-26 22:54:43 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:54:43 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:54:43 --> Utf8 Class Initialized
INFO - 2020-09-26 22:54:43 --> URI Class Initialized
INFO - 2020-09-26 22:54:43 --> Router Class Initialized
INFO - 2020-09-26 22:54:43 --> Output Class Initialized
INFO - 2020-09-26 22:54:43 --> Security Class Initialized
DEBUG - 2020-09-26 22:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:54:43 --> Input Class Initialized
INFO - 2020-09-26 22:54:43 --> Language Class Initialized
INFO - 2020-09-26 22:54:44 --> Loader Class Initialized
INFO - 2020-09-26 22:54:44 --> Helper loaded: url_helper
INFO - 2020-09-26 22:54:44 --> Helper loaded: file_helper
INFO - 2020-09-26 22:54:44 --> Database Driver Class Initialized
INFO - 2020-09-26 22:54:44 --> Email Class Initialized
DEBUG - 2020-09-26 22:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:54:44 --> Controller Class Initialized
INFO - 2020-09-26 22:54:44 --> Model "Main_model" initialized
INFO - 2020-09-26 22:54:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:54:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:54:44 --> Final output sent to browser
DEBUG - 2020-09-26 22:54:44 --> Total execution time: 0.6061
INFO - 2020-09-26 22:54:58 --> Config Class Initialized
INFO - 2020-09-26 22:54:58 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:54:58 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:54:58 --> Utf8 Class Initialized
INFO - 2020-09-26 22:54:58 --> URI Class Initialized
INFO - 2020-09-26 22:54:58 --> Router Class Initialized
INFO - 2020-09-26 22:54:58 --> Output Class Initialized
INFO - 2020-09-26 22:54:58 --> Security Class Initialized
DEBUG - 2020-09-26 22:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:54:58 --> Input Class Initialized
INFO - 2020-09-26 22:54:58 --> Language Class Initialized
INFO - 2020-09-26 22:54:58 --> Loader Class Initialized
INFO - 2020-09-26 22:54:58 --> Helper loaded: url_helper
INFO - 2020-09-26 22:54:58 --> Helper loaded: file_helper
INFO - 2020-09-26 22:54:59 --> Database Driver Class Initialized
INFO - 2020-09-26 22:54:59 --> Email Class Initialized
DEBUG - 2020-09-26 22:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:54:59 --> Controller Class Initialized
INFO - 2020-09-26 22:54:59 --> Model "Main_model" initialized
INFO - 2020-09-26 22:54:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:54:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:54:59 --> Final output sent to browser
DEBUG - 2020-09-26 22:54:59 --> Total execution time: 0.4883
INFO - 2020-09-26 22:56:14 --> Config Class Initialized
INFO - 2020-09-26 22:56:14 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:56:14 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:56:14 --> Utf8 Class Initialized
INFO - 2020-09-26 22:56:14 --> URI Class Initialized
INFO - 2020-09-26 22:56:14 --> Router Class Initialized
INFO - 2020-09-26 22:56:14 --> Output Class Initialized
INFO - 2020-09-26 22:56:14 --> Security Class Initialized
DEBUG - 2020-09-26 22:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:56:14 --> Input Class Initialized
INFO - 2020-09-26 22:56:14 --> Language Class Initialized
INFO - 2020-09-26 22:56:14 --> Loader Class Initialized
INFO - 2020-09-26 22:56:14 --> Helper loaded: url_helper
INFO - 2020-09-26 22:56:14 --> Helper loaded: file_helper
INFO - 2020-09-26 22:56:14 --> Database Driver Class Initialized
INFO - 2020-09-26 22:56:14 --> Email Class Initialized
DEBUG - 2020-09-26 22:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:56:14 --> Controller Class Initialized
INFO - 2020-09-26 22:56:14 --> Model "Main_model" initialized
INFO - 2020-09-26 22:56:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:56:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:56:14 --> Final output sent to browser
DEBUG - 2020-09-26 22:56:14 --> Total execution time: 0.5669
INFO - 2020-09-26 22:56:32 --> Config Class Initialized
INFO - 2020-09-26 22:56:32 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:56:32 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:56:32 --> Utf8 Class Initialized
INFO - 2020-09-26 22:56:32 --> URI Class Initialized
INFO - 2020-09-26 22:56:32 --> Router Class Initialized
INFO - 2020-09-26 22:56:32 --> Output Class Initialized
INFO - 2020-09-26 22:56:32 --> Security Class Initialized
DEBUG - 2020-09-26 22:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:56:32 --> Input Class Initialized
INFO - 2020-09-26 22:56:32 --> Language Class Initialized
INFO - 2020-09-26 22:56:32 --> Loader Class Initialized
INFO - 2020-09-26 22:56:32 --> Helper loaded: url_helper
INFO - 2020-09-26 22:56:32 --> Helper loaded: file_helper
INFO - 2020-09-26 22:56:33 --> Database Driver Class Initialized
INFO - 2020-09-26 22:56:33 --> Email Class Initialized
DEBUG - 2020-09-26 22:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:56:33 --> Controller Class Initialized
INFO - 2020-09-26 22:56:33 --> Model "Main_model" initialized
INFO - 2020-09-26 22:56:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:56:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:56:33 --> Final output sent to browser
DEBUG - 2020-09-26 22:56:33 --> Total execution time: 0.5353
INFO - 2020-09-26 22:58:31 --> Config Class Initialized
INFO - 2020-09-26 22:58:31 --> Hooks Class Initialized
DEBUG - 2020-09-26 22:58:31 --> UTF-8 Support Enabled
INFO - 2020-09-26 22:58:31 --> Utf8 Class Initialized
INFO - 2020-09-26 22:58:31 --> URI Class Initialized
INFO - 2020-09-26 22:58:31 --> Router Class Initialized
INFO - 2020-09-26 22:58:31 --> Output Class Initialized
INFO - 2020-09-26 22:58:31 --> Security Class Initialized
DEBUG - 2020-09-26 22:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 22:58:31 --> Input Class Initialized
INFO - 2020-09-26 22:58:31 --> Language Class Initialized
INFO - 2020-09-26 22:58:31 --> Loader Class Initialized
INFO - 2020-09-26 22:58:31 --> Helper loaded: url_helper
INFO - 2020-09-26 22:58:31 --> Helper loaded: file_helper
INFO - 2020-09-26 22:58:31 --> Database Driver Class Initialized
INFO - 2020-09-26 22:58:31 --> Email Class Initialized
DEBUG - 2020-09-26 22:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 22:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 22:58:32 --> Controller Class Initialized
INFO - 2020-09-26 22:58:32 --> Model "Main_model" initialized
INFO - 2020-09-26 22:58:32 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 22:58:32 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 22:58:32 --> Final output sent to browser
DEBUG - 2020-09-26 22:58:32 --> Total execution time: 0.6229
INFO - 2020-09-26 23:00:12 --> Config Class Initialized
INFO - 2020-09-26 23:00:12 --> Hooks Class Initialized
DEBUG - 2020-09-26 23:00:12 --> UTF-8 Support Enabled
INFO - 2020-09-26 23:00:12 --> Utf8 Class Initialized
INFO - 2020-09-26 23:00:12 --> URI Class Initialized
INFO - 2020-09-26 23:00:12 --> Router Class Initialized
INFO - 2020-09-26 23:00:12 --> Output Class Initialized
INFO - 2020-09-26 23:00:12 --> Security Class Initialized
DEBUG - 2020-09-26 23:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 23:00:12 --> Input Class Initialized
INFO - 2020-09-26 23:00:12 --> Language Class Initialized
INFO - 2020-09-26 23:00:12 --> Loader Class Initialized
INFO - 2020-09-26 23:00:12 --> Helper loaded: url_helper
INFO - 2020-09-26 23:00:12 --> Helper loaded: file_helper
INFO - 2020-09-26 23:00:12 --> Database Driver Class Initialized
INFO - 2020-09-26 23:00:12 --> Email Class Initialized
DEBUG - 2020-09-26 23:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 23:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 23:00:12 --> Controller Class Initialized
INFO - 2020-09-26 23:00:12 --> Model "Main_model" initialized
INFO - 2020-09-26 23:00:12 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 23:00:12 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-26 23:00:12 --> Final output sent to browser
DEBUG - 2020-09-26 23:00:12 --> Total execution time: 0.4379
INFO - 2020-09-26 23:00:41 --> Config Class Initialized
INFO - 2020-09-26 23:00:41 --> Hooks Class Initialized
DEBUG - 2020-09-26 23:00:41 --> UTF-8 Support Enabled
INFO - 2020-09-26 23:00:41 --> Utf8 Class Initialized
INFO - 2020-09-26 23:00:41 --> URI Class Initialized
INFO - 2020-09-26 23:00:41 --> Router Class Initialized
INFO - 2020-09-26 23:00:41 --> Output Class Initialized
INFO - 2020-09-26 23:00:41 --> Security Class Initialized
DEBUG - 2020-09-26 23:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 23:00:41 --> Input Class Initialized
INFO - 2020-09-26 23:00:41 --> Language Class Initialized
INFO - 2020-09-26 23:00:41 --> Loader Class Initialized
INFO - 2020-09-26 23:00:41 --> Helper loaded: url_helper
INFO - 2020-09-26 23:00:41 --> Helper loaded: file_helper
INFO - 2020-09-26 23:00:41 --> Database Driver Class Initialized
INFO - 2020-09-26 23:00:41 --> Email Class Initialized
DEBUG - 2020-09-26 23:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 23:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 23:00:41 --> Controller Class Initialized
INFO - 2020-09-26 23:00:41 --> Model "Main_model" initialized
INFO - 2020-09-26 23:00:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 23:00:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 23:00:41 --> Final output sent to browser
DEBUG - 2020-09-26 23:00:41 --> Total execution time: 0.4256
INFO - 2020-09-26 23:00:45 --> Config Class Initialized
INFO - 2020-09-26 23:00:45 --> Hooks Class Initialized
DEBUG - 2020-09-26 23:00:45 --> UTF-8 Support Enabled
INFO - 2020-09-26 23:00:45 --> Utf8 Class Initialized
INFO - 2020-09-26 23:00:45 --> URI Class Initialized
INFO - 2020-09-26 23:00:45 --> Router Class Initialized
INFO - 2020-09-26 23:00:45 --> Output Class Initialized
INFO - 2020-09-26 23:00:46 --> Security Class Initialized
DEBUG - 2020-09-26 23:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 23:00:46 --> Input Class Initialized
INFO - 2020-09-26 23:00:46 --> Language Class Initialized
INFO - 2020-09-26 23:00:46 --> Loader Class Initialized
INFO - 2020-09-26 23:00:46 --> Helper loaded: url_helper
INFO - 2020-09-26 23:00:46 --> Helper loaded: file_helper
INFO - 2020-09-26 23:00:46 --> Database Driver Class Initialized
INFO - 2020-09-26 23:00:46 --> Email Class Initialized
DEBUG - 2020-09-26 23:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 23:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 23:00:46 --> Controller Class Initialized
INFO - 2020-09-26 23:00:46 --> Model "Main_model" initialized
INFO - 2020-09-26 23:00:46 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 23:00:46 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkim_lookup.php
INFO - 2020-09-26 23:00:46 --> Final output sent to browser
DEBUG - 2020-09-26 23:00:46 --> Total execution time: 0.7097
INFO - 2020-09-26 23:01:06 --> Config Class Initialized
INFO - 2020-09-26 23:01:06 --> Hooks Class Initialized
DEBUG - 2020-09-26 23:01:06 --> UTF-8 Support Enabled
INFO - 2020-09-26 23:01:06 --> Utf8 Class Initialized
INFO - 2020-09-26 23:01:06 --> URI Class Initialized
INFO - 2020-09-26 23:01:06 --> Router Class Initialized
INFO - 2020-09-26 23:01:06 --> Output Class Initialized
INFO - 2020-09-26 23:01:07 --> Security Class Initialized
DEBUG - 2020-09-26 23:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 23:01:07 --> Input Class Initialized
INFO - 2020-09-26 23:01:07 --> Language Class Initialized
INFO - 2020-09-26 23:01:07 --> Loader Class Initialized
INFO - 2020-09-26 23:01:07 --> Helper loaded: url_helper
INFO - 2020-09-26 23:01:07 --> Helper loaded: file_helper
INFO - 2020-09-26 23:01:07 --> Database Driver Class Initialized
INFO - 2020-09-26 23:01:07 --> Email Class Initialized
DEBUG - 2020-09-26 23:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 23:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 23:01:07 --> Controller Class Initialized
INFO - 2020-09-26 23:01:07 --> Model "Main_model" initialized
INFO - 2020-09-26 23:01:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 23:01:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 23:01:07 --> Final output sent to browser
DEBUG - 2020-09-26 23:01:07 --> Total execution time: 0.4375
INFO - 2020-09-26 23:01:13 --> Config Class Initialized
INFO - 2020-09-26 23:01:13 --> Hooks Class Initialized
DEBUG - 2020-09-26 23:01:13 --> UTF-8 Support Enabled
INFO - 2020-09-26 23:01:13 --> Utf8 Class Initialized
INFO - 2020-09-26 23:01:13 --> URI Class Initialized
INFO - 2020-09-26 23:01:13 --> Router Class Initialized
INFO - 2020-09-26 23:01:13 --> Output Class Initialized
INFO - 2020-09-26 23:01:13 --> Security Class Initialized
DEBUG - 2020-09-26 23:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-26 23:01:13 --> Input Class Initialized
INFO - 2020-09-26 23:01:13 --> Language Class Initialized
INFO - 2020-09-26 23:01:13 --> Loader Class Initialized
INFO - 2020-09-26 23:01:13 --> Helper loaded: url_helper
INFO - 2020-09-26 23:01:13 --> Helper loaded: file_helper
INFO - 2020-09-26 23:01:13 --> Database Driver Class Initialized
INFO - 2020-09-26 23:01:13 --> Email Class Initialized
DEBUG - 2020-09-26 23:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-26 23:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-26 23:01:13 --> Controller Class Initialized
INFO - 2020-09-26 23:01:13 --> Model "Main_model" initialized
INFO - 2020-09-26 23:01:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-26 23:01:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dkimgenerate.php
INFO - 2020-09-26 23:01:14 --> Final output sent to browser
DEBUG - 2020-09-26 23:01:14 --> Total execution time: 0.5845
