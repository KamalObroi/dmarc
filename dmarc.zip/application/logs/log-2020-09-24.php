<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-24 09:15:20 --> Config Class Initialized
INFO - 2020-09-24 09:15:20 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:15:20 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:15:20 --> Utf8 Class Initialized
INFO - 2020-09-24 09:15:20 --> URI Class Initialized
INFO - 2020-09-24 09:15:20 --> Router Class Initialized
INFO - 2020-09-24 09:15:20 --> Output Class Initialized
INFO - 2020-09-24 09:15:20 --> Security Class Initialized
DEBUG - 2020-09-24 09:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:15:20 --> Input Class Initialized
INFO - 2020-09-24 09:15:20 --> Language Class Initialized
INFO - 2020-09-24 09:15:20 --> Loader Class Initialized
INFO - 2020-09-24 09:15:20 --> Helper loaded: url_helper
INFO - 2020-09-24 09:15:20 --> Helper loaded: file_helper
INFO - 2020-09-24 09:15:20 --> Database Driver Class Initialized
INFO - 2020-09-24 09:15:20 --> Email Class Initialized
DEBUG - 2020-09-24 09:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:15:20 --> Controller Class Initialized
INFO - 2020-09-24 09:15:20 --> Model "Main_model" initialized
INFO - 2020-09-24 09:15:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 09:15:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-24 09:15:21 --> Final output sent to browser
DEBUG - 2020-09-24 09:15:21 --> Total execution time: 1.0306
INFO - 2020-09-24 09:15:25 --> Config Class Initialized
INFO - 2020-09-24 09:15:25 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:15:25 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:15:25 --> Utf8 Class Initialized
INFO - 2020-09-24 09:15:25 --> URI Class Initialized
INFO - 2020-09-24 09:15:25 --> Router Class Initialized
INFO - 2020-09-24 09:15:25 --> Output Class Initialized
INFO - 2020-09-24 09:15:25 --> Security Class Initialized
DEBUG - 2020-09-24 09:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:15:25 --> Input Class Initialized
INFO - 2020-09-24 09:15:25 --> Language Class Initialized
INFO - 2020-09-24 09:15:25 --> Loader Class Initialized
INFO - 2020-09-24 09:15:25 --> Helper loaded: url_helper
INFO - 2020-09-24 09:15:25 --> Helper loaded: file_helper
INFO - 2020-09-24 09:15:25 --> Database Driver Class Initialized
INFO - 2020-09-24 09:15:26 --> Email Class Initialized
DEBUG - 2020-09-24 09:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:15:26 --> Controller Class Initialized
INFO - 2020-09-24 09:15:26 --> Model "Main_model" initialized
INFO - 2020-09-24 09:15:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 09:15:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 09:15:26 --> Final output sent to browser
DEBUG - 2020-09-24 09:15:26 --> Total execution time: 0.3352
INFO - 2020-09-24 09:15:30 --> Config Class Initialized
INFO - 2020-09-24 09:15:30 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:15:30 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:15:30 --> Utf8 Class Initialized
INFO - 2020-09-24 09:15:30 --> URI Class Initialized
INFO - 2020-09-24 09:15:30 --> Router Class Initialized
INFO - 2020-09-24 09:15:30 --> Output Class Initialized
INFO - 2020-09-24 09:15:30 --> Security Class Initialized
DEBUG - 2020-09-24 09:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:15:30 --> Input Class Initialized
INFO - 2020-09-24 09:15:30 --> Language Class Initialized
INFO - 2020-09-24 09:15:30 --> Loader Class Initialized
INFO - 2020-09-24 09:15:30 --> Helper loaded: url_helper
INFO - 2020-09-24 09:15:30 --> Helper loaded: file_helper
INFO - 2020-09-24 09:15:30 --> Database Driver Class Initialized
INFO - 2020-09-24 09:15:30 --> Email Class Initialized
DEBUG - 2020-09-24 09:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:15:30 --> Controller Class Initialized
INFO - 2020-09-24 09:15:30 --> Model "Main_model" initialized
INFO - 2020-09-24 09:15:34 --> Config Class Initialized
INFO - 2020-09-24 09:15:34 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:15:34 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:15:34 --> Utf8 Class Initialized
INFO - 2020-09-24 09:15:34 --> URI Class Initialized
INFO - 2020-09-24 09:15:34 --> Router Class Initialized
INFO - 2020-09-24 09:15:34 --> Output Class Initialized
INFO - 2020-09-24 09:15:34 --> Security Class Initialized
DEBUG - 2020-09-24 09:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:15:34 --> Input Class Initialized
INFO - 2020-09-24 09:15:34 --> Language Class Initialized
INFO - 2020-09-24 09:15:34 --> Loader Class Initialized
INFO - 2020-09-24 09:15:34 --> Helper loaded: url_helper
INFO - 2020-09-24 09:15:34 --> Helper loaded: file_helper
INFO - 2020-09-24 09:15:34 --> Database Driver Class Initialized
INFO - 2020-09-24 09:15:34 --> Email Class Initialized
DEBUG - 2020-09-24 09:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:15:34 --> Controller Class Initialized
INFO - 2020-09-24 09:15:34 --> Model "Main_model" initialized
INFO - 2020-09-24 09:34:38 --> Config Class Initialized
INFO - 2020-09-24 09:34:38 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:34:38 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:34:38 --> Utf8 Class Initialized
INFO - 2020-09-24 09:34:38 --> URI Class Initialized
INFO - 2020-09-24 09:34:38 --> Router Class Initialized
INFO - 2020-09-24 09:34:38 --> Output Class Initialized
INFO - 2020-09-24 09:34:38 --> Security Class Initialized
DEBUG - 2020-09-24 09:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:34:38 --> Input Class Initialized
INFO - 2020-09-24 09:34:38 --> Language Class Initialized
INFO - 2020-09-24 09:34:38 --> Loader Class Initialized
INFO - 2020-09-24 09:34:38 --> Helper loaded: url_helper
INFO - 2020-09-24 09:34:38 --> Helper loaded: file_helper
INFO - 2020-09-24 09:34:38 --> Database Driver Class Initialized
INFO - 2020-09-24 09:34:38 --> Email Class Initialized
DEBUG - 2020-09-24 09:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:34:38 --> Controller Class Initialized
INFO - 2020-09-24 09:34:38 --> Model "Main_model" initialized
INFO - 2020-09-24 09:37:04 --> Config Class Initialized
INFO - 2020-09-24 09:37:04 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:37:04 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:37:04 --> Utf8 Class Initialized
INFO - 2020-09-24 09:37:04 --> URI Class Initialized
INFO - 2020-09-24 09:37:04 --> Router Class Initialized
INFO - 2020-09-24 09:37:04 --> Output Class Initialized
INFO - 2020-09-24 09:37:04 --> Security Class Initialized
DEBUG - 2020-09-24 09:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:37:04 --> Input Class Initialized
INFO - 2020-09-24 09:37:04 --> Language Class Initialized
INFO - 2020-09-24 09:37:04 --> Loader Class Initialized
INFO - 2020-09-24 09:37:04 --> Helper loaded: url_helper
INFO - 2020-09-24 09:37:04 --> Helper loaded: file_helper
INFO - 2020-09-24 09:37:04 --> Database Driver Class Initialized
INFO - 2020-09-24 09:37:04 --> Email Class Initialized
DEBUG - 2020-09-24 09:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:37:04 --> Controller Class Initialized
INFO - 2020-09-24 09:37:04 --> Model "Main_model" initialized
ERROR - 2020-09-24 09:37:04 --> Severity: Warning --> checkdnsrr(): Type '32768' not supported C:\xampp\htdocs\dmarc\application\controllers\Home.php 40
INFO - 2020-09-24 09:37:08 --> Config Class Initialized
INFO - 2020-09-24 09:37:08 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:37:08 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:37:08 --> Utf8 Class Initialized
INFO - 2020-09-24 09:37:08 --> URI Class Initialized
INFO - 2020-09-24 09:37:08 --> Router Class Initialized
INFO - 2020-09-24 09:37:08 --> Output Class Initialized
INFO - 2020-09-24 09:37:08 --> Security Class Initialized
DEBUG - 2020-09-24 09:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:37:08 --> Input Class Initialized
INFO - 2020-09-24 09:37:08 --> Language Class Initialized
INFO - 2020-09-24 09:37:08 --> Loader Class Initialized
INFO - 2020-09-24 09:37:08 --> Helper loaded: url_helper
INFO - 2020-09-24 09:37:08 --> Helper loaded: file_helper
INFO - 2020-09-24 09:37:08 --> Database Driver Class Initialized
INFO - 2020-09-24 09:37:08 --> Email Class Initialized
DEBUG - 2020-09-24 09:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:37:08 --> Controller Class Initialized
INFO - 2020-09-24 09:37:08 --> Model "Main_model" initialized
INFO - 2020-09-24 09:37:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 09:37:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 09:37:08 --> Final output sent to browser
DEBUG - 2020-09-24 09:37:08 --> Total execution time: 0.3305
INFO - 2020-09-24 09:37:11 --> Config Class Initialized
INFO - 2020-09-24 09:37:11 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:37:11 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:37:11 --> Utf8 Class Initialized
INFO - 2020-09-24 09:37:11 --> URI Class Initialized
INFO - 2020-09-24 09:37:11 --> Router Class Initialized
INFO - 2020-09-24 09:37:11 --> Output Class Initialized
INFO - 2020-09-24 09:37:11 --> Security Class Initialized
DEBUG - 2020-09-24 09:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:37:11 --> Input Class Initialized
INFO - 2020-09-24 09:37:11 --> Language Class Initialized
INFO - 2020-09-24 09:37:11 --> Loader Class Initialized
INFO - 2020-09-24 09:37:11 --> Helper loaded: url_helper
INFO - 2020-09-24 09:37:11 --> Helper loaded: file_helper
INFO - 2020-09-24 09:37:11 --> Database Driver Class Initialized
INFO - 2020-09-24 09:37:11 --> Email Class Initialized
DEBUG - 2020-09-24 09:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:37:11 --> Controller Class Initialized
INFO - 2020-09-24 09:37:11 --> Model "Main_model" initialized
ERROR - 2020-09-24 09:37:11 --> Severity: Warning --> checkdnsrr(): Type '32768' not supported C:\xampp\htdocs\dmarc\application\controllers\Home.php 40
INFO - 2020-09-24 09:38:00 --> Config Class Initialized
INFO - 2020-09-24 09:38:00 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:38:00 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:38:00 --> Utf8 Class Initialized
INFO - 2020-09-24 09:38:00 --> URI Class Initialized
INFO - 2020-09-24 09:38:00 --> Router Class Initialized
INFO - 2020-09-24 09:38:00 --> Output Class Initialized
INFO - 2020-09-24 09:38:00 --> Security Class Initialized
DEBUG - 2020-09-24 09:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:38:00 --> Input Class Initialized
INFO - 2020-09-24 09:38:00 --> Language Class Initialized
INFO - 2020-09-24 09:38:00 --> Loader Class Initialized
INFO - 2020-09-24 09:38:00 --> Helper loaded: url_helper
INFO - 2020-09-24 09:38:00 --> Helper loaded: file_helper
INFO - 2020-09-24 09:38:00 --> Database Driver Class Initialized
INFO - 2020-09-24 09:38:00 --> Email Class Initialized
DEBUG - 2020-09-24 09:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:38:00 --> Controller Class Initialized
INFO - 2020-09-24 09:38:00 --> Model "Main_model" initialized
ERROR - 2020-09-24 09:38:00 --> Severity: Warning --> dns_check_record(): Type '32768' not supported C:\xampp\htdocs\dmarc\application\controllers\Home.php 40
INFO - 2020-09-24 09:38:12 --> Config Class Initialized
INFO - 2020-09-24 09:38:12 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:38:12 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:38:12 --> Utf8 Class Initialized
INFO - 2020-09-24 09:38:12 --> URI Class Initialized
INFO - 2020-09-24 09:38:12 --> Router Class Initialized
INFO - 2020-09-24 09:38:12 --> Output Class Initialized
INFO - 2020-09-24 09:38:12 --> Security Class Initialized
DEBUG - 2020-09-24 09:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:38:12 --> Input Class Initialized
INFO - 2020-09-24 09:38:12 --> Language Class Initialized
INFO - 2020-09-24 09:38:12 --> Loader Class Initialized
INFO - 2020-09-24 09:38:12 --> Helper loaded: url_helper
INFO - 2020-09-24 09:38:12 --> Helper loaded: file_helper
INFO - 2020-09-24 09:38:12 --> Database Driver Class Initialized
INFO - 2020-09-24 09:38:12 --> Email Class Initialized
DEBUG - 2020-09-24 09:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:38:12 --> Controller Class Initialized
INFO - 2020-09-24 09:38:12 --> Model "Main_model" initialized
ERROR - 2020-09-24 09:38:12 --> Severity: Warning --> dns_check_record(): Type '32768' not supported C:\xampp\htdocs\dmarc\application\controllers\Home.php 40
INFO - 2020-09-24 09:38:28 --> Config Class Initialized
INFO - 2020-09-24 09:38:28 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:38:28 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:38:28 --> Utf8 Class Initialized
INFO - 2020-09-24 09:38:28 --> URI Class Initialized
INFO - 2020-09-24 09:38:28 --> Router Class Initialized
INFO - 2020-09-24 09:38:28 --> Output Class Initialized
INFO - 2020-09-24 09:38:28 --> Security Class Initialized
DEBUG - 2020-09-24 09:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:38:28 --> Input Class Initialized
INFO - 2020-09-24 09:38:28 --> Language Class Initialized
INFO - 2020-09-24 09:38:28 --> Loader Class Initialized
INFO - 2020-09-24 09:38:28 --> Helper loaded: url_helper
INFO - 2020-09-24 09:38:28 --> Helper loaded: file_helper
INFO - 2020-09-24 09:38:28 --> Database Driver Class Initialized
INFO - 2020-09-24 09:38:28 --> Email Class Initialized
DEBUG - 2020-09-24 09:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:38:28 --> Controller Class Initialized
INFO - 2020-09-24 09:38:28 --> Model "Main_model" initialized
INFO - 2020-09-24 09:38:31 --> Config Class Initialized
INFO - 2020-09-24 09:38:31 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:38:31 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:38:31 --> Utf8 Class Initialized
INFO - 2020-09-24 09:38:31 --> URI Class Initialized
INFO - 2020-09-24 09:38:31 --> Router Class Initialized
INFO - 2020-09-24 09:38:31 --> Output Class Initialized
INFO - 2020-09-24 09:38:31 --> Security Class Initialized
DEBUG - 2020-09-24 09:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:38:31 --> Input Class Initialized
INFO - 2020-09-24 09:38:31 --> Language Class Initialized
INFO - 2020-09-24 09:38:31 --> Loader Class Initialized
INFO - 2020-09-24 09:38:31 --> Helper loaded: url_helper
INFO - 2020-09-24 09:38:31 --> Helper loaded: file_helper
INFO - 2020-09-24 09:38:31 --> Database Driver Class Initialized
INFO - 2020-09-24 09:38:31 --> Email Class Initialized
DEBUG - 2020-09-24 09:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:38:31 --> Controller Class Initialized
INFO - 2020-09-24 09:38:31 --> Model "Main_model" initialized
INFO - 2020-09-24 09:41:26 --> Config Class Initialized
INFO - 2020-09-24 09:41:26 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:41:26 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:41:26 --> Utf8 Class Initialized
INFO - 2020-09-24 09:41:26 --> URI Class Initialized
INFO - 2020-09-24 09:41:26 --> Router Class Initialized
INFO - 2020-09-24 09:41:26 --> Output Class Initialized
INFO - 2020-09-24 09:41:27 --> Security Class Initialized
DEBUG - 2020-09-24 09:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:41:27 --> Input Class Initialized
INFO - 2020-09-24 09:41:27 --> Language Class Initialized
INFO - 2020-09-24 09:41:27 --> Loader Class Initialized
INFO - 2020-09-24 09:41:27 --> Helper loaded: url_helper
INFO - 2020-09-24 09:41:27 --> Helper loaded: file_helper
INFO - 2020-09-24 09:41:27 --> Database Driver Class Initialized
INFO - 2020-09-24 09:41:27 --> Email Class Initialized
DEBUG - 2020-09-24 09:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:41:27 --> Controller Class Initialized
INFO - 2020-09-24 09:41:27 --> Model "Main_model" initialized
INFO - 2020-09-24 09:41:29 --> Config Class Initialized
INFO - 2020-09-24 09:41:29 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:41:29 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:41:29 --> Utf8 Class Initialized
INFO - 2020-09-24 09:41:29 --> URI Class Initialized
INFO - 2020-09-24 09:41:29 --> Router Class Initialized
INFO - 2020-09-24 09:41:29 --> Output Class Initialized
INFO - 2020-09-24 09:41:29 --> Security Class Initialized
DEBUG - 2020-09-24 09:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:41:29 --> Input Class Initialized
INFO - 2020-09-24 09:41:29 --> Language Class Initialized
INFO - 2020-09-24 09:41:29 --> Loader Class Initialized
INFO - 2020-09-24 09:41:29 --> Helper loaded: url_helper
INFO - 2020-09-24 09:41:29 --> Helper loaded: file_helper
INFO - 2020-09-24 09:41:29 --> Database Driver Class Initialized
INFO - 2020-09-24 09:41:29 --> Email Class Initialized
DEBUG - 2020-09-24 09:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:41:29 --> Controller Class Initialized
INFO - 2020-09-24 09:41:30 --> Model "Main_model" initialized
INFO - 2020-09-24 09:42:53 --> Config Class Initialized
INFO - 2020-09-24 09:42:53 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:42:53 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:42:53 --> Utf8 Class Initialized
INFO - 2020-09-24 09:42:53 --> URI Class Initialized
INFO - 2020-09-24 09:42:53 --> Router Class Initialized
INFO - 2020-09-24 09:42:53 --> Output Class Initialized
INFO - 2020-09-24 09:42:53 --> Security Class Initialized
DEBUG - 2020-09-24 09:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:42:53 --> Input Class Initialized
INFO - 2020-09-24 09:42:53 --> Language Class Initialized
INFO - 2020-09-24 09:42:53 --> Loader Class Initialized
INFO - 2020-09-24 09:42:53 --> Helper loaded: url_helper
INFO - 2020-09-24 09:42:53 --> Helper loaded: file_helper
INFO - 2020-09-24 09:42:53 --> Database Driver Class Initialized
INFO - 2020-09-24 09:42:53 --> Email Class Initialized
DEBUG - 2020-09-24 09:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:42:53 --> Controller Class Initialized
INFO - 2020-09-24 09:42:53 --> Model "Main_model" initialized
INFO - 2020-09-24 09:42:57 --> Config Class Initialized
INFO - 2020-09-24 09:42:57 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:42:57 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:42:57 --> Utf8 Class Initialized
INFO - 2020-09-24 09:42:57 --> URI Class Initialized
INFO - 2020-09-24 09:42:57 --> Router Class Initialized
INFO - 2020-09-24 09:42:57 --> Output Class Initialized
INFO - 2020-09-24 09:42:57 --> Security Class Initialized
DEBUG - 2020-09-24 09:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:42:57 --> Input Class Initialized
INFO - 2020-09-24 09:42:57 --> Language Class Initialized
INFO - 2020-09-24 09:42:57 --> Loader Class Initialized
INFO - 2020-09-24 09:42:57 --> Helper loaded: url_helper
INFO - 2020-09-24 09:42:57 --> Helper loaded: file_helper
INFO - 2020-09-24 09:42:57 --> Database Driver Class Initialized
INFO - 2020-09-24 09:42:57 --> Email Class Initialized
DEBUG - 2020-09-24 09:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:42:57 --> Controller Class Initialized
INFO - 2020-09-24 09:42:57 --> Model "Main_model" initialized
INFO - 2020-09-24 09:45:28 --> Config Class Initialized
INFO - 2020-09-24 09:45:28 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:45:28 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:45:28 --> Utf8 Class Initialized
INFO - 2020-09-24 09:45:28 --> URI Class Initialized
INFO - 2020-09-24 09:45:28 --> Router Class Initialized
INFO - 2020-09-24 09:45:28 --> Output Class Initialized
INFO - 2020-09-24 09:45:28 --> Security Class Initialized
DEBUG - 2020-09-24 09:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:45:28 --> Input Class Initialized
INFO - 2020-09-24 09:45:28 --> Language Class Initialized
INFO - 2020-09-24 09:45:28 --> Loader Class Initialized
INFO - 2020-09-24 09:45:28 --> Helper loaded: url_helper
INFO - 2020-09-24 09:45:28 --> Helper loaded: file_helper
INFO - 2020-09-24 09:45:28 --> Database Driver Class Initialized
INFO - 2020-09-24 09:45:28 --> Email Class Initialized
DEBUG - 2020-09-24 09:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:45:28 --> Controller Class Initialized
INFO - 2020-09-24 09:45:28 --> Model "Main_model" initialized
INFO - 2020-09-24 09:50:45 --> Config Class Initialized
INFO - 2020-09-24 09:50:45 --> Hooks Class Initialized
DEBUG - 2020-09-24 09:50:45 --> UTF-8 Support Enabled
INFO - 2020-09-24 09:50:45 --> Utf8 Class Initialized
INFO - 2020-09-24 09:50:45 --> URI Class Initialized
INFO - 2020-09-24 09:50:45 --> Router Class Initialized
INFO - 2020-09-24 09:50:45 --> Output Class Initialized
INFO - 2020-09-24 09:50:45 --> Security Class Initialized
DEBUG - 2020-09-24 09:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 09:50:45 --> Input Class Initialized
INFO - 2020-09-24 09:50:45 --> Language Class Initialized
INFO - 2020-09-24 09:50:45 --> Loader Class Initialized
INFO - 2020-09-24 09:50:45 --> Helper loaded: url_helper
INFO - 2020-09-24 09:50:45 --> Helper loaded: file_helper
INFO - 2020-09-24 09:50:45 --> Database Driver Class Initialized
INFO - 2020-09-24 09:50:45 --> Email Class Initialized
DEBUG - 2020-09-24 09:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 09:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 09:50:45 --> Controller Class Initialized
INFO - 2020-09-24 09:50:45 --> Model "Main_model" initialized
INFO - 2020-09-24 11:38:59 --> Config Class Initialized
INFO - 2020-09-24 11:38:59 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:38:59 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:38:59 --> Utf8 Class Initialized
INFO - 2020-09-24 11:38:59 --> URI Class Initialized
INFO - 2020-09-24 11:38:59 --> Router Class Initialized
INFO - 2020-09-24 11:38:59 --> Output Class Initialized
INFO - 2020-09-24 11:38:59 --> Security Class Initialized
DEBUG - 2020-09-24 11:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:38:59 --> Input Class Initialized
INFO - 2020-09-24 11:38:59 --> Language Class Initialized
INFO - 2020-09-24 11:38:59 --> Loader Class Initialized
INFO - 2020-09-24 11:38:59 --> Helper loaded: url_helper
INFO - 2020-09-24 11:38:59 --> Helper loaded: file_helper
INFO - 2020-09-24 11:38:59 --> Database Driver Class Initialized
INFO - 2020-09-24 11:38:59 --> Email Class Initialized
DEBUG - 2020-09-24 11:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 11:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 11:38:59 --> Controller Class Initialized
INFO - 2020-09-24 11:38:59 --> Model "Main_model" initialized
INFO - 2020-09-24 11:39:08 --> Config Class Initialized
INFO - 2020-09-24 11:39:08 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:39:08 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:39:08 --> Utf8 Class Initialized
INFO - 2020-09-24 11:39:08 --> URI Class Initialized
INFO - 2020-09-24 11:39:08 --> Router Class Initialized
INFO - 2020-09-24 11:39:08 --> Output Class Initialized
INFO - 2020-09-24 11:39:08 --> Security Class Initialized
DEBUG - 2020-09-24 11:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:39:08 --> Input Class Initialized
INFO - 2020-09-24 11:39:08 --> Language Class Initialized
INFO - 2020-09-24 11:39:08 --> Loader Class Initialized
INFO - 2020-09-24 11:39:08 --> Helper loaded: url_helper
INFO - 2020-09-24 11:39:08 --> Helper loaded: file_helper
INFO - 2020-09-24 11:39:08 --> Database Driver Class Initialized
INFO - 2020-09-24 11:39:08 --> Email Class Initialized
DEBUG - 2020-09-24 11:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 11:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 11:39:08 --> Controller Class Initialized
INFO - 2020-09-24 11:39:08 --> Model "Main_model" initialized
INFO - 2020-09-24 11:40:46 --> Config Class Initialized
INFO - 2020-09-24 11:40:46 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:40:46 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:40:46 --> Utf8 Class Initialized
INFO - 2020-09-24 11:40:46 --> URI Class Initialized
INFO - 2020-09-24 11:40:46 --> Router Class Initialized
INFO - 2020-09-24 11:40:46 --> Output Class Initialized
INFO - 2020-09-24 11:40:46 --> Security Class Initialized
DEBUG - 2020-09-24 11:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:40:46 --> Input Class Initialized
INFO - 2020-09-24 11:40:46 --> Language Class Initialized
INFO - 2020-09-24 11:40:46 --> Loader Class Initialized
INFO - 2020-09-24 11:40:46 --> Helper loaded: url_helper
INFO - 2020-09-24 11:40:47 --> Helper loaded: file_helper
INFO - 2020-09-24 11:40:47 --> Database Driver Class Initialized
INFO - 2020-09-24 11:40:47 --> Email Class Initialized
DEBUG - 2020-09-24 11:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 11:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 11:40:47 --> Controller Class Initialized
INFO - 2020-09-24 11:40:47 --> Model "Main_model" initialized
INFO - 2020-09-24 11:40:54 --> Config Class Initialized
INFO - 2020-09-24 11:40:54 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:40:54 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:40:54 --> Utf8 Class Initialized
INFO - 2020-09-24 11:40:54 --> URI Class Initialized
INFO - 2020-09-24 11:40:54 --> Router Class Initialized
INFO - 2020-09-24 11:40:54 --> Output Class Initialized
INFO - 2020-09-24 11:40:54 --> Security Class Initialized
DEBUG - 2020-09-24 11:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:40:54 --> Input Class Initialized
INFO - 2020-09-24 11:40:54 --> Language Class Initialized
INFO - 2020-09-24 11:40:54 --> Loader Class Initialized
INFO - 2020-09-24 11:40:54 --> Helper loaded: url_helper
INFO - 2020-09-24 11:40:54 --> Helper loaded: file_helper
INFO - 2020-09-24 11:40:54 --> Database Driver Class Initialized
INFO - 2020-09-24 11:40:54 --> Email Class Initialized
DEBUG - 2020-09-24 11:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 11:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 11:40:54 --> Controller Class Initialized
INFO - 2020-09-24 11:40:54 --> Model "Main_model" initialized
INFO - 2020-09-24 11:41:04 --> Config Class Initialized
INFO - 2020-09-24 11:41:04 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:41:04 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:41:04 --> Utf8 Class Initialized
INFO - 2020-09-24 11:41:04 --> URI Class Initialized
INFO - 2020-09-24 11:41:04 --> Router Class Initialized
INFO - 2020-09-24 11:41:04 --> Output Class Initialized
INFO - 2020-09-24 11:41:04 --> Security Class Initialized
DEBUG - 2020-09-24 11:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:41:04 --> Input Class Initialized
INFO - 2020-09-24 11:41:04 --> Language Class Initialized
INFO - 2020-09-24 11:41:04 --> Loader Class Initialized
INFO - 2020-09-24 11:41:05 --> Helper loaded: url_helper
INFO - 2020-09-24 11:41:05 --> Helper loaded: file_helper
INFO - 2020-09-24 11:41:05 --> Database Driver Class Initialized
INFO - 2020-09-24 11:41:05 --> Email Class Initialized
DEBUG - 2020-09-24 11:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 11:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 11:41:05 --> Controller Class Initialized
INFO - 2020-09-24 11:41:05 --> Model "Main_model" initialized
INFO - 2020-09-24 11:42:47 --> Config Class Initialized
INFO - 2020-09-24 11:42:47 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:42:47 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:42:47 --> Utf8 Class Initialized
INFO - 2020-09-24 11:42:47 --> URI Class Initialized
INFO - 2020-09-24 11:42:47 --> Router Class Initialized
INFO - 2020-09-24 11:42:47 --> Output Class Initialized
INFO - 2020-09-24 11:42:47 --> Security Class Initialized
DEBUG - 2020-09-24 11:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:42:47 --> Input Class Initialized
INFO - 2020-09-24 11:42:47 --> Language Class Initialized
INFO - 2020-09-24 11:42:47 --> Loader Class Initialized
INFO - 2020-09-24 11:42:47 --> Helper loaded: url_helper
INFO - 2020-09-24 11:42:47 --> Helper loaded: file_helper
INFO - 2020-09-24 11:42:47 --> Database Driver Class Initialized
INFO - 2020-09-24 11:42:47 --> Email Class Initialized
DEBUG - 2020-09-24 11:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 11:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 11:42:47 --> Controller Class Initialized
INFO - 2020-09-24 11:42:47 --> Model "Main_model" initialized
INFO - 2020-09-24 11:49:04 --> Config Class Initialized
INFO - 2020-09-24 11:49:04 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:49:04 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:49:04 --> Utf8 Class Initialized
INFO - 2020-09-24 11:49:04 --> URI Class Initialized
INFO - 2020-09-24 11:49:04 --> Router Class Initialized
INFO - 2020-09-24 11:49:04 --> Output Class Initialized
INFO - 2020-09-24 11:49:04 --> Security Class Initialized
DEBUG - 2020-09-24 11:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:49:04 --> Input Class Initialized
INFO - 2020-09-24 11:49:04 --> Language Class Initialized
INFO - 2020-09-24 11:49:04 --> Loader Class Initialized
INFO - 2020-09-24 11:49:04 --> Helper loaded: url_helper
INFO - 2020-09-24 11:49:04 --> Helper loaded: file_helper
INFO - 2020-09-24 11:49:04 --> Database Driver Class Initialized
INFO - 2020-09-24 11:49:04 --> Email Class Initialized
DEBUG - 2020-09-24 11:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 11:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 11:49:04 --> Controller Class Initialized
INFO - 2020-09-24 11:49:04 --> Model "Main_model" initialized
INFO - 2020-09-24 11:49:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 11:49:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 11:49:04 --> Final output sent to browser
DEBUG - 2020-09-24 11:49:04 --> Total execution time: 0.7674
INFO - 2020-09-24 11:49:17 --> Config Class Initialized
INFO - 2020-09-24 11:49:17 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:49:17 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:49:17 --> Utf8 Class Initialized
INFO - 2020-09-24 11:49:17 --> URI Class Initialized
INFO - 2020-09-24 11:49:17 --> Router Class Initialized
INFO - 2020-09-24 11:49:17 --> Output Class Initialized
INFO - 2020-09-24 11:49:17 --> Security Class Initialized
DEBUG - 2020-09-24 11:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:49:18 --> Input Class Initialized
INFO - 2020-09-24 11:49:18 --> Language Class Initialized
INFO - 2020-09-24 11:49:18 --> Loader Class Initialized
INFO - 2020-09-24 11:49:18 --> Helper loaded: url_helper
INFO - 2020-09-24 11:49:18 --> Helper loaded: file_helper
INFO - 2020-09-24 11:49:18 --> Database Driver Class Initialized
INFO - 2020-09-24 11:49:18 --> Email Class Initialized
DEBUG - 2020-09-24 11:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 11:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 11:49:18 --> Controller Class Initialized
INFO - 2020-09-24 11:49:18 --> Model "Main_model" initialized
INFO - 2020-09-24 11:49:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 11:49:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 11:49:18 --> Final output sent to browser
DEBUG - 2020-09-24 11:49:18 --> Total execution time: 0.5055
INFO - 2020-09-24 11:49:24 --> Config Class Initialized
INFO - 2020-09-24 11:49:24 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:49:24 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:49:24 --> Utf8 Class Initialized
INFO - 2020-09-24 11:49:24 --> URI Class Initialized
INFO - 2020-09-24 11:49:24 --> Router Class Initialized
INFO - 2020-09-24 11:49:24 --> Output Class Initialized
INFO - 2020-09-24 11:49:24 --> Security Class Initialized
DEBUG - 2020-09-24 11:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:49:24 --> Input Class Initialized
INFO - 2020-09-24 11:49:24 --> Language Class Initialized
ERROR - 2020-09-24 11:49:24 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-24 11:51:15 --> Config Class Initialized
INFO - 2020-09-24 11:51:15 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:51:15 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:51:15 --> Utf8 Class Initialized
INFO - 2020-09-24 11:51:15 --> URI Class Initialized
INFO - 2020-09-24 11:51:15 --> Router Class Initialized
INFO - 2020-09-24 11:51:15 --> Output Class Initialized
INFO - 2020-09-24 11:51:15 --> Security Class Initialized
DEBUG - 2020-09-24 11:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:51:15 --> Input Class Initialized
INFO - 2020-09-24 11:51:15 --> Language Class Initialized
INFO - 2020-09-24 11:51:15 --> Loader Class Initialized
INFO - 2020-09-24 11:51:15 --> Helper loaded: url_helper
INFO - 2020-09-24 11:51:15 --> Helper loaded: file_helper
INFO - 2020-09-24 11:51:15 --> Database Driver Class Initialized
INFO - 2020-09-24 11:51:15 --> Email Class Initialized
DEBUG - 2020-09-24 11:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 11:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 11:51:15 --> Controller Class Initialized
INFO - 2020-09-24 11:51:15 --> Model "Main_model" initialized
INFO - 2020-09-24 11:51:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 11:51:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 11:51:15 --> Final output sent to browser
DEBUG - 2020-09-24 11:51:15 --> Total execution time: 0.4602
INFO - 2020-09-24 11:51:16 --> Config Class Initialized
INFO - 2020-09-24 11:51:16 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:51:16 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:51:16 --> Utf8 Class Initialized
INFO - 2020-09-24 11:51:16 --> URI Class Initialized
INFO - 2020-09-24 11:51:16 --> Router Class Initialized
INFO - 2020-09-24 11:51:16 --> Output Class Initialized
INFO - 2020-09-24 11:51:16 --> Security Class Initialized
DEBUG - 2020-09-24 11:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:51:16 --> Input Class Initialized
INFO - 2020-09-24 11:51:16 --> Language Class Initialized
ERROR - 2020-09-24 11:51:16 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-24 11:52:12 --> Config Class Initialized
INFO - 2020-09-24 11:52:12 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:52:12 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:52:12 --> Utf8 Class Initialized
INFO - 2020-09-24 11:52:12 --> URI Class Initialized
INFO - 2020-09-24 11:52:12 --> Router Class Initialized
INFO - 2020-09-24 11:52:12 --> Output Class Initialized
INFO - 2020-09-24 11:52:12 --> Security Class Initialized
DEBUG - 2020-09-24 11:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:52:12 --> Input Class Initialized
INFO - 2020-09-24 11:52:12 --> Language Class Initialized
INFO - 2020-09-24 11:52:12 --> Loader Class Initialized
INFO - 2020-09-24 11:52:12 --> Helper loaded: url_helper
INFO - 2020-09-24 11:52:12 --> Helper loaded: file_helper
INFO - 2020-09-24 11:52:12 --> Database Driver Class Initialized
INFO - 2020-09-24 11:52:12 --> Email Class Initialized
DEBUG - 2020-09-24 11:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 11:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 11:52:12 --> Controller Class Initialized
INFO - 2020-09-24 11:52:12 --> Model "Main_model" initialized
INFO - 2020-09-24 11:52:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 11:52:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 11:52:18 --> Final output sent to browser
DEBUG - 2020-09-24 11:52:18 --> Total execution time: 6.1173
INFO - 2020-09-24 11:54:01 --> Config Class Initialized
INFO - 2020-09-24 11:54:01 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:54:01 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:54:01 --> Utf8 Class Initialized
INFO - 2020-09-24 11:54:01 --> URI Class Initialized
INFO - 2020-09-24 11:54:01 --> Router Class Initialized
INFO - 2020-09-24 11:54:01 --> Output Class Initialized
INFO - 2020-09-24 11:54:01 --> Security Class Initialized
DEBUG - 2020-09-24 11:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:54:02 --> Input Class Initialized
INFO - 2020-09-24 11:54:02 --> Language Class Initialized
INFO - 2020-09-24 11:54:02 --> Loader Class Initialized
INFO - 2020-09-24 11:54:02 --> Helper loaded: url_helper
INFO - 2020-09-24 11:54:02 --> Helper loaded: file_helper
INFO - 2020-09-24 11:54:02 --> Database Driver Class Initialized
INFO - 2020-09-24 11:54:02 --> Email Class Initialized
DEBUG - 2020-09-24 11:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 11:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 11:54:02 --> Controller Class Initialized
INFO - 2020-09-24 11:54:02 --> Model "Main_model" initialized
INFO - 2020-09-24 11:54:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 11:54:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 11:54:02 --> Final output sent to browser
DEBUG - 2020-09-24 11:54:02 --> Total execution time: 0.5910
INFO - 2020-09-24 11:54:04 --> Config Class Initialized
INFO - 2020-09-24 11:54:04 --> Hooks Class Initialized
DEBUG - 2020-09-24 11:54:04 --> UTF-8 Support Enabled
INFO - 2020-09-24 11:54:04 --> Utf8 Class Initialized
INFO - 2020-09-24 11:54:04 --> URI Class Initialized
INFO - 2020-09-24 11:54:04 --> Router Class Initialized
INFO - 2020-09-24 11:54:04 --> Output Class Initialized
INFO - 2020-09-24 11:54:04 --> Security Class Initialized
DEBUG - 2020-09-24 11:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 11:54:04 --> Input Class Initialized
INFO - 2020-09-24 11:54:04 --> Language Class Initialized
INFO - 2020-09-24 11:54:04 --> Loader Class Initialized
INFO - 2020-09-24 11:54:04 --> Helper loaded: url_helper
INFO - 2020-09-24 11:54:04 --> Helper loaded: file_helper
INFO - 2020-09-24 11:54:04 --> Database Driver Class Initialized
INFO - 2020-09-24 11:54:04 --> Email Class Initialized
DEBUG - 2020-09-24 11:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 11:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 11:54:04 --> Controller Class Initialized
INFO - 2020-09-24 11:54:04 --> Model "Main_model" initialized
INFO - 2020-09-24 11:54:05 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 11:54:05 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 11:54:05 --> Final output sent to browser
DEBUG - 2020-09-24 11:54:05 --> Total execution time: 0.7148
INFO - 2020-09-24 12:05:34 --> Config Class Initialized
INFO - 2020-09-24 12:05:34 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:05:34 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:05:34 --> Utf8 Class Initialized
INFO - 2020-09-24 12:05:34 --> URI Class Initialized
INFO - 2020-09-24 12:05:34 --> Router Class Initialized
INFO - 2020-09-24 12:05:34 --> Output Class Initialized
INFO - 2020-09-24 12:05:34 --> Security Class Initialized
DEBUG - 2020-09-24 12:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:05:34 --> Input Class Initialized
INFO - 2020-09-24 12:05:34 --> Language Class Initialized
INFO - 2020-09-24 12:05:34 --> Loader Class Initialized
INFO - 2020-09-24 12:05:34 --> Helper loaded: url_helper
INFO - 2020-09-24 12:05:34 --> Helper loaded: file_helper
INFO - 2020-09-24 12:05:34 --> Database Driver Class Initialized
INFO - 2020-09-24 12:05:34 --> Email Class Initialized
DEBUG - 2020-09-24 12:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:05:35 --> Controller Class Initialized
INFO - 2020-09-24 12:05:35 --> Model "Main_model" initialized
INFO - 2020-09-24 12:05:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:05:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:05:35 --> Final output sent to browser
DEBUG - 2020-09-24 12:05:35 --> Total execution time: 1.1974
INFO - 2020-09-24 12:05:56 --> Config Class Initialized
INFO - 2020-09-24 12:05:56 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:05:57 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:05:57 --> Utf8 Class Initialized
INFO - 2020-09-24 12:05:57 --> URI Class Initialized
INFO - 2020-09-24 12:05:57 --> Router Class Initialized
INFO - 2020-09-24 12:05:57 --> Output Class Initialized
INFO - 2020-09-24 12:05:57 --> Security Class Initialized
DEBUG - 2020-09-24 12:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:05:57 --> Input Class Initialized
INFO - 2020-09-24 12:05:57 --> Language Class Initialized
ERROR - 2020-09-24 12:05:57 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-24 12:20:51 --> Config Class Initialized
INFO - 2020-09-24 12:20:51 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:20:51 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:20:52 --> Utf8 Class Initialized
INFO - 2020-09-24 12:20:52 --> URI Class Initialized
INFO - 2020-09-24 12:20:52 --> Router Class Initialized
INFO - 2020-09-24 12:20:52 --> Output Class Initialized
INFO - 2020-09-24 12:20:52 --> Security Class Initialized
DEBUG - 2020-09-24 12:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:20:52 --> Input Class Initialized
INFO - 2020-09-24 12:20:52 --> Language Class Initialized
ERROR - 2020-09-24 12:20:52 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-24 12:21:49 --> Config Class Initialized
INFO - 2020-09-24 12:21:49 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:21:49 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:21:49 --> Utf8 Class Initialized
INFO - 2020-09-24 12:21:49 --> URI Class Initialized
INFO - 2020-09-24 12:21:49 --> Router Class Initialized
INFO - 2020-09-24 12:21:49 --> Output Class Initialized
INFO - 2020-09-24 12:21:49 --> Security Class Initialized
DEBUG - 2020-09-24 12:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:21:49 --> Input Class Initialized
INFO - 2020-09-24 12:21:49 --> Language Class Initialized
INFO - 2020-09-24 12:21:49 --> Loader Class Initialized
INFO - 2020-09-24 12:21:49 --> Helper loaded: url_helper
INFO - 2020-09-24 12:21:49 --> Helper loaded: file_helper
INFO - 2020-09-24 12:21:49 --> Database Driver Class Initialized
INFO - 2020-09-24 12:21:49 --> Email Class Initialized
DEBUG - 2020-09-24 12:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:21:50 --> Controller Class Initialized
INFO - 2020-09-24 12:21:50 --> Model "Main_model" initialized
INFO - 2020-09-24 12:21:50 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:21:50 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:21:50 --> Final output sent to browser
DEBUG - 2020-09-24 12:21:50 --> Total execution time: 0.3384
INFO - 2020-09-24 12:21:50 --> Config Class Initialized
INFO - 2020-09-24 12:21:50 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:21:50 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:21:50 --> Utf8 Class Initialized
INFO - 2020-09-24 12:21:50 --> URI Class Initialized
INFO - 2020-09-24 12:21:50 --> Router Class Initialized
INFO - 2020-09-24 12:21:51 --> Output Class Initialized
INFO - 2020-09-24 12:21:51 --> Security Class Initialized
DEBUG - 2020-09-24 12:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:21:51 --> Input Class Initialized
INFO - 2020-09-24 12:21:51 --> Language Class Initialized
ERROR - 2020-09-24 12:21:51 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-24 12:21:54 --> Config Class Initialized
INFO - 2020-09-24 12:21:54 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:21:54 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:21:54 --> Utf8 Class Initialized
INFO - 2020-09-24 12:21:54 --> URI Class Initialized
INFO - 2020-09-24 12:21:54 --> Router Class Initialized
INFO - 2020-09-24 12:21:54 --> Output Class Initialized
INFO - 2020-09-24 12:21:54 --> Security Class Initialized
DEBUG - 2020-09-24 12:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:21:54 --> Input Class Initialized
INFO - 2020-09-24 12:21:54 --> Language Class Initialized
INFO - 2020-09-24 12:21:54 --> Loader Class Initialized
INFO - 2020-09-24 12:21:54 --> Helper loaded: url_helper
INFO - 2020-09-24 12:21:54 --> Helper loaded: file_helper
INFO - 2020-09-24 12:21:54 --> Database Driver Class Initialized
INFO - 2020-09-24 12:21:54 --> Email Class Initialized
DEBUG - 2020-09-24 12:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:21:54 --> Controller Class Initialized
INFO - 2020-09-24 12:21:54 --> Model "Main_model" initialized
INFO - 2020-09-24 12:22:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:22:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:22:02 --> Final output sent to browser
DEBUG - 2020-09-24 12:22:02 --> Total execution time: 8.3043
INFO - 2020-09-24 12:22:03 --> Config Class Initialized
INFO - 2020-09-24 12:22:03 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:22:03 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:22:03 --> Utf8 Class Initialized
INFO - 2020-09-24 12:22:03 --> URI Class Initialized
INFO - 2020-09-24 12:22:03 --> Router Class Initialized
INFO - 2020-09-24 12:22:03 --> Output Class Initialized
INFO - 2020-09-24 12:22:03 --> Security Class Initialized
DEBUG - 2020-09-24 12:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:22:03 --> Input Class Initialized
INFO - 2020-09-24 12:22:03 --> Language Class Initialized
ERROR - 2020-09-24 12:22:03 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-24 12:25:34 --> Config Class Initialized
INFO - 2020-09-24 12:25:34 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:25:34 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:25:34 --> Utf8 Class Initialized
INFO - 2020-09-24 12:25:34 --> URI Class Initialized
INFO - 2020-09-24 12:25:34 --> Router Class Initialized
INFO - 2020-09-24 12:25:34 --> Output Class Initialized
INFO - 2020-09-24 12:25:34 --> Security Class Initialized
DEBUG - 2020-09-24 12:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:25:34 --> Input Class Initialized
INFO - 2020-09-24 12:25:34 --> Language Class Initialized
INFO - 2020-09-24 12:25:34 --> Loader Class Initialized
INFO - 2020-09-24 12:25:34 --> Helper loaded: url_helper
INFO - 2020-09-24 12:25:34 --> Helper loaded: file_helper
INFO - 2020-09-24 12:25:34 --> Database Driver Class Initialized
INFO - 2020-09-24 12:25:34 --> Email Class Initialized
DEBUG - 2020-09-24 12:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:25:34 --> Controller Class Initialized
INFO - 2020-09-24 12:25:34 --> Model "Main_model" initialized
INFO - 2020-09-24 12:25:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:25:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:25:34 --> Final output sent to browser
DEBUG - 2020-09-24 12:25:34 --> Total execution time: 0.3352
INFO - 2020-09-24 12:25:37 --> Config Class Initialized
INFO - 2020-09-24 12:25:37 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:25:37 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:25:37 --> Utf8 Class Initialized
INFO - 2020-09-24 12:25:37 --> URI Class Initialized
INFO - 2020-09-24 12:25:37 --> Router Class Initialized
INFO - 2020-09-24 12:25:37 --> Output Class Initialized
INFO - 2020-09-24 12:25:37 --> Security Class Initialized
DEBUG - 2020-09-24 12:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:25:37 --> Input Class Initialized
INFO - 2020-09-24 12:25:37 --> Language Class Initialized
INFO - 2020-09-24 12:25:37 --> Loader Class Initialized
INFO - 2020-09-24 12:25:37 --> Helper loaded: url_helper
INFO - 2020-09-24 12:25:38 --> Helper loaded: file_helper
INFO - 2020-09-24 12:25:38 --> Database Driver Class Initialized
INFO - 2020-09-24 12:25:38 --> Email Class Initialized
DEBUG - 2020-09-24 12:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:25:38 --> Controller Class Initialized
INFO - 2020-09-24 12:25:38 --> Model "Main_model" initialized
INFO - 2020-09-24 12:25:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:25:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:25:43 --> Final output sent to browser
DEBUG - 2020-09-24 12:25:43 --> Total execution time: 5.7324
INFO - 2020-09-24 12:27:07 --> Config Class Initialized
INFO - 2020-09-24 12:27:07 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:27:07 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:27:07 --> Utf8 Class Initialized
INFO - 2020-09-24 12:27:07 --> URI Class Initialized
INFO - 2020-09-24 12:27:07 --> Router Class Initialized
INFO - 2020-09-24 12:27:08 --> Output Class Initialized
INFO - 2020-09-24 12:27:08 --> Security Class Initialized
DEBUG - 2020-09-24 12:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:27:08 --> Input Class Initialized
INFO - 2020-09-24 12:27:08 --> Language Class Initialized
INFO - 2020-09-24 12:27:08 --> Loader Class Initialized
INFO - 2020-09-24 12:27:08 --> Helper loaded: url_helper
INFO - 2020-09-24 12:27:08 --> Helper loaded: file_helper
INFO - 2020-09-24 12:27:08 --> Database Driver Class Initialized
INFO - 2020-09-24 12:27:08 --> Email Class Initialized
DEBUG - 2020-09-24 12:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:27:08 --> Controller Class Initialized
INFO - 2020-09-24 12:27:08 --> Model "Main_model" initialized
INFO - 2020-09-24 12:27:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:27:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '1' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '1' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '1' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '1' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '1' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '1' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '1' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '1' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
INFO - 2020-09-24 12:27:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:27:08 --> Final output sent to browser
DEBUG - 2020-09-24 12:27:08 --> Total execution time: 1.0528
INFO - 2020-09-24 12:27:20 --> Config Class Initialized
INFO - 2020-09-24 12:27:20 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:27:20 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:27:20 --> Utf8 Class Initialized
INFO - 2020-09-24 12:27:20 --> URI Class Initialized
INFO - 2020-09-24 12:27:20 --> Router Class Initialized
INFO - 2020-09-24 12:27:20 --> Output Class Initialized
INFO - 2020-09-24 12:27:20 --> Security Class Initialized
DEBUG - 2020-09-24 12:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:27:20 --> Input Class Initialized
INFO - 2020-09-24 12:27:20 --> Language Class Initialized
INFO - 2020-09-24 12:27:20 --> Loader Class Initialized
INFO - 2020-09-24 12:27:21 --> Helper loaded: url_helper
INFO - 2020-09-24 12:27:21 --> Helper loaded: file_helper
INFO - 2020-09-24 12:27:21 --> Database Driver Class Initialized
INFO - 2020-09-24 12:27:21 --> Email Class Initialized
DEBUG - 2020-09-24 12:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:27:21 --> Controller Class Initialized
INFO - 2020-09-24 12:27:21 --> Model "Main_model" initialized
INFO - 2020-09-24 12:27:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:27:21 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:21 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:21 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:21 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:21 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:21 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:21 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:21 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
INFO - 2020-09-24 12:27:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:27:21 --> Final output sent to browser
DEBUG - 2020-09-24 12:27:21 --> Total execution time: 0.5141
INFO - 2020-09-24 12:27:37 --> Config Class Initialized
INFO - 2020-09-24 12:27:37 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:27:37 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:27:37 --> Utf8 Class Initialized
INFO - 2020-09-24 12:27:37 --> URI Class Initialized
INFO - 2020-09-24 12:27:37 --> Router Class Initialized
INFO - 2020-09-24 12:27:37 --> Output Class Initialized
INFO - 2020-09-24 12:27:37 --> Security Class Initialized
DEBUG - 2020-09-24 12:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:27:37 --> Input Class Initialized
INFO - 2020-09-24 12:27:37 --> Language Class Initialized
INFO - 2020-09-24 12:27:37 --> Loader Class Initialized
INFO - 2020-09-24 12:27:37 --> Helper loaded: url_helper
INFO - 2020-09-24 12:27:37 --> Helper loaded: file_helper
INFO - 2020-09-24 12:27:37 --> Database Driver Class Initialized
INFO - 2020-09-24 12:27:37 --> Email Class Initialized
DEBUG - 2020-09-24 12:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:27:37 --> Controller Class Initialized
INFO - 2020-09-24 12:27:37 --> Model "Main_model" initialized
INFO - 2020-09-24 12:27:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:27:37 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:37 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:37 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:37 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:37 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:37 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:37 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:37 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
INFO - 2020-09-24 12:27:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:27:37 --> Final output sent to browser
DEBUG - 2020-09-24 12:27:37 --> Total execution time: 0.5349
INFO - 2020-09-24 12:27:58 --> Config Class Initialized
INFO - 2020-09-24 12:27:58 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:27:58 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:27:58 --> Utf8 Class Initialized
INFO - 2020-09-24 12:27:58 --> URI Class Initialized
INFO - 2020-09-24 12:27:58 --> Router Class Initialized
INFO - 2020-09-24 12:27:58 --> Output Class Initialized
INFO - 2020-09-24 12:27:58 --> Security Class Initialized
DEBUG - 2020-09-24 12:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:27:58 --> Input Class Initialized
INFO - 2020-09-24 12:27:58 --> Language Class Initialized
INFO - 2020-09-24 12:27:58 --> Loader Class Initialized
INFO - 2020-09-24 12:27:58 --> Helper loaded: url_helper
INFO - 2020-09-24 12:27:58 --> Helper loaded: file_helper
INFO - 2020-09-24 12:27:58 --> Database Driver Class Initialized
INFO - 2020-09-24 12:27:58 --> Email Class Initialized
DEBUG - 2020-09-24 12:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:27:59 --> Controller Class Initialized
INFO - 2020-09-24 12:27:59 --> Model "Main_model" initialized
INFO - 2020-09-24 12:27:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:27:59 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:59 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:59 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:59 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:59 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:59 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:59 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:27:59 --> Severity: Warning --> preg_match_all(): Unknown modifier '{' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
INFO - 2020-09-24 12:27:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:27:59 --> Final output sent to browser
DEBUG - 2020-09-24 12:27:59 --> Total execution time: 0.5222
INFO - 2020-09-24 12:28:08 --> Config Class Initialized
INFO - 2020-09-24 12:28:08 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:28:08 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:28:08 --> Utf8 Class Initialized
INFO - 2020-09-24 12:28:08 --> URI Class Initialized
INFO - 2020-09-24 12:28:08 --> Router Class Initialized
INFO - 2020-09-24 12:28:08 --> Output Class Initialized
INFO - 2020-09-24 12:28:08 --> Security Class Initialized
DEBUG - 2020-09-24 12:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:28:08 --> Input Class Initialized
INFO - 2020-09-24 12:28:08 --> Language Class Initialized
INFO - 2020-09-24 12:28:08 --> Loader Class Initialized
INFO - 2020-09-24 12:28:08 --> Helper loaded: url_helper
INFO - 2020-09-24 12:28:08 --> Helper loaded: file_helper
INFO - 2020-09-24 12:28:08 --> Database Driver Class Initialized
INFO - 2020-09-24 12:28:08 --> Email Class Initialized
DEBUG - 2020-09-24 12:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:28:08 --> Controller Class Initialized
INFO - 2020-09-24 12:28:08 --> Model "Main_model" initialized
INFO - 2020-09-24 12:28:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:28:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:28:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:28:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:28:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:28:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:28:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:28:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:28:08 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
INFO - 2020-09-24 12:28:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:28:08 --> Final output sent to browser
DEBUG - 2020-09-24 12:28:08 --> Total execution time: 0.5580
INFO - 2020-09-24 12:28:18 --> Config Class Initialized
INFO - 2020-09-24 12:28:19 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:28:19 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:28:19 --> Utf8 Class Initialized
INFO - 2020-09-24 12:28:19 --> URI Class Initialized
INFO - 2020-09-24 12:28:19 --> Router Class Initialized
INFO - 2020-09-24 12:28:19 --> Output Class Initialized
INFO - 2020-09-24 12:28:19 --> Security Class Initialized
DEBUG - 2020-09-24 12:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:28:19 --> Input Class Initialized
INFO - 2020-09-24 12:28:19 --> Language Class Initialized
INFO - 2020-09-24 12:28:19 --> Loader Class Initialized
INFO - 2020-09-24 12:28:19 --> Helper loaded: url_helper
INFO - 2020-09-24 12:28:19 --> Helper loaded: file_helper
INFO - 2020-09-24 12:28:19 --> Database Driver Class Initialized
INFO - 2020-09-24 12:28:19 --> Email Class Initialized
DEBUG - 2020-09-24 12:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:28:19 --> Controller Class Initialized
INFO - 2020-09-24 12:28:19 --> Model "Main_model" initialized
INFO - 2020-09-24 12:28:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:28:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:28:24 --> Final output sent to browser
DEBUG - 2020-09-24 12:28:24 --> Total execution time: 5.5199
INFO - 2020-09-24 12:29:29 --> Config Class Initialized
INFO - 2020-09-24 12:29:29 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:29:29 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:29:29 --> Utf8 Class Initialized
INFO - 2020-09-24 12:29:29 --> URI Class Initialized
INFO - 2020-09-24 12:29:29 --> Router Class Initialized
INFO - 2020-09-24 12:29:29 --> Output Class Initialized
INFO - 2020-09-24 12:29:29 --> Security Class Initialized
DEBUG - 2020-09-24 12:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:29:29 --> Input Class Initialized
INFO - 2020-09-24 12:29:29 --> Language Class Initialized
INFO - 2020-09-24 12:29:29 --> Loader Class Initialized
INFO - 2020-09-24 12:29:29 --> Helper loaded: url_helper
INFO - 2020-09-24 12:29:29 --> Helper loaded: file_helper
INFO - 2020-09-24 12:29:29 --> Database Driver Class Initialized
INFO - 2020-09-24 12:29:29 --> Email Class Initialized
DEBUG - 2020-09-24 12:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:29:29 --> Controller Class Initialized
INFO - 2020-09-24 12:29:29 --> Model "Main_model" initialized
INFO - 2020-09-24 12:29:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:29:29 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:29 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:29 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:29 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:29 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:29 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:29 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:29 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
INFO - 2020-09-24 12:29:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:29:29 --> Final output sent to browser
DEBUG - 2020-09-24 12:29:29 --> Total execution time: 0.5631
INFO - 2020-09-24 12:29:48 --> Config Class Initialized
INFO - 2020-09-24 12:29:48 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:29:48 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:29:48 --> Utf8 Class Initialized
INFO - 2020-09-24 12:29:48 --> URI Class Initialized
INFO - 2020-09-24 12:29:48 --> Router Class Initialized
INFO - 2020-09-24 12:29:48 --> Output Class Initialized
INFO - 2020-09-24 12:29:48 --> Security Class Initialized
DEBUG - 2020-09-24 12:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:29:48 --> Input Class Initialized
INFO - 2020-09-24 12:29:48 --> Language Class Initialized
INFO - 2020-09-24 12:29:48 --> Loader Class Initialized
INFO - 2020-09-24 12:29:48 --> Helper loaded: url_helper
INFO - 2020-09-24 12:29:48 --> Helper loaded: file_helper
INFO - 2020-09-24 12:29:48 --> Database Driver Class Initialized
INFO - 2020-09-24 12:29:48 --> Email Class Initialized
DEBUG - 2020-09-24 12:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:29:48 --> Controller Class Initialized
INFO - 2020-09-24 12:29:48 --> Model "Main_model" initialized
INFO - 2020-09-24 12:29:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:29:48 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:29:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
INFO - 2020-09-24 12:29:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:29:49 --> Final output sent to browser
DEBUG - 2020-09-24 12:29:49 --> Total execution time: 0.5602
INFO - 2020-09-24 12:30:05 --> Config Class Initialized
INFO - 2020-09-24 12:30:05 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:30:05 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:30:05 --> Utf8 Class Initialized
INFO - 2020-09-24 12:30:05 --> URI Class Initialized
INFO - 2020-09-24 12:30:05 --> Router Class Initialized
INFO - 2020-09-24 12:30:05 --> Output Class Initialized
INFO - 2020-09-24 12:30:05 --> Security Class Initialized
DEBUG - 2020-09-24 12:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:30:05 --> Input Class Initialized
INFO - 2020-09-24 12:30:05 --> Language Class Initialized
INFO - 2020-09-24 12:30:05 --> Loader Class Initialized
INFO - 2020-09-24 12:30:05 --> Helper loaded: url_helper
INFO - 2020-09-24 12:30:05 --> Helper loaded: file_helper
INFO - 2020-09-24 12:30:05 --> Database Driver Class Initialized
INFO - 2020-09-24 12:30:05 --> Email Class Initialized
DEBUG - 2020-09-24 12:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:30:05 --> Controller Class Initialized
INFO - 2020-09-24 12:30:05 --> Model "Main_model" initialized
INFO - 2020-09-24 12:30:05 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:30:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
INFO - 2020-09-24 12:30:05 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:30:05 --> Final output sent to browser
DEBUG - 2020-09-24 12:30:05 --> Total execution time: 0.5820
INFO - 2020-09-24 12:30:14 --> Config Class Initialized
INFO - 2020-09-24 12:30:14 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:30:14 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:30:14 --> Utf8 Class Initialized
INFO - 2020-09-24 12:30:14 --> URI Class Initialized
INFO - 2020-09-24 12:30:14 --> Router Class Initialized
INFO - 2020-09-24 12:30:14 --> Output Class Initialized
INFO - 2020-09-24 12:30:14 --> Security Class Initialized
DEBUG - 2020-09-24 12:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:30:14 --> Input Class Initialized
INFO - 2020-09-24 12:30:14 --> Language Class Initialized
INFO - 2020-09-24 12:30:14 --> Loader Class Initialized
INFO - 2020-09-24 12:30:14 --> Helper loaded: url_helper
INFO - 2020-09-24 12:30:14 --> Helper loaded: file_helper
INFO - 2020-09-24 12:30:14 --> Database Driver Class Initialized
INFO - 2020-09-24 12:30:14 --> Email Class Initialized
DEBUG - 2020-09-24 12:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:30:15 --> Controller Class Initialized
INFO - 2020-09-24 12:30:15 --> Model "Main_model" initialized
INFO - 2020-09-24 12:30:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:30:15 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:15 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:15 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:15 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:15 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:15 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:15 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:30:15 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
INFO - 2020-09-24 12:30:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:30:15 --> Final output sent to browser
DEBUG - 2020-09-24 12:30:15 --> Total execution time: 0.5633
INFO - 2020-09-24 12:30:27 --> Config Class Initialized
INFO - 2020-09-24 12:30:27 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:30:27 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:30:27 --> Utf8 Class Initialized
INFO - 2020-09-24 12:30:27 --> URI Class Initialized
INFO - 2020-09-24 12:30:27 --> Router Class Initialized
INFO - 2020-09-24 12:30:27 --> Output Class Initialized
INFO - 2020-09-24 12:30:27 --> Security Class Initialized
DEBUG - 2020-09-24 12:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:30:27 --> Input Class Initialized
INFO - 2020-09-24 12:30:27 --> Language Class Initialized
INFO - 2020-09-24 12:30:27 --> Loader Class Initialized
INFO - 2020-09-24 12:30:27 --> Helper loaded: url_helper
INFO - 2020-09-24 12:30:27 --> Helper loaded: file_helper
INFO - 2020-09-24 12:30:27 --> Database Driver Class Initialized
INFO - 2020-09-24 12:30:27 --> Email Class Initialized
DEBUG - 2020-09-24 12:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:30:27 --> Controller Class Initialized
INFO - 2020-09-24 12:30:27 --> Model "Main_model" initialized
INFO - 2020-09-24 12:30:27 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:30:27 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:30:27 --> Final output sent to browser
DEBUG - 2020-09-24 12:30:27 --> Total execution time: 0.4433
INFO - 2020-09-24 12:31:05 --> Config Class Initialized
INFO - 2020-09-24 12:31:05 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:31:05 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:31:05 --> Utf8 Class Initialized
INFO - 2020-09-24 12:31:05 --> URI Class Initialized
INFO - 2020-09-24 12:31:05 --> Router Class Initialized
INFO - 2020-09-24 12:31:05 --> Output Class Initialized
INFO - 2020-09-24 12:31:05 --> Security Class Initialized
DEBUG - 2020-09-24 12:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:31:05 --> Input Class Initialized
INFO - 2020-09-24 12:31:05 --> Language Class Initialized
INFO - 2020-09-24 12:31:05 --> Loader Class Initialized
INFO - 2020-09-24 12:31:05 --> Helper loaded: url_helper
INFO - 2020-09-24 12:31:05 --> Helper loaded: file_helper
INFO - 2020-09-24 12:31:05 --> Database Driver Class Initialized
INFO - 2020-09-24 12:31:05 --> Email Class Initialized
DEBUG - 2020-09-24 12:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:31:05 --> Controller Class Initialized
INFO - 2020-09-24 12:31:06 --> Model "Main_model" initialized
INFO - 2020-09-24 12:31:06 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:31:06 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:31:06 --> Final output sent to browser
DEBUG - 2020-09-24 12:31:06 --> Total execution time: 0.4640
INFO - 2020-09-24 12:31:32 --> Config Class Initialized
INFO - 2020-09-24 12:31:32 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:31:32 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:31:32 --> Utf8 Class Initialized
INFO - 2020-09-24 12:31:32 --> URI Class Initialized
INFO - 2020-09-24 12:31:32 --> Router Class Initialized
INFO - 2020-09-24 12:31:32 --> Output Class Initialized
INFO - 2020-09-24 12:31:32 --> Security Class Initialized
DEBUG - 2020-09-24 12:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:31:32 --> Input Class Initialized
INFO - 2020-09-24 12:31:32 --> Language Class Initialized
INFO - 2020-09-24 12:31:32 --> Loader Class Initialized
INFO - 2020-09-24 12:31:32 --> Helper loaded: url_helper
INFO - 2020-09-24 12:31:32 --> Helper loaded: file_helper
INFO - 2020-09-24 12:31:32 --> Database Driver Class Initialized
INFO - 2020-09-24 12:31:32 --> Email Class Initialized
DEBUG - 2020-09-24 12:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:31:32 --> Controller Class Initialized
INFO - 2020-09-24 12:31:32 --> Model "Main_model" initialized
INFO - 2020-09-24 12:31:32 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:31:32 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:32 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:32 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:32 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:32 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:32 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:32 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:32 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
INFO - 2020-09-24 12:31:32 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:31:32 --> Final output sent to browser
DEBUG - 2020-09-24 12:31:32 --> Total execution time: 0.5740
INFO - 2020-09-24 12:31:48 --> Config Class Initialized
INFO - 2020-09-24 12:31:48 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:31:48 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:31:48 --> Utf8 Class Initialized
INFO - 2020-09-24 12:31:48 --> URI Class Initialized
INFO - 2020-09-24 12:31:48 --> Router Class Initialized
INFO - 2020-09-24 12:31:48 --> Output Class Initialized
INFO - 2020-09-24 12:31:48 --> Security Class Initialized
DEBUG - 2020-09-24 12:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:31:48 --> Input Class Initialized
INFO - 2020-09-24 12:31:48 --> Language Class Initialized
INFO - 2020-09-24 12:31:48 --> Loader Class Initialized
INFO - 2020-09-24 12:31:48 --> Helper loaded: url_helper
INFO - 2020-09-24 12:31:48 --> Helper loaded: file_helper
INFO - 2020-09-24 12:31:48 --> Database Driver Class Initialized
INFO - 2020-09-24 12:31:48 --> Email Class Initialized
DEBUG - 2020-09-24 12:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:31:48 --> Controller Class Initialized
INFO - 2020-09-24 12:31:48 --> Model "Main_model" initialized
INFO - 2020-09-24 12:31:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:31:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:31:49 --> Severity: Warning --> preg_match_all(): Unknown modifier '/' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
INFO - 2020-09-24 12:31:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:31:49 --> Final output sent to browser
DEBUG - 2020-09-24 12:31:49 --> Total execution time: 0.5379
INFO - 2020-09-24 12:32:05 --> Config Class Initialized
INFO - 2020-09-24 12:32:05 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:32:05 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:32:05 --> Utf8 Class Initialized
INFO - 2020-09-24 12:32:05 --> URI Class Initialized
INFO - 2020-09-24 12:32:05 --> Router Class Initialized
INFO - 2020-09-24 12:32:05 --> Output Class Initialized
INFO - 2020-09-24 12:32:05 --> Security Class Initialized
DEBUG - 2020-09-24 12:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:32:05 --> Input Class Initialized
INFO - 2020-09-24 12:32:05 --> Language Class Initialized
INFO - 2020-09-24 12:32:05 --> Loader Class Initialized
INFO - 2020-09-24 12:32:05 --> Helper loaded: url_helper
INFO - 2020-09-24 12:32:05 --> Helper loaded: file_helper
INFO - 2020-09-24 12:32:05 --> Database Driver Class Initialized
INFO - 2020-09-24 12:32:05 --> Email Class Initialized
DEBUG - 2020-09-24 12:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:32:05 --> Controller Class Initialized
INFO - 2020-09-24 12:32:05 --> Model "Main_model" initialized
INFO - 2020-09-24 12:32:05 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:32:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:32:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:32:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:32:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:32:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:32:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:32:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
ERROR - 2020-09-24 12:32:05 --> Severity: Warning --> preg_match_all(): Unknown modifier '\' C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 172
INFO - 2020-09-24 12:32:05 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:32:05 --> Final output sent to browser
DEBUG - 2020-09-24 12:32:05 --> Total execution time: 0.5449
INFO - 2020-09-24 12:34:35 --> Config Class Initialized
INFO - 2020-09-24 12:34:35 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:34:35 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:34:35 --> Utf8 Class Initialized
INFO - 2020-09-24 12:34:35 --> URI Class Initialized
INFO - 2020-09-24 12:34:35 --> Router Class Initialized
INFO - 2020-09-24 12:34:35 --> Output Class Initialized
INFO - 2020-09-24 12:34:35 --> Security Class Initialized
DEBUG - 2020-09-24 12:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:34:35 --> Input Class Initialized
INFO - 2020-09-24 12:34:35 --> Language Class Initialized
INFO - 2020-09-24 12:34:35 --> Loader Class Initialized
INFO - 2020-09-24 12:34:35 --> Helper loaded: url_helper
INFO - 2020-09-24 12:34:35 --> Helper loaded: file_helper
INFO - 2020-09-24 12:34:35 --> Database Driver Class Initialized
INFO - 2020-09-24 12:34:35 --> Email Class Initialized
DEBUG - 2020-09-24 12:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:34:35 --> Controller Class Initialized
INFO - 2020-09-24 12:34:35 --> Model "Main_model" initialized
INFO - 2020-09-24 12:34:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:34:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:34:48 --> Final output sent to browser
DEBUG - 2020-09-24 12:34:48 --> Total execution time: 13.4699
INFO - 2020-09-24 12:36:21 --> Config Class Initialized
INFO - 2020-09-24 12:36:21 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:36:21 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:36:21 --> Utf8 Class Initialized
INFO - 2020-09-24 12:36:21 --> URI Class Initialized
INFO - 2020-09-24 12:36:21 --> Router Class Initialized
INFO - 2020-09-24 12:36:21 --> Output Class Initialized
INFO - 2020-09-24 12:36:21 --> Security Class Initialized
DEBUG - 2020-09-24 12:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:36:21 --> Input Class Initialized
INFO - 2020-09-24 12:36:21 --> Language Class Initialized
INFO - 2020-09-24 12:36:21 --> Loader Class Initialized
INFO - 2020-09-24 12:36:21 --> Helper loaded: url_helper
INFO - 2020-09-24 12:36:21 --> Helper loaded: file_helper
INFO - 2020-09-24 12:36:21 --> Database Driver Class Initialized
INFO - 2020-09-24 12:36:21 --> Email Class Initialized
DEBUG - 2020-09-24 12:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:36:21 --> Controller Class Initialized
INFO - 2020-09-24 12:36:21 --> Model "Main_model" initialized
INFO - 2020-09-24 12:36:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:36:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:36:21 --> Final output sent to browser
DEBUG - 2020-09-24 12:36:21 --> Total execution time: 0.4442
INFO - 2020-09-24 12:37:25 --> Config Class Initialized
INFO - 2020-09-24 12:37:25 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:37:25 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:37:25 --> Utf8 Class Initialized
INFO - 2020-09-24 12:37:25 --> URI Class Initialized
INFO - 2020-09-24 12:37:25 --> Router Class Initialized
INFO - 2020-09-24 12:37:25 --> Output Class Initialized
INFO - 2020-09-24 12:37:25 --> Security Class Initialized
DEBUG - 2020-09-24 12:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:37:25 --> Input Class Initialized
INFO - 2020-09-24 12:37:25 --> Language Class Initialized
ERROR - 2020-09-24 12:37:25 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-24 12:39:21 --> Config Class Initialized
INFO - 2020-09-24 12:39:21 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:39:21 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:39:21 --> Utf8 Class Initialized
INFO - 2020-09-24 12:39:21 --> URI Class Initialized
INFO - 2020-09-24 12:39:21 --> Router Class Initialized
INFO - 2020-09-24 12:39:21 --> Output Class Initialized
INFO - 2020-09-24 12:39:21 --> Security Class Initialized
DEBUG - 2020-09-24 12:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:39:21 --> Input Class Initialized
INFO - 2020-09-24 12:39:21 --> Language Class Initialized
INFO - 2020-09-24 12:39:21 --> Loader Class Initialized
INFO - 2020-09-24 12:39:21 --> Helper loaded: url_helper
INFO - 2020-09-24 12:39:21 --> Helper loaded: file_helper
INFO - 2020-09-24 12:39:21 --> Database Driver Class Initialized
INFO - 2020-09-24 12:39:21 --> Email Class Initialized
DEBUG - 2020-09-24 12:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:39:21 --> Controller Class Initialized
INFO - 2020-09-24 12:39:21 --> Model "Main_model" initialized
INFO - 2020-09-24 12:39:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:39:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:39:21 --> Final output sent to browser
DEBUG - 2020-09-24 12:39:21 --> Total execution time: 0.6986
INFO - 2020-09-24 12:39:31 --> Config Class Initialized
INFO - 2020-09-24 12:39:31 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:39:31 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:39:31 --> Utf8 Class Initialized
INFO - 2020-09-24 12:39:31 --> URI Class Initialized
INFO - 2020-09-24 12:39:31 --> Router Class Initialized
INFO - 2020-09-24 12:39:31 --> Output Class Initialized
INFO - 2020-09-24 12:39:31 --> Security Class Initialized
DEBUG - 2020-09-24 12:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:39:31 --> Input Class Initialized
INFO - 2020-09-24 12:39:31 --> Language Class Initialized
ERROR - 2020-09-24 12:39:31 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-24 12:41:50 --> Config Class Initialized
INFO - 2020-09-24 12:41:50 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:41:50 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:41:50 --> Utf8 Class Initialized
INFO - 2020-09-24 12:41:50 --> URI Class Initialized
INFO - 2020-09-24 12:41:50 --> Router Class Initialized
INFO - 2020-09-24 12:41:50 --> Output Class Initialized
INFO - 2020-09-24 12:41:50 --> Security Class Initialized
DEBUG - 2020-09-24 12:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:41:50 --> Input Class Initialized
INFO - 2020-09-24 12:41:50 --> Language Class Initialized
INFO - 2020-09-24 12:41:50 --> Loader Class Initialized
INFO - 2020-09-24 12:41:50 --> Helper loaded: url_helper
INFO - 2020-09-24 12:41:50 --> Helper loaded: file_helper
INFO - 2020-09-24 12:41:50 --> Database Driver Class Initialized
INFO - 2020-09-24 12:41:50 --> Email Class Initialized
DEBUG - 2020-09-24 12:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:41:51 --> Controller Class Initialized
INFO - 2020-09-24 12:41:51 --> Model "Main_model" initialized
INFO - 2020-09-24 12:41:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:41:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:41:51 --> Final output sent to browser
DEBUG - 2020-09-24 12:41:51 --> Total execution time: 0.9159
INFO - 2020-09-24 12:41:53 --> Config Class Initialized
INFO - 2020-09-24 12:41:53 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:41:53 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:41:53 --> Utf8 Class Initialized
INFO - 2020-09-24 12:41:53 --> URI Class Initialized
INFO - 2020-09-24 12:41:53 --> Router Class Initialized
INFO - 2020-09-24 12:41:53 --> Output Class Initialized
INFO - 2020-09-24 12:41:53 --> Security Class Initialized
DEBUG - 2020-09-24 12:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:41:53 --> Input Class Initialized
INFO - 2020-09-24 12:41:53 --> Language Class Initialized
ERROR - 2020-09-24 12:41:53 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-24 12:42:29 --> Config Class Initialized
INFO - 2020-09-24 12:42:29 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:42:29 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:42:29 --> Utf8 Class Initialized
INFO - 2020-09-24 12:42:29 --> URI Class Initialized
INFO - 2020-09-24 12:42:29 --> Router Class Initialized
INFO - 2020-09-24 12:42:29 --> Output Class Initialized
INFO - 2020-09-24 12:42:29 --> Security Class Initialized
DEBUG - 2020-09-24 12:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:42:29 --> Input Class Initialized
INFO - 2020-09-24 12:42:29 --> Language Class Initialized
INFO - 2020-09-24 12:42:29 --> Loader Class Initialized
INFO - 2020-09-24 12:42:29 --> Helper loaded: url_helper
INFO - 2020-09-24 12:42:29 --> Helper loaded: file_helper
INFO - 2020-09-24 12:42:29 --> Database Driver Class Initialized
INFO - 2020-09-24 12:42:29 --> Email Class Initialized
DEBUG - 2020-09-24 12:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:42:29 --> Controller Class Initialized
INFO - 2020-09-24 12:42:29 --> Model "Main_model" initialized
INFO - 2020-09-24 12:42:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:42:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:42:33 --> Final output sent to browser
DEBUG - 2020-09-24 12:42:33 --> Total execution time: 4.0353
INFO - 2020-09-24 12:42:41 --> Config Class Initialized
INFO - 2020-09-24 12:42:41 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:42:41 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:42:41 --> Utf8 Class Initialized
INFO - 2020-09-24 12:42:41 --> URI Class Initialized
INFO - 2020-09-24 12:42:41 --> Router Class Initialized
INFO - 2020-09-24 12:42:41 --> Output Class Initialized
INFO - 2020-09-24 12:42:41 --> Security Class Initialized
DEBUG - 2020-09-24 12:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:42:42 --> Input Class Initialized
INFO - 2020-09-24 12:42:42 --> Language Class Initialized
INFO - 2020-09-24 12:42:42 --> Loader Class Initialized
INFO - 2020-09-24 12:42:42 --> Helper loaded: url_helper
INFO - 2020-09-24 12:42:42 --> Helper loaded: file_helper
INFO - 2020-09-24 12:42:42 --> Database Driver Class Initialized
INFO - 2020-09-24 12:42:42 --> Email Class Initialized
DEBUG - 2020-09-24 12:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:42:42 --> Controller Class Initialized
INFO - 2020-09-24 12:42:42 --> Model "Main_model" initialized
INFO - 2020-09-24 12:42:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:42:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:42:43 --> Final output sent to browser
DEBUG - 2020-09-24 12:42:43 --> Total execution time: 1.2677
INFO - 2020-09-24 12:42:57 --> Config Class Initialized
INFO - 2020-09-24 12:42:57 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:42:57 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:42:57 --> Utf8 Class Initialized
INFO - 2020-09-24 12:42:57 --> URI Class Initialized
INFO - 2020-09-24 12:42:57 --> Router Class Initialized
INFO - 2020-09-24 12:42:57 --> Output Class Initialized
INFO - 2020-09-24 12:42:57 --> Security Class Initialized
DEBUG - 2020-09-24 12:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:42:57 --> Input Class Initialized
INFO - 2020-09-24 12:42:57 --> Language Class Initialized
INFO - 2020-09-24 12:42:57 --> Loader Class Initialized
INFO - 2020-09-24 12:42:57 --> Helper loaded: url_helper
INFO - 2020-09-24 12:42:57 --> Helper loaded: file_helper
INFO - 2020-09-24 12:42:57 --> Database Driver Class Initialized
INFO - 2020-09-24 12:42:57 --> Email Class Initialized
DEBUG - 2020-09-24 12:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:42:57 --> Controller Class Initialized
INFO - 2020-09-24 12:42:57 --> Model "Main_model" initialized
ERROR - 2020-09-24 12:43:08 --> Severity: Notice --> Undefined variable: spf C:\xampp\htdocs\dmarc\application\controllers\Home.php 59
INFO - 2020-09-24 12:43:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:43:08 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 161
INFO - 2020-09-24 12:43:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:43:08 --> Final output sent to browser
DEBUG - 2020-09-24 12:43:08 --> Total execution time: 11.4645
INFO - 2020-09-24 12:43:19 --> Config Class Initialized
INFO - 2020-09-24 12:43:19 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:43:19 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:43:19 --> Utf8 Class Initialized
INFO - 2020-09-24 12:43:19 --> URI Class Initialized
INFO - 2020-09-24 12:43:19 --> Router Class Initialized
INFO - 2020-09-24 12:43:19 --> Output Class Initialized
INFO - 2020-09-24 12:43:19 --> Security Class Initialized
DEBUG - 2020-09-24 12:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:43:19 --> Input Class Initialized
INFO - 2020-09-24 12:43:19 --> Language Class Initialized
INFO - 2020-09-24 12:43:19 --> Loader Class Initialized
INFO - 2020-09-24 12:43:19 --> Helper loaded: url_helper
INFO - 2020-09-24 12:43:19 --> Helper loaded: file_helper
INFO - 2020-09-24 12:43:19 --> Database Driver Class Initialized
INFO - 2020-09-24 12:43:19 --> Email Class Initialized
DEBUG - 2020-09-24 12:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:43:19 --> Controller Class Initialized
INFO - 2020-09-24 12:43:19 --> Model "Main_model" initialized
ERROR - 2020-09-24 12:43:34 --> Severity: Notice --> Undefined variable: spf C:\xampp\htdocs\dmarc\application\controllers\Home.php 59
INFO - 2020-09-24 12:43:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 12:43:34 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\dmarc\application\views\spf_lookup.php 161
INFO - 2020-09-24 12:43:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:43:34 --> Final output sent to browser
DEBUG - 2020-09-24 12:43:34 --> Total execution time: 14.6790
INFO - 2020-09-24 12:44:09 --> Config Class Initialized
INFO - 2020-09-24 12:44:09 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:44:09 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:44:09 --> Utf8 Class Initialized
INFO - 2020-09-24 12:44:09 --> URI Class Initialized
INFO - 2020-09-24 12:44:09 --> Router Class Initialized
INFO - 2020-09-24 12:44:09 --> Output Class Initialized
INFO - 2020-09-24 12:44:09 --> Security Class Initialized
DEBUG - 2020-09-24 12:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:44:09 --> Input Class Initialized
INFO - 2020-09-24 12:44:10 --> Language Class Initialized
INFO - 2020-09-24 12:44:10 --> Loader Class Initialized
INFO - 2020-09-24 12:44:10 --> Helper loaded: url_helper
INFO - 2020-09-24 12:44:10 --> Helper loaded: file_helper
INFO - 2020-09-24 12:44:10 --> Database Driver Class Initialized
INFO - 2020-09-24 12:44:10 --> Email Class Initialized
DEBUG - 2020-09-24 12:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:44:10 --> Controller Class Initialized
INFO - 2020-09-24 12:44:10 --> Model "Main_model" initialized
INFO - 2020-09-24 12:44:10 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:44:10 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:44:10 --> Final output sent to browser
DEBUG - 2020-09-24 12:44:10 --> Total execution time: 0.6132
INFO - 2020-09-24 12:45:15 --> Config Class Initialized
INFO - 2020-09-24 12:45:15 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:45:15 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:45:15 --> Utf8 Class Initialized
INFO - 2020-09-24 12:45:15 --> URI Class Initialized
INFO - 2020-09-24 12:45:15 --> Router Class Initialized
INFO - 2020-09-24 12:45:15 --> Output Class Initialized
INFO - 2020-09-24 12:45:15 --> Security Class Initialized
DEBUG - 2020-09-24 12:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:45:15 --> Input Class Initialized
INFO - 2020-09-24 12:45:15 --> Language Class Initialized
INFO - 2020-09-24 12:45:15 --> Loader Class Initialized
INFO - 2020-09-24 12:45:15 --> Helper loaded: url_helper
INFO - 2020-09-24 12:45:15 --> Helper loaded: file_helper
INFO - 2020-09-24 12:45:15 --> Database Driver Class Initialized
INFO - 2020-09-24 12:45:15 --> Email Class Initialized
DEBUG - 2020-09-24 12:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:45:15 --> Controller Class Initialized
INFO - 2020-09-24 12:45:15 --> Model "Main_model" initialized
INFO - 2020-09-24 12:45:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:45:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:45:15 --> Final output sent to browser
DEBUG - 2020-09-24 12:45:15 --> Total execution time: 0.5614
INFO - 2020-09-24 12:56:20 --> Config Class Initialized
INFO - 2020-09-24 12:56:20 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:56:20 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:56:20 --> Utf8 Class Initialized
INFO - 2020-09-24 12:56:20 --> URI Class Initialized
INFO - 2020-09-24 12:56:20 --> Router Class Initialized
INFO - 2020-09-24 12:56:20 --> Output Class Initialized
INFO - 2020-09-24 12:56:20 --> Security Class Initialized
DEBUG - 2020-09-24 12:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:56:20 --> Input Class Initialized
INFO - 2020-09-24 12:56:20 --> Language Class Initialized
INFO - 2020-09-24 12:56:20 --> Loader Class Initialized
INFO - 2020-09-24 12:56:20 --> Helper loaded: url_helper
INFO - 2020-09-24 12:56:20 --> Helper loaded: file_helper
INFO - 2020-09-24 12:56:20 --> Database Driver Class Initialized
INFO - 2020-09-24 12:56:20 --> Email Class Initialized
DEBUG - 2020-09-24 12:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:56:20 --> Controller Class Initialized
INFO - 2020-09-24 12:56:20 --> Model "Main_model" initialized
INFO - 2020-09-24 12:56:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:56:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:56:21 --> Final output sent to browser
DEBUG - 2020-09-24 12:56:21 --> Total execution time: 1.2471
INFO - 2020-09-24 12:56:43 --> Config Class Initialized
INFO - 2020-09-24 12:56:43 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:56:43 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:56:43 --> Utf8 Class Initialized
INFO - 2020-09-24 12:56:43 --> URI Class Initialized
INFO - 2020-09-24 12:56:43 --> Router Class Initialized
INFO - 2020-09-24 12:56:43 --> Output Class Initialized
INFO - 2020-09-24 12:56:43 --> Security Class Initialized
DEBUG - 2020-09-24 12:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:56:43 --> Input Class Initialized
INFO - 2020-09-24 12:56:43 --> Language Class Initialized
INFO - 2020-09-24 12:56:43 --> Loader Class Initialized
INFO - 2020-09-24 12:56:43 --> Helper loaded: url_helper
INFO - 2020-09-24 12:56:43 --> Helper loaded: file_helper
INFO - 2020-09-24 12:56:43 --> Database Driver Class Initialized
INFO - 2020-09-24 12:56:43 --> Email Class Initialized
DEBUG - 2020-09-24 12:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:56:43 --> Controller Class Initialized
INFO - 2020-09-24 12:56:43 --> Model "Main_model" initialized
INFO - 2020-09-24 12:57:05 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:57:05 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:57:05 --> Final output sent to browser
DEBUG - 2020-09-24 12:57:05 --> Total execution time: 21.7023
INFO - 2020-09-24 12:57:09 --> Config Class Initialized
INFO - 2020-09-24 12:57:09 --> Hooks Class Initialized
DEBUG - 2020-09-24 12:57:09 --> UTF-8 Support Enabled
INFO - 2020-09-24 12:57:09 --> Utf8 Class Initialized
INFO - 2020-09-24 12:57:09 --> URI Class Initialized
INFO - 2020-09-24 12:57:09 --> Router Class Initialized
INFO - 2020-09-24 12:57:09 --> Output Class Initialized
INFO - 2020-09-24 12:57:09 --> Security Class Initialized
DEBUG - 2020-09-24 12:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 12:57:09 --> Input Class Initialized
INFO - 2020-09-24 12:57:09 --> Language Class Initialized
INFO - 2020-09-24 12:57:09 --> Loader Class Initialized
INFO - 2020-09-24 12:57:09 --> Helper loaded: url_helper
INFO - 2020-09-24 12:57:09 --> Helper loaded: file_helper
INFO - 2020-09-24 12:57:09 --> Database Driver Class Initialized
INFO - 2020-09-24 12:57:09 --> Email Class Initialized
DEBUG - 2020-09-24 12:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 12:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 12:57:09 --> Controller Class Initialized
INFO - 2020-09-24 12:57:09 --> Model "Main_model" initialized
INFO - 2020-09-24 12:57:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 12:57:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 12:57:09 --> Final output sent to browser
DEBUG - 2020-09-24 12:57:09 --> Total execution time: 0.4389
INFO - 2020-09-24 13:08:14 --> Config Class Initialized
INFO - 2020-09-24 13:08:14 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:08:14 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:08:14 --> Utf8 Class Initialized
INFO - 2020-09-24 13:08:14 --> URI Class Initialized
INFO - 2020-09-24 13:08:14 --> Router Class Initialized
INFO - 2020-09-24 13:08:14 --> Output Class Initialized
INFO - 2020-09-24 13:08:14 --> Security Class Initialized
DEBUG - 2020-09-24 13:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:08:14 --> Input Class Initialized
INFO - 2020-09-24 13:08:14 --> Language Class Initialized
INFO - 2020-09-24 13:08:14 --> Loader Class Initialized
INFO - 2020-09-24 13:08:14 --> Helper loaded: url_helper
INFO - 2020-09-24 13:08:14 --> Helper loaded: file_helper
INFO - 2020-09-24 13:08:14 --> Database Driver Class Initialized
INFO - 2020-09-24 13:08:14 --> Email Class Initialized
DEBUG - 2020-09-24 13:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:08:14 --> Controller Class Initialized
INFO - 2020-09-24 13:08:14 --> Model "Main_model" initialized
INFO - 2020-09-24 13:08:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 13:08:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 13:08:15 --> Final output sent to browser
DEBUG - 2020-09-24 13:08:15 --> Total execution time: 0.9393
INFO - 2020-09-24 13:08:18 --> Config Class Initialized
INFO - 2020-09-24 13:08:18 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:08:18 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:08:18 --> Utf8 Class Initialized
INFO - 2020-09-24 13:08:18 --> URI Class Initialized
INFO - 2020-09-24 13:08:18 --> Router Class Initialized
INFO - 2020-09-24 13:08:18 --> Output Class Initialized
INFO - 2020-09-24 13:08:18 --> Security Class Initialized
DEBUG - 2020-09-24 13:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:08:18 --> Input Class Initialized
INFO - 2020-09-24 13:08:18 --> Language Class Initialized
ERROR - 2020-09-24 13:08:18 --> 404 Page Not Found: Spfrawchecker/index
INFO - 2020-09-24 13:11:31 --> Config Class Initialized
INFO - 2020-09-24 13:11:31 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:11:31 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:11:31 --> Utf8 Class Initialized
INFO - 2020-09-24 13:11:31 --> URI Class Initialized
INFO - 2020-09-24 13:11:31 --> Router Class Initialized
INFO - 2020-09-24 13:11:31 --> Output Class Initialized
INFO - 2020-09-24 13:11:31 --> Security Class Initialized
DEBUG - 2020-09-24 13:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:11:31 --> Input Class Initialized
INFO - 2020-09-24 13:11:31 --> Language Class Initialized
ERROR - 2020-09-24 13:11:31 --> 404 Page Not Found: Spfrawchecker/index
INFO - 2020-09-24 13:11:38 --> Config Class Initialized
INFO - 2020-09-24 13:11:38 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:11:38 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:11:38 --> Utf8 Class Initialized
INFO - 2020-09-24 13:11:38 --> URI Class Initialized
INFO - 2020-09-24 13:11:38 --> Router Class Initialized
INFO - 2020-09-24 13:11:38 --> Output Class Initialized
INFO - 2020-09-24 13:11:38 --> Security Class Initialized
DEBUG - 2020-09-24 13:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:11:38 --> Input Class Initialized
INFO - 2020-09-24 13:11:38 --> Language Class Initialized
INFO - 2020-09-24 13:11:38 --> Loader Class Initialized
INFO - 2020-09-24 13:11:38 --> Helper loaded: url_helper
INFO - 2020-09-24 13:11:38 --> Helper loaded: file_helper
INFO - 2020-09-24 13:11:38 --> Database Driver Class Initialized
INFO - 2020-09-24 13:11:38 --> Email Class Initialized
DEBUG - 2020-09-24 13:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:11:38 --> Controller Class Initialized
INFO - 2020-09-24 13:11:38 --> Model "Main_model" initialized
INFO - 2020-09-24 13:11:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 13:11:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 13:11:39 --> Final output sent to browser
DEBUG - 2020-09-24 13:11:39 --> Total execution time: 0.7148
INFO - 2020-09-24 13:12:22 --> Config Class Initialized
INFO - 2020-09-24 13:12:22 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:12:22 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:12:22 --> Utf8 Class Initialized
INFO - 2020-09-24 13:12:22 --> URI Class Initialized
INFO - 2020-09-24 13:12:22 --> Router Class Initialized
INFO - 2020-09-24 13:12:22 --> Output Class Initialized
INFO - 2020-09-24 13:12:22 --> Security Class Initialized
DEBUG - 2020-09-24 13:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:12:22 --> Input Class Initialized
INFO - 2020-09-24 13:12:23 --> Language Class Initialized
INFO - 2020-09-24 13:12:23 --> Loader Class Initialized
INFO - 2020-09-24 13:12:23 --> Helper loaded: url_helper
INFO - 2020-09-24 13:12:23 --> Helper loaded: file_helper
INFO - 2020-09-24 13:12:23 --> Database Driver Class Initialized
INFO - 2020-09-24 13:12:23 --> Email Class Initialized
DEBUG - 2020-09-24 13:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:12:23 --> Controller Class Initialized
INFO - 2020-09-24 13:12:23 --> Model "Main_model" initialized
INFO - 2020-09-24 13:12:23 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 13:12:23 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 13:12:23 --> Final output sent to browser
DEBUG - 2020-09-24 13:12:23 --> Total execution time: 0.5104
INFO - 2020-09-24 13:12:28 --> Config Class Initialized
INFO - 2020-09-24 13:12:28 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:12:28 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:12:28 --> Utf8 Class Initialized
INFO - 2020-09-24 13:12:28 --> URI Class Initialized
INFO - 2020-09-24 13:12:28 --> Router Class Initialized
INFO - 2020-09-24 13:12:28 --> Output Class Initialized
INFO - 2020-09-24 13:12:28 --> Security Class Initialized
DEBUG - 2020-09-24 13:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:12:28 --> Input Class Initialized
INFO - 2020-09-24 13:12:28 --> Language Class Initialized
INFO - 2020-09-24 13:12:28 --> Loader Class Initialized
INFO - 2020-09-24 13:12:28 --> Helper loaded: url_helper
INFO - 2020-09-24 13:12:28 --> Helper loaded: file_helper
INFO - 2020-09-24 13:12:28 --> Database Driver Class Initialized
INFO - 2020-09-24 13:12:28 --> Email Class Initialized
DEBUG - 2020-09-24 13:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:12:28 --> Controller Class Initialized
INFO - 2020-09-24 13:12:28 --> Model "Main_model" initialized
INFO - 2020-09-24 13:12:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 13:12:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 13:12:29 --> Final output sent to browser
DEBUG - 2020-09-24 13:12:29 --> Total execution time: 0.4991
INFO - 2020-09-24 13:12:40 --> Config Class Initialized
INFO - 2020-09-24 13:12:40 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:12:40 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:12:40 --> Utf8 Class Initialized
INFO - 2020-09-24 13:12:40 --> URI Class Initialized
INFO - 2020-09-24 13:12:40 --> Router Class Initialized
INFO - 2020-09-24 13:12:40 --> Output Class Initialized
INFO - 2020-09-24 13:12:40 --> Security Class Initialized
DEBUG - 2020-09-24 13:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:12:40 --> Input Class Initialized
INFO - 2020-09-24 13:12:40 --> Language Class Initialized
ERROR - 2020-09-24 13:12:40 --> 404 Page Not Found: Spfrawchecker/index
INFO - 2020-09-24 13:13:00 --> Config Class Initialized
INFO - 2020-09-24 13:13:00 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:13:00 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:13:00 --> Utf8 Class Initialized
INFO - 2020-09-24 13:13:00 --> URI Class Initialized
INFO - 2020-09-24 13:13:00 --> Router Class Initialized
INFO - 2020-09-24 13:13:00 --> Output Class Initialized
INFO - 2020-09-24 13:13:00 --> Security Class Initialized
DEBUG - 2020-09-24 13:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:13:00 --> Input Class Initialized
INFO - 2020-09-24 13:13:00 --> Language Class Initialized
INFO - 2020-09-24 13:13:00 --> Loader Class Initialized
INFO - 2020-09-24 13:13:00 --> Helper loaded: url_helper
INFO - 2020-09-24 13:13:00 --> Helper loaded: file_helper
INFO - 2020-09-24 13:13:00 --> Database Driver Class Initialized
INFO - 2020-09-24 13:13:00 --> Email Class Initialized
DEBUG - 2020-09-24 13:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:13:00 --> Controller Class Initialized
INFO - 2020-09-24 13:13:00 --> Model "Main_model" initialized
INFO - 2020-09-24 13:13:00 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 13:13:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 13:13:01 --> Final output sent to browser
DEBUG - 2020-09-24 13:13:01 --> Total execution time: 0.4354
INFO - 2020-09-24 13:13:56 --> Config Class Initialized
INFO - 2020-09-24 13:13:56 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:13:56 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:13:56 --> Utf8 Class Initialized
INFO - 2020-09-24 13:13:56 --> URI Class Initialized
INFO - 2020-09-24 13:13:56 --> Router Class Initialized
INFO - 2020-09-24 13:13:56 --> Output Class Initialized
INFO - 2020-09-24 13:13:56 --> Security Class Initialized
DEBUG - 2020-09-24 13:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:13:56 --> Input Class Initialized
INFO - 2020-09-24 13:13:56 --> Language Class Initialized
INFO - 2020-09-24 13:13:56 --> Loader Class Initialized
INFO - 2020-09-24 13:13:56 --> Helper loaded: url_helper
INFO - 2020-09-24 13:13:56 --> Helper loaded: file_helper
INFO - 2020-09-24 13:13:56 --> Database Driver Class Initialized
INFO - 2020-09-24 13:13:56 --> Email Class Initialized
DEBUG - 2020-09-24 13:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:13:56 --> Controller Class Initialized
INFO - 2020-09-24 13:13:56 --> Model "Main_model" initialized
INFO - 2020-09-24 13:13:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 13:13:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 13:13:56 --> Final output sent to browser
DEBUG - 2020-09-24 13:13:56 --> Total execution time: 0.4183
INFO - 2020-09-24 13:14:51 --> Config Class Initialized
INFO - 2020-09-24 13:14:51 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:14:51 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:14:51 --> Utf8 Class Initialized
INFO - 2020-09-24 13:14:51 --> URI Class Initialized
INFO - 2020-09-24 13:14:51 --> Router Class Initialized
INFO - 2020-09-24 13:14:51 --> Output Class Initialized
INFO - 2020-09-24 13:14:51 --> Security Class Initialized
DEBUG - 2020-09-24 13:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:14:51 --> Input Class Initialized
INFO - 2020-09-24 13:14:51 --> Language Class Initialized
INFO - 2020-09-24 13:14:51 --> Loader Class Initialized
INFO - 2020-09-24 13:14:51 --> Helper loaded: url_helper
INFO - 2020-09-24 13:14:51 --> Helper loaded: file_helper
INFO - 2020-09-24 13:14:51 --> Database Driver Class Initialized
INFO - 2020-09-24 13:14:51 --> Email Class Initialized
DEBUG - 2020-09-24 13:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:14:51 --> Controller Class Initialized
INFO - 2020-09-24 13:14:51 --> Model "Main_model" initialized
INFO - 2020-09-24 13:14:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 13:14:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 13:14:51 --> Final output sent to browser
DEBUG - 2020-09-24 13:14:51 --> Total execution time: 0.4060
INFO - 2020-09-24 13:15:27 --> Config Class Initialized
INFO - 2020-09-24 13:15:27 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:15:27 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:15:27 --> Utf8 Class Initialized
INFO - 2020-09-24 13:15:27 --> URI Class Initialized
INFO - 2020-09-24 13:15:28 --> Router Class Initialized
INFO - 2020-09-24 13:15:28 --> Output Class Initialized
INFO - 2020-09-24 13:15:28 --> Security Class Initialized
DEBUG - 2020-09-24 13:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:15:28 --> Input Class Initialized
INFO - 2020-09-24 13:15:28 --> Language Class Initialized
INFO - 2020-09-24 13:15:28 --> Loader Class Initialized
INFO - 2020-09-24 13:15:28 --> Helper loaded: url_helper
INFO - 2020-09-24 13:15:28 --> Helper loaded: file_helper
INFO - 2020-09-24 13:15:28 --> Database Driver Class Initialized
INFO - 2020-09-24 13:15:28 --> Email Class Initialized
DEBUG - 2020-09-24 13:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:15:28 --> Controller Class Initialized
INFO - 2020-09-24 13:15:28 --> Model "Main_model" initialized
INFO - 2020-09-24 13:15:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 13:15:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 13:15:28 --> Final output sent to browser
DEBUG - 2020-09-24 13:15:28 --> Total execution time: 0.4113
INFO - 2020-09-24 13:30:31 --> Config Class Initialized
INFO - 2020-09-24 13:30:31 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:30:32 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:30:32 --> Utf8 Class Initialized
INFO - 2020-09-24 13:30:32 --> URI Class Initialized
INFO - 2020-09-24 13:30:32 --> Router Class Initialized
INFO - 2020-09-24 13:30:32 --> Output Class Initialized
INFO - 2020-09-24 13:30:32 --> Security Class Initialized
DEBUG - 2020-09-24 13:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:30:32 --> Input Class Initialized
INFO - 2020-09-24 13:30:32 --> Language Class Initialized
INFO - 2020-09-24 13:30:32 --> Loader Class Initialized
INFO - 2020-09-24 13:30:32 --> Helper loaded: url_helper
INFO - 2020-09-24 13:30:32 --> Helper loaded: file_helper
INFO - 2020-09-24 13:30:32 --> Database Driver Class Initialized
INFO - 2020-09-24 13:30:32 --> Email Class Initialized
DEBUG - 2020-09-24 13:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:30:32 --> Controller Class Initialized
INFO - 2020-09-24 13:30:32 --> Model "Main_model" initialized
INFO - 2020-09-24 13:30:32 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 13:30:32 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 13:30:32 --> Final output sent to browser
DEBUG - 2020-09-24 13:30:32 --> Total execution time: 0.4143
INFO - 2020-09-24 13:30:52 --> Config Class Initialized
INFO - 2020-09-24 13:30:52 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:30:52 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:30:52 --> Utf8 Class Initialized
INFO - 2020-09-24 13:30:52 --> URI Class Initialized
INFO - 2020-09-24 13:30:53 --> Router Class Initialized
INFO - 2020-09-24 13:30:53 --> Output Class Initialized
INFO - 2020-09-24 13:30:53 --> Security Class Initialized
DEBUG - 2020-09-24 13:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:30:53 --> Input Class Initialized
INFO - 2020-09-24 13:30:53 --> Language Class Initialized
INFO - 2020-09-24 13:30:53 --> Loader Class Initialized
INFO - 2020-09-24 13:30:53 --> Helper loaded: url_helper
INFO - 2020-09-24 13:30:53 --> Helper loaded: file_helper
INFO - 2020-09-24 13:30:53 --> Database Driver Class Initialized
INFO - 2020-09-24 13:30:53 --> Email Class Initialized
DEBUG - 2020-09-24 13:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:30:53 --> Controller Class Initialized
INFO - 2020-09-24 13:30:53 --> Model "Main_model" initialized
INFO - 2020-09-24 13:30:53 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 13:30:53 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 13:30:53 --> Final output sent to browser
DEBUG - 2020-09-24 13:30:53 --> Total execution time: 0.4050
INFO - 2020-09-24 13:31:03 --> Config Class Initialized
INFO - 2020-09-24 13:31:03 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:31:03 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:31:03 --> Utf8 Class Initialized
INFO - 2020-09-24 13:31:03 --> URI Class Initialized
INFO - 2020-09-24 13:31:03 --> Router Class Initialized
INFO - 2020-09-24 13:31:03 --> Output Class Initialized
INFO - 2020-09-24 13:31:03 --> Security Class Initialized
DEBUG - 2020-09-24 13:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:31:03 --> Input Class Initialized
INFO - 2020-09-24 13:31:03 --> Language Class Initialized
INFO - 2020-09-24 13:31:03 --> Loader Class Initialized
INFO - 2020-09-24 13:31:03 --> Helper loaded: url_helper
INFO - 2020-09-24 13:31:03 --> Helper loaded: file_helper
INFO - 2020-09-24 13:31:03 --> Database Driver Class Initialized
INFO - 2020-09-24 13:31:03 --> Email Class Initialized
DEBUG - 2020-09-24 13:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:31:04 --> Controller Class Initialized
INFO - 2020-09-24 13:31:04 --> Model "Main_model" initialized
ERROR - 2020-09-24 13:31:04 --> Severity: Warning --> dns_get_record() expects parameter 2 to be integer, string given C:\xampp\htdocs\dmarc\application\controllers\Home.php 42
ERROR - 2020-09-24 13:31:04 --> Severity: Warning --> dns_get_record() expects parameter 2 to be integer, string given C:\xampp\htdocs\dmarc\application\controllers\Home.php 42
INFO - 2020-09-24 13:34:28 --> Config Class Initialized
INFO - 2020-09-24 13:34:29 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:34:29 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:34:29 --> Utf8 Class Initialized
INFO - 2020-09-24 13:34:29 --> URI Class Initialized
INFO - 2020-09-24 13:34:29 --> Router Class Initialized
INFO - 2020-09-24 13:34:29 --> Output Class Initialized
INFO - 2020-09-24 13:34:29 --> Security Class Initialized
DEBUG - 2020-09-24 13:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:34:29 --> Input Class Initialized
INFO - 2020-09-24 13:34:29 --> Language Class Initialized
INFO - 2020-09-24 13:34:29 --> Loader Class Initialized
INFO - 2020-09-24 13:34:29 --> Helper loaded: url_helper
INFO - 2020-09-24 13:34:29 --> Helper loaded: file_helper
INFO - 2020-09-24 13:34:29 --> Database Driver Class Initialized
INFO - 2020-09-24 13:34:29 --> Email Class Initialized
DEBUG - 2020-09-24 13:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:34:29 --> Controller Class Initialized
INFO - 2020-09-24 13:34:29 --> Model "Main_model" initialized
INFO - 2020-09-24 13:34:31 --> Config Class Initialized
INFO - 2020-09-24 13:34:31 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:34:31 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:34:31 --> Utf8 Class Initialized
INFO - 2020-09-24 13:34:31 --> URI Class Initialized
INFO - 2020-09-24 13:34:31 --> Router Class Initialized
INFO - 2020-09-24 13:34:31 --> Output Class Initialized
INFO - 2020-09-24 13:34:31 --> Security Class Initialized
DEBUG - 2020-09-24 13:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:34:31 --> Input Class Initialized
INFO - 2020-09-24 13:34:31 --> Language Class Initialized
INFO - 2020-09-24 13:34:31 --> Loader Class Initialized
INFO - 2020-09-24 13:34:31 --> Helper loaded: url_helper
INFO - 2020-09-24 13:34:31 --> Helper loaded: file_helper
INFO - 2020-09-24 13:34:31 --> Database Driver Class Initialized
INFO - 2020-09-24 13:34:31 --> Email Class Initialized
DEBUG - 2020-09-24 13:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:34:31 --> Controller Class Initialized
INFO - 2020-09-24 13:34:32 --> Model "Main_model" initialized
INFO - 2020-09-24 13:36:47 --> Config Class Initialized
INFO - 2020-09-24 13:36:47 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:36:47 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:36:47 --> Utf8 Class Initialized
INFO - 2020-09-24 13:36:47 --> URI Class Initialized
INFO - 2020-09-24 13:36:47 --> Router Class Initialized
INFO - 2020-09-24 13:36:47 --> Output Class Initialized
INFO - 2020-09-24 13:36:47 --> Security Class Initialized
DEBUG - 2020-09-24 13:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:36:47 --> Input Class Initialized
INFO - 2020-09-24 13:36:48 --> Language Class Initialized
INFO - 2020-09-24 13:36:48 --> Loader Class Initialized
INFO - 2020-09-24 13:36:48 --> Helper loaded: url_helper
INFO - 2020-09-24 13:36:48 --> Helper loaded: file_helper
INFO - 2020-09-24 13:36:48 --> Database Driver Class Initialized
INFO - 2020-09-24 13:36:48 --> Email Class Initialized
DEBUG - 2020-09-24 13:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:36:48 --> Controller Class Initialized
INFO - 2020-09-24 13:36:48 --> Model "Main_model" initialized
INFO - 2020-09-24 13:36:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 13:36:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 13:36:48 --> Final output sent to browser
DEBUG - 2020-09-24 13:36:48 --> Total execution time: 0.4290
INFO - 2020-09-24 13:38:38 --> Config Class Initialized
INFO - 2020-09-24 13:38:38 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:38:38 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:38:38 --> Utf8 Class Initialized
INFO - 2020-09-24 13:38:38 --> URI Class Initialized
INFO - 2020-09-24 13:38:38 --> Router Class Initialized
INFO - 2020-09-24 13:38:38 --> Output Class Initialized
INFO - 2020-09-24 13:38:38 --> Security Class Initialized
DEBUG - 2020-09-24 13:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:38:38 --> Input Class Initialized
INFO - 2020-09-24 13:38:38 --> Language Class Initialized
INFO - 2020-09-24 13:38:38 --> Loader Class Initialized
INFO - 2020-09-24 13:38:38 --> Helper loaded: url_helper
INFO - 2020-09-24 13:38:38 --> Helper loaded: file_helper
INFO - 2020-09-24 13:38:38 --> Database Driver Class Initialized
INFO - 2020-09-24 13:38:38 --> Email Class Initialized
DEBUG - 2020-09-24 13:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:38:39 --> Controller Class Initialized
INFO - 2020-09-24 13:38:39 --> Model "Main_model" initialized
INFO - 2020-09-24 13:38:41 --> Config Class Initialized
INFO - 2020-09-24 13:38:41 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:38:41 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:38:41 --> Utf8 Class Initialized
INFO - 2020-09-24 13:38:41 --> URI Class Initialized
INFO - 2020-09-24 13:38:41 --> Router Class Initialized
INFO - 2020-09-24 13:38:41 --> Output Class Initialized
INFO - 2020-09-24 13:38:41 --> Security Class Initialized
DEBUG - 2020-09-24 13:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:38:41 --> Input Class Initialized
INFO - 2020-09-24 13:38:41 --> Language Class Initialized
INFO - 2020-09-24 13:38:41 --> Loader Class Initialized
INFO - 2020-09-24 13:38:41 --> Helper loaded: url_helper
INFO - 2020-09-24 13:38:41 --> Helper loaded: file_helper
INFO - 2020-09-24 13:38:41 --> Database Driver Class Initialized
INFO - 2020-09-24 13:38:41 --> Email Class Initialized
DEBUG - 2020-09-24 13:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:38:41 --> Controller Class Initialized
INFO - 2020-09-24 13:38:41 --> Model "Main_model" initialized
INFO - 2020-09-24 13:39:04 --> Config Class Initialized
INFO - 2020-09-24 13:39:04 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:39:04 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:39:04 --> Utf8 Class Initialized
INFO - 2020-09-24 13:39:04 --> URI Class Initialized
INFO - 2020-09-24 13:39:04 --> Router Class Initialized
INFO - 2020-09-24 13:39:04 --> Output Class Initialized
INFO - 2020-09-24 13:39:04 --> Security Class Initialized
DEBUG - 2020-09-24 13:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:39:04 --> Input Class Initialized
INFO - 2020-09-24 13:39:04 --> Language Class Initialized
INFO - 2020-09-24 13:39:04 --> Loader Class Initialized
INFO - 2020-09-24 13:39:04 --> Helper loaded: url_helper
INFO - 2020-09-24 13:39:04 --> Helper loaded: file_helper
INFO - 2020-09-24 13:39:04 --> Database Driver Class Initialized
INFO - 2020-09-24 13:39:04 --> Email Class Initialized
DEBUG - 2020-09-24 13:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:39:04 --> Controller Class Initialized
INFO - 2020-09-24 13:39:04 --> Model "Main_model" initialized
INFO - 2020-09-24 13:39:13 --> Config Class Initialized
INFO - 2020-09-24 13:39:13 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:39:13 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:39:13 --> Utf8 Class Initialized
INFO - 2020-09-24 13:39:13 --> URI Class Initialized
INFO - 2020-09-24 13:39:13 --> Router Class Initialized
INFO - 2020-09-24 13:39:13 --> Output Class Initialized
INFO - 2020-09-24 13:39:13 --> Security Class Initialized
DEBUG - 2020-09-24 13:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:39:13 --> Input Class Initialized
INFO - 2020-09-24 13:39:13 --> Language Class Initialized
INFO - 2020-09-24 13:39:13 --> Loader Class Initialized
INFO - 2020-09-24 13:39:13 --> Helper loaded: url_helper
INFO - 2020-09-24 13:39:13 --> Helper loaded: file_helper
INFO - 2020-09-24 13:39:14 --> Database Driver Class Initialized
INFO - 2020-09-24 13:39:14 --> Email Class Initialized
DEBUG - 2020-09-24 13:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:39:14 --> Controller Class Initialized
INFO - 2020-09-24 13:39:14 --> Model "Main_model" initialized
INFO - 2020-09-24 13:40:24 --> Config Class Initialized
INFO - 2020-09-24 13:40:24 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:40:24 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:40:24 --> Utf8 Class Initialized
INFO - 2020-09-24 13:40:24 --> URI Class Initialized
INFO - 2020-09-24 13:40:24 --> Router Class Initialized
INFO - 2020-09-24 13:40:24 --> Output Class Initialized
INFO - 2020-09-24 13:40:24 --> Security Class Initialized
DEBUG - 2020-09-24 13:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:40:24 --> Input Class Initialized
INFO - 2020-09-24 13:40:24 --> Language Class Initialized
INFO - 2020-09-24 13:40:24 --> Loader Class Initialized
INFO - 2020-09-24 13:40:24 --> Helper loaded: url_helper
INFO - 2020-09-24 13:40:24 --> Helper loaded: file_helper
INFO - 2020-09-24 13:40:24 --> Database Driver Class Initialized
INFO - 2020-09-24 13:40:24 --> Email Class Initialized
DEBUG - 2020-09-24 13:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:40:24 --> Controller Class Initialized
INFO - 2020-09-24 13:40:24 --> Model "Main_model" initialized
ERROR - 2020-09-24 13:40:24 --> Severity: Notice --> Undefined variable: spf_record C:\xampp\htdocs\dmarc\application\controllers\Home.php 57
INFO - 2020-09-24 13:41:15 --> Config Class Initialized
INFO - 2020-09-24 13:41:15 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:41:15 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:41:15 --> Utf8 Class Initialized
INFO - 2020-09-24 13:41:15 --> URI Class Initialized
INFO - 2020-09-24 13:41:15 --> Router Class Initialized
INFO - 2020-09-24 13:41:15 --> Output Class Initialized
INFO - 2020-09-24 13:41:15 --> Security Class Initialized
DEBUG - 2020-09-24 13:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:41:15 --> Input Class Initialized
INFO - 2020-09-24 13:41:15 --> Language Class Initialized
INFO - 2020-09-24 13:41:15 --> Loader Class Initialized
INFO - 2020-09-24 13:41:15 --> Helper loaded: url_helper
INFO - 2020-09-24 13:41:15 --> Helper loaded: file_helper
INFO - 2020-09-24 13:41:15 --> Database Driver Class Initialized
INFO - 2020-09-24 13:41:15 --> Email Class Initialized
DEBUG - 2020-09-24 13:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:41:15 --> Controller Class Initialized
INFO - 2020-09-24 13:41:15 --> Model "Main_model" initialized
INFO - 2020-09-24 13:41:17 --> Config Class Initialized
INFO - 2020-09-24 13:41:17 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:41:17 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:41:17 --> Utf8 Class Initialized
INFO - 2020-09-24 13:41:17 --> URI Class Initialized
INFO - 2020-09-24 13:41:18 --> Router Class Initialized
INFO - 2020-09-24 13:41:18 --> Output Class Initialized
INFO - 2020-09-24 13:41:18 --> Security Class Initialized
DEBUG - 2020-09-24 13:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:41:18 --> Input Class Initialized
INFO - 2020-09-24 13:41:18 --> Language Class Initialized
INFO - 2020-09-24 13:41:18 --> Loader Class Initialized
INFO - 2020-09-24 13:41:18 --> Helper loaded: url_helper
INFO - 2020-09-24 13:41:18 --> Helper loaded: file_helper
INFO - 2020-09-24 13:41:18 --> Database Driver Class Initialized
INFO - 2020-09-24 13:41:18 --> Email Class Initialized
DEBUG - 2020-09-24 13:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:41:18 --> Controller Class Initialized
INFO - 2020-09-24 13:41:18 --> Model "Main_model" initialized
INFO - 2020-09-24 13:42:27 --> Config Class Initialized
INFO - 2020-09-24 13:42:27 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:42:27 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:42:27 --> Utf8 Class Initialized
INFO - 2020-09-24 13:42:27 --> URI Class Initialized
INFO - 2020-09-24 13:42:27 --> Router Class Initialized
INFO - 2020-09-24 13:42:27 --> Output Class Initialized
INFO - 2020-09-24 13:42:27 --> Security Class Initialized
DEBUG - 2020-09-24 13:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:42:27 --> Input Class Initialized
INFO - 2020-09-24 13:42:27 --> Language Class Initialized
INFO - 2020-09-24 13:42:27 --> Loader Class Initialized
INFO - 2020-09-24 13:42:27 --> Helper loaded: url_helper
INFO - 2020-09-24 13:42:27 --> Helper loaded: file_helper
INFO - 2020-09-24 13:42:27 --> Database Driver Class Initialized
INFO - 2020-09-24 13:42:27 --> Email Class Initialized
DEBUG - 2020-09-24 13:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:42:28 --> Controller Class Initialized
INFO - 2020-09-24 13:42:28 --> Model "Main_model" initialized
INFO - 2020-09-24 13:42:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 13:42:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 13:42:28 --> Final output sent to browser
DEBUG - 2020-09-24 13:42:28 --> Total execution time: 0.4762
INFO - 2020-09-24 13:42:43 --> Config Class Initialized
INFO - 2020-09-24 13:42:43 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:42:43 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:42:43 --> Utf8 Class Initialized
INFO - 2020-09-24 13:42:43 --> URI Class Initialized
INFO - 2020-09-24 13:42:43 --> Router Class Initialized
INFO - 2020-09-24 13:42:43 --> Output Class Initialized
INFO - 2020-09-24 13:42:43 --> Security Class Initialized
DEBUG - 2020-09-24 13:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:42:43 --> Input Class Initialized
INFO - 2020-09-24 13:42:43 --> Language Class Initialized
INFO - 2020-09-24 13:42:44 --> Loader Class Initialized
INFO - 2020-09-24 13:42:44 --> Helper loaded: url_helper
INFO - 2020-09-24 13:42:44 --> Helper loaded: file_helper
INFO - 2020-09-24 13:42:44 --> Database Driver Class Initialized
INFO - 2020-09-24 13:42:44 --> Email Class Initialized
DEBUG - 2020-09-24 13:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:42:44 --> Controller Class Initialized
INFO - 2020-09-24 13:42:44 --> Model "Main_model" initialized
INFO - 2020-09-24 13:42:46 --> Config Class Initialized
INFO - 2020-09-24 13:42:46 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:42:46 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:42:46 --> Utf8 Class Initialized
INFO - 2020-09-24 13:42:46 --> URI Class Initialized
INFO - 2020-09-24 13:42:46 --> Router Class Initialized
INFO - 2020-09-24 13:42:46 --> Output Class Initialized
INFO - 2020-09-24 13:42:46 --> Security Class Initialized
DEBUG - 2020-09-24 13:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:42:46 --> Input Class Initialized
INFO - 2020-09-24 13:42:46 --> Language Class Initialized
INFO - 2020-09-24 13:42:46 --> Loader Class Initialized
INFO - 2020-09-24 13:42:46 --> Helper loaded: url_helper
INFO - 2020-09-24 13:42:46 --> Helper loaded: file_helper
INFO - 2020-09-24 13:42:46 --> Database Driver Class Initialized
INFO - 2020-09-24 13:42:46 --> Email Class Initialized
DEBUG - 2020-09-24 13:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:42:46 --> Controller Class Initialized
INFO - 2020-09-24 13:42:46 --> Model "Main_model" initialized
INFO - 2020-09-24 13:44:23 --> Config Class Initialized
INFO - 2020-09-24 13:44:23 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:44:23 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:44:23 --> Utf8 Class Initialized
INFO - 2020-09-24 13:44:23 --> URI Class Initialized
INFO - 2020-09-24 13:44:23 --> Router Class Initialized
INFO - 2020-09-24 13:44:23 --> Output Class Initialized
INFO - 2020-09-24 13:44:23 --> Security Class Initialized
DEBUG - 2020-09-24 13:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:44:23 --> Input Class Initialized
INFO - 2020-09-24 13:44:23 --> Language Class Initialized
INFO - 2020-09-24 13:44:23 --> Loader Class Initialized
INFO - 2020-09-24 13:44:23 --> Helper loaded: url_helper
INFO - 2020-09-24 13:44:23 --> Helper loaded: file_helper
INFO - 2020-09-24 13:44:23 --> Database Driver Class Initialized
INFO - 2020-09-24 13:44:24 --> Email Class Initialized
DEBUG - 2020-09-24 13:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:44:24 --> Controller Class Initialized
INFO - 2020-09-24 13:44:24 --> Model "Main_model" initialized
INFO - 2020-09-24 13:47:15 --> Config Class Initialized
INFO - 2020-09-24 13:47:15 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:47:15 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:47:15 --> Utf8 Class Initialized
INFO - 2020-09-24 13:47:15 --> URI Class Initialized
INFO - 2020-09-24 13:47:15 --> Router Class Initialized
INFO - 2020-09-24 13:47:15 --> Output Class Initialized
INFO - 2020-09-24 13:47:16 --> Security Class Initialized
DEBUG - 2020-09-24 13:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:47:16 --> Input Class Initialized
INFO - 2020-09-24 13:47:16 --> Language Class Initialized
INFO - 2020-09-24 13:47:16 --> Loader Class Initialized
INFO - 2020-09-24 13:47:16 --> Helper loaded: url_helper
INFO - 2020-09-24 13:47:16 --> Helper loaded: file_helper
INFO - 2020-09-24 13:47:16 --> Database Driver Class Initialized
INFO - 2020-09-24 13:47:16 --> Email Class Initialized
DEBUG - 2020-09-24 13:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:47:16 --> Controller Class Initialized
INFO - 2020-09-24 13:47:16 --> Model "Main_model" initialized
INFO - 2020-09-24 13:48:02 --> Config Class Initialized
INFO - 2020-09-24 13:48:02 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:48:02 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:48:02 --> Utf8 Class Initialized
INFO - 2020-09-24 13:48:02 --> URI Class Initialized
INFO - 2020-09-24 13:48:02 --> Router Class Initialized
INFO - 2020-09-24 13:48:02 --> Output Class Initialized
INFO - 2020-09-24 13:48:02 --> Security Class Initialized
DEBUG - 2020-09-24 13:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:48:02 --> Input Class Initialized
INFO - 2020-09-24 13:48:02 --> Language Class Initialized
INFO - 2020-09-24 13:48:02 --> Loader Class Initialized
INFO - 2020-09-24 13:48:02 --> Helper loaded: url_helper
INFO - 2020-09-24 13:48:02 --> Helper loaded: file_helper
INFO - 2020-09-24 13:48:02 --> Database Driver Class Initialized
INFO - 2020-09-24 13:48:02 --> Email Class Initialized
DEBUG - 2020-09-24 13:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:48:02 --> Controller Class Initialized
INFO - 2020-09-24 13:48:02 --> Model "Main_model" initialized
INFO - 2020-09-24 13:51:09 --> Config Class Initialized
INFO - 2020-09-24 13:51:09 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:51:09 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:51:09 --> Utf8 Class Initialized
INFO - 2020-09-24 13:51:09 --> URI Class Initialized
INFO - 2020-09-24 13:51:09 --> Router Class Initialized
INFO - 2020-09-24 13:51:09 --> Output Class Initialized
INFO - 2020-09-24 13:51:09 --> Security Class Initialized
DEBUG - 2020-09-24 13:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:51:09 --> Input Class Initialized
INFO - 2020-09-24 13:51:09 --> Language Class Initialized
INFO - 2020-09-24 13:51:09 --> Loader Class Initialized
INFO - 2020-09-24 13:51:10 --> Helper loaded: url_helper
INFO - 2020-09-24 13:51:10 --> Helper loaded: file_helper
INFO - 2020-09-24 13:51:10 --> Database Driver Class Initialized
INFO - 2020-09-24 13:51:10 --> Email Class Initialized
DEBUG - 2020-09-24 13:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:51:10 --> Controller Class Initialized
INFO - 2020-09-24 13:51:10 --> Model "Main_model" initialized
INFO - 2020-09-24 13:55:08 --> Config Class Initialized
INFO - 2020-09-24 13:55:08 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:55:08 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:55:08 --> Utf8 Class Initialized
INFO - 2020-09-24 13:55:08 --> URI Class Initialized
INFO - 2020-09-24 13:55:08 --> Router Class Initialized
INFO - 2020-09-24 13:55:08 --> Output Class Initialized
INFO - 2020-09-24 13:55:08 --> Security Class Initialized
DEBUG - 2020-09-24 13:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:55:08 --> Input Class Initialized
INFO - 2020-09-24 13:55:08 --> Language Class Initialized
ERROR - 2020-09-24 13:55:08 --> Severity: error --> Exception: syntax error, unexpected '&' C:\xampp\htdocs\dmarc\application\controllers\Home.php 46
INFO - 2020-09-24 13:55:20 --> Config Class Initialized
INFO - 2020-09-24 13:55:20 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:55:20 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:55:20 --> Utf8 Class Initialized
INFO - 2020-09-24 13:55:20 --> URI Class Initialized
INFO - 2020-09-24 13:55:20 --> Router Class Initialized
INFO - 2020-09-24 13:55:20 --> Output Class Initialized
INFO - 2020-09-24 13:55:20 --> Security Class Initialized
DEBUG - 2020-09-24 13:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:55:20 --> Input Class Initialized
INFO - 2020-09-24 13:55:20 --> Language Class Initialized
INFO - 2020-09-24 13:55:20 --> Loader Class Initialized
INFO - 2020-09-24 13:55:20 --> Helper loaded: url_helper
INFO - 2020-09-24 13:55:20 --> Helper loaded: file_helper
INFO - 2020-09-24 13:55:20 --> Database Driver Class Initialized
INFO - 2020-09-24 13:55:20 --> Email Class Initialized
DEBUG - 2020-09-24 13:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:55:20 --> Controller Class Initialized
INFO - 2020-09-24 13:55:20 --> Model "Main_model" initialized
INFO - 2020-09-24 13:55:33 --> Config Class Initialized
INFO - 2020-09-24 13:55:33 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:55:33 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:55:33 --> Utf8 Class Initialized
INFO - 2020-09-24 13:55:33 --> URI Class Initialized
INFO - 2020-09-24 13:55:33 --> Router Class Initialized
INFO - 2020-09-24 13:55:33 --> Output Class Initialized
INFO - 2020-09-24 13:55:33 --> Security Class Initialized
DEBUG - 2020-09-24 13:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:55:33 --> Input Class Initialized
INFO - 2020-09-24 13:55:33 --> Language Class Initialized
INFO - 2020-09-24 13:55:33 --> Loader Class Initialized
INFO - 2020-09-24 13:55:33 --> Helper loaded: url_helper
INFO - 2020-09-24 13:55:33 --> Helper loaded: file_helper
INFO - 2020-09-24 13:55:33 --> Database Driver Class Initialized
INFO - 2020-09-24 13:55:33 --> Email Class Initialized
DEBUG - 2020-09-24 13:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:55:33 --> Controller Class Initialized
INFO - 2020-09-24 13:55:33 --> Model "Main_model" initialized
INFO - 2020-09-24 13:58:03 --> Config Class Initialized
INFO - 2020-09-24 13:58:03 --> Hooks Class Initialized
DEBUG - 2020-09-24 13:58:03 --> UTF-8 Support Enabled
INFO - 2020-09-24 13:58:03 --> Utf8 Class Initialized
INFO - 2020-09-24 13:58:03 --> URI Class Initialized
INFO - 2020-09-24 13:58:03 --> Router Class Initialized
INFO - 2020-09-24 13:58:03 --> Output Class Initialized
INFO - 2020-09-24 13:58:03 --> Security Class Initialized
DEBUG - 2020-09-24 13:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 13:58:03 --> Input Class Initialized
INFO - 2020-09-24 13:58:03 --> Language Class Initialized
INFO - 2020-09-24 13:58:04 --> Loader Class Initialized
INFO - 2020-09-24 13:58:04 --> Helper loaded: url_helper
INFO - 2020-09-24 13:58:04 --> Helper loaded: file_helper
INFO - 2020-09-24 13:58:04 --> Database Driver Class Initialized
INFO - 2020-09-24 13:58:04 --> Email Class Initialized
DEBUG - 2020-09-24 13:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 13:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 13:58:04 --> Controller Class Initialized
INFO - 2020-09-24 13:58:04 --> Model "Main_model" initialized
INFO - 2020-09-24 14:01:45 --> Config Class Initialized
INFO - 2020-09-24 14:01:45 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:01:45 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:01:45 --> Utf8 Class Initialized
INFO - 2020-09-24 14:01:45 --> URI Class Initialized
INFO - 2020-09-24 14:01:45 --> Router Class Initialized
INFO - 2020-09-24 14:01:45 --> Output Class Initialized
INFO - 2020-09-24 14:01:45 --> Security Class Initialized
DEBUG - 2020-09-24 14:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:01:45 --> Input Class Initialized
INFO - 2020-09-24 14:01:45 --> Language Class Initialized
INFO - 2020-09-24 14:01:45 --> Loader Class Initialized
INFO - 2020-09-24 14:01:45 --> Helper loaded: url_helper
INFO - 2020-09-24 14:01:45 --> Helper loaded: file_helper
INFO - 2020-09-24 14:01:45 --> Database Driver Class Initialized
INFO - 2020-09-24 14:01:45 --> Email Class Initialized
DEBUG - 2020-09-24 14:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:01:45 --> Controller Class Initialized
INFO - 2020-09-24 14:01:45 --> Model "Main_model" initialized
INFO - 2020-09-24 14:02:21 --> Config Class Initialized
INFO - 2020-09-24 14:02:21 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:02:21 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:02:21 --> Utf8 Class Initialized
INFO - 2020-09-24 14:02:21 --> URI Class Initialized
INFO - 2020-09-24 14:02:21 --> Router Class Initialized
INFO - 2020-09-24 14:02:21 --> Output Class Initialized
INFO - 2020-09-24 14:02:21 --> Security Class Initialized
DEBUG - 2020-09-24 14:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:02:21 --> Input Class Initialized
INFO - 2020-09-24 14:02:21 --> Language Class Initialized
INFO - 2020-09-24 14:02:21 --> Loader Class Initialized
INFO - 2020-09-24 14:02:21 --> Helper loaded: url_helper
INFO - 2020-09-24 14:02:21 --> Helper loaded: file_helper
INFO - 2020-09-24 14:02:21 --> Database Driver Class Initialized
INFO - 2020-09-24 14:02:21 --> Email Class Initialized
DEBUG - 2020-09-24 14:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:02:21 --> Controller Class Initialized
INFO - 2020-09-24 14:02:21 --> Model "Main_model" initialized
INFO - 2020-09-24 14:11:02 --> Config Class Initialized
INFO - 2020-09-24 14:11:02 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:11:02 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:11:02 --> Utf8 Class Initialized
INFO - 2020-09-24 14:11:02 --> URI Class Initialized
INFO - 2020-09-24 14:11:02 --> Router Class Initialized
INFO - 2020-09-24 14:11:02 --> Output Class Initialized
INFO - 2020-09-24 14:11:02 --> Security Class Initialized
DEBUG - 2020-09-24 14:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:11:02 --> Input Class Initialized
INFO - 2020-09-24 14:11:02 --> Language Class Initialized
INFO - 2020-09-24 14:11:02 --> Loader Class Initialized
INFO - 2020-09-24 14:11:02 --> Helper loaded: url_helper
INFO - 2020-09-24 14:11:02 --> Helper loaded: file_helper
INFO - 2020-09-24 14:11:02 --> Database Driver Class Initialized
INFO - 2020-09-24 14:11:02 --> Email Class Initialized
DEBUG - 2020-09-24 14:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:11:03 --> Controller Class Initialized
INFO - 2020-09-24 14:11:03 --> Model "Main_model" initialized
INFO - 2020-09-24 14:11:06 --> Config Class Initialized
INFO - 2020-09-24 14:11:06 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:11:06 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:11:06 --> Utf8 Class Initialized
INFO - 2020-09-24 14:11:06 --> URI Class Initialized
INFO - 2020-09-24 14:11:06 --> Router Class Initialized
INFO - 2020-09-24 14:11:06 --> Output Class Initialized
INFO - 2020-09-24 14:11:06 --> Security Class Initialized
DEBUG - 2020-09-24 14:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:11:06 --> Input Class Initialized
INFO - 2020-09-24 14:11:06 --> Language Class Initialized
INFO - 2020-09-24 14:11:06 --> Loader Class Initialized
INFO - 2020-09-24 14:11:06 --> Helper loaded: url_helper
INFO - 2020-09-24 14:11:06 --> Helper loaded: file_helper
INFO - 2020-09-24 14:11:06 --> Database Driver Class Initialized
INFO - 2020-09-24 14:11:06 --> Email Class Initialized
DEBUG - 2020-09-24 14:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:11:06 --> Controller Class Initialized
INFO - 2020-09-24 14:11:06 --> Model "Main_model" initialized
INFO - 2020-09-24 14:11:08 --> Config Class Initialized
INFO - 2020-09-24 14:11:08 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:11:08 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:11:08 --> Utf8 Class Initialized
INFO - 2020-09-24 14:11:08 --> URI Class Initialized
INFO - 2020-09-24 14:11:08 --> Router Class Initialized
INFO - 2020-09-24 14:11:08 --> Output Class Initialized
INFO - 2020-09-24 14:11:08 --> Security Class Initialized
DEBUG - 2020-09-24 14:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:11:08 --> Input Class Initialized
INFO - 2020-09-24 14:11:08 --> Language Class Initialized
INFO - 2020-09-24 14:11:08 --> Loader Class Initialized
INFO - 2020-09-24 14:11:08 --> Helper loaded: url_helper
INFO - 2020-09-24 14:11:08 --> Helper loaded: file_helper
INFO - 2020-09-24 14:11:08 --> Database Driver Class Initialized
INFO - 2020-09-24 14:11:08 --> Email Class Initialized
DEBUG - 2020-09-24 14:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:11:08 --> Controller Class Initialized
INFO - 2020-09-24 14:11:08 --> Model "Main_model" initialized
INFO - 2020-09-24 14:11:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:11:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:11:08 --> Final output sent to browser
DEBUG - 2020-09-24 14:11:08 --> Total execution time: 0.4177
INFO - 2020-09-24 14:11:57 --> Config Class Initialized
INFO - 2020-09-24 14:11:57 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:11:57 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:11:57 --> Utf8 Class Initialized
INFO - 2020-09-24 14:11:57 --> URI Class Initialized
INFO - 2020-09-24 14:11:57 --> Router Class Initialized
INFO - 2020-09-24 14:11:57 --> Output Class Initialized
INFO - 2020-09-24 14:11:57 --> Security Class Initialized
DEBUG - 2020-09-24 14:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:11:57 --> Input Class Initialized
INFO - 2020-09-24 14:11:58 --> Language Class Initialized
INFO - 2020-09-24 14:11:58 --> Loader Class Initialized
INFO - 2020-09-24 14:11:58 --> Helper loaded: url_helper
INFO - 2020-09-24 14:11:58 --> Helper loaded: file_helper
INFO - 2020-09-24 14:11:58 --> Database Driver Class Initialized
INFO - 2020-09-24 14:11:58 --> Email Class Initialized
DEBUG - 2020-09-24 14:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:11:58 --> Controller Class Initialized
INFO - 2020-09-24 14:11:58 --> Model "Main_model" initialized
INFO - 2020-09-24 14:11:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:11:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:11:58 --> Final output sent to browser
DEBUG - 2020-09-24 14:11:58 --> Total execution time: 0.4249
INFO - 2020-09-24 14:12:11 --> Config Class Initialized
INFO - 2020-09-24 14:12:11 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:12:11 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:12:11 --> Utf8 Class Initialized
INFO - 2020-09-24 14:12:11 --> URI Class Initialized
INFO - 2020-09-24 14:12:11 --> Router Class Initialized
INFO - 2020-09-24 14:12:11 --> Output Class Initialized
INFO - 2020-09-24 14:12:11 --> Security Class Initialized
DEBUG - 2020-09-24 14:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:12:11 --> Input Class Initialized
INFO - 2020-09-24 14:12:11 --> Language Class Initialized
INFO - 2020-09-24 14:12:11 --> Loader Class Initialized
INFO - 2020-09-24 14:12:11 --> Helper loaded: url_helper
INFO - 2020-09-24 14:12:11 --> Helper loaded: file_helper
INFO - 2020-09-24 14:12:11 --> Database Driver Class Initialized
INFO - 2020-09-24 14:12:11 --> Email Class Initialized
DEBUG - 2020-09-24 14:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:12:11 --> Controller Class Initialized
INFO - 2020-09-24 14:12:11 --> Model "Main_model" initialized
INFO - 2020-09-24 14:12:11 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 14:12:11 --> Severity: Notice --> Undefined index: host C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 172
ERROR - 2020-09-24 14:12:11 --> Severity: Notice --> Undefined index: txt C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 175
ERROR - 2020-09-24 14:12:11 --> Severity: Notice --> Undefined index: txt C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 177
ERROR - 2020-09-24 14:12:11 --> Severity: Notice --> Undefined index: host C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 172
ERROR - 2020-09-24 14:12:11 --> Severity: Notice --> Undefined index: txt C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 175
ERROR - 2020-09-24 14:12:11 --> Severity: Notice --> Undefined index: txt C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 177
INFO - 2020-09-24 14:12:11 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:12:11 --> Final output sent to browser
DEBUG - 2020-09-24 14:12:11 --> Total execution time: 0.5918
INFO - 2020-09-24 14:12:52 --> Config Class Initialized
INFO - 2020-09-24 14:12:52 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:12:52 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:12:52 --> Utf8 Class Initialized
INFO - 2020-09-24 14:12:52 --> URI Class Initialized
INFO - 2020-09-24 14:12:52 --> Router Class Initialized
INFO - 2020-09-24 14:12:52 --> Output Class Initialized
INFO - 2020-09-24 14:12:52 --> Security Class Initialized
DEBUG - 2020-09-24 14:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:12:52 --> Input Class Initialized
INFO - 2020-09-24 14:12:52 --> Language Class Initialized
INFO - 2020-09-24 14:12:52 --> Loader Class Initialized
INFO - 2020-09-24 14:12:53 --> Helper loaded: url_helper
INFO - 2020-09-24 14:12:53 --> Helper loaded: file_helper
INFO - 2020-09-24 14:12:53 --> Database Driver Class Initialized
INFO - 2020-09-24 14:12:53 --> Email Class Initialized
DEBUG - 2020-09-24 14:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:12:53 --> Controller Class Initialized
INFO - 2020-09-24 14:12:53 --> Model "Main_model" initialized
INFO - 2020-09-24 14:12:53 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:12:56 --> Config Class Initialized
INFO - 2020-09-24 14:12:56 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:12:57 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:12:57 --> Utf8 Class Initialized
INFO - 2020-09-24 14:12:57 --> URI Class Initialized
INFO - 2020-09-24 14:12:57 --> Router Class Initialized
INFO - 2020-09-24 14:12:57 --> Output Class Initialized
INFO - 2020-09-24 14:12:57 --> Security Class Initialized
DEBUG - 2020-09-24 14:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:12:57 --> Input Class Initialized
INFO - 2020-09-24 14:12:57 --> Language Class Initialized
INFO - 2020-09-24 14:12:57 --> Loader Class Initialized
INFO - 2020-09-24 14:12:57 --> Helper loaded: url_helper
INFO - 2020-09-24 14:12:57 --> Helper loaded: file_helper
INFO - 2020-09-24 14:12:57 --> Database Driver Class Initialized
INFO - 2020-09-24 14:12:57 --> Email Class Initialized
DEBUG - 2020-09-24 14:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:12:57 --> Controller Class Initialized
INFO - 2020-09-24 14:12:57 --> Model "Main_model" initialized
INFO - 2020-09-24 14:12:57 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:17:16 --> Config Class Initialized
INFO - 2020-09-24 14:17:16 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:17:16 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:17:16 --> Utf8 Class Initialized
INFO - 2020-09-24 14:17:16 --> URI Class Initialized
INFO - 2020-09-24 14:17:16 --> Router Class Initialized
INFO - 2020-09-24 14:17:16 --> Output Class Initialized
INFO - 2020-09-24 14:17:16 --> Security Class Initialized
DEBUG - 2020-09-24 14:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:17:16 --> Input Class Initialized
INFO - 2020-09-24 14:17:16 --> Language Class Initialized
INFO - 2020-09-24 14:17:16 --> Loader Class Initialized
INFO - 2020-09-24 14:17:16 --> Helper loaded: url_helper
INFO - 2020-09-24 14:17:16 --> Helper loaded: file_helper
INFO - 2020-09-24 14:17:16 --> Database Driver Class Initialized
INFO - 2020-09-24 14:17:16 --> Email Class Initialized
DEBUG - 2020-09-24 14:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:17:16 --> Controller Class Initialized
INFO - 2020-09-24 14:17:16 --> Model "Main_model" initialized
ERROR - 2020-09-24 14:17:17 --> Severity: Warning --> dns_get_record(): DNS Query failed C:\xampp\htdocs\dmarc\application\controllers\Home.php 53
ERROR - 2020-09-24 14:17:18 --> Severity: Warning --> dns_get_record(): DNS Query failed C:\xampp\htdocs\dmarc\application\controllers\Home.php 63
ERROR - 2020-09-24 14:17:19 --> Severity: Warning --> dns_get_record(): DNS Query failed C:\xampp\htdocs\dmarc\application\controllers\Home.php 66
INFO - 2020-09-24 14:17:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:17:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:17:19 --> Final output sent to browser
DEBUG - 2020-09-24 14:17:19 --> Total execution time: 3.4953
INFO - 2020-09-24 14:18:09 --> Config Class Initialized
INFO - 2020-09-24 14:18:09 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:18:09 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:18:09 --> Utf8 Class Initialized
INFO - 2020-09-24 14:18:09 --> URI Class Initialized
INFO - 2020-09-24 14:18:09 --> Router Class Initialized
INFO - 2020-09-24 14:18:09 --> Output Class Initialized
INFO - 2020-09-24 14:18:09 --> Security Class Initialized
DEBUG - 2020-09-24 14:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:18:09 --> Input Class Initialized
INFO - 2020-09-24 14:18:09 --> Language Class Initialized
INFO - 2020-09-24 14:18:09 --> Loader Class Initialized
INFO - 2020-09-24 14:18:10 --> Helper loaded: url_helper
INFO - 2020-09-24 14:18:10 --> Helper loaded: file_helper
INFO - 2020-09-24 14:18:10 --> Database Driver Class Initialized
INFO - 2020-09-24 14:18:10 --> Email Class Initialized
DEBUG - 2020-09-24 14:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:18:10 --> Controller Class Initialized
INFO - 2020-09-24 14:18:10 --> Model "Main_model" initialized
INFO - 2020-09-24 14:18:10 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:18:53 --> Config Class Initialized
INFO - 2020-09-24 14:18:53 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:18:53 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:18:53 --> Utf8 Class Initialized
INFO - 2020-09-24 14:18:53 --> URI Class Initialized
INFO - 2020-09-24 14:18:53 --> Router Class Initialized
INFO - 2020-09-24 14:18:53 --> Output Class Initialized
INFO - 2020-09-24 14:18:53 --> Security Class Initialized
DEBUG - 2020-09-24 14:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:18:53 --> Input Class Initialized
INFO - 2020-09-24 14:18:53 --> Language Class Initialized
INFO - 2020-09-24 14:18:53 --> Loader Class Initialized
INFO - 2020-09-24 14:18:54 --> Helper loaded: url_helper
INFO - 2020-09-24 14:18:54 --> Helper loaded: file_helper
INFO - 2020-09-24 14:18:54 --> Database Driver Class Initialized
INFO - 2020-09-24 14:18:54 --> Email Class Initialized
DEBUG - 2020-09-24 14:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:18:54 --> Controller Class Initialized
INFO - 2020-09-24 14:18:54 --> Model "Main_model" initialized
INFO - 2020-09-24 14:18:54 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:18:56 --> Config Class Initialized
INFO - 2020-09-24 14:18:56 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:18:56 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:18:56 --> Utf8 Class Initialized
INFO - 2020-09-24 14:18:56 --> URI Class Initialized
INFO - 2020-09-24 14:18:56 --> Router Class Initialized
INFO - 2020-09-24 14:18:56 --> Output Class Initialized
INFO - 2020-09-24 14:18:56 --> Security Class Initialized
DEBUG - 2020-09-24 14:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:18:56 --> Input Class Initialized
INFO - 2020-09-24 14:18:56 --> Language Class Initialized
INFO - 2020-09-24 14:18:56 --> Loader Class Initialized
INFO - 2020-09-24 14:18:56 --> Helper loaded: url_helper
INFO - 2020-09-24 14:18:56 --> Helper loaded: file_helper
INFO - 2020-09-24 14:18:56 --> Database Driver Class Initialized
INFO - 2020-09-24 14:18:56 --> Email Class Initialized
DEBUG - 2020-09-24 14:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:18:56 --> Controller Class Initialized
INFO - 2020-09-24 14:18:56 --> Model "Main_model" initialized
INFO - 2020-09-24 14:18:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:19:51 --> Config Class Initialized
INFO - 2020-09-24 14:19:51 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:19:51 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:19:51 --> Utf8 Class Initialized
INFO - 2020-09-24 14:19:51 --> URI Class Initialized
INFO - 2020-09-24 14:19:51 --> Router Class Initialized
INFO - 2020-09-24 14:19:51 --> Output Class Initialized
INFO - 2020-09-24 14:19:51 --> Security Class Initialized
DEBUG - 2020-09-24 14:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:19:51 --> Input Class Initialized
INFO - 2020-09-24 14:19:51 --> Language Class Initialized
INFO - 2020-09-24 14:19:51 --> Loader Class Initialized
INFO - 2020-09-24 14:19:51 --> Helper loaded: url_helper
INFO - 2020-09-24 14:19:51 --> Helper loaded: file_helper
INFO - 2020-09-24 14:19:51 --> Database Driver Class Initialized
INFO - 2020-09-24 14:19:51 --> Email Class Initialized
DEBUG - 2020-09-24 14:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:19:51 --> Controller Class Initialized
INFO - 2020-09-24 14:19:51 --> Model "Main_model" initialized
INFO - 2020-09-24 14:19:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:21:28 --> Config Class Initialized
INFO - 2020-09-24 14:21:28 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:21:28 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:21:28 --> Utf8 Class Initialized
INFO - 2020-09-24 14:21:29 --> URI Class Initialized
INFO - 2020-09-24 14:21:29 --> Router Class Initialized
INFO - 2020-09-24 14:21:29 --> Output Class Initialized
INFO - 2020-09-24 14:21:29 --> Security Class Initialized
DEBUG - 2020-09-24 14:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:21:29 --> Input Class Initialized
INFO - 2020-09-24 14:21:29 --> Language Class Initialized
INFO - 2020-09-24 14:21:29 --> Loader Class Initialized
INFO - 2020-09-24 14:21:29 --> Helper loaded: url_helper
INFO - 2020-09-24 14:21:29 --> Helper loaded: file_helper
INFO - 2020-09-24 14:21:29 --> Database Driver Class Initialized
INFO - 2020-09-24 14:21:29 --> Email Class Initialized
DEBUG - 2020-09-24 14:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:21:29 --> Controller Class Initialized
INFO - 2020-09-24 14:21:29 --> Model "Main_model" initialized
INFO - 2020-09-24 14:21:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'host' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 173
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 176
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 178
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'host' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 173
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 176
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 178
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'host' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 173
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 176
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 178
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'host' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 173
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 176
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 178
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'host' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 173
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 176
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 178
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'host' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 173
ERROR - 2020-09-24 14:21:29 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 176
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 178
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'host' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 173
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 176
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 178
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'host' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 173
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 176
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 178
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'host' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 173
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 176
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 178
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'host' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 173
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 176
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 178
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'host' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 173
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 176
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 178
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'host' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 173
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 176
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 178
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'host' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 173
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 176
ERROR - 2020-09-24 14:21:30 --> Severity: Warning --> Illegal string offset 'txt' C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php 178
INFO - 2020-09-24 14:21:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:21:30 --> Final output sent to browser
DEBUG - 2020-09-24 14:21:30 --> Total execution time: 1.8353
INFO - 2020-09-24 14:22:14 --> Config Class Initialized
INFO - 2020-09-24 14:22:14 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:22:14 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:22:14 --> Utf8 Class Initialized
INFO - 2020-09-24 14:22:14 --> URI Class Initialized
INFO - 2020-09-24 14:22:14 --> Router Class Initialized
INFO - 2020-09-24 14:22:14 --> Output Class Initialized
INFO - 2020-09-24 14:22:14 --> Security Class Initialized
DEBUG - 2020-09-24 14:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:22:14 --> Input Class Initialized
INFO - 2020-09-24 14:22:14 --> Language Class Initialized
INFO - 2020-09-24 14:22:14 --> Loader Class Initialized
INFO - 2020-09-24 14:22:14 --> Helper loaded: url_helper
INFO - 2020-09-24 14:22:14 --> Helper loaded: file_helper
INFO - 2020-09-24 14:22:14 --> Database Driver Class Initialized
INFO - 2020-09-24 14:22:14 --> Email Class Initialized
DEBUG - 2020-09-24 14:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:22:14 --> Controller Class Initialized
INFO - 2020-09-24 14:22:14 --> Model "Main_model" initialized
INFO - 2020-09-24 14:22:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:22:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:22:14 --> Final output sent to browser
DEBUG - 2020-09-24 14:22:14 --> Total execution time: 0.5424
INFO - 2020-09-24 14:22:58 --> Config Class Initialized
INFO - 2020-09-24 14:22:58 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:22:58 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:22:58 --> Utf8 Class Initialized
INFO - 2020-09-24 14:22:58 --> URI Class Initialized
INFO - 2020-09-24 14:22:58 --> Router Class Initialized
INFO - 2020-09-24 14:22:58 --> Output Class Initialized
INFO - 2020-09-24 14:22:58 --> Security Class Initialized
DEBUG - 2020-09-24 14:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:22:58 --> Input Class Initialized
INFO - 2020-09-24 14:22:58 --> Language Class Initialized
ERROR - 2020-09-24 14:22:58 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-24 14:24:26 --> Config Class Initialized
INFO - 2020-09-24 14:24:26 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:24:26 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:24:26 --> Utf8 Class Initialized
INFO - 2020-09-24 14:24:26 --> URI Class Initialized
INFO - 2020-09-24 14:24:26 --> Router Class Initialized
INFO - 2020-09-24 14:24:26 --> Output Class Initialized
INFO - 2020-09-24 14:24:26 --> Security Class Initialized
DEBUG - 2020-09-24 14:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:24:26 --> Input Class Initialized
INFO - 2020-09-24 14:24:26 --> Language Class Initialized
INFO - 2020-09-24 14:24:26 --> Loader Class Initialized
INFO - 2020-09-24 14:24:26 --> Helper loaded: url_helper
INFO - 2020-09-24 14:24:26 --> Helper loaded: file_helper
INFO - 2020-09-24 14:24:26 --> Database Driver Class Initialized
INFO - 2020-09-24 14:24:26 --> Email Class Initialized
DEBUG - 2020-09-24 14:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:24:26 --> Controller Class Initialized
INFO - 2020-09-24 14:24:26 --> Model "Main_model" initialized
INFO - 2020-09-24 14:24:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:24:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:24:26 --> Final output sent to browser
DEBUG - 2020-09-24 14:24:26 --> Total execution time: 0.5015
INFO - 2020-09-24 14:24:27 --> Config Class Initialized
INFO - 2020-09-24 14:24:27 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:24:27 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:24:27 --> Utf8 Class Initialized
INFO - 2020-09-24 14:24:27 --> URI Class Initialized
INFO - 2020-09-24 14:24:27 --> Router Class Initialized
INFO - 2020-09-24 14:24:27 --> Output Class Initialized
INFO - 2020-09-24 14:24:27 --> Security Class Initialized
DEBUG - 2020-09-24 14:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:24:27 --> Input Class Initialized
INFO - 2020-09-24 14:24:27 --> Language Class Initialized
ERROR - 2020-09-24 14:24:27 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-24 14:24:40 --> Config Class Initialized
INFO - 2020-09-24 14:24:40 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:24:40 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:24:40 --> Utf8 Class Initialized
INFO - 2020-09-24 14:24:40 --> URI Class Initialized
INFO - 2020-09-24 14:24:40 --> Router Class Initialized
INFO - 2020-09-24 14:24:40 --> Output Class Initialized
INFO - 2020-09-24 14:24:40 --> Security Class Initialized
DEBUG - 2020-09-24 14:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:24:40 --> Input Class Initialized
INFO - 2020-09-24 14:24:40 --> Language Class Initialized
INFO - 2020-09-24 14:24:40 --> Loader Class Initialized
INFO - 2020-09-24 14:24:40 --> Helper loaded: url_helper
INFO - 2020-09-24 14:24:40 --> Helper loaded: file_helper
INFO - 2020-09-24 14:24:40 --> Database Driver Class Initialized
INFO - 2020-09-24 14:24:40 --> Email Class Initialized
DEBUG - 2020-09-24 14:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:24:40 --> Controller Class Initialized
INFO - 2020-09-24 14:24:40 --> Model "Main_model" initialized
INFO - 2020-09-24 14:24:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:24:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:24:40 --> Final output sent to browser
DEBUG - 2020-09-24 14:24:40 --> Total execution time: 0.4861
INFO - 2020-09-24 14:29:14 --> Config Class Initialized
INFO - 2020-09-24 14:29:14 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:29:14 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:29:14 --> Utf8 Class Initialized
INFO - 2020-09-24 14:29:14 --> URI Class Initialized
INFO - 2020-09-24 14:29:14 --> Router Class Initialized
INFO - 2020-09-24 14:29:14 --> Output Class Initialized
INFO - 2020-09-24 14:29:14 --> Security Class Initialized
DEBUG - 2020-09-24 14:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:29:14 --> Input Class Initialized
INFO - 2020-09-24 14:29:14 --> Language Class Initialized
INFO - 2020-09-24 14:29:14 --> Loader Class Initialized
INFO - 2020-09-24 14:29:14 --> Helper loaded: url_helper
INFO - 2020-09-24 14:29:14 --> Helper loaded: file_helper
INFO - 2020-09-24 14:29:14 --> Database Driver Class Initialized
INFO - 2020-09-24 14:29:14 --> Email Class Initialized
DEBUG - 2020-09-24 14:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:29:14 --> Controller Class Initialized
INFO - 2020-09-24 14:29:14 --> Model "Main_model" initialized
INFO - 2020-09-24 14:29:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:29:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:29:14 --> Final output sent to browser
DEBUG - 2020-09-24 14:29:14 --> Total execution time: 0.4730
INFO - 2020-09-24 14:29:23 --> Config Class Initialized
INFO - 2020-09-24 14:29:23 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:29:23 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:29:23 --> Utf8 Class Initialized
INFO - 2020-09-24 14:29:23 --> URI Class Initialized
INFO - 2020-09-24 14:29:23 --> Router Class Initialized
INFO - 2020-09-24 14:29:23 --> Output Class Initialized
INFO - 2020-09-24 14:29:23 --> Security Class Initialized
DEBUG - 2020-09-24 14:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:29:23 --> Input Class Initialized
INFO - 2020-09-24 14:29:23 --> Language Class Initialized
INFO - 2020-09-24 14:29:23 --> Loader Class Initialized
INFO - 2020-09-24 14:29:23 --> Helper loaded: url_helper
INFO - 2020-09-24 14:29:23 --> Helper loaded: file_helper
INFO - 2020-09-24 14:29:23 --> Database Driver Class Initialized
INFO - 2020-09-24 14:29:23 --> Email Class Initialized
DEBUG - 2020-09-24 14:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:29:23 --> Controller Class Initialized
INFO - 2020-09-24 14:29:23 --> Model "Main_model" initialized
INFO - 2020-09-24 14:29:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:29:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:29:24 --> Final output sent to browser
DEBUG - 2020-09-24 14:29:24 --> Total execution time: 0.4980
INFO - 2020-09-24 14:29:44 --> Config Class Initialized
INFO - 2020-09-24 14:29:44 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:29:44 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:29:44 --> Utf8 Class Initialized
INFO - 2020-09-24 14:29:44 --> URI Class Initialized
INFO - 2020-09-24 14:29:44 --> Router Class Initialized
INFO - 2020-09-24 14:29:44 --> Output Class Initialized
INFO - 2020-09-24 14:29:44 --> Security Class Initialized
DEBUG - 2020-09-24 14:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:29:44 --> Input Class Initialized
INFO - 2020-09-24 14:29:44 --> Language Class Initialized
INFO - 2020-09-24 14:29:44 --> Loader Class Initialized
INFO - 2020-09-24 14:29:44 --> Helper loaded: url_helper
INFO - 2020-09-24 14:29:44 --> Helper loaded: file_helper
INFO - 2020-09-24 14:29:44 --> Database Driver Class Initialized
INFO - 2020-09-24 14:29:44 --> Email Class Initialized
DEBUG - 2020-09-24 14:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:29:44 --> Controller Class Initialized
INFO - 2020-09-24 14:29:44 --> Model "Main_model" initialized
INFO - 2020-09-24 14:29:45 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:29:45 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:29:45 --> Final output sent to browser
DEBUG - 2020-09-24 14:29:45 --> Total execution time: 0.7739
INFO - 2020-09-24 14:30:51 --> Config Class Initialized
INFO - 2020-09-24 14:30:51 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:30:51 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:30:51 --> Utf8 Class Initialized
INFO - 2020-09-24 14:30:51 --> URI Class Initialized
INFO - 2020-09-24 14:30:51 --> Router Class Initialized
INFO - 2020-09-24 14:30:51 --> Output Class Initialized
INFO - 2020-09-24 14:30:51 --> Security Class Initialized
DEBUG - 2020-09-24 14:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:30:51 --> Input Class Initialized
INFO - 2020-09-24 14:30:52 --> Language Class Initialized
INFO - 2020-09-24 14:30:52 --> Loader Class Initialized
INFO - 2020-09-24 14:30:52 --> Helper loaded: url_helper
INFO - 2020-09-24 14:30:52 --> Helper loaded: file_helper
INFO - 2020-09-24 14:30:52 --> Database Driver Class Initialized
INFO - 2020-09-24 14:30:52 --> Email Class Initialized
DEBUG - 2020-09-24 14:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:30:52 --> Controller Class Initialized
INFO - 2020-09-24 14:30:52 --> Model "Main_model" initialized
INFO - 2020-09-24 14:30:52 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:30:52 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:30:52 --> Final output sent to browser
DEBUG - 2020-09-24 14:30:52 --> Total execution time: 0.5150
INFO - 2020-09-24 14:31:35 --> Config Class Initialized
INFO - 2020-09-24 14:31:35 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:31:35 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:31:35 --> Utf8 Class Initialized
INFO - 2020-09-24 14:31:35 --> URI Class Initialized
INFO - 2020-09-24 14:31:35 --> Router Class Initialized
INFO - 2020-09-24 14:31:35 --> Output Class Initialized
INFO - 2020-09-24 14:31:35 --> Security Class Initialized
DEBUG - 2020-09-24 14:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:31:35 --> Input Class Initialized
INFO - 2020-09-24 14:31:35 --> Language Class Initialized
INFO - 2020-09-24 14:31:35 --> Loader Class Initialized
INFO - 2020-09-24 14:31:35 --> Helper loaded: url_helper
INFO - 2020-09-24 14:31:35 --> Helper loaded: file_helper
INFO - 2020-09-24 14:31:35 --> Database Driver Class Initialized
INFO - 2020-09-24 14:31:35 --> Email Class Initialized
DEBUG - 2020-09-24 14:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:31:35 --> Controller Class Initialized
INFO - 2020-09-24 14:31:35 --> Model "Main_model" initialized
INFO - 2020-09-24 14:31:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:31:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:31:35 --> Final output sent to browser
DEBUG - 2020-09-24 14:31:35 --> Total execution time: 0.5094
INFO - 2020-09-24 14:31:47 --> Config Class Initialized
INFO - 2020-09-24 14:31:47 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:31:47 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:31:47 --> Utf8 Class Initialized
INFO - 2020-09-24 14:31:47 --> URI Class Initialized
INFO - 2020-09-24 14:31:47 --> Router Class Initialized
INFO - 2020-09-24 14:31:47 --> Output Class Initialized
INFO - 2020-09-24 14:31:47 --> Security Class Initialized
DEBUG - 2020-09-24 14:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:31:47 --> Input Class Initialized
INFO - 2020-09-24 14:31:47 --> Language Class Initialized
ERROR - 2020-09-24 14:31:47 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-24 14:32:34 --> Config Class Initialized
INFO - 2020-09-24 14:32:34 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:32:34 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:32:34 --> Utf8 Class Initialized
INFO - 2020-09-24 14:32:34 --> URI Class Initialized
INFO - 2020-09-24 14:32:34 --> Router Class Initialized
INFO - 2020-09-24 14:32:34 --> Output Class Initialized
INFO - 2020-09-24 14:32:34 --> Security Class Initialized
DEBUG - 2020-09-24 14:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:32:34 --> Input Class Initialized
INFO - 2020-09-24 14:32:34 --> Language Class Initialized
INFO - 2020-09-24 14:32:34 --> Loader Class Initialized
INFO - 2020-09-24 14:32:34 --> Helper loaded: url_helper
INFO - 2020-09-24 14:32:34 --> Helper loaded: file_helper
INFO - 2020-09-24 14:32:34 --> Database Driver Class Initialized
INFO - 2020-09-24 14:32:34 --> Email Class Initialized
DEBUG - 2020-09-24 14:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 14:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 14:32:34 --> Controller Class Initialized
INFO - 2020-09-24 14:32:34 --> Model "Main_model" initialized
INFO - 2020-09-24 14:32:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 14:32:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 14:32:34 --> Final output sent to browser
DEBUG - 2020-09-24 14:32:34 --> Total execution time: 0.5020
INFO - 2020-09-24 14:32:35 --> Config Class Initialized
INFO - 2020-09-24 14:32:35 --> Hooks Class Initialized
DEBUG - 2020-09-24 14:32:35 --> UTF-8 Support Enabled
INFO - 2020-09-24 14:32:36 --> Utf8 Class Initialized
INFO - 2020-09-24 14:32:36 --> URI Class Initialized
INFO - 2020-09-24 14:32:36 --> Router Class Initialized
INFO - 2020-09-24 14:32:36 --> Output Class Initialized
INFO - 2020-09-24 14:32:36 --> Security Class Initialized
DEBUG - 2020-09-24 14:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 14:32:36 --> Input Class Initialized
INFO - 2020-09-24 14:32:36 --> Language Class Initialized
ERROR - 2020-09-24 14:32:36 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-24 15:09:19 --> Config Class Initialized
INFO - 2020-09-24 15:09:19 --> Hooks Class Initialized
DEBUG - 2020-09-24 15:09:19 --> UTF-8 Support Enabled
INFO - 2020-09-24 15:09:19 --> Utf8 Class Initialized
INFO - 2020-09-24 15:09:19 --> URI Class Initialized
INFO - 2020-09-24 15:09:19 --> Router Class Initialized
INFO - 2020-09-24 15:09:19 --> Output Class Initialized
INFO - 2020-09-24 15:09:19 --> Security Class Initialized
DEBUG - 2020-09-24 15:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 15:09:19 --> Input Class Initialized
INFO - 2020-09-24 15:09:19 --> Language Class Initialized
INFO - 2020-09-24 15:09:19 --> Loader Class Initialized
INFO - 2020-09-24 15:09:20 --> Helper loaded: url_helper
INFO - 2020-09-24 15:09:20 --> Helper loaded: file_helper
INFO - 2020-09-24 15:09:20 --> Database Driver Class Initialized
INFO - 2020-09-24 15:09:20 --> Email Class Initialized
DEBUG - 2020-09-24 15:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 15:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 15:09:20 --> Controller Class Initialized
INFO - 2020-09-24 15:09:20 --> Model "Main_model" initialized
INFO - 2020-09-24 15:09:20 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 15:09:20 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 15:09:20 --> Final output sent to browser
DEBUG - 2020-09-24 15:09:20 --> Total execution time: 0.5156
INFO - 2020-09-24 15:20:02 --> Config Class Initialized
INFO - 2020-09-24 15:20:02 --> Hooks Class Initialized
DEBUG - 2020-09-24 15:20:03 --> UTF-8 Support Enabled
INFO - 2020-09-24 15:20:03 --> Utf8 Class Initialized
INFO - 2020-09-24 15:20:03 --> URI Class Initialized
INFO - 2020-09-24 15:20:03 --> Router Class Initialized
INFO - 2020-09-24 15:20:03 --> Output Class Initialized
INFO - 2020-09-24 15:20:03 --> Security Class Initialized
DEBUG - 2020-09-24 15:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 15:20:03 --> Input Class Initialized
INFO - 2020-09-24 15:20:03 --> Language Class Initialized
INFO - 2020-09-24 15:20:03 --> Loader Class Initialized
INFO - 2020-09-24 15:20:03 --> Helper loaded: url_helper
INFO - 2020-09-24 15:20:03 --> Helper loaded: file_helper
INFO - 2020-09-24 15:20:03 --> Database Driver Class Initialized
INFO - 2020-09-24 15:20:03 --> Email Class Initialized
DEBUG - 2020-09-24 15:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 15:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 15:20:03 --> Controller Class Initialized
INFO - 2020-09-24 15:20:03 --> Model "Main_model" initialized
INFO - 2020-09-24 15:20:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 15:20:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-24 15:20:03 --> Final output sent to browser
DEBUG - 2020-09-24 15:20:03 --> Total execution time: 0.4705
INFO - 2020-09-24 15:21:28 --> Config Class Initialized
INFO - 2020-09-24 15:21:28 --> Hooks Class Initialized
DEBUG - 2020-09-24 15:21:28 --> UTF-8 Support Enabled
INFO - 2020-09-24 15:21:28 --> Utf8 Class Initialized
INFO - 2020-09-24 15:21:28 --> URI Class Initialized
INFO - 2020-09-24 15:21:28 --> Router Class Initialized
INFO - 2020-09-24 15:21:28 --> Output Class Initialized
INFO - 2020-09-24 15:21:28 --> Security Class Initialized
DEBUG - 2020-09-24 15:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 15:21:28 --> Input Class Initialized
INFO - 2020-09-24 15:21:28 --> Language Class Initialized
INFO - 2020-09-24 15:21:28 --> Loader Class Initialized
INFO - 2020-09-24 15:21:28 --> Helper loaded: url_helper
INFO - 2020-09-24 15:21:28 --> Helper loaded: file_helper
INFO - 2020-09-24 15:21:28 --> Database Driver Class Initialized
INFO - 2020-09-24 15:21:28 --> Email Class Initialized
DEBUG - 2020-09-24 15:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 15:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 15:21:28 --> Controller Class Initialized
INFO - 2020-09-24 15:21:28 --> Model "Main_model" initialized
INFO - 2020-09-24 15:21:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 15:21:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-24 15:21:28 --> Final output sent to browser
DEBUG - 2020-09-24 15:21:28 --> Total execution time: 0.4409
INFO - 2020-09-24 15:21:47 --> Config Class Initialized
INFO - 2020-09-24 15:21:47 --> Hooks Class Initialized
DEBUG - 2020-09-24 15:21:47 --> UTF-8 Support Enabled
INFO - 2020-09-24 15:21:47 --> Utf8 Class Initialized
INFO - 2020-09-24 15:21:47 --> URI Class Initialized
INFO - 2020-09-24 15:21:47 --> Router Class Initialized
INFO - 2020-09-24 15:21:47 --> Output Class Initialized
INFO - 2020-09-24 15:21:47 --> Security Class Initialized
DEBUG - 2020-09-24 15:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 15:21:48 --> Input Class Initialized
INFO - 2020-09-24 15:21:48 --> Language Class Initialized
INFO - 2020-09-24 15:21:48 --> Loader Class Initialized
INFO - 2020-09-24 15:21:48 --> Helper loaded: url_helper
INFO - 2020-09-24 15:21:48 --> Helper loaded: file_helper
INFO - 2020-09-24 15:21:48 --> Database Driver Class Initialized
INFO - 2020-09-24 15:21:48 --> Email Class Initialized
DEBUG - 2020-09-24 15:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 15:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 15:21:48 --> Controller Class Initialized
INFO - 2020-09-24 15:21:48 --> Model "Main_model" initialized
INFO - 2020-09-24 15:21:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 15:21:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 15:21:48 --> Final output sent to browser
DEBUG - 2020-09-24 15:21:48 --> Total execution time: 0.4467
INFO - 2020-09-24 15:24:15 --> Config Class Initialized
INFO - 2020-09-24 15:24:15 --> Hooks Class Initialized
DEBUG - 2020-09-24 15:24:15 --> UTF-8 Support Enabled
INFO - 2020-09-24 15:24:15 --> Utf8 Class Initialized
INFO - 2020-09-24 15:24:15 --> URI Class Initialized
INFO - 2020-09-24 15:24:15 --> Router Class Initialized
INFO - 2020-09-24 15:24:15 --> Output Class Initialized
INFO - 2020-09-24 15:24:15 --> Security Class Initialized
DEBUG - 2020-09-24 15:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 15:24:15 --> Input Class Initialized
INFO - 2020-09-24 15:24:15 --> Language Class Initialized
INFO - 2020-09-24 15:24:15 --> Loader Class Initialized
INFO - 2020-09-24 15:24:15 --> Helper loaded: url_helper
INFO - 2020-09-24 15:24:15 --> Helper loaded: file_helper
INFO - 2020-09-24 15:24:15 --> Database Driver Class Initialized
INFO - 2020-09-24 15:24:15 --> Email Class Initialized
DEBUG - 2020-09-24 15:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 15:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 15:24:15 --> Controller Class Initialized
INFO - 2020-09-24 15:24:15 --> Model "Main_model" initialized
INFO - 2020-09-24 15:24:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 15:24:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 15:24:15 --> Final output sent to browser
DEBUG - 2020-09-24 15:24:15 --> Total execution time: 0.4448
INFO - 2020-09-24 15:24:19 --> Config Class Initialized
INFO - 2020-09-24 15:24:19 --> Hooks Class Initialized
DEBUG - 2020-09-24 15:24:19 --> UTF-8 Support Enabled
INFO - 2020-09-24 15:24:19 --> Utf8 Class Initialized
INFO - 2020-09-24 15:24:19 --> URI Class Initialized
INFO - 2020-09-24 15:24:19 --> Router Class Initialized
INFO - 2020-09-24 15:24:19 --> Output Class Initialized
INFO - 2020-09-24 15:24:19 --> Security Class Initialized
DEBUG - 2020-09-24 15:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 15:24:19 --> Input Class Initialized
INFO - 2020-09-24 15:24:19 --> Language Class Initialized
INFO - 2020-09-24 15:24:19 --> Loader Class Initialized
INFO - 2020-09-24 15:24:19 --> Helper loaded: url_helper
INFO - 2020-09-24 15:24:19 --> Helper loaded: file_helper
INFO - 2020-09-24 15:24:19 --> Database Driver Class Initialized
INFO - 2020-09-24 15:24:19 --> Email Class Initialized
DEBUG - 2020-09-24 15:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 15:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 15:24:19 --> Controller Class Initialized
INFO - 2020-09-24 15:24:19 --> Model "Main_model" initialized
INFO - 2020-09-24 15:24:20 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 15:24:20 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-24 15:24:20 --> Final output sent to browser
DEBUG - 2020-09-24 15:24:20 --> Total execution time: 1.2439
INFO - 2020-09-24 15:24:59 --> Config Class Initialized
INFO - 2020-09-24 15:24:59 --> Hooks Class Initialized
DEBUG - 2020-09-24 15:24:59 --> UTF-8 Support Enabled
INFO - 2020-09-24 15:24:59 --> Utf8 Class Initialized
INFO - 2020-09-24 15:24:59 --> URI Class Initialized
INFO - 2020-09-24 15:24:59 --> Router Class Initialized
INFO - 2020-09-24 15:24:59 --> Output Class Initialized
INFO - 2020-09-24 15:24:59 --> Security Class Initialized
DEBUG - 2020-09-24 15:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 15:24:59 --> Input Class Initialized
INFO - 2020-09-24 15:24:59 --> Language Class Initialized
INFO - 2020-09-24 15:24:59 --> Loader Class Initialized
INFO - 2020-09-24 15:24:59 --> Helper loaded: url_helper
INFO - 2020-09-24 15:24:59 --> Helper loaded: file_helper
INFO - 2020-09-24 15:24:59 --> Database Driver Class Initialized
INFO - 2020-09-24 15:24:59 --> Email Class Initialized
DEBUG - 2020-09-24 15:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 15:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 15:24:59 --> Controller Class Initialized
INFO - 2020-09-24 15:24:59 --> Model "Main_model" initialized
INFO - 2020-09-24 15:24:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 15:24:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 15:24:59 --> Final output sent to browser
DEBUG - 2020-09-24 15:24:59 --> Total execution time: 0.4284
INFO - 2020-09-24 15:25:12 --> Config Class Initialized
INFO - 2020-09-24 15:25:12 --> Hooks Class Initialized
DEBUG - 2020-09-24 15:25:12 --> UTF-8 Support Enabled
INFO - 2020-09-24 15:25:12 --> Utf8 Class Initialized
INFO - 2020-09-24 15:25:12 --> URI Class Initialized
INFO - 2020-09-24 15:25:12 --> Router Class Initialized
INFO - 2020-09-24 15:25:12 --> Output Class Initialized
INFO - 2020-09-24 15:25:12 --> Security Class Initialized
DEBUG - 2020-09-24 15:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 15:25:13 --> Input Class Initialized
INFO - 2020-09-24 15:25:13 --> Language Class Initialized
INFO - 2020-09-24 15:25:13 --> Loader Class Initialized
INFO - 2020-09-24 15:25:13 --> Helper loaded: url_helper
INFO - 2020-09-24 15:25:13 --> Helper loaded: file_helper
INFO - 2020-09-24 15:25:13 --> Database Driver Class Initialized
INFO - 2020-09-24 15:25:13 --> Email Class Initialized
DEBUG - 2020-09-24 15:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 15:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 15:25:13 --> Controller Class Initialized
INFO - 2020-09-24 15:25:13 --> Model "Main_model" initialized
INFO - 2020-09-24 15:25:13 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 15:25:13 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrawchecker.php
INFO - 2020-09-24 15:25:13 --> Final output sent to browser
DEBUG - 2020-09-24 15:25:13 --> Total execution time: 0.4963
INFO - 2020-09-24 15:25:48 --> Config Class Initialized
INFO - 2020-09-24 15:25:48 --> Hooks Class Initialized
DEBUG - 2020-09-24 15:25:48 --> UTF-8 Support Enabled
INFO - 2020-09-24 15:25:48 --> Utf8 Class Initialized
INFO - 2020-09-24 15:25:48 --> URI Class Initialized
INFO - 2020-09-24 15:25:48 --> Router Class Initialized
INFO - 2020-09-24 15:25:48 --> Output Class Initialized
INFO - 2020-09-24 15:25:49 --> Security Class Initialized
DEBUG - 2020-09-24 15:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 15:25:49 --> Input Class Initialized
INFO - 2020-09-24 15:25:49 --> Language Class Initialized
INFO - 2020-09-24 15:25:49 --> Loader Class Initialized
INFO - 2020-09-24 15:25:49 --> Helper loaded: url_helper
INFO - 2020-09-24 15:25:49 --> Helper loaded: file_helper
INFO - 2020-09-24 15:25:49 --> Database Driver Class Initialized
INFO - 2020-09-24 15:25:49 --> Email Class Initialized
DEBUG - 2020-09-24 15:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 15:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 15:25:49 --> Controller Class Initialized
INFO - 2020-09-24 15:25:49 --> Model "Main_model" initialized
INFO - 2020-09-24 15:25:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 15:25:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-24 15:25:49 --> Final output sent to browser
DEBUG - 2020-09-24 15:25:49 --> Total execution time: 0.4682
INFO - 2020-09-24 15:26:11 --> Config Class Initialized
INFO - 2020-09-24 15:26:12 --> Hooks Class Initialized
DEBUG - 2020-09-24 15:26:12 --> UTF-8 Support Enabled
INFO - 2020-09-24 15:26:12 --> Utf8 Class Initialized
INFO - 2020-09-24 15:26:12 --> URI Class Initialized
INFO - 2020-09-24 15:26:12 --> Router Class Initialized
INFO - 2020-09-24 15:26:12 --> Output Class Initialized
INFO - 2020-09-24 15:26:12 --> Security Class Initialized
DEBUG - 2020-09-24 15:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 15:26:12 --> Input Class Initialized
INFO - 2020-09-24 15:26:12 --> Language Class Initialized
INFO - 2020-09-24 15:26:12 --> Loader Class Initialized
INFO - 2020-09-24 15:26:12 --> Helper loaded: url_helper
INFO - 2020-09-24 15:26:12 --> Helper loaded: file_helper
INFO - 2020-09-24 15:26:12 --> Database Driver Class Initialized
INFO - 2020-09-24 15:26:12 --> Email Class Initialized
DEBUG - 2020-09-24 15:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 15:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 15:26:12 --> Controller Class Initialized
INFO - 2020-09-24 15:26:12 --> Model "Main_model" initialized
INFO - 2020-09-24 15:26:12 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 15:26:12 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-24 15:26:12 --> Final output sent to browser
DEBUG - 2020-09-24 15:26:12 --> Total execution time: 0.4568
INFO - 2020-09-24 15:26:30 --> Config Class Initialized
INFO - 2020-09-24 15:26:30 --> Hooks Class Initialized
DEBUG - 2020-09-24 15:26:31 --> UTF-8 Support Enabled
INFO - 2020-09-24 15:26:31 --> Utf8 Class Initialized
INFO - 2020-09-24 15:26:31 --> URI Class Initialized
INFO - 2020-09-24 15:26:31 --> Router Class Initialized
INFO - 2020-09-24 15:26:31 --> Output Class Initialized
INFO - 2020-09-24 15:26:31 --> Security Class Initialized
DEBUG - 2020-09-24 15:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 15:26:31 --> Input Class Initialized
INFO - 2020-09-24 15:26:31 --> Language Class Initialized
INFO - 2020-09-24 15:26:31 --> Loader Class Initialized
INFO - 2020-09-24 15:26:31 --> Helper loaded: url_helper
INFO - 2020-09-24 15:26:31 --> Helper loaded: file_helper
INFO - 2020-09-24 15:26:31 --> Database Driver Class Initialized
INFO - 2020-09-24 15:26:31 --> Email Class Initialized
DEBUG - 2020-09-24 15:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 15:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 15:26:31 --> Controller Class Initialized
INFO - 2020-09-24 15:26:31 --> Model "Main_model" initialized
INFO - 2020-09-24 15:26:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-24 15:26:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spfrecordgenerator.php
INFO - 2020-09-24 15:26:31 --> Final output sent to browser
DEBUG - 2020-09-24 15:26:31 --> Total execution time: 0.4315
