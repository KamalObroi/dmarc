<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-25 09:41:44 --> Config Class Initialized
INFO - 2020-09-25 09:41:44 --> Hooks Class Initialized
DEBUG - 2020-09-25 09:41:44 --> UTF-8 Support Enabled
INFO - 2020-09-25 09:41:44 --> Utf8 Class Initialized
INFO - 2020-09-25 09:41:44 --> URI Class Initialized
DEBUG - 2020-09-25 09:41:44 --> No URI present. Default controller set.
INFO - 2020-09-25 09:41:44 --> Router Class Initialized
INFO - 2020-09-25 09:41:44 --> Output Class Initialized
INFO - 2020-09-25 09:41:44 --> Security Class Initialized
DEBUG - 2020-09-25 09:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 09:41:44 --> Input Class Initialized
INFO - 2020-09-25 09:41:44 --> Language Class Initialized
INFO - 2020-09-25 09:41:44 --> Loader Class Initialized
INFO - 2020-09-25 09:41:44 --> Helper loaded: url_helper
INFO - 2020-09-25 09:41:44 --> Helper loaded: file_helper
INFO - 2020-09-25 09:41:44 --> Database Driver Class Initialized
INFO - 2020-09-25 09:41:44 --> Email Class Initialized
DEBUG - 2020-09-25 09:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 09:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 09:41:44 --> Controller Class Initialized
INFO - 2020-09-25 09:41:44 --> Model "Main_model" initialized
INFO - 2020-09-25 09:41:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 09:41:44 --> Final output sent to browser
DEBUG - 2020-09-25 09:41:44 --> Total execution time: 0.8620
INFO - 2020-09-25 09:50:53 --> Config Class Initialized
INFO - 2020-09-25 09:50:53 --> Hooks Class Initialized
DEBUG - 2020-09-25 09:50:53 --> UTF-8 Support Enabled
INFO - 2020-09-25 09:50:53 --> Utf8 Class Initialized
INFO - 2020-09-25 09:50:53 --> URI Class Initialized
DEBUG - 2020-09-25 09:50:53 --> No URI present. Default controller set.
INFO - 2020-09-25 09:50:53 --> Router Class Initialized
INFO - 2020-09-25 09:50:53 --> Output Class Initialized
INFO - 2020-09-25 09:50:53 --> Security Class Initialized
DEBUG - 2020-09-25 09:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 09:50:53 --> Input Class Initialized
INFO - 2020-09-25 09:50:53 --> Language Class Initialized
INFO - 2020-09-25 09:50:53 --> Loader Class Initialized
INFO - 2020-09-25 09:50:53 --> Helper loaded: url_helper
INFO - 2020-09-25 09:50:53 --> Helper loaded: file_helper
INFO - 2020-09-25 09:50:53 --> Database Driver Class Initialized
INFO - 2020-09-25 09:50:53 --> Email Class Initialized
DEBUG - 2020-09-25 09:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 09:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 09:50:53 --> Controller Class Initialized
INFO - 2020-09-25 09:50:53 --> Model "Main_model" initialized
INFO - 2020-09-25 09:50:53 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 09:50:53 --> Final output sent to browser
DEBUG - 2020-09-25 09:50:53 --> Total execution time: 0.3621
INFO - 2020-09-25 09:56:23 --> Config Class Initialized
INFO - 2020-09-25 09:56:23 --> Hooks Class Initialized
DEBUG - 2020-09-25 09:56:23 --> UTF-8 Support Enabled
INFO - 2020-09-25 09:56:23 --> Utf8 Class Initialized
INFO - 2020-09-25 09:56:23 --> URI Class Initialized
DEBUG - 2020-09-25 09:56:23 --> No URI present. Default controller set.
INFO - 2020-09-25 09:56:23 --> Router Class Initialized
INFO - 2020-09-25 09:56:23 --> Output Class Initialized
INFO - 2020-09-25 09:56:23 --> Security Class Initialized
DEBUG - 2020-09-25 09:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 09:56:24 --> Input Class Initialized
INFO - 2020-09-25 09:56:24 --> Language Class Initialized
INFO - 2020-09-25 09:56:24 --> Loader Class Initialized
INFO - 2020-09-25 09:56:24 --> Helper loaded: url_helper
INFO - 2020-09-25 09:56:24 --> Helper loaded: file_helper
INFO - 2020-09-25 09:56:24 --> Database Driver Class Initialized
INFO - 2020-09-25 09:56:24 --> Email Class Initialized
DEBUG - 2020-09-25 09:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 09:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 09:56:24 --> Controller Class Initialized
INFO - 2020-09-25 09:56:24 --> Model "Main_model" initialized
INFO - 2020-09-25 09:56:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 09:56:24 --> Final output sent to browser
DEBUG - 2020-09-25 09:56:24 --> Total execution time: 0.3903
INFO - 2020-09-25 09:57:58 --> Config Class Initialized
INFO - 2020-09-25 09:57:58 --> Hooks Class Initialized
DEBUG - 2020-09-25 09:57:58 --> UTF-8 Support Enabled
INFO - 2020-09-25 09:57:58 --> Utf8 Class Initialized
INFO - 2020-09-25 09:57:58 --> URI Class Initialized
DEBUG - 2020-09-25 09:57:58 --> No URI present. Default controller set.
INFO - 2020-09-25 09:57:58 --> Router Class Initialized
INFO - 2020-09-25 09:57:58 --> Output Class Initialized
INFO - 2020-09-25 09:57:58 --> Security Class Initialized
DEBUG - 2020-09-25 09:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 09:57:58 --> Input Class Initialized
INFO - 2020-09-25 09:57:58 --> Language Class Initialized
INFO - 2020-09-25 09:57:58 --> Loader Class Initialized
INFO - 2020-09-25 09:57:58 --> Helper loaded: url_helper
INFO - 2020-09-25 09:57:58 --> Helper loaded: file_helper
INFO - 2020-09-25 09:57:58 --> Database Driver Class Initialized
INFO - 2020-09-25 09:57:58 --> Email Class Initialized
DEBUG - 2020-09-25 09:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 09:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 09:57:58 --> Controller Class Initialized
INFO - 2020-09-25 09:57:58 --> Model "Main_model" initialized
INFO - 2020-09-25 09:57:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 09:57:58 --> Final output sent to browser
DEBUG - 2020-09-25 09:57:58 --> Total execution time: 0.3633
INFO - 2020-09-25 10:05:36 --> Config Class Initialized
INFO - 2020-09-25 10:05:36 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:05:36 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:05:36 --> Utf8 Class Initialized
INFO - 2020-09-25 10:05:36 --> URI Class Initialized
DEBUG - 2020-09-25 10:05:36 --> No URI present. Default controller set.
INFO - 2020-09-25 10:05:36 --> Router Class Initialized
INFO - 2020-09-25 10:05:36 --> Output Class Initialized
INFO - 2020-09-25 10:05:36 --> Security Class Initialized
DEBUG - 2020-09-25 10:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:05:36 --> Input Class Initialized
INFO - 2020-09-25 10:05:36 --> Language Class Initialized
INFO - 2020-09-25 10:05:36 --> Loader Class Initialized
INFO - 2020-09-25 10:05:36 --> Helper loaded: url_helper
INFO - 2020-09-25 10:05:36 --> Helper loaded: file_helper
INFO - 2020-09-25 10:05:36 --> Database Driver Class Initialized
INFO - 2020-09-25 10:05:36 --> Email Class Initialized
DEBUG - 2020-09-25 10:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:05:36 --> Controller Class Initialized
INFO - 2020-09-25 10:05:36 --> Model "Main_model" initialized
INFO - 2020-09-25 10:05:36 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 10:05:36 --> Final output sent to browser
DEBUG - 2020-09-25 10:05:36 --> Total execution time: 0.3716
INFO - 2020-09-25 10:06:26 --> Config Class Initialized
INFO - 2020-09-25 10:06:26 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:06:26 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:06:26 --> Utf8 Class Initialized
INFO - 2020-09-25 10:06:26 --> URI Class Initialized
DEBUG - 2020-09-25 10:06:26 --> No URI present. Default controller set.
INFO - 2020-09-25 10:06:26 --> Router Class Initialized
INFO - 2020-09-25 10:06:26 --> Output Class Initialized
INFO - 2020-09-25 10:06:26 --> Security Class Initialized
DEBUG - 2020-09-25 10:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:06:26 --> Input Class Initialized
INFO - 2020-09-25 10:06:26 --> Language Class Initialized
INFO - 2020-09-25 10:06:26 --> Loader Class Initialized
INFO - 2020-09-25 10:06:26 --> Helper loaded: url_helper
INFO - 2020-09-25 10:06:26 --> Helper loaded: file_helper
INFO - 2020-09-25 10:06:26 --> Database Driver Class Initialized
INFO - 2020-09-25 10:06:26 --> Email Class Initialized
DEBUG - 2020-09-25 10:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:06:26 --> Controller Class Initialized
INFO - 2020-09-25 10:06:26 --> Model "Main_model" initialized
INFO - 2020-09-25 10:06:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 10:06:26 --> Final output sent to browser
DEBUG - 2020-09-25 10:06:27 --> Total execution time: 0.3451
INFO - 2020-09-25 10:06:38 --> Config Class Initialized
INFO - 2020-09-25 10:06:38 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:06:38 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:06:38 --> Utf8 Class Initialized
INFO - 2020-09-25 10:06:38 --> URI Class Initialized
DEBUG - 2020-09-25 10:06:38 --> No URI present. Default controller set.
INFO - 2020-09-25 10:06:38 --> Router Class Initialized
INFO - 2020-09-25 10:06:38 --> Output Class Initialized
INFO - 2020-09-25 10:06:38 --> Security Class Initialized
DEBUG - 2020-09-25 10:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:06:38 --> Input Class Initialized
INFO - 2020-09-25 10:06:38 --> Language Class Initialized
INFO - 2020-09-25 10:06:38 --> Loader Class Initialized
INFO - 2020-09-25 10:06:38 --> Helper loaded: url_helper
INFO - 2020-09-25 10:06:38 --> Helper loaded: file_helper
INFO - 2020-09-25 10:06:38 --> Database Driver Class Initialized
INFO - 2020-09-25 10:06:39 --> Email Class Initialized
DEBUG - 2020-09-25 10:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:06:39 --> Controller Class Initialized
INFO - 2020-09-25 10:06:39 --> Model "Main_model" initialized
INFO - 2020-09-25 10:06:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 10:06:39 --> Final output sent to browser
DEBUG - 2020-09-25 10:06:39 --> Total execution time: 0.3690
INFO - 2020-09-25 10:06:57 --> Config Class Initialized
INFO - 2020-09-25 10:06:57 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:06:57 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:06:57 --> Utf8 Class Initialized
INFO - 2020-09-25 10:06:57 --> URI Class Initialized
DEBUG - 2020-09-25 10:06:57 --> No URI present. Default controller set.
INFO - 2020-09-25 10:06:57 --> Router Class Initialized
INFO - 2020-09-25 10:06:57 --> Output Class Initialized
INFO - 2020-09-25 10:06:57 --> Security Class Initialized
DEBUG - 2020-09-25 10:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:06:57 --> Input Class Initialized
INFO - 2020-09-25 10:06:57 --> Language Class Initialized
INFO - 2020-09-25 10:06:57 --> Loader Class Initialized
INFO - 2020-09-25 10:06:57 --> Helper loaded: url_helper
INFO - 2020-09-25 10:06:57 --> Helper loaded: file_helper
INFO - 2020-09-25 10:06:57 --> Database Driver Class Initialized
INFO - 2020-09-25 10:06:57 --> Email Class Initialized
DEBUG - 2020-09-25 10:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:06:57 --> Controller Class Initialized
INFO - 2020-09-25 10:06:57 --> Model "Main_model" initialized
INFO - 2020-09-25 10:06:57 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 10:06:57 --> Final output sent to browser
DEBUG - 2020-09-25 10:06:58 --> Total execution time: 0.3847
INFO - 2020-09-25 10:07:05 --> Config Class Initialized
INFO - 2020-09-25 10:07:05 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:07:05 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:07:05 --> Utf8 Class Initialized
INFO - 2020-09-25 10:07:06 --> URI Class Initialized
DEBUG - 2020-09-25 10:07:06 --> No URI present. Default controller set.
INFO - 2020-09-25 10:07:06 --> Router Class Initialized
INFO - 2020-09-25 10:07:06 --> Output Class Initialized
INFO - 2020-09-25 10:07:06 --> Security Class Initialized
DEBUG - 2020-09-25 10:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:07:06 --> Input Class Initialized
INFO - 2020-09-25 10:07:06 --> Language Class Initialized
INFO - 2020-09-25 10:07:06 --> Loader Class Initialized
INFO - 2020-09-25 10:07:06 --> Helper loaded: url_helper
INFO - 2020-09-25 10:07:06 --> Helper loaded: file_helper
INFO - 2020-09-25 10:07:06 --> Database Driver Class Initialized
INFO - 2020-09-25 10:07:06 --> Email Class Initialized
DEBUG - 2020-09-25 10:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:07:06 --> Controller Class Initialized
INFO - 2020-09-25 10:07:06 --> Model "Main_model" initialized
INFO - 2020-09-25 10:07:06 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 10:07:06 --> Final output sent to browser
DEBUG - 2020-09-25 10:07:06 --> Total execution time: 0.3791
INFO - 2020-09-25 10:08:40 --> Config Class Initialized
INFO - 2020-09-25 10:08:40 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:08:40 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:08:40 --> Utf8 Class Initialized
INFO - 2020-09-25 10:08:40 --> URI Class Initialized
DEBUG - 2020-09-25 10:08:40 --> No URI present. Default controller set.
INFO - 2020-09-25 10:08:40 --> Router Class Initialized
INFO - 2020-09-25 10:08:40 --> Output Class Initialized
INFO - 2020-09-25 10:08:40 --> Security Class Initialized
DEBUG - 2020-09-25 10:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:08:40 --> Input Class Initialized
INFO - 2020-09-25 10:08:40 --> Language Class Initialized
INFO - 2020-09-25 10:08:40 --> Loader Class Initialized
INFO - 2020-09-25 10:08:40 --> Helper loaded: url_helper
INFO - 2020-09-25 10:08:40 --> Helper loaded: file_helper
INFO - 2020-09-25 10:08:40 --> Database Driver Class Initialized
INFO - 2020-09-25 10:08:40 --> Email Class Initialized
DEBUG - 2020-09-25 10:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:08:40 --> Controller Class Initialized
INFO - 2020-09-25 10:08:40 --> Model "Main_model" initialized
INFO - 2020-09-25 10:08:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 10:08:40 --> Final output sent to browser
DEBUG - 2020-09-25 10:08:41 --> Total execution time: 0.3860
INFO - 2020-09-25 10:11:16 --> Config Class Initialized
INFO - 2020-09-25 10:11:16 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:11:16 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:11:16 --> Utf8 Class Initialized
INFO - 2020-09-25 10:11:16 --> URI Class Initialized
DEBUG - 2020-09-25 10:11:16 --> No URI present. Default controller set.
INFO - 2020-09-25 10:11:16 --> Router Class Initialized
INFO - 2020-09-25 10:11:16 --> Output Class Initialized
INFO - 2020-09-25 10:11:16 --> Security Class Initialized
DEBUG - 2020-09-25 10:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:11:16 --> Input Class Initialized
INFO - 2020-09-25 10:11:16 --> Language Class Initialized
INFO - 2020-09-25 10:11:16 --> Loader Class Initialized
INFO - 2020-09-25 10:11:16 --> Helper loaded: url_helper
INFO - 2020-09-25 10:11:16 --> Helper loaded: file_helper
INFO - 2020-09-25 10:11:16 --> Database Driver Class Initialized
INFO - 2020-09-25 10:11:16 --> Email Class Initialized
DEBUG - 2020-09-25 10:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:11:16 --> Controller Class Initialized
INFO - 2020-09-25 10:11:16 --> Model "Main_model" initialized
INFO - 2020-09-25 10:11:16 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 10:11:16 --> Final output sent to browser
DEBUG - 2020-09-25 10:11:16 --> Total execution time: 0.3960
INFO - 2020-09-25 10:11:29 --> Config Class Initialized
INFO - 2020-09-25 10:11:29 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:11:29 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:11:30 --> Utf8 Class Initialized
INFO - 2020-09-25 10:11:30 --> URI Class Initialized
DEBUG - 2020-09-25 10:11:30 --> No URI present. Default controller set.
INFO - 2020-09-25 10:11:30 --> Router Class Initialized
INFO - 2020-09-25 10:11:30 --> Output Class Initialized
INFO - 2020-09-25 10:11:30 --> Security Class Initialized
DEBUG - 2020-09-25 10:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:11:30 --> Input Class Initialized
INFO - 2020-09-25 10:11:30 --> Language Class Initialized
INFO - 2020-09-25 10:11:30 --> Loader Class Initialized
INFO - 2020-09-25 10:11:30 --> Helper loaded: url_helper
INFO - 2020-09-25 10:11:30 --> Helper loaded: file_helper
INFO - 2020-09-25 10:11:30 --> Database Driver Class Initialized
INFO - 2020-09-25 10:11:30 --> Email Class Initialized
DEBUG - 2020-09-25 10:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:11:30 --> Controller Class Initialized
INFO - 2020-09-25 10:11:30 --> Model "Main_model" initialized
INFO - 2020-09-25 10:11:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 10:11:30 --> Final output sent to browser
DEBUG - 2020-09-25 10:11:30 --> Total execution time: 0.4070
INFO - 2020-09-25 10:11:49 --> Config Class Initialized
INFO - 2020-09-25 10:11:49 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:11:49 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:11:49 --> Utf8 Class Initialized
INFO - 2020-09-25 10:11:49 --> URI Class Initialized
DEBUG - 2020-09-25 10:11:49 --> No URI present. Default controller set.
INFO - 2020-09-25 10:11:49 --> Router Class Initialized
INFO - 2020-09-25 10:11:49 --> Output Class Initialized
INFO - 2020-09-25 10:11:49 --> Security Class Initialized
DEBUG - 2020-09-25 10:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:11:49 --> Input Class Initialized
INFO - 2020-09-25 10:11:49 --> Language Class Initialized
INFO - 2020-09-25 10:11:49 --> Loader Class Initialized
INFO - 2020-09-25 10:11:49 --> Helper loaded: url_helper
INFO - 2020-09-25 10:11:49 --> Helper loaded: file_helper
INFO - 2020-09-25 10:11:49 --> Database Driver Class Initialized
INFO - 2020-09-25 10:11:49 --> Email Class Initialized
DEBUG - 2020-09-25 10:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:11:49 --> Controller Class Initialized
INFO - 2020-09-25 10:11:49 --> Model "Main_model" initialized
INFO - 2020-09-25 10:11:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 10:11:49 --> Final output sent to browser
DEBUG - 2020-09-25 10:11:49 --> Total execution time: 0.3762
INFO - 2020-09-25 10:11:52 --> Config Class Initialized
INFO - 2020-09-25 10:11:52 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:11:52 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:11:52 --> Utf8 Class Initialized
INFO - 2020-09-25 10:11:52 --> URI Class Initialized
DEBUG - 2020-09-25 10:11:52 --> No URI present. Default controller set.
INFO - 2020-09-25 10:11:52 --> Router Class Initialized
INFO - 2020-09-25 10:11:52 --> Output Class Initialized
INFO - 2020-09-25 10:11:52 --> Security Class Initialized
DEBUG - 2020-09-25 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:11:52 --> Input Class Initialized
INFO - 2020-09-25 10:11:52 --> Language Class Initialized
INFO - 2020-09-25 10:11:52 --> Loader Class Initialized
INFO - 2020-09-25 10:11:52 --> Helper loaded: url_helper
INFO - 2020-09-25 10:11:52 --> Helper loaded: file_helper
INFO - 2020-09-25 10:11:52 --> Database Driver Class Initialized
INFO - 2020-09-25 10:11:52 --> Email Class Initialized
DEBUG - 2020-09-25 10:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:11:52 --> Controller Class Initialized
INFO - 2020-09-25 10:11:52 --> Model "Main_model" initialized
INFO - 2020-09-25 10:11:52 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 10:11:53 --> Final output sent to browser
DEBUG - 2020-09-25 10:11:53 --> Total execution time: 0.4063
INFO - 2020-09-25 10:15:17 --> Config Class Initialized
INFO - 2020-09-25 10:15:17 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:15:17 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:15:17 --> Utf8 Class Initialized
INFO - 2020-09-25 10:15:17 --> URI Class Initialized
DEBUG - 2020-09-25 10:15:17 --> No URI present. Default controller set.
INFO - 2020-09-25 10:15:17 --> Router Class Initialized
INFO - 2020-09-25 10:15:17 --> Output Class Initialized
INFO - 2020-09-25 10:15:17 --> Security Class Initialized
DEBUG - 2020-09-25 10:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:15:17 --> Input Class Initialized
INFO - 2020-09-25 10:15:17 --> Language Class Initialized
INFO - 2020-09-25 10:15:17 --> Loader Class Initialized
INFO - 2020-09-25 10:15:17 --> Helper loaded: url_helper
INFO - 2020-09-25 10:15:17 --> Helper loaded: file_helper
INFO - 2020-09-25 10:15:17 --> Database Driver Class Initialized
INFO - 2020-09-25 10:15:17 --> Email Class Initialized
DEBUG - 2020-09-25 10:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:15:17 --> Controller Class Initialized
INFO - 2020-09-25 10:15:17 --> Model "Main_model" initialized
ERROR - 2020-09-25 10:15:17 --> Severity: error --> Exception: syntax error, unexpected 'en' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\dmarc\application\views\home.php 5
INFO - 2020-09-25 10:18:01 --> Config Class Initialized
INFO - 2020-09-25 10:18:01 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:18:01 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:18:01 --> Utf8 Class Initialized
INFO - 2020-09-25 10:18:02 --> URI Class Initialized
DEBUG - 2020-09-25 10:18:02 --> No URI present. Default controller set.
INFO - 2020-09-25 10:18:02 --> Router Class Initialized
INFO - 2020-09-25 10:18:02 --> Output Class Initialized
INFO - 2020-09-25 10:18:02 --> Security Class Initialized
DEBUG - 2020-09-25 10:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:18:02 --> Input Class Initialized
INFO - 2020-09-25 10:18:02 --> Language Class Initialized
INFO - 2020-09-25 10:18:02 --> Loader Class Initialized
INFO - 2020-09-25 10:18:02 --> Helper loaded: url_helper
INFO - 2020-09-25 10:18:02 --> Helper loaded: file_helper
INFO - 2020-09-25 10:18:02 --> Database Driver Class Initialized
INFO - 2020-09-25 10:18:02 --> Email Class Initialized
DEBUG - 2020-09-25 10:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:18:02 --> Controller Class Initialized
INFO - 2020-09-25 10:18:02 --> Model "Main_model" initialized
ERROR - 2020-09-25 10:18:02 --> Severity: error --> Exception: syntax error, unexpected 'strtotime' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\dmarc\application\views\home.php 3
INFO - 2020-09-25 10:18:46 --> Config Class Initialized
INFO - 2020-09-25 10:18:46 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:18:46 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:18:47 --> Utf8 Class Initialized
INFO - 2020-09-25 10:18:47 --> URI Class Initialized
DEBUG - 2020-09-25 10:18:47 --> No URI present. Default controller set.
INFO - 2020-09-25 10:18:47 --> Router Class Initialized
INFO - 2020-09-25 10:18:47 --> Output Class Initialized
INFO - 2020-09-25 10:18:47 --> Security Class Initialized
DEBUG - 2020-09-25 10:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:18:47 --> Input Class Initialized
INFO - 2020-09-25 10:18:47 --> Language Class Initialized
INFO - 2020-09-25 10:18:47 --> Loader Class Initialized
INFO - 2020-09-25 10:18:47 --> Helper loaded: url_helper
INFO - 2020-09-25 10:18:47 --> Helper loaded: file_helper
INFO - 2020-09-25 10:18:47 --> Database Driver Class Initialized
INFO - 2020-09-25 10:18:47 --> Email Class Initialized
DEBUG - 2020-09-25 10:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:18:47 --> Controller Class Initialized
INFO - 2020-09-25 10:18:47 --> Model "Main_model" initialized
ERROR - 2020-09-25 10:18:47 --> Severity: error --> Exception: syntax error, unexpected 'strtotime' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\dmarc\application\views\home.php 3
INFO - 2020-09-25 10:19:06 --> Config Class Initialized
INFO - 2020-09-25 10:19:06 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:19:06 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:19:06 --> Utf8 Class Initialized
INFO - 2020-09-25 10:19:06 --> URI Class Initialized
DEBUG - 2020-09-25 10:19:06 --> No URI present. Default controller set.
INFO - 2020-09-25 10:19:06 --> Router Class Initialized
INFO - 2020-09-25 10:19:06 --> Output Class Initialized
INFO - 2020-09-25 10:19:06 --> Security Class Initialized
DEBUG - 2020-09-25 10:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:19:06 --> Input Class Initialized
INFO - 2020-09-25 10:19:06 --> Language Class Initialized
INFO - 2020-09-25 10:19:06 --> Loader Class Initialized
INFO - 2020-09-25 10:19:06 --> Helper loaded: url_helper
INFO - 2020-09-25 10:19:06 --> Helper loaded: file_helper
INFO - 2020-09-25 10:19:06 --> Database Driver Class Initialized
INFO - 2020-09-25 10:19:06 --> Email Class Initialized
DEBUG - 2020-09-25 10:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:19:06 --> Controller Class Initialized
INFO - 2020-09-25 10:19:06 --> Model "Main_model" initialized
INFO - 2020-09-25 10:19:06 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 10:19:06 --> Final output sent to browser
DEBUG - 2020-09-25 10:19:06 --> Total execution time: 0.3443
INFO - 2020-09-25 10:29:52 --> Config Class Initialized
INFO - 2020-09-25 10:29:52 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:29:52 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:29:52 --> Utf8 Class Initialized
INFO - 2020-09-25 10:29:52 --> URI Class Initialized
DEBUG - 2020-09-25 10:29:52 --> No URI present. Default controller set.
INFO - 2020-09-25 10:29:52 --> Router Class Initialized
INFO - 2020-09-25 10:29:53 --> Output Class Initialized
INFO - 2020-09-25 10:29:53 --> Security Class Initialized
DEBUG - 2020-09-25 10:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:29:53 --> Input Class Initialized
INFO - 2020-09-25 10:29:53 --> Language Class Initialized
INFO - 2020-09-25 10:29:53 --> Loader Class Initialized
INFO - 2020-09-25 10:29:53 --> Helper loaded: url_helper
INFO - 2020-09-25 10:29:53 --> Helper loaded: file_helper
INFO - 2020-09-25 10:29:53 --> Database Driver Class Initialized
INFO - 2020-09-25 10:29:53 --> Email Class Initialized
DEBUG - 2020-09-25 10:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:29:53 --> Controller Class Initialized
INFO - 2020-09-25 10:29:53 --> Model "Main_model" initialized
INFO - 2020-09-25 10:29:53 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 10:29:53 --> Final output sent to browser
DEBUG - 2020-09-25 10:29:53 --> Total execution time: 0.3839
INFO - 2020-09-25 10:30:09 --> Config Class Initialized
INFO - 2020-09-25 10:30:09 --> Hooks Class Initialized
DEBUG - 2020-09-25 10:30:09 --> UTF-8 Support Enabled
INFO - 2020-09-25 10:30:09 --> Utf8 Class Initialized
INFO - 2020-09-25 10:30:09 --> URI Class Initialized
DEBUG - 2020-09-25 10:30:09 --> No URI present. Default controller set.
INFO - 2020-09-25 10:30:09 --> Router Class Initialized
INFO - 2020-09-25 10:30:09 --> Output Class Initialized
INFO - 2020-09-25 10:30:09 --> Security Class Initialized
DEBUG - 2020-09-25 10:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 10:30:09 --> Input Class Initialized
INFO - 2020-09-25 10:30:09 --> Language Class Initialized
INFO - 2020-09-25 10:30:09 --> Loader Class Initialized
INFO - 2020-09-25 10:30:09 --> Helper loaded: url_helper
INFO - 2020-09-25 10:30:09 --> Helper loaded: file_helper
INFO - 2020-09-25 10:30:09 --> Database Driver Class Initialized
INFO - 2020-09-25 10:30:09 --> Email Class Initialized
DEBUG - 2020-09-25 10:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 10:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 10:30:09 --> Controller Class Initialized
INFO - 2020-09-25 10:30:09 --> Model "Main_model" initialized
INFO - 2020-09-25 10:30:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 10:30:09 --> Final output sent to browser
DEBUG - 2020-09-25 10:30:09 --> Total execution time: 0.3533
INFO - 2020-09-25 14:01:30 --> Config Class Initialized
INFO - 2020-09-25 14:01:30 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:01:30 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:01:30 --> Utf8 Class Initialized
INFO - 2020-09-25 14:01:30 --> URI Class Initialized
DEBUG - 2020-09-25 14:01:30 --> No URI present. Default controller set.
INFO - 2020-09-25 14:01:30 --> Router Class Initialized
INFO - 2020-09-25 14:01:31 --> Output Class Initialized
INFO - 2020-09-25 14:01:31 --> Security Class Initialized
DEBUG - 2020-09-25 14:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:01:31 --> Input Class Initialized
INFO - 2020-09-25 14:01:31 --> Language Class Initialized
INFO - 2020-09-25 14:01:31 --> Loader Class Initialized
INFO - 2020-09-25 14:01:31 --> Helper loaded: url_helper
INFO - 2020-09-25 14:01:31 --> Helper loaded: file_helper
INFO - 2020-09-25 14:01:31 --> Database Driver Class Initialized
INFO - 2020-09-25 14:01:31 --> Email Class Initialized
DEBUG - 2020-09-25 14:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:01:31 --> Controller Class Initialized
INFO - 2020-09-25 14:01:31 --> Model "Main_model" initialized
INFO - 2020-09-25 14:01:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:01:31 --> Final output sent to browser
DEBUG - 2020-09-25 14:01:31 --> Total execution time: 0.3814
INFO - 2020-09-25 14:02:14 --> Config Class Initialized
INFO - 2020-09-25 14:02:14 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:02:14 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:02:14 --> Utf8 Class Initialized
INFO - 2020-09-25 14:02:14 --> URI Class Initialized
DEBUG - 2020-09-25 14:02:14 --> No URI present. Default controller set.
INFO - 2020-09-25 14:02:14 --> Router Class Initialized
INFO - 2020-09-25 14:02:14 --> Output Class Initialized
INFO - 2020-09-25 14:02:14 --> Security Class Initialized
DEBUG - 2020-09-25 14:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:02:14 --> Input Class Initialized
INFO - 2020-09-25 14:02:14 --> Language Class Initialized
INFO - 2020-09-25 14:02:14 --> Loader Class Initialized
INFO - 2020-09-25 14:02:14 --> Helper loaded: url_helper
INFO - 2020-09-25 14:02:14 --> Helper loaded: file_helper
INFO - 2020-09-25 14:02:14 --> Database Driver Class Initialized
INFO - 2020-09-25 14:02:14 --> Email Class Initialized
DEBUG - 2020-09-25 14:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:02:14 --> Controller Class Initialized
INFO - 2020-09-25 14:02:14 --> Model "Main_model" initialized
INFO - 2020-09-25 14:02:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:02:14 --> Final output sent to browser
DEBUG - 2020-09-25 14:02:14 --> Total execution time: 0.3705
INFO - 2020-09-25 14:02:24 --> Config Class Initialized
INFO - 2020-09-25 14:02:24 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:02:24 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:02:24 --> Utf8 Class Initialized
INFO - 2020-09-25 14:02:24 --> URI Class Initialized
DEBUG - 2020-09-25 14:02:24 --> No URI present. Default controller set.
INFO - 2020-09-25 14:02:24 --> Router Class Initialized
INFO - 2020-09-25 14:02:24 --> Output Class Initialized
INFO - 2020-09-25 14:02:24 --> Security Class Initialized
DEBUG - 2020-09-25 14:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:02:24 --> Input Class Initialized
INFO - 2020-09-25 14:02:24 --> Language Class Initialized
INFO - 2020-09-25 14:02:25 --> Loader Class Initialized
INFO - 2020-09-25 14:02:25 --> Helper loaded: url_helper
INFO - 2020-09-25 14:02:25 --> Helper loaded: file_helper
INFO - 2020-09-25 14:02:25 --> Database Driver Class Initialized
INFO - 2020-09-25 14:02:25 --> Email Class Initialized
DEBUG - 2020-09-25 14:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:02:25 --> Controller Class Initialized
INFO - 2020-09-25 14:02:25 --> Model "Main_model" initialized
INFO - 2020-09-25 14:02:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:02:25 --> Final output sent to browser
DEBUG - 2020-09-25 14:02:25 --> Total execution time: 0.3705
INFO - 2020-09-25 14:08:13 --> Config Class Initialized
INFO - 2020-09-25 14:08:13 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:08:13 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:08:13 --> Utf8 Class Initialized
INFO - 2020-09-25 14:08:13 --> URI Class Initialized
DEBUG - 2020-09-25 14:08:13 --> No URI present. Default controller set.
INFO - 2020-09-25 14:08:13 --> Router Class Initialized
INFO - 2020-09-25 14:08:13 --> Output Class Initialized
INFO - 2020-09-25 14:08:13 --> Security Class Initialized
DEBUG - 2020-09-25 14:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:08:13 --> Input Class Initialized
INFO - 2020-09-25 14:08:13 --> Language Class Initialized
INFO - 2020-09-25 14:08:13 --> Loader Class Initialized
INFO - 2020-09-25 14:08:13 --> Helper loaded: url_helper
INFO - 2020-09-25 14:08:13 --> Helper loaded: file_helper
INFO - 2020-09-25 14:08:13 --> Database Driver Class Initialized
INFO - 2020-09-25 14:08:13 --> Email Class Initialized
DEBUG - 2020-09-25 14:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:08:13 --> Controller Class Initialized
INFO - 2020-09-25 14:08:13 --> Model "Main_model" initialized
INFO - 2020-09-25 14:08:13 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:08:13 --> Final output sent to browser
DEBUG - 2020-09-25 14:08:13 --> Total execution time: 0.3618
INFO - 2020-09-25 14:08:36 --> Config Class Initialized
INFO - 2020-09-25 14:08:36 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:08:36 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:08:36 --> Utf8 Class Initialized
INFO - 2020-09-25 14:08:36 --> URI Class Initialized
DEBUG - 2020-09-25 14:08:36 --> No URI present. Default controller set.
INFO - 2020-09-25 14:08:36 --> Router Class Initialized
INFO - 2020-09-25 14:08:36 --> Output Class Initialized
INFO - 2020-09-25 14:08:36 --> Security Class Initialized
DEBUG - 2020-09-25 14:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:08:36 --> Input Class Initialized
INFO - 2020-09-25 14:08:37 --> Language Class Initialized
INFO - 2020-09-25 14:08:37 --> Loader Class Initialized
INFO - 2020-09-25 14:08:37 --> Helper loaded: url_helper
INFO - 2020-09-25 14:08:37 --> Helper loaded: file_helper
INFO - 2020-09-25 14:08:37 --> Database Driver Class Initialized
INFO - 2020-09-25 14:08:37 --> Email Class Initialized
DEBUG - 2020-09-25 14:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:08:37 --> Controller Class Initialized
INFO - 2020-09-25 14:08:37 --> Model "Main_model" initialized
INFO - 2020-09-25 14:08:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:08:37 --> Final output sent to browser
DEBUG - 2020-09-25 14:08:37 --> Total execution time: 0.3342
INFO - 2020-09-25 14:08:55 --> Config Class Initialized
INFO - 2020-09-25 14:08:55 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:08:55 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:08:55 --> Utf8 Class Initialized
INFO - 2020-09-25 14:08:55 --> URI Class Initialized
DEBUG - 2020-09-25 14:08:55 --> No URI present. Default controller set.
INFO - 2020-09-25 14:08:55 --> Router Class Initialized
INFO - 2020-09-25 14:08:55 --> Output Class Initialized
INFO - 2020-09-25 14:08:55 --> Security Class Initialized
DEBUG - 2020-09-25 14:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:08:55 --> Input Class Initialized
INFO - 2020-09-25 14:08:55 --> Language Class Initialized
INFO - 2020-09-25 14:08:55 --> Loader Class Initialized
INFO - 2020-09-25 14:08:55 --> Helper loaded: url_helper
INFO - 2020-09-25 14:08:55 --> Helper loaded: file_helper
INFO - 2020-09-25 14:08:55 --> Database Driver Class Initialized
INFO - 2020-09-25 14:08:55 --> Email Class Initialized
DEBUG - 2020-09-25 14:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:08:55 --> Controller Class Initialized
INFO - 2020-09-25 14:08:55 --> Model "Main_model" initialized
INFO - 2020-09-25 14:08:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:08:55 --> Final output sent to browser
DEBUG - 2020-09-25 14:08:55 --> Total execution time: 0.3564
INFO - 2020-09-25 14:09:10 --> Config Class Initialized
INFO - 2020-09-25 14:09:10 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:09:10 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:09:10 --> Utf8 Class Initialized
INFO - 2020-09-25 14:09:10 --> URI Class Initialized
DEBUG - 2020-09-25 14:09:10 --> No URI present. Default controller set.
INFO - 2020-09-25 14:09:10 --> Router Class Initialized
INFO - 2020-09-25 14:09:10 --> Output Class Initialized
INFO - 2020-09-25 14:09:10 --> Security Class Initialized
DEBUG - 2020-09-25 14:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:09:10 --> Input Class Initialized
INFO - 2020-09-25 14:09:10 --> Language Class Initialized
INFO - 2020-09-25 14:09:10 --> Loader Class Initialized
INFO - 2020-09-25 14:09:10 --> Helper loaded: url_helper
INFO - 2020-09-25 14:09:10 --> Helper loaded: file_helper
INFO - 2020-09-25 14:09:10 --> Database Driver Class Initialized
INFO - 2020-09-25 14:09:10 --> Email Class Initialized
DEBUG - 2020-09-25 14:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:09:10 --> Controller Class Initialized
INFO - 2020-09-25 14:09:10 --> Model "Main_model" initialized
INFO - 2020-09-25 14:09:11 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:09:11 --> Final output sent to browser
DEBUG - 2020-09-25 14:09:11 --> Total execution time: 0.3591
INFO - 2020-09-25 14:16:19 --> Config Class Initialized
INFO - 2020-09-25 14:16:19 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:16:19 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:16:19 --> Utf8 Class Initialized
INFO - 2020-09-25 14:16:19 --> URI Class Initialized
DEBUG - 2020-09-25 14:16:19 --> No URI present. Default controller set.
INFO - 2020-09-25 14:16:19 --> Router Class Initialized
INFO - 2020-09-25 14:16:19 --> Output Class Initialized
INFO - 2020-09-25 14:16:19 --> Security Class Initialized
DEBUG - 2020-09-25 14:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:16:19 --> Input Class Initialized
INFO - 2020-09-25 14:16:19 --> Language Class Initialized
INFO - 2020-09-25 14:16:19 --> Loader Class Initialized
INFO - 2020-09-25 14:16:19 --> Helper loaded: url_helper
INFO - 2020-09-25 14:16:19 --> Helper loaded: file_helper
INFO - 2020-09-25 14:16:19 --> Database Driver Class Initialized
INFO - 2020-09-25 14:16:19 --> Email Class Initialized
DEBUG - 2020-09-25 14:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:16:19 --> Controller Class Initialized
INFO - 2020-09-25 14:16:19 --> Model "Main_model" initialized
INFO - 2020-09-25 14:16:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:16:19 --> Final output sent to browser
DEBUG - 2020-09-25 14:16:19 --> Total execution time: 0.4183
INFO - 2020-09-25 14:18:58 --> Config Class Initialized
INFO - 2020-09-25 14:18:58 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:18:58 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:18:58 --> Utf8 Class Initialized
INFO - 2020-09-25 14:18:58 --> URI Class Initialized
DEBUG - 2020-09-25 14:18:58 --> No URI present. Default controller set.
INFO - 2020-09-25 14:18:58 --> Router Class Initialized
INFO - 2020-09-25 14:18:58 --> Output Class Initialized
INFO - 2020-09-25 14:18:58 --> Security Class Initialized
DEBUG - 2020-09-25 14:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:18:58 --> Input Class Initialized
INFO - 2020-09-25 14:18:58 --> Language Class Initialized
INFO - 2020-09-25 14:18:58 --> Loader Class Initialized
INFO - 2020-09-25 14:18:58 --> Helper loaded: url_helper
INFO - 2020-09-25 14:18:58 --> Helper loaded: file_helper
INFO - 2020-09-25 14:18:58 --> Database Driver Class Initialized
INFO - 2020-09-25 14:18:58 --> Email Class Initialized
DEBUG - 2020-09-25 14:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:18:58 --> Controller Class Initialized
INFO - 2020-09-25 14:18:58 --> Model "Main_model" initialized
INFO - 2020-09-25 14:18:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:18:58 --> Final output sent to browser
DEBUG - 2020-09-25 14:18:58 --> Total execution time: 0.4369
INFO - 2020-09-25 14:19:02 --> Config Class Initialized
INFO - 2020-09-25 14:19:02 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:19:02 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:19:02 --> Utf8 Class Initialized
INFO - 2020-09-25 14:19:02 --> URI Class Initialized
DEBUG - 2020-09-25 14:19:02 --> No URI present. Default controller set.
INFO - 2020-09-25 14:19:02 --> Router Class Initialized
INFO - 2020-09-25 14:19:02 --> Output Class Initialized
INFO - 2020-09-25 14:19:02 --> Security Class Initialized
DEBUG - 2020-09-25 14:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:19:02 --> Input Class Initialized
INFO - 2020-09-25 14:19:02 --> Language Class Initialized
INFO - 2020-09-25 14:19:02 --> Loader Class Initialized
INFO - 2020-09-25 14:19:02 --> Helper loaded: url_helper
INFO - 2020-09-25 14:19:02 --> Helper loaded: file_helper
INFO - 2020-09-25 14:19:02 --> Database Driver Class Initialized
INFO - 2020-09-25 14:19:02 --> Email Class Initialized
DEBUG - 2020-09-25 14:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:19:02 --> Controller Class Initialized
INFO - 2020-09-25 14:19:02 --> Model "Main_model" initialized
INFO - 2020-09-25 14:19:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:19:02 --> Final output sent to browser
DEBUG - 2020-09-25 14:19:02 --> Total execution time: 0.3846
INFO - 2020-09-25 14:19:04 --> Config Class Initialized
INFO - 2020-09-25 14:19:04 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:19:04 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:19:04 --> Utf8 Class Initialized
INFO - 2020-09-25 14:19:04 --> URI Class Initialized
DEBUG - 2020-09-25 14:19:04 --> No URI present. Default controller set.
INFO - 2020-09-25 14:19:04 --> Router Class Initialized
INFO - 2020-09-25 14:19:04 --> Output Class Initialized
INFO - 2020-09-25 14:19:04 --> Security Class Initialized
DEBUG - 2020-09-25 14:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:19:04 --> Input Class Initialized
INFO - 2020-09-25 14:19:04 --> Language Class Initialized
INFO - 2020-09-25 14:19:04 --> Loader Class Initialized
INFO - 2020-09-25 14:19:04 --> Helper loaded: url_helper
INFO - 2020-09-25 14:19:04 --> Helper loaded: file_helper
INFO - 2020-09-25 14:19:04 --> Database Driver Class Initialized
INFO - 2020-09-25 14:19:04 --> Email Class Initialized
DEBUG - 2020-09-25 14:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:19:04 --> Controller Class Initialized
INFO - 2020-09-25 14:19:04 --> Model "Main_model" initialized
INFO - 2020-09-25 14:19:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:19:04 --> Final output sent to browser
DEBUG - 2020-09-25 14:19:04 --> Total execution time: 0.3749
INFO - 2020-09-25 14:19:23 --> Config Class Initialized
INFO - 2020-09-25 14:19:23 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:19:23 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:19:23 --> Utf8 Class Initialized
INFO - 2020-09-25 14:19:23 --> URI Class Initialized
DEBUG - 2020-09-25 14:19:23 --> No URI present. Default controller set.
INFO - 2020-09-25 14:19:23 --> Router Class Initialized
INFO - 2020-09-25 14:19:23 --> Output Class Initialized
INFO - 2020-09-25 14:19:23 --> Security Class Initialized
DEBUG - 2020-09-25 14:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:19:23 --> Input Class Initialized
INFO - 2020-09-25 14:19:23 --> Language Class Initialized
INFO - 2020-09-25 14:19:23 --> Loader Class Initialized
INFO - 2020-09-25 14:19:23 --> Helper loaded: url_helper
INFO - 2020-09-25 14:19:23 --> Helper loaded: file_helper
INFO - 2020-09-25 14:19:23 --> Database Driver Class Initialized
INFO - 2020-09-25 14:19:23 --> Email Class Initialized
DEBUG - 2020-09-25 14:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:19:24 --> Controller Class Initialized
INFO - 2020-09-25 14:19:24 --> Model "Main_model" initialized
INFO - 2020-09-25 14:19:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:19:24 --> Final output sent to browser
DEBUG - 2020-09-25 14:19:24 --> Total execution time: 0.3962
INFO - 2020-09-25 14:21:28 --> Config Class Initialized
INFO - 2020-09-25 14:21:28 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:21:28 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:21:29 --> Utf8 Class Initialized
INFO - 2020-09-25 14:21:29 --> URI Class Initialized
DEBUG - 2020-09-25 14:21:29 --> No URI present. Default controller set.
INFO - 2020-09-25 14:21:29 --> Router Class Initialized
INFO - 2020-09-25 14:21:29 --> Output Class Initialized
INFO - 2020-09-25 14:21:29 --> Security Class Initialized
DEBUG - 2020-09-25 14:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:21:29 --> Input Class Initialized
INFO - 2020-09-25 14:21:29 --> Language Class Initialized
INFO - 2020-09-25 14:21:29 --> Loader Class Initialized
INFO - 2020-09-25 14:21:29 --> Helper loaded: url_helper
INFO - 2020-09-25 14:21:29 --> Helper loaded: file_helper
INFO - 2020-09-25 14:21:29 --> Database Driver Class Initialized
INFO - 2020-09-25 14:21:29 --> Email Class Initialized
DEBUG - 2020-09-25 14:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:21:29 --> Controller Class Initialized
INFO - 2020-09-25 14:21:29 --> Model "Main_model" initialized
INFO - 2020-09-25 14:21:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:21:29 --> Final output sent to browser
DEBUG - 2020-09-25 14:21:29 --> Total execution time: 0.3990
INFO - 2020-09-25 14:21:58 --> Config Class Initialized
INFO - 2020-09-25 14:21:58 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:21:58 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:21:58 --> Utf8 Class Initialized
INFO - 2020-09-25 14:21:58 --> URI Class Initialized
DEBUG - 2020-09-25 14:21:58 --> No URI present. Default controller set.
INFO - 2020-09-25 14:21:58 --> Router Class Initialized
INFO - 2020-09-25 14:21:58 --> Output Class Initialized
INFO - 2020-09-25 14:21:58 --> Security Class Initialized
DEBUG - 2020-09-25 14:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:21:58 --> Input Class Initialized
INFO - 2020-09-25 14:21:58 --> Language Class Initialized
INFO - 2020-09-25 14:21:58 --> Loader Class Initialized
INFO - 2020-09-25 14:21:58 --> Helper loaded: url_helper
INFO - 2020-09-25 14:21:58 --> Helper loaded: file_helper
INFO - 2020-09-25 14:21:58 --> Database Driver Class Initialized
INFO - 2020-09-25 14:21:58 --> Email Class Initialized
DEBUG - 2020-09-25 14:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:21:58 --> Controller Class Initialized
INFO - 2020-09-25 14:21:58 --> Model "Main_model" initialized
INFO - 2020-09-25 14:21:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:21:58 --> Final output sent to browser
DEBUG - 2020-09-25 14:21:58 --> Total execution time: 0.3335
INFO - 2020-09-25 14:26:51 --> Config Class Initialized
INFO - 2020-09-25 14:26:51 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:26:51 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:26:51 --> Utf8 Class Initialized
INFO - 2020-09-25 14:26:51 --> URI Class Initialized
DEBUG - 2020-09-25 14:26:51 --> No URI present. Default controller set.
INFO - 2020-09-25 14:26:51 --> Router Class Initialized
INFO - 2020-09-25 14:26:51 --> Output Class Initialized
INFO - 2020-09-25 14:26:51 --> Security Class Initialized
DEBUG - 2020-09-25 14:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:26:51 --> Input Class Initialized
INFO - 2020-09-25 14:26:51 --> Language Class Initialized
INFO - 2020-09-25 14:26:51 --> Loader Class Initialized
INFO - 2020-09-25 14:26:51 --> Helper loaded: url_helper
INFO - 2020-09-25 14:26:51 --> Helper loaded: file_helper
INFO - 2020-09-25 14:26:51 --> Database Driver Class Initialized
INFO - 2020-09-25 14:26:51 --> Email Class Initialized
DEBUG - 2020-09-25 14:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:26:51 --> Controller Class Initialized
INFO - 2020-09-25 14:26:51 --> Model "Main_model" initialized
INFO - 2020-09-25 14:26:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:26:51 --> Final output sent to browser
DEBUG - 2020-09-25 14:26:51 --> Total execution time: 0.3670
INFO - 2020-09-25 14:27:18 --> Config Class Initialized
INFO - 2020-09-25 14:27:18 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:27:18 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:27:18 --> Utf8 Class Initialized
INFO - 2020-09-25 14:27:18 --> URI Class Initialized
DEBUG - 2020-09-25 14:27:18 --> No URI present. Default controller set.
INFO - 2020-09-25 14:27:18 --> Router Class Initialized
INFO - 2020-09-25 14:27:18 --> Output Class Initialized
INFO - 2020-09-25 14:27:18 --> Security Class Initialized
DEBUG - 2020-09-25 14:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:27:18 --> Input Class Initialized
INFO - 2020-09-25 14:27:18 --> Language Class Initialized
INFO - 2020-09-25 14:27:18 --> Loader Class Initialized
INFO - 2020-09-25 14:27:18 --> Helper loaded: url_helper
INFO - 2020-09-25 14:27:18 --> Helper loaded: file_helper
INFO - 2020-09-25 14:27:18 --> Database Driver Class Initialized
INFO - 2020-09-25 14:27:18 --> Email Class Initialized
DEBUG - 2020-09-25 14:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:27:18 --> Controller Class Initialized
INFO - 2020-09-25 14:27:18 --> Model "Main_model" initialized
INFO - 2020-09-25 14:27:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:27:18 --> Final output sent to browser
DEBUG - 2020-09-25 14:27:18 --> Total execution time: 0.3653
INFO - 2020-09-25 14:27:21 --> Config Class Initialized
INFO - 2020-09-25 14:27:21 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:27:21 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:27:21 --> Utf8 Class Initialized
INFO - 2020-09-25 14:27:21 --> URI Class Initialized
DEBUG - 2020-09-25 14:27:21 --> No URI present. Default controller set.
INFO - 2020-09-25 14:27:21 --> Router Class Initialized
INFO - 2020-09-25 14:27:21 --> Output Class Initialized
INFO - 2020-09-25 14:27:21 --> Security Class Initialized
DEBUG - 2020-09-25 14:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:27:21 --> Input Class Initialized
INFO - 2020-09-25 14:27:21 --> Language Class Initialized
INFO - 2020-09-25 14:27:21 --> Loader Class Initialized
INFO - 2020-09-25 14:27:21 --> Helper loaded: url_helper
INFO - 2020-09-25 14:27:21 --> Helper loaded: file_helper
INFO - 2020-09-25 14:27:21 --> Database Driver Class Initialized
INFO - 2020-09-25 14:27:21 --> Email Class Initialized
DEBUG - 2020-09-25 14:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:27:21 --> Controller Class Initialized
INFO - 2020-09-25 14:27:21 --> Model "Main_model" initialized
INFO - 2020-09-25 14:27:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:27:21 --> Final output sent to browser
DEBUG - 2020-09-25 14:27:21 --> Total execution time: 0.3543
INFO - 2020-09-25 14:27:22 --> Config Class Initialized
INFO - 2020-09-25 14:27:22 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:27:22 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:27:22 --> Utf8 Class Initialized
INFO - 2020-09-25 14:27:22 --> URI Class Initialized
DEBUG - 2020-09-25 14:27:22 --> No URI present. Default controller set.
INFO - 2020-09-25 14:27:22 --> Router Class Initialized
INFO - 2020-09-25 14:27:22 --> Output Class Initialized
INFO - 2020-09-25 14:27:22 --> Security Class Initialized
DEBUG - 2020-09-25 14:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:27:22 --> Input Class Initialized
INFO - 2020-09-25 14:27:22 --> Language Class Initialized
INFO - 2020-09-25 14:27:22 --> Loader Class Initialized
INFO - 2020-09-25 14:27:22 --> Helper loaded: url_helper
INFO - 2020-09-25 14:27:22 --> Helper loaded: file_helper
INFO - 2020-09-25 14:27:22 --> Database Driver Class Initialized
INFO - 2020-09-25 14:27:22 --> Email Class Initialized
DEBUG - 2020-09-25 14:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:27:22 --> Controller Class Initialized
INFO - 2020-09-25 14:27:22 --> Model "Main_model" initialized
INFO - 2020-09-25 14:27:22 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:27:22 --> Final output sent to browser
DEBUG - 2020-09-25 14:27:22 --> Total execution time: 0.3882
INFO - 2020-09-25 14:27:35 --> Config Class Initialized
INFO - 2020-09-25 14:27:35 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:27:35 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:27:35 --> Utf8 Class Initialized
INFO - 2020-09-25 14:27:35 --> URI Class Initialized
DEBUG - 2020-09-25 14:27:35 --> No URI present. Default controller set.
INFO - 2020-09-25 14:27:35 --> Router Class Initialized
INFO - 2020-09-25 14:27:35 --> Output Class Initialized
INFO - 2020-09-25 14:27:35 --> Security Class Initialized
DEBUG - 2020-09-25 14:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:27:35 --> Input Class Initialized
INFO - 2020-09-25 14:27:35 --> Language Class Initialized
INFO - 2020-09-25 14:27:35 --> Loader Class Initialized
INFO - 2020-09-25 14:27:35 --> Helper loaded: url_helper
INFO - 2020-09-25 14:27:35 --> Helper loaded: file_helper
INFO - 2020-09-25 14:27:35 --> Database Driver Class Initialized
INFO - 2020-09-25 14:27:35 --> Email Class Initialized
DEBUG - 2020-09-25 14:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:27:35 --> Controller Class Initialized
INFO - 2020-09-25 14:27:35 --> Model "Main_model" initialized
INFO - 2020-09-25 14:27:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:27:35 --> Final output sent to browser
DEBUG - 2020-09-25 14:27:35 --> Total execution time: 0.4060
INFO - 2020-09-25 14:38:41 --> Config Class Initialized
INFO - 2020-09-25 14:38:41 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:38:41 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:38:41 --> Utf8 Class Initialized
INFO - 2020-09-25 14:38:41 --> URI Class Initialized
DEBUG - 2020-09-25 14:38:41 --> No URI present. Default controller set.
INFO - 2020-09-25 14:38:41 --> Router Class Initialized
INFO - 2020-09-25 14:38:41 --> Output Class Initialized
INFO - 2020-09-25 14:38:41 --> Security Class Initialized
DEBUG - 2020-09-25 14:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:38:41 --> Input Class Initialized
INFO - 2020-09-25 14:38:42 --> Language Class Initialized
INFO - 2020-09-25 14:38:42 --> Loader Class Initialized
INFO - 2020-09-25 14:38:42 --> Helper loaded: url_helper
INFO - 2020-09-25 14:38:42 --> Helper loaded: file_helper
INFO - 2020-09-25 14:38:42 --> Database Driver Class Initialized
INFO - 2020-09-25 14:38:42 --> Email Class Initialized
DEBUG - 2020-09-25 14:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:38:42 --> Controller Class Initialized
INFO - 2020-09-25 14:38:42 --> Model "Main_model" initialized
INFO - 2020-09-25 14:38:42 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:38:42 --> Final output sent to browser
DEBUG - 2020-09-25 14:38:42 --> Total execution time: 0.3834
INFO - 2020-09-25 14:41:48 --> Config Class Initialized
INFO - 2020-09-25 14:41:48 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:41:48 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:41:48 --> Utf8 Class Initialized
INFO - 2020-09-25 14:41:48 --> URI Class Initialized
DEBUG - 2020-09-25 14:41:48 --> No URI present. Default controller set.
INFO - 2020-09-25 14:41:48 --> Router Class Initialized
INFO - 2020-09-25 14:41:48 --> Output Class Initialized
INFO - 2020-09-25 14:41:48 --> Security Class Initialized
DEBUG - 2020-09-25 14:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:41:48 --> Input Class Initialized
INFO - 2020-09-25 14:41:48 --> Language Class Initialized
INFO - 2020-09-25 14:41:48 --> Loader Class Initialized
INFO - 2020-09-25 14:41:48 --> Helper loaded: url_helper
INFO - 2020-09-25 14:41:48 --> Helper loaded: file_helper
INFO - 2020-09-25 14:41:49 --> Database Driver Class Initialized
INFO - 2020-09-25 14:41:49 --> Email Class Initialized
DEBUG - 2020-09-25 14:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:41:49 --> Controller Class Initialized
INFO - 2020-09-25 14:41:49 --> Model "Main_model" initialized
INFO - 2020-09-25 14:41:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:41:49 --> Final output sent to browser
DEBUG - 2020-09-25 14:41:49 --> Total execution time: 0.4306
INFO - 2020-09-25 14:41:51 --> Config Class Initialized
INFO - 2020-09-25 14:41:51 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:41:51 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:41:51 --> Utf8 Class Initialized
INFO - 2020-09-25 14:41:51 --> URI Class Initialized
DEBUG - 2020-09-25 14:41:51 --> No URI present. Default controller set.
INFO - 2020-09-25 14:41:51 --> Router Class Initialized
INFO - 2020-09-25 14:41:51 --> Output Class Initialized
INFO - 2020-09-25 14:41:51 --> Security Class Initialized
DEBUG - 2020-09-25 14:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:41:51 --> Input Class Initialized
INFO - 2020-09-25 14:41:51 --> Language Class Initialized
INFO - 2020-09-25 14:41:51 --> Loader Class Initialized
INFO - 2020-09-25 14:41:51 --> Helper loaded: url_helper
INFO - 2020-09-25 14:41:51 --> Helper loaded: file_helper
INFO - 2020-09-25 14:41:51 --> Database Driver Class Initialized
INFO - 2020-09-25 14:41:51 --> Email Class Initialized
DEBUG - 2020-09-25 14:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:41:51 --> Controller Class Initialized
INFO - 2020-09-25 14:41:51 --> Model "Main_model" initialized
INFO - 2020-09-25 14:41:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:41:52 --> Final output sent to browser
DEBUG - 2020-09-25 14:41:52 --> Total execution time: 0.3666
INFO - 2020-09-25 14:41:52 --> Config Class Initialized
INFO - 2020-09-25 14:41:52 --> Hooks Class Initialized
DEBUG - 2020-09-25 14:41:52 --> UTF-8 Support Enabled
INFO - 2020-09-25 14:41:52 --> Utf8 Class Initialized
INFO - 2020-09-25 14:41:52 --> URI Class Initialized
DEBUG - 2020-09-25 14:41:52 --> No URI present. Default controller set.
INFO - 2020-09-25 14:41:52 --> Router Class Initialized
INFO - 2020-09-25 14:41:52 --> Output Class Initialized
INFO - 2020-09-25 14:41:53 --> Security Class Initialized
DEBUG - 2020-09-25 14:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 14:41:53 --> Input Class Initialized
INFO - 2020-09-25 14:41:53 --> Language Class Initialized
INFO - 2020-09-25 14:41:53 --> Loader Class Initialized
INFO - 2020-09-25 14:41:53 --> Helper loaded: url_helper
INFO - 2020-09-25 14:41:53 --> Helper loaded: file_helper
INFO - 2020-09-25 14:41:53 --> Database Driver Class Initialized
INFO - 2020-09-25 14:41:53 --> Email Class Initialized
DEBUG - 2020-09-25 14:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 14:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 14:41:53 --> Controller Class Initialized
INFO - 2020-09-25 14:41:53 --> Model "Main_model" initialized
INFO - 2020-09-25 14:41:53 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 14:41:53 --> Final output sent to browser
DEBUG - 2020-09-25 14:41:53 --> Total execution time: 0.3870
INFO - 2020-09-25 15:43:42 --> Config Class Initialized
INFO - 2020-09-25 15:43:42 --> Hooks Class Initialized
DEBUG - 2020-09-25 15:43:42 --> UTF-8 Support Enabled
INFO - 2020-09-25 15:43:42 --> Utf8 Class Initialized
INFO - 2020-09-25 15:43:42 --> URI Class Initialized
DEBUG - 2020-09-25 15:43:42 --> No URI present. Default controller set.
INFO - 2020-09-25 15:43:42 --> Router Class Initialized
INFO - 2020-09-25 15:43:42 --> Output Class Initialized
INFO - 2020-09-25 15:43:42 --> Security Class Initialized
DEBUG - 2020-09-25 15:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 15:43:42 --> Input Class Initialized
INFO - 2020-09-25 15:43:42 --> Language Class Initialized
INFO - 2020-09-25 15:43:42 --> Loader Class Initialized
INFO - 2020-09-25 15:43:42 --> Helper loaded: url_helper
INFO - 2020-09-25 15:43:42 --> Helper loaded: file_helper
INFO - 2020-09-25 15:43:42 --> Database Driver Class Initialized
INFO - 2020-09-25 15:43:43 --> Email Class Initialized
DEBUG - 2020-09-25 15:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 15:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 15:43:43 --> Controller Class Initialized
INFO - 2020-09-25 15:43:43 --> Model "Main_model" initialized
INFO - 2020-09-25 15:43:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 15:43:43 --> Final output sent to browser
DEBUG - 2020-09-25 15:43:43 --> Total execution time: 0.4244
INFO - 2020-09-25 15:43:47 --> Config Class Initialized
INFO - 2020-09-25 15:43:47 --> Hooks Class Initialized
DEBUG - 2020-09-25 15:43:47 --> UTF-8 Support Enabled
INFO - 2020-09-25 15:43:47 --> Utf8 Class Initialized
INFO - 2020-09-25 15:43:47 --> URI Class Initialized
INFO - 2020-09-25 15:43:47 --> Router Class Initialized
INFO - 2020-09-25 15:43:47 --> Output Class Initialized
INFO - 2020-09-25 15:43:47 --> Security Class Initialized
DEBUG - 2020-09-25 15:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 15:43:47 --> Input Class Initialized
INFO - 2020-09-25 15:43:47 --> Language Class Initialized
INFO - 2020-09-25 15:43:47 --> Loader Class Initialized
INFO - 2020-09-25 15:43:47 --> Helper loaded: url_helper
INFO - 2020-09-25 15:43:47 --> Helper loaded: file_helper
INFO - 2020-09-25 15:43:47 --> Database Driver Class Initialized
INFO - 2020-09-25 15:43:47 --> Email Class Initialized
DEBUG - 2020-09-25 15:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 15:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 15:43:47 --> Controller Class Initialized
INFO - 2020-09-25 15:43:47 --> Model "Main_model" initialized
INFO - 2020-09-25 15:43:47 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-09-25 15:43:47 --> Final output sent to browser
DEBUG - 2020-09-25 15:43:47 --> Total execution time: 0.3962
INFO - 2020-09-25 18:04:49 --> Config Class Initialized
INFO - 2020-09-25 18:04:49 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:04:49 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:04:49 --> Utf8 Class Initialized
INFO - 2020-09-25 18:04:49 --> URI Class Initialized
INFO - 2020-09-25 18:04:49 --> Router Class Initialized
INFO - 2020-09-25 18:04:49 --> Output Class Initialized
INFO - 2020-09-25 18:04:49 --> Security Class Initialized
DEBUG - 2020-09-25 18:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:04:49 --> Input Class Initialized
INFO - 2020-09-25 18:04:49 --> Language Class Initialized
INFO - 2020-09-25 18:04:49 --> Loader Class Initialized
INFO - 2020-09-25 18:04:49 --> Helper loaded: url_helper
INFO - 2020-09-25 18:04:49 --> Helper loaded: file_helper
INFO - 2020-09-25 18:04:49 --> Database Driver Class Initialized
INFO - 2020-09-25 18:04:49 --> Email Class Initialized
DEBUG - 2020-09-25 18:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:04:50 --> Controller Class Initialized
INFO - 2020-09-25 18:04:50 --> Helper loaded: form_helper
INFO - 2020-09-25 18:04:50 --> Helper loaded: security_helper
INFO - 2020-09-25 18:04:58 --> Config Class Initialized
INFO - 2020-09-25 18:04:58 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:04:58 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:04:58 --> Utf8 Class Initialized
INFO - 2020-09-25 18:04:58 --> URI Class Initialized
INFO - 2020-09-25 18:04:58 --> Router Class Initialized
INFO - 2020-09-25 18:04:58 --> Output Class Initialized
INFO - 2020-09-25 18:04:58 --> Security Class Initialized
DEBUG - 2020-09-25 18:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:04:58 --> Input Class Initialized
INFO - 2020-09-25 18:04:58 --> Language Class Initialized
INFO - 2020-09-25 18:04:58 --> Loader Class Initialized
INFO - 2020-09-25 18:04:58 --> Helper loaded: url_helper
INFO - 2020-09-25 18:04:58 --> Helper loaded: file_helper
INFO - 2020-09-25 18:04:58 --> Database Driver Class Initialized
INFO - 2020-09-25 18:04:58 --> Email Class Initialized
DEBUG - 2020-09-25 18:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:04:58 --> Controller Class Initialized
INFO - 2020-09-25 18:04:58 --> Helper loaded: form_helper
INFO - 2020-09-25 18:04:58 --> Helper loaded: security_helper
INFO - 2020-09-25 18:05:44 --> Config Class Initialized
INFO - 2020-09-25 18:05:44 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:05:44 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:05:44 --> Utf8 Class Initialized
INFO - 2020-09-25 18:05:44 --> URI Class Initialized
INFO - 2020-09-25 18:05:44 --> Router Class Initialized
INFO - 2020-09-25 18:05:44 --> Output Class Initialized
INFO - 2020-09-25 18:05:44 --> Security Class Initialized
DEBUG - 2020-09-25 18:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:05:44 --> Input Class Initialized
INFO - 2020-09-25 18:05:44 --> Language Class Initialized
INFO - 2020-09-25 18:05:44 --> Loader Class Initialized
INFO - 2020-09-25 18:05:44 --> Helper loaded: url_helper
INFO - 2020-09-25 18:05:44 --> Helper loaded: file_helper
INFO - 2020-09-25 18:05:44 --> Database Driver Class Initialized
INFO - 2020-09-25 18:05:44 --> Email Class Initialized
DEBUG - 2020-09-25 18:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:05:44 --> Controller Class Initialized
INFO - 2020-09-25 18:05:44 --> Helper loaded: form_helper
INFO - 2020-09-25 18:05:44 --> Helper loaded: security_helper
INFO - 2020-09-25 18:05:44 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:05:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-25 18:05:44 --> Unable to load the requested class: Mpdf
INFO - 2020-09-25 18:06:08 --> Config Class Initialized
INFO - 2020-09-25 18:06:08 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:06:08 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:06:08 --> Utf8 Class Initialized
INFO - 2020-09-25 18:06:08 --> URI Class Initialized
INFO - 2020-09-25 18:06:08 --> Router Class Initialized
INFO - 2020-09-25 18:06:08 --> Output Class Initialized
INFO - 2020-09-25 18:06:08 --> Security Class Initialized
DEBUG - 2020-09-25 18:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:06:08 --> Input Class Initialized
INFO - 2020-09-25 18:06:08 --> Language Class Initialized
INFO - 2020-09-25 18:06:08 --> Loader Class Initialized
INFO - 2020-09-25 18:06:08 --> Helper loaded: url_helper
INFO - 2020-09-25 18:06:08 --> Helper loaded: file_helper
INFO - 2020-09-25 18:06:08 --> Database Driver Class Initialized
INFO - 2020-09-25 18:06:08 --> Email Class Initialized
DEBUG - 2020-09-25 18:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:06:08 --> Controller Class Initialized
INFO - 2020-09-25 18:06:08 --> Helper loaded: form_helper
INFO - 2020-09-25 18:06:08 --> Helper loaded: security_helper
INFO - 2020-09-25 18:06:08 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:06:08 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:06:08 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
ERROR - 2020-09-25 18:06:08 --> Severity: Warning --> file_get_contents(C:/xampp/htdocs/csr_file/uidai_auth_encrypt_preprod.cer): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\controllers\Test.php 100
ERROR - 2020-09-25 18:06:08 --> Severity: Warning --> fopen(C:/xampp/htdocs/csr_file/uidai_auth_encrypt_preprod.cer): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\controllers\Test.php 106
ERROR - 2020-09-25 18:06:08 --> Severity: Warning --> fread() expects parameter 1 to be resource, boolean given C:\xampp\htdocs\dmarc\application\controllers\Test.php 107
ERROR - 2020-09-25 18:06:08 --> Severity: Warning --> openssl_public_encrypt(): key parameter is not a valid public key C:\xampp\htdocs\dmarc\application\controllers\Test.php 109
INFO - 2020-09-25 18:06:14 --> Config Class Initialized
INFO - 2020-09-25 18:06:14 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:06:14 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:06:14 --> Utf8 Class Initialized
INFO - 2020-09-25 18:06:14 --> URI Class Initialized
INFO - 2020-09-25 18:06:14 --> Router Class Initialized
INFO - 2020-09-25 18:06:14 --> Output Class Initialized
INFO - 2020-09-25 18:06:14 --> Security Class Initialized
DEBUG - 2020-09-25 18:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:06:15 --> Input Class Initialized
INFO - 2020-09-25 18:06:15 --> Language Class Initialized
INFO - 2020-09-25 18:06:15 --> Loader Class Initialized
INFO - 2020-09-25 18:06:15 --> Helper loaded: url_helper
INFO - 2020-09-25 18:06:15 --> Helper loaded: file_helper
INFO - 2020-09-25 18:06:15 --> Database Driver Class Initialized
INFO - 2020-09-25 18:06:15 --> Email Class Initialized
DEBUG - 2020-09-25 18:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:06:15 --> Controller Class Initialized
INFO - 2020-09-25 18:06:15 --> Helper loaded: form_helper
INFO - 2020-09-25 18:06:15 --> Helper loaded: security_helper
INFO - 2020-09-25 18:06:15 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:06:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:06:15 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:06:15 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
ERROR - 2020-09-25 18:06:15 --> Severity: Warning --> file_get_contents(C:/xampp/htdocs/csr_file/uidai_auth_encrypt_preprod.cer): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\controllers\Test.php 100
ERROR - 2020-09-25 18:06:15 --> Severity: Warning --> fopen(C:/xampp/htdocs/csr_file/uidai_auth_encrypt_preprod.cer): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\controllers\Test.php 106
ERROR - 2020-09-25 18:06:15 --> Severity: Warning --> fread() expects parameter 1 to be resource, boolean given C:\xampp\htdocs\dmarc\application\controllers\Test.php 107
ERROR - 2020-09-25 18:06:15 --> Severity: Warning --> openssl_public_encrypt(): key parameter is not a valid public key C:\xampp\htdocs\dmarc\application\controllers\Test.php 109
INFO - 2020-09-25 18:06:43 --> Config Class Initialized
INFO - 2020-09-25 18:06:43 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:06:43 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:06:43 --> Utf8 Class Initialized
INFO - 2020-09-25 18:06:43 --> URI Class Initialized
INFO - 2020-09-25 18:06:43 --> Router Class Initialized
INFO - 2020-09-25 18:06:43 --> Output Class Initialized
INFO - 2020-09-25 18:06:43 --> Security Class Initialized
DEBUG - 2020-09-25 18:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:06:43 --> Input Class Initialized
INFO - 2020-09-25 18:06:43 --> Language Class Initialized
INFO - 2020-09-25 18:06:43 --> Loader Class Initialized
INFO - 2020-09-25 18:06:43 --> Helper loaded: url_helper
INFO - 2020-09-25 18:06:43 --> Helper loaded: file_helper
INFO - 2020-09-25 18:06:43 --> Database Driver Class Initialized
INFO - 2020-09-25 18:06:43 --> Email Class Initialized
DEBUG - 2020-09-25 18:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:06:43 --> Controller Class Initialized
INFO - 2020-09-25 18:06:43 --> Helper loaded: form_helper
INFO - 2020-09-25 18:06:43 --> Helper loaded: security_helper
INFO - 2020-09-25 18:06:43 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:06:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:06:43 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:06:43 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
ERROR - 2020-09-25 18:06:43 --> Severity: Warning --> Use of undefined constant UIDAI_PUBLIC_CERTIFICATE - assumed 'UIDAI_PUBLIC_CERTIFICATE' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\dmarc\application\controllers\Test.php 106
ERROR - 2020-09-25 18:06:43 --> Severity: Warning --> fopen(UIDAI_PUBLIC_CERTIFICATE): failed to open stream: No such file or directory C:\xampp\htdocs\dmarc\application\controllers\Test.php 106
ERROR - 2020-09-25 18:06:43 --> Severity: Warning --> fread() expects parameter 1 to be resource, boolean given C:\xampp\htdocs\dmarc\application\controllers\Test.php 107
ERROR - 2020-09-25 18:06:43 --> Severity: Warning --> openssl_public_encrypt(): key parameter is not a valid public key C:\xampp\htdocs\dmarc\application\controllers\Test.php 109
INFO - 2020-09-25 18:07:57 --> Config Class Initialized
INFO - 2020-09-25 18:07:57 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:07:57 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:07:57 --> Utf8 Class Initialized
INFO - 2020-09-25 18:07:57 --> URI Class Initialized
INFO - 2020-09-25 18:07:57 --> Router Class Initialized
INFO - 2020-09-25 18:07:57 --> Output Class Initialized
INFO - 2020-09-25 18:07:57 --> Security Class Initialized
DEBUG - 2020-09-25 18:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:07:57 --> Input Class Initialized
INFO - 2020-09-25 18:07:57 --> Language Class Initialized
INFO - 2020-09-25 18:07:57 --> Loader Class Initialized
INFO - 2020-09-25 18:07:57 --> Helper loaded: url_helper
INFO - 2020-09-25 18:07:57 --> Helper loaded: file_helper
INFO - 2020-09-25 18:07:57 --> Database Driver Class Initialized
INFO - 2020-09-25 18:07:57 --> Email Class Initialized
DEBUG - 2020-09-25 18:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:07:57 --> Controller Class Initialized
INFO - 2020-09-25 18:07:57 --> Helper loaded: form_helper
INFO - 2020-09-25 18:07:57 --> Helper loaded: security_helper
INFO - 2020-09-25 18:07:57 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:07:57 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:07:57 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
INFO - 2020-09-25 18:08:23 --> Config Class Initialized
INFO - 2020-09-25 18:08:23 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:08:23 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:08:23 --> Utf8 Class Initialized
INFO - 2020-09-25 18:08:23 --> URI Class Initialized
INFO - 2020-09-25 18:08:23 --> Router Class Initialized
INFO - 2020-09-25 18:08:23 --> Output Class Initialized
INFO - 2020-09-25 18:08:24 --> Security Class Initialized
DEBUG - 2020-09-25 18:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:08:24 --> Input Class Initialized
INFO - 2020-09-25 18:08:24 --> Language Class Initialized
INFO - 2020-09-25 18:08:24 --> Loader Class Initialized
INFO - 2020-09-25 18:08:24 --> Helper loaded: url_helper
INFO - 2020-09-25 18:08:24 --> Helper loaded: file_helper
INFO - 2020-09-25 18:08:24 --> Database Driver Class Initialized
INFO - 2020-09-25 18:08:24 --> Email Class Initialized
DEBUG - 2020-09-25 18:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:08:24 --> Controller Class Initialized
INFO - 2020-09-25 18:08:24 --> Helper loaded: form_helper
INFO - 2020-09-25 18:08:24 --> Helper loaded: security_helper
INFO - 2020-09-25 18:08:24 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:08:24 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:08:24 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
INFO - 2020-09-25 18:09:24 --> Config Class Initialized
INFO - 2020-09-25 18:09:24 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:09:24 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:09:24 --> Utf8 Class Initialized
INFO - 2020-09-25 18:09:24 --> URI Class Initialized
INFO - 2020-09-25 18:09:24 --> Router Class Initialized
INFO - 2020-09-25 18:09:24 --> Output Class Initialized
INFO - 2020-09-25 18:09:24 --> Security Class Initialized
DEBUG - 2020-09-25 18:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:09:24 --> Input Class Initialized
INFO - 2020-09-25 18:09:24 --> Language Class Initialized
INFO - 2020-09-25 18:09:24 --> Loader Class Initialized
INFO - 2020-09-25 18:09:24 --> Helper loaded: url_helper
INFO - 2020-09-25 18:09:24 --> Helper loaded: file_helper
INFO - 2020-09-25 18:09:24 --> Database Driver Class Initialized
INFO - 2020-09-25 18:09:24 --> Email Class Initialized
DEBUG - 2020-09-25 18:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:09:24 --> Controller Class Initialized
INFO - 2020-09-25 18:09:24 --> Helper loaded: form_helper
INFO - 2020-09-25 18:09:24 --> Helper loaded: security_helper
INFO - 2020-09-25 18:09:24 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:09:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:09:24 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:09:24 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
INFO - 2020-09-25 18:09:28 --> Config Class Initialized
INFO - 2020-09-25 18:09:28 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:09:28 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:09:28 --> Utf8 Class Initialized
INFO - 2020-09-25 18:09:28 --> URI Class Initialized
INFO - 2020-09-25 18:09:28 --> Router Class Initialized
INFO - 2020-09-25 18:09:28 --> Output Class Initialized
INFO - 2020-09-25 18:09:28 --> Security Class Initialized
DEBUG - 2020-09-25 18:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:09:28 --> Input Class Initialized
INFO - 2020-09-25 18:09:28 --> Language Class Initialized
INFO - 2020-09-25 18:09:28 --> Loader Class Initialized
INFO - 2020-09-25 18:09:28 --> Helper loaded: url_helper
INFO - 2020-09-25 18:09:28 --> Helper loaded: file_helper
INFO - 2020-09-25 18:09:28 --> Database Driver Class Initialized
INFO - 2020-09-25 18:09:28 --> Email Class Initialized
DEBUG - 2020-09-25 18:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:09:28 --> Controller Class Initialized
INFO - 2020-09-25 18:09:28 --> Helper loaded: form_helper
INFO - 2020-09-25 18:09:28 --> Helper loaded: security_helper
INFO - 2020-09-25 18:09:28 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:09:28 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:09:28 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
INFO - 2020-09-25 18:09:41 --> Config Class Initialized
INFO - 2020-09-25 18:09:42 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:09:42 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:09:42 --> Utf8 Class Initialized
INFO - 2020-09-25 18:09:42 --> URI Class Initialized
INFO - 2020-09-25 18:09:42 --> Router Class Initialized
INFO - 2020-09-25 18:09:42 --> Output Class Initialized
INFO - 2020-09-25 18:09:42 --> Security Class Initialized
DEBUG - 2020-09-25 18:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:09:42 --> Input Class Initialized
INFO - 2020-09-25 18:09:42 --> Language Class Initialized
INFO - 2020-09-25 18:09:42 --> Loader Class Initialized
INFO - 2020-09-25 18:09:42 --> Helper loaded: url_helper
INFO - 2020-09-25 18:09:42 --> Helper loaded: file_helper
INFO - 2020-09-25 18:09:42 --> Database Driver Class Initialized
INFO - 2020-09-25 18:09:42 --> Email Class Initialized
DEBUG - 2020-09-25 18:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:09:42 --> Controller Class Initialized
INFO - 2020-09-25 18:09:42 --> Helper loaded: form_helper
INFO - 2020-09-25 18:09:42 --> Helper loaded: security_helper
INFO - 2020-09-25 18:09:42 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:09:42 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:09:42 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
INFO - 2020-09-25 18:10:38 --> Config Class Initialized
INFO - 2020-09-25 18:10:38 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:10:38 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:10:38 --> Utf8 Class Initialized
INFO - 2020-09-25 18:10:38 --> URI Class Initialized
INFO - 2020-09-25 18:10:38 --> Router Class Initialized
INFO - 2020-09-25 18:10:38 --> Output Class Initialized
INFO - 2020-09-25 18:10:38 --> Security Class Initialized
DEBUG - 2020-09-25 18:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:10:38 --> Input Class Initialized
INFO - 2020-09-25 18:10:38 --> Language Class Initialized
INFO - 2020-09-25 18:10:38 --> Loader Class Initialized
INFO - 2020-09-25 18:10:38 --> Helper loaded: url_helper
INFO - 2020-09-25 18:10:38 --> Helper loaded: file_helper
INFO - 2020-09-25 18:10:38 --> Database Driver Class Initialized
INFO - 2020-09-25 18:10:38 --> Email Class Initialized
DEBUG - 2020-09-25 18:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:10:39 --> Controller Class Initialized
INFO - 2020-09-25 18:10:39 --> Helper loaded: form_helper
INFO - 2020-09-25 18:10:39 --> Helper loaded: security_helper
INFO - 2020-09-25 18:10:39 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:10:39 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:10:39 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
INFO - 2020-09-25 18:11:01 --> Config Class Initialized
INFO - 2020-09-25 18:11:01 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:11:01 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:11:01 --> Utf8 Class Initialized
INFO - 2020-09-25 18:11:01 --> URI Class Initialized
INFO - 2020-09-25 18:11:01 --> Router Class Initialized
INFO - 2020-09-25 18:11:01 --> Output Class Initialized
INFO - 2020-09-25 18:11:01 --> Security Class Initialized
DEBUG - 2020-09-25 18:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:11:02 --> Input Class Initialized
INFO - 2020-09-25 18:11:02 --> Language Class Initialized
INFO - 2020-09-25 18:11:02 --> Loader Class Initialized
INFO - 2020-09-25 18:11:02 --> Helper loaded: url_helper
INFO - 2020-09-25 18:11:02 --> Helper loaded: file_helper
INFO - 2020-09-25 18:11:02 --> Database Driver Class Initialized
INFO - 2020-09-25 18:11:02 --> Email Class Initialized
DEBUG - 2020-09-25 18:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:11:02 --> Controller Class Initialized
INFO - 2020-09-25 18:11:02 --> Helper loaded: form_helper
INFO - 2020-09-25 18:11:02 --> Helper loaded: security_helper
INFO - 2020-09-25 18:11:02 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:11:02 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:11:02 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
INFO - 2020-09-25 18:11:23 --> Config Class Initialized
INFO - 2020-09-25 18:11:23 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:11:23 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:11:23 --> Utf8 Class Initialized
INFO - 2020-09-25 18:11:23 --> URI Class Initialized
INFO - 2020-09-25 18:11:23 --> Router Class Initialized
INFO - 2020-09-25 18:11:23 --> Output Class Initialized
INFO - 2020-09-25 18:11:23 --> Security Class Initialized
DEBUG - 2020-09-25 18:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:11:23 --> Input Class Initialized
INFO - 2020-09-25 18:11:23 --> Language Class Initialized
INFO - 2020-09-25 18:11:23 --> Loader Class Initialized
INFO - 2020-09-25 18:11:23 --> Helper loaded: url_helper
INFO - 2020-09-25 18:11:23 --> Helper loaded: file_helper
INFO - 2020-09-25 18:11:23 --> Database Driver Class Initialized
INFO - 2020-09-25 18:11:23 --> Email Class Initialized
DEBUG - 2020-09-25 18:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:11:23 --> Controller Class Initialized
INFO - 2020-09-25 18:11:23 --> Helper loaded: form_helper
INFO - 2020-09-25 18:11:23 --> Helper loaded: security_helper
INFO - 2020-09-25 18:11:23 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:11:23 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:11:23 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
INFO - 2020-09-25 18:12:24 --> Config Class Initialized
INFO - 2020-09-25 18:12:24 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:12:24 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:12:24 --> Utf8 Class Initialized
INFO - 2020-09-25 18:12:24 --> URI Class Initialized
INFO - 2020-09-25 18:12:24 --> Router Class Initialized
INFO - 2020-09-25 18:12:24 --> Output Class Initialized
INFO - 2020-09-25 18:12:24 --> Security Class Initialized
DEBUG - 2020-09-25 18:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:12:24 --> Input Class Initialized
INFO - 2020-09-25 18:12:24 --> Language Class Initialized
INFO - 2020-09-25 18:12:24 --> Loader Class Initialized
INFO - 2020-09-25 18:12:24 --> Helper loaded: url_helper
INFO - 2020-09-25 18:12:24 --> Helper loaded: file_helper
INFO - 2020-09-25 18:12:24 --> Database Driver Class Initialized
INFO - 2020-09-25 18:12:24 --> Email Class Initialized
DEBUG - 2020-09-25 18:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:12:24 --> Controller Class Initialized
INFO - 2020-09-25 18:12:24 --> Helper loaded: form_helper
INFO - 2020-09-25 18:12:24 --> Helper loaded: security_helper
INFO - 2020-09-25 18:12:24 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:12:24 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:12:24 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
INFO - 2020-09-25 18:12:49 --> Config Class Initialized
INFO - 2020-09-25 18:12:49 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:12:49 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:12:49 --> Utf8 Class Initialized
INFO - 2020-09-25 18:12:49 --> URI Class Initialized
INFO - 2020-09-25 18:12:49 --> Router Class Initialized
INFO - 2020-09-25 18:12:49 --> Output Class Initialized
INFO - 2020-09-25 18:12:49 --> Security Class Initialized
DEBUG - 2020-09-25 18:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:12:49 --> Input Class Initialized
INFO - 2020-09-25 18:12:49 --> Language Class Initialized
INFO - 2020-09-25 18:12:49 --> Loader Class Initialized
INFO - 2020-09-25 18:12:49 --> Helper loaded: url_helper
INFO - 2020-09-25 18:12:49 --> Helper loaded: file_helper
INFO - 2020-09-25 18:12:49 --> Database Driver Class Initialized
INFO - 2020-09-25 18:12:49 --> Email Class Initialized
DEBUG - 2020-09-25 18:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:12:49 --> Controller Class Initialized
INFO - 2020-09-25 18:12:49 --> Helper loaded: form_helper
INFO - 2020-09-25 18:12:49 --> Helper loaded: security_helper
INFO - 2020-09-25 18:12:49 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:12:49 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:12:49 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
INFO - 2020-09-25 18:13:00 --> Config Class Initialized
INFO - 2020-09-25 18:13:00 --> Hooks Class Initialized
DEBUG - 2020-09-25 18:13:00 --> UTF-8 Support Enabled
INFO - 2020-09-25 18:13:00 --> Utf8 Class Initialized
INFO - 2020-09-25 18:13:00 --> URI Class Initialized
INFO - 2020-09-25 18:13:00 --> Router Class Initialized
INFO - 2020-09-25 18:13:00 --> Output Class Initialized
INFO - 2020-09-25 18:13:00 --> Security Class Initialized
DEBUG - 2020-09-25 18:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 18:13:00 --> Input Class Initialized
INFO - 2020-09-25 18:13:00 --> Language Class Initialized
INFO - 2020-09-25 18:13:00 --> Loader Class Initialized
INFO - 2020-09-25 18:13:00 --> Helper loaded: url_helper
INFO - 2020-09-25 18:13:00 --> Helper loaded: file_helper
INFO - 2020-09-25 18:13:00 --> Database Driver Class Initialized
INFO - 2020-09-25 18:13:00 --> Email Class Initialized
DEBUG - 2020-09-25 18:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 18:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 18:13:00 --> Controller Class Initialized
INFO - 2020-09-25 18:13:00 --> Helper loaded: form_helper
INFO - 2020-09-25 18:13:00 --> Helper loaded: security_helper
INFO - 2020-09-25 18:13:00 --> Form Validation Class Initialized
DEBUG - 2020-09-25 18:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-25 18:13:00 --> User Agent Class Initialized
DEBUG - 2020-09-25 18:13:00 --> Config file loaded: C:\xampp\htdocs\dmarc\application\config/config.php
INFO - 2020-09-25 19:21:26 --> Config Class Initialized
INFO - 2020-09-25 19:21:26 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:21:26 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:21:26 --> Utf8 Class Initialized
INFO - 2020-09-25 19:21:26 --> URI Class Initialized
INFO - 2020-09-25 19:21:26 --> Router Class Initialized
INFO - 2020-09-25 19:21:26 --> Output Class Initialized
INFO - 2020-09-25 19:21:26 --> Security Class Initialized
DEBUG - 2020-09-25 19:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:21:26 --> Input Class Initialized
INFO - 2020-09-25 19:21:26 --> Language Class Initialized
ERROR - 2020-09-25 19:21:26 --> Severity: error --> Exception: syntax error, unexpected 'pubic' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\dmarc\application\controllers\Home.php 14
INFO - 2020-09-25 19:21:44 --> Config Class Initialized
INFO - 2020-09-25 19:21:44 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:21:44 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:21:44 --> Utf8 Class Initialized
INFO - 2020-09-25 19:21:44 --> URI Class Initialized
INFO - 2020-09-25 19:21:44 --> Router Class Initialized
INFO - 2020-09-25 19:21:44 --> Output Class Initialized
INFO - 2020-09-25 19:21:44 --> Security Class Initialized
DEBUG - 2020-09-25 19:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:21:44 --> Input Class Initialized
INFO - 2020-09-25 19:21:44 --> Language Class Initialized
INFO - 2020-09-25 19:21:44 --> Loader Class Initialized
INFO - 2020-09-25 19:21:44 --> Helper loaded: url_helper
INFO - 2020-09-25 19:21:44 --> Helper loaded: file_helper
INFO - 2020-09-25 19:21:44 --> Database Driver Class Initialized
INFO - 2020-09-25 19:21:44 --> Email Class Initialized
DEBUG - 2020-09-25 19:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:21:44 --> Controller Class Initialized
INFO - 2020-09-25 19:21:44 --> Model "Main_model" initialized
INFO - 2020-09-25 19:21:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-09-25 19:21:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-09-25 19:21:44 --> Final output sent to browser
DEBUG - 2020-09-25 19:21:44 --> Total execution time: 0.3611
INFO - 2020-09-25 19:21:59 --> Config Class Initialized
INFO - 2020-09-25 19:21:59 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:21:59 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:21:59 --> Utf8 Class Initialized
INFO - 2020-09-25 19:21:59 --> URI Class Initialized
INFO - 2020-09-25 19:21:59 --> Router Class Initialized
INFO - 2020-09-25 19:21:59 --> Output Class Initialized
INFO - 2020-09-25 19:21:59 --> Security Class Initialized
DEBUG - 2020-09-25 19:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:21:59 --> Input Class Initialized
INFO - 2020-09-25 19:21:59 --> Language Class Initialized
INFO - 2020-09-25 19:21:59 --> Loader Class Initialized
INFO - 2020-09-25 19:21:59 --> Helper loaded: url_helper
INFO - 2020-09-25 19:21:59 --> Helper loaded: file_helper
INFO - 2020-09-25 19:21:59 --> Database Driver Class Initialized
INFO - 2020-09-25 19:21:59 --> Email Class Initialized
DEBUG - 2020-09-25 19:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:21:59 --> Controller Class Initialized
INFO - 2020-09-25 19:21:59 --> Model "Main_model" initialized
INFO - 2020-09-25 19:21:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-25 19:21:59 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\dmarc\application\views\adddomain.php 146
INFO - 2020-09-25 19:21:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 19:21:59 --> Final output sent to browser
DEBUG - 2020-09-25 19:21:59 --> Total execution time: 0.4017
INFO - 2020-09-25 19:22:32 --> Config Class Initialized
INFO - 2020-09-25 19:22:32 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:22:32 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:22:32 --> Utf8 Class Initialized
INFO - 2020-09-25 19:22:32 --> URI Class Initialized
INFO - 2020-09-25 19:22:32 --> Router Class Initialized
INFO - 2020-09-25 19:22:32 --> Output Class Initialized
INFO - 2020-09-25 19:22:32 --> Security Class Initialized
DEBUG - 2020-09-25 19:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:22:32 --> Input Class Initialized
INFO - 2020-09-25 19:22:32 --> Language Class Initialized
INFO - 2020-09-25 19:22:32 --> Loader Class Initialized
INFO - 2020-09-25 19:22:32 --> Helper loaded: url_helper
INFO - 2020-09-25 19:22:32 --> Helper loaded: file_helper
INFO - 2020-09-25 19:22:32 --> Database Driver Class Initialized
INFO - 2020-09-25 19:22:32 --> Email Class Initialized
DEBUG - 2020-09-25 19:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:22:32 --> Controller Class Initialized
INFO - 2020-09-25 19:22:32 --> Model "Main_model" initialized
INFO - 2020-09-25 19:22:32 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 19:22:32 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 19:22:32 --> Final output sent to browser
DEBUG - 2020-09-25 19:22:32 --> Total execution time: 0.3837
INFO - 2020-09-25 19:24:36 --> Config Class Initialized
INFO - 2020-09-25 19:24:36 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:24:36 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:24:36 --> Utf8 Class Initialized
INFO - 2020-09-25 19:24:36 --> URI Class Initialized
INFO - 2020-09-25 19:24:36 --> Router Class Initialized
INFO - 2020-09-25 19:24:36 --> Output Class Initialized
INFO - 2020-09-25 19:24:36 --> Security Class Initialized
DEBUG - 2020-09-25 19:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:24:36 --> Input Class Initialized
INFO - 2020-09-25 19:24:36 --> Language Class Initialized
INFO - 2020-09-25 19:24:36 --> Loader Class Initialized
INFO - 2020-09-25 19:24:36 --> Helper loaded: url_helper
INFO - 2020-09-25 19:24:36 --> Helper loaded: file_helper
INFO - 2020-09-25 19:24:36 --> Database Driver Class Initialized
INFO - 2020-09-25 19:24:36 --> Email Class Initialized
DEBUG - 2020-09-25 19:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:24:36 --> Controller Class Initialized
INFO - 2020-09-25 19:24:36 --> Model "Main_model" initialized
INFO - 2020-09-25 19:24:36 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 19:24:36 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 19:24:36 --> Final output sent to browser
DEBUG - 2020-09-25 19:24:36 --> Total execution time: 0.4262
INFO - 2020-09-25 19:27:27 --> Config Class Initialized
INFO - 2020-09-25 19:27:27 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:27:27 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:27:27 --> Utf8 Class Initialized
INFO - 2020-09-25 19:27:27 --> URI Class Initialized
INFO - 2020-09-25 19:27:27 --> Router Class Initialized
INFO - 2020-09-25 19:27:27 --> Output Class Initialized
INFO - 2020-09-25 19:27:27 --> Security Class Initialized
DEBUG - 2020-09-25 19:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:27:27 --> Input Class Initialized
INFO - 2020-09-25 19:27:27 --> Language Class Initialized
INFO - 2020-09-25 19:27:27 --> Loader Class Initialized
INFO - 2020-09-25 19:27:27 --> Helper loaded: url_helper
INFO - 2020-09-25 19:27:27 --> Helper loaded: file_helper
INFO - 2020-09-25 19:27:27 --> Database Driver Class Initialized
INFO - 2020-09-25 19:27:27 --> Email Class Initialized
DEBUG - 2020-09-25 19:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:27:27 --> Controller Class Initialized
INFO - 2020-09-25 19:27:27 --> Model "Main_model" initialized
INFO - 2020-09-25 19:27:27 --> Config Class Initialized
INFO - 2020-09-25 19:27:27 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:27:27 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:27:27 --> Utf8 Class Initialized
INFO - 2020-09-25 19:27:28 --> URI Class Initialized
INFO - 2020-09-25 19:27:28 --> Router Class Initialized
INFO - 2020-09-25 19:27:28 --> Output Class Initialized
INFO - 2020-09-25 19:27:28 --> Security Class Initialized
DEBUG - 2020-09-25 19:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:27:28 --> Input Class Initialized
INFO - 2020-09-25 19:27:28 --> Language Class Initialized
INFO - 2020-09-25 19:27:28 --> Loader Class Initialized
INFO - 2020-09-25 19:27:28 --> Helper loaded: url_helper
INFO - 2020-09-25 19:27:28 --> Helper loaded: file_helper
INFO - 2020-09-25 19:27:28 --> Database Driver Class Initialized
INFO - 2020-09-25 19:27:28 --> Email Class Initialized
DEBUG - 2020-09-25 19:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:27:28 --> Controller Class Initialized
INFO - 2020-09-25 19:27:28 --> Model "Main_model" initialized
INFO - 2020-09-25 19:27:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-09-25 19:27:28 --> Final output sent to browser
DEBUG - 2020-09-25 19:27:28 --> Total execution time: 0.3373
INFO - 2020-09-25 19:27:34 --> Config Class Initialized
INFO - 2020-09-25 19:27:34 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:27:34 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:27:34 --> Utf8 Class Initialized
INFO - 2020-09-25 19:27:34 --> URI Class Initialized
INFO - 2020-09-25 19:27:34 --> Router Class Initialized
INFO - 2020-09-25 19:27:34 --> Output Class Initialized
INFO - 2020-09-25 19:27:34 --> Security Class Initialized
DEBUG - 2020-09-25 19:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:27:34 --> Input Class Initialized
INFO - 2020-09-25 19:27:35 --> Language Class Initialized
INFO - 2020-09-25 19:27:35 --> Loader Class Initialized
INFO - 2020-09-25 19:27:35 --> Helper loaded: url_helper
INFO - 2020-09-25 19:27:35 --> Helper loaded: file_helper
INFO - 2020-09-25 19:27:35 --> Database Driver Class Initialized
INFO - 2020-09-25 19:27:35 --> Email Class Initialized
DEBUG - 2020-09-25 19:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:27:35 --> Controller Class Initialized
INFO - 2020-09-25 19:27:35 --> Model "Main_model" initialized
INFO - 2020-09-25 19:27:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-09-25 19:27:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-09-25 19:27:35 --> Final output sent to browser
DEBUG - 2020-09-25 19:27:35 --> Total execution time: 0.3819
INFO - 2020-09-25 19:27:40 --> Config Class Initialized
INFO - 2020-09-25 19:27:40 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:27:40 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:27:40 --> Utf8 Class Initialized
INFO - 2020-09-25 19:27:40 --> URI Class Initialized
INFO - 2020-09-25 19:27:40 --> Router Class Initialized
INFO - 2020-09-25 19:27:40 --> Output Class Initialized
INFO - 2020-09-25 19:27:41 --> Security Class Initialized
DEBUG - 2020-09-25 19:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:27:41 --> Input Class Initialized
INFO - 2020-09-25 19:27:41 --> Language Class Initialized
INFO - 2020-09-25 19:27:41 --> Loader Class Initialized
INFO - 2020-09-25 19:27:41 --> Helper loaded: url_helper
INFO - 2020-09-25 19:27:41 --> Helper loaded: file_helper
INFO - 2020-09-25 19:27:41 --> Database Driver Class Initialized
INFO - 2020-09-25 19:27:41 --> Email Class Initialized
DEBUG - 2020-09-25 19:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:27:41 --> Controller Class Initialized
INFO - 2020-09-25 19:27:41 --> Model "Main_model" initialized
INFO - 2020-09-25 19:27:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-09-25 19:27:41 --> Final output sent to browser
DEBUG - 2020-09-25 19:27:41 --> Total execution time: 0.3674
INFO - 2020-09-25 19:27:53 --> Config Class Initialized
INFO - 2020-09-25 19:27:53 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:27:53 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:27:53 --> Utf8 Class Initialized
INFO - 2020-09-25 19:27:53 --> URI Class Initialized
INFO - 2020-09-25 19:27:54 --> Router Class Initialized
INFO - 2020-09-25 19:27:54 --> Output Class Initialized
INFO - 2020-09-25 19:27:54 --> Security Class Initialized
DEBUG - 2020-09-25 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:27:54 --> Input Class Initialized
INFO - 2020-09-25 19:27:54 --> Language Class Initialized
INFO - 2020-09-25 19:27:54 --> Loader Class Initialized
INFO - 2020-09-25 19:27:54 --> Helper loaded: url_helper
INFO - 2020-09-25 19:27:54 --> Helper loaded: file_helper
INFO - 2020-09-25 19:27:54 --> Database Driver Class Initialized
INFO - 2020-09-25 19:27:54 --> Email Class Initialized
DEBUG - 2020-09-25 19:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:27:54 --> Controller Class Initialized
INFO - 2020-09-25 19:27:54 --> Model "Main_model" initialized
INFO - 2020-09-25 19:27:54 --> Config Class Initialized
INFO - 2020-09-25 19:27:54 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:27:54 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:27:54 --> Utf8 Class Initialized
INFO - 2020-09-25 19:27:54 --> URI Class Initialized
INFO - 2020-09-25 19:27:54 --> Router Class Initialized
INFO - 2020-09-25 19:27:54 --> Output Class Initialized
INFO - 2020-09-25 19:27:54 --> Security Class Initialized
DEBUG - 2020-09-25 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:27:54 --> Input Class Initialized
INFO - 2020-09-25 19:27:54 --> Language Class Initialized
INFO - 2020-09-25 19:27:54 --> Loader Class Initialized
INFO - 2020-09-25 19:27:54 --> Helper loaded: url_helper
INFO - 2020-09-25 19:27:54 --> Helper loaded: file_helper
INFO - 2020-09-25 19:27:54 --> Database Driver Class Initialized
INFO - 2020-09-25 19:27:54 --> Email Class Initialized
DEBUG - 2020-09-25 19:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:27:54 --> Controller Class Initialized
INFO - 2020-09-25 19:27:54 --> Model "Main_model" initialized
INFO - 2020-09-25 19:27:54 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-09-25 19:27:54 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-09-25 19:27:54 --> Final output sent to browser
DEBUG - 2020-09-25 19:27:54 --> Total execution time: 0.3755
INFO - 2020-09-25 19:27:59 --> Config Class Initialized
INFO - 2020-09-25 19:27:59 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:27:59 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:27:59 --> Utf8 Class Initialized
INFO - 2020-09-25 19:27:59 --> URI Class Initialized
INFO - 2020-09-25 19:27:59 --> Router Class Initialized
INFO - 2020-09-25 19:27:59 --> Output Class Initialized
INFO - 2020-09-25 19:27:59 --> Security Class Initialized
DEBUG - 2020-09-25 19:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:27:59 --> Input Class Initialized
INFO - 2020-09-25 19:27:59 --> Language Class Initialized
INFO - 2020-09-25 19:27:59 --> Loader Class Initialized
INFO - 2020-09-25 19:27:59 --> Helper loaded: url_helper
INFO - 2020-09-25 19:27:59 --> Helper loaded: file_helper
INFO - 2020-09-25 19:27:59 --> Database Driver Class Initialized
INFO - 2020-09-25 19:27:59 --> Email Class Initialized
DEBUG - 2020-09-25 19:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:27:59 --> Controller Class Initialized
INFO - 2020-09-25 19:27:59 --> Model "Main_model" initialized
INFO - 2020-09-25 19:27:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 19:27:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 19:27:59 --> Final output sent to browser
DEBUG - 2020-09-25 19:27:59 --> Total execution time: 0.3927
INFO - 2020-09-25 19:54:04 --> Config Class Initialized
INFO - 2020-09-25 19:54:04 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:54:04 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:54:04 --> Utf8 Class Initialized
INFO - 2020-09-25 19:54:05 --> URI Class Initialized
INFO - 2020-09-25 19:54:05 --> Router Class Initialized
INFO - 2020-09-25 19:54:05 --> Output Class Initialized
INFO - 2020-09-25 19:54:05 --> Security Class Initialized
DEBUG - 2020-09-25 19:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:54:05 --> Input Class Initialized
INFO - 2020-09-25 19:54:05 --> Language Class Initialized
INFO - 2020-09-25 19:54:05 --> Loader Class Initialized
INFO - 2020-09-25 19:54:05 --> Helper loaded: url_helper
INFO - 2020-09-25 19:54:05 --> Helper loaded: file_helper
INFO - 2020-09-25 19:54:05 --> Database Driver Class Initialized
INFO - 2020-09-25 19:54:05 --> Email Class Initialized
DEBUG - 2020-09-25 19:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:54:05 --> Controller Class Initialized
INFO - 2020-09-25 19:54:05 --> Model "Main_model" initialized
INFO - 2020-09-25 19:54:05 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 19:54:05 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 19:54:05 --> Final output sent to browser
DEBUG - 2020-09-25 19:54:05 --> Total execution time: 0.9432
INFO - 2020-09-25 19:54:18 --> Config Class Initialized
INFO - 2020-09-25 19:54:18 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:54:18 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:54:18 --> Utf8 Class Initialized
INFO - 2020-09-25 19:54:18 --> URI Class Initialized
INFO - 2020-09-25 19:54:18 --> Router Class Initialized
INFO - 2020-09-25 19:54:18 --> Output Class Initialized
INFO - 2020-09-25 19:54:18 --> Security Class Initialized
DEBUG - 2020-09-25 19:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:54:18 --> Input Class Initialized
INFO - 2020-09-25 19:54:18 --> Language Class Initialized
INFO - 2020-09-25 19:54:18 --> Loader Class Initialized
INFO - 2020-09-25 19:54:18 --> Helper loaded: url_helper
INFO - 2020-09-25 19:54:18 --> Helper loaded: file_helper
INFO - 2020-09-25 19:54:18 --> Database Driver Class Initialized
INFO - 2020-09-25 19:54:18 --> Email Class Initialized
DEBUG - 2020-09-25 19:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:54:18 --> Controller Class Initialized
INFO - 2020-09-25 19:54:18 --> Model "Main_model" initialized
INFO - 2020-09-25 19:54:18 --> Final output sent to browser
DEBUG - 2020-09-25 19:54:18 --> Total execution time: 0.3604
INFO - 2020-09-25 19:54:57 --> Config Class Initialized
INFO - 2020-09-25 19:54:57 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:54:57 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:54:57 --> Utf8 Class Initialized
INFO - 2020-09-25 19:54:57 --> URI Class Initialized
INFO - 2020-09-25 19:54:57 --> Router Class Initialized
INFO - 2020-09-25 19:54:57 --> Output Class Initialized
INFO - 2020-09-25 19:54:57 --> Security Class Initialized
DEBUG - 2020-09-25 19:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:54:57 --> Input Class Initialized
INFO - 2020-09-25 19:54:57 --> Language Class Initialized
INFO - 2020-09-25 19:54:57 --> Loader Class Initialized
INFO - 2020-09-25 19:54:57 --> Helper loaded: url_helper
INFO - 2020-09-25 19:54:57 --> Helper loaded: file_helper
INFO - 2020-09-25 19:54:58 --> Database Driver Class Initialized
INFO - 2020-09-25 19:54:58 --> Email Class Initialized
DEBUG - 2020-09-25 19:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:54:58 --> Controller Class Initialized
INFO - 2020-09-25 19:54:58 --> Model "Main_model" initialized
INFO - 2020-09-25 19:54:58 --> Final output sent to browser
DEBUG - 2020-09-25 19:54:58 --> Total execution time: 0.4741
INFO - 2020-09-25 19:55:21 --> Config Class Initialized
INFO - 2020-09-25 19:55:21 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:55:21 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:55:21 --> Utf8 Class Initialized
INFO - 2020-09-25 19:55:21 --> URI Class Initialized
INFO - 2020-09-25 19:55:21 --> Router Class Initialized
INFO - 2020-09-25 19:55:21 --> Output Class Initialized
INFO - 2020-09-25 19:55:21 --> Security Class Initialized
DEBUG - 2020-09-25 19:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:55:21 --> Input Class Initialized
INFO - 2020-09-25 19:55:21 --> Language Class Initialized
INFO - 2020-09-25 19:55:21 --> Loader Class Initialized
INFO - 2020-09-25 19:55:21 --> Helper loaded: url_helper
INFO - 2020-09-25 19:55:21 --> Helper loaded: file_helper
INFO - 2020-09-25 19:55:21 --> Database Driver Class Initialized
INFO - 2020-09-25 19:55:21 --> Email Class Initialized
DEBUG - 2020-09-25 19:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:55:21 --> Controller Class Initialized
INFO - 2020-09-25 19:55:21 --> Model "Main_model" initialized
INFO - 2020-09-25 19:55:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 19:55:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 19:55:21 --> Final output sent to browser
DEBUG - 2020-09-25 19:55:21 --> Total execution time: 0.3497
INFO - 2020-09-25 19:55:25 --> Config Class Initialized
INFO - 2020-09-25 19:55:25 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:55:25 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:55:25 --> Utf8 Class Initialized
INFO - 2020-09-25 19:55:25 --> URI Class Initialized
INFO - 2020-09-25 19:55:25 --> Router Class Initialized
INFO - 2020-09-25 19:55:25 --> Output Class Initialized
INFO - 2020-09-25 19:55:25 --> Security Class Initialized
DEBUG - 2020-09-25 19:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:55:25 --> Input Class Initialized
INFO - 2020-09-25 19:55:25 --> Language Class Initialized
INFO - 2020-09-25 19:55:25 --> Loader Class Initialized
INFO - 2020-09-25 19:55:25 --> Helper loaded: url_helper
INFO - 2020-09-25 19:55:25 --> Helper loaded: file_helper
INFO - 2020-09-25 19:55:25 --> Database Driver Class Initialized
INFO - 2020-09-25 19:55:25 --> Email Class Initialized
DEBUG - 2020-09-25 19:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:55:25 --> Controller Class Initialized
INFO - 2020-09-25 19:55:25 --> Model "Main_model" initialized
INFO - 2020-09-25 19:55:25 --> Config Class Initialized
INFO - 2020-09-25 19:55:25 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:55:25 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:55:25 --> Utf8 Class Initialized
INFO - 2020-09-25 19:55:25 --> URI Class Initialized
DEBUG - 2020-09-25 19:55:25 --> No URI present. Default controller set.
INFO - 2020-09-25 19:55:25 --> Router Class Initialized
INFO - 2020-09-25 19:55:25 --> Output Class Initialized
INFO - 2020-09-25 19:55:25 --> Security Class Initialized
DEBUG - 2020-09-25 19:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:55:26 --> Input Class Initialized
INFO - 2020-09-25 19:55:26 --> Language Class Initialized
INFO - 2020-09-25 19:55:26 --> Loader Class Initialized
INFO - 2020-09-25 19:55:26 --> Helper loaded: url_helper
INFO - 2020-09-25 19:55:26 --> Helper loaded: file_helper
INFO - 2020-09-25 19:55:26 --> Database Driver Class Initialized
INFO - 2020-09-25 19:55:26 --> Email Class Initialized
DEBUG - 2020-09-25 19:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:55:26 --> Controller Class Initialized
INFO - 2020-09-25 19:55:26 --> Model "Main_model" initialized
INFO - 2020-09-25 19:55:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-25 19:55:26 --> Final output sent to browser
DEBUG - 2020-09-25 19:55:26 --> Total execution time: 0.3533
INFO - 2020-09-25 19:55:27 --> Config Class Initialized
INFO - 2020-09-25 19:55:27 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:55:27 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:55:27 --> Utf8 Class Initialized
INFO - 2020-09-25 19:55:27 --> URI Class Initialized
INFO - 2020-09-25 19:55:27 --> Router Class Initialized
INFO - 2020-09-25 19:55:27 --> Output Class Initialized
INFO - 2020-09-25 19:55:27 --> Security Class Initialized
DEBUG - 2020-09-25 19:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:55:28 --> Input Class Initialized
INFO - 2020-09-25 19:55:28 --> Language Class Initialized
INFO - 2020-09-25 19:55:28 --> Loader Class Initialized
INFO - 2020-09-25 19:55:28 --> Helper loaded: url_helper
INFO - 2020-09-25 19:55:28 --> Helper loaded: file_helper
INFO - 2020-09-25 19:55:28 --> Database Driver Class Initialized
INFO - 2020-09-25 19:55:28 --> Email Class Initialized
DEBUG - 2020-09-25 19:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:55:28 --> Controller Class Initialized
INFO - 2020-09-25 19:55:28 --> Model "Main_model" initialized
INFO - 2020-09-25 19:55:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-09-25 19:55:28 --> Final output sent to browser
DEBUG - 2020-09-25 19:55:28 --> Total execution time: 0.4188
INFO - 2020-09-25 19:55:32 --> Config Class Initialized
INFO - 2020-09-25 19:55:32 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:55:32 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:55:32 --> Utf8 Class Initialized
INFO - 2020-09-25 19:55:32 --> URI Class Initialized
INFO - 2020-09-25 19:55:32 --> Router Class Initialized
INFO - 2020-09-25 19:55:32 --> Output Class Initialized
INFO - 2020-09-25 19:55:32 --> Security Class Initialized
DEBUG - 2020-09-25 19:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:55:32 --> Input Class Initialized
INFO - 2020-09-25 19:55:32 --> Language Class Initialized
INFO - 2020-09-25 19:55:33 --> Loader Class Initialized
INFO - 2020-09-25 19:55:33 --> Helper loaded: url_helper
INFO - 2020-09-25 19:55:33 --> Helper loaded: file_helper
INFO - 2020-09-25 19:55:33 --> Database Driver Class Initialized
INFO - 2020-09-25 19:55:33 --> Email Class Initialized
DEBUG - 2020-09-25 19:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:55:33 --> Controller Class Initialized
INFO - 2020-09-25 19:55:33 --> Model "Main_model" initialized
INFO - 2020-09-25 19:55:33 --> Config Class Initialized
INFO - 2020-09-25 19:55:33 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:55:33 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:55:33 --> Utf8 Class Initialized
INFO - 2020-09-25 19:55:33 --> URI Class Initialized
INFO - 2020-09-25 19:55:33 --> Router Class Initialized
INFO - 2020-09-25 19:55:33 --> Output Class Initialized
INFO - 2020-09-25 19:55:33 --> Security Class Initialized
DEBUG - 2020-09-25 19:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:55:33 --> Input Class Initialized
INFO - 2020-09-25 19:55:33 --> Language Class Initialized
INFO - 2020-09-25 19:55:33 --> Loader Class Initialized
INFO - 2020-09-25 19:55:33 --> Helper loaded: url_helper
INFO - 2020-09-25 19:55:33 --> Helper loaded: file_helper
INFO - 2020-09-25 19:55:33 --> Database Driver Class Initialized
INFO - 2020-09-25 19:55:33 --> Email Class Initialized
DEBUG - 2020-09-25 19:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:55:33 --> Controller Class Initialized
INFO - 2020-09-25 19:55:33 --> Model "Main_model" initialized
INFO - 2020-09-25 19:55:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-09-25 19:55:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-09-25 19:55:33 --> Final output sent to browser
DEBUG - 2020-09-25 19:55:33 --> Total execution time: 0.4763
INFO - 2020-09-25 19:55:38 --> Config Class Initialized
INFO - 2020-09-25 19:55:38 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:55:38 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:55:38 --> Utf8 Class Initialized
INFO - 2020-09-25 19:55:38 --> URI Class Initialized
INFO - 2020-09-25 19:55:38 --> Router Class Initialized
INFO - 2020-09-25 19:55:38 --> Output Class Initialized
INFO - 2020-09-25 19:55:38 --> Security Class Initialized
DEBUG - 2020-09-25 19:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:55:38 --> Input Class Initialized
INFO - 2020-09-25 19:55:38 --> Language Class Initialized
INFO - 2020-09-25 19:55:38 --> Loader Class Initialized
INFO - 2020-09-25 19:55:38 --> Helper loaded: url_helper
INFO - 2020-09-25 19:55:38 --> Helper loaded: file_helper
INFO - 2020-09-25 19:55:38 --> Database Driver Class Initialized
INFO - 2020-09-25 19:55:38 --> Email Class Initialized
DEBUG - 2020-09-25 19:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:55:38 --> Controller Class Initialized
INFO - 2020-09-25 19:55:38 --> Model "Main_model" initialized
INFO - 2020-09-25 19:55:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 19:55:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 19:55:38 --> Final output sent to browser
DEBUG - 2020-09-25 19:55:38 --> Total execution time: 0.3836
INFO - 2020-09-25 19:56:55 --> Config Class Initialized
INFO - 2020-09-25 19:56:55 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:56:56 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:56:56 --> Utf8 Class Initialized
INFO - 2020-09-25 19:56:56 --> URI Class Initialized
INFO - 2020-09-25 19:56:56 --> Router Class Initialized
INFO - 2020-09-25 19:56:56 --> Output Class Initialized
INFO - 2020-09-25 19:56:56 --> Security Class Initialized
DEBUG - 2020-09-25 19:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:56:56 --> Input Class Initialized
INFO - 2020-09-25 19:56:56 --> Language Class Initialized
INFO - 2020-09-25 19:56:56 --> Loader Class Initialized
INFO - 2020-09-25 19:56:56 --> Helper loaded: url_helper
INFO - 2020-09-25 19:56:56 --> Helper loaded: file_helper
INFO - 2020-09-25 19:56:56 --> Database Driver Class Initialized
INFO - 2020-09-25 19:56:56 --> Email Class Initialized
DEBUG - 2020-09-25 19:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:56:56 --> Controller Class Initialized
INFO - 2020-09-25 19:56:56 --> Model "Main_model" initialized
INFO - 2020-09-25 19:56:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 19:56:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 19:56:56 --> Final output sent to browser
DEBUG - 2020-09-25 19:56:56 --> Total execution time: 0.3827
INFO - 2020-09-25 19:56:59 --> Config Class Initialized
INFO - 2020-09-25 19:56:59 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:56:59 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:56:59 --> Utf8 Class Initialized
INFO - 2020-09-25 19:56:59 --> URI Class Initialized
INFO - 2020-09-25 19:56:59 --> Router Class Initialized
INFO - 2020-09-25 19:56:59 --> Output Class Initialized
INFO - 2020-09-25 19:56:59 --> Security Class Initialized
DEBUG - 2020-09-25 19:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:56:59 --> Input Class Initialized
INFO - 2020-09-25 19:56:59 --> Language Class Initialized
INFO - 2020-09-25 19:56:59 --> Loader Class Initialized
INFO - 2020-09-25 19:57:00 --> Helper loaded: url_helper
INFO - 2020-09-25 19:57:00 --> Helper loaded: file_helper
INFO - 2020-09-25 19:57:00 --> Database Driver Class Initialized
INFO - 2020-09-25 19:57:00 --> Email Class Initialized
DEBUG - 2020-09-25 19:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:57:00 --> Controller Class Initialized
INFO - 2020-09-25 19:57:00 --> Model "Main_model" initialized
INFO - 2020-09-25 19:57:00 --> Final output sent to browser
DEBUG - 2020-09-25 19:57:00 --> Total execution time: 0.3599
INFO - 2020-09-25 19:57:34 --> Config Class Initialized
INFO - 2020-09-25 19:57:34 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:57:34 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:57:34 --> Utf8 Class Initialized
INFO - 2020-09-25 19:57:34 --> URI Class Initialized
INFO - 2020-09-25 19:57:34 --> Router Class Initialized
INFO - 2020-09-25 19:57:34 --> Output Class Initialized
INFO - 2020-09-25 19:57:34 --> Security Class Initialized
DEBUG - 2020-09-25 19:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:57:34 --> Input Class Initialized
INFO - 2020-09-25 19:57:34 --> Language Class Initialized
INFO - 2020-09-25 19:57:34 --> Loader Class Initialized
INFO - 2020-09-25 19:57:34 --> Helper loaded: url_helper
INFO - 2020-09-25 19:57:34 --> Helper loaded: file_helper
INFO - 2020-09-25 19:57:34 --> Database Driver Class Initialized
INFO - 2020-09-25 19:57:34 --> Email Class Initialized
DEBUG - 2020-09-25 19:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:57:34 --> Controller Class Initialized
INFO - 2020-09-25 19:57:34 --> Model "Main_model" initialized
INFO - 2020-09-25 19:57:34 --> Config Class Initialized
INFO - 2020-09-25 19:57:34 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:57:34 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:57:34 --> Utf8 Class Initialized
INFO - 2020-09-25 19:57:34 --> URI Class Initialized
INFO - 2020-09-25 19:57:34 --> Router Class Initialized
INFO - 2020-09-25 19:57:34 --> Output Class Initialized
INFO - 2020-09-25 19:57:34 --> Security Class Initialized
DEBUG - 2020-09-25 19:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:57:34 --> Input Class Initialized
INFO - 2020-09-25 19:57:34 --> Language Class Initialized
INFO - 2020-09-25 19:57:34 --> Loader Class Initialized
INFO - 2020-09-25 19:57:34 --> Helper loaded: url_helper
INFO - 2020-09-25 19:57:34 --> Helper loaded: file_helper
INFO - 2020-09-25 19:57:34 --> Database Driver Class Initialized
INFO - 2020-09-25 19:57:34 --> Email Class Initialized
DEBUG - 2020-09-25 19:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 19:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 19:57:34 --> Controller Class Initialized
INFO - 2020-09-25 19:57:34 --> Model "Main_model" initialized
INFO - 2020-09-25 19:57:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 19:57:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 19:57:35 --> Final output sent to browser
DEBUG - 2020-09-25 19:57:35 --> Total execution time: 0.3457
INFO - 2020-09-25 19:57:42 --> Config Class Initialized
INFO - 2020-09-25 19:57:42 --> Hooks Class Initialized
DEBUG - 2020-09-25 19:57:42 --> UTF-8 Support Enabled
INFO - 2020-09-25 19:57:42 --> Utf8 Class Initialized
INFO - 2020-09-25 19:57:42 --> URI Class Initialized
INFO - 2020-09-25 19:57:42 --> Router Class Initialized
INFO - 2020-09-25 19:57:42 --> Output Class Initialized
INFO - 2020-09-25 19:57:42 --> Security Class Initialized
DEBUG - 2020-09-25 19:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 19:57:42 --> Input Class Initialized
INFO - 2020-09-25 19:57:42 --> Language Class Initialized
ERROR - 2020-09-25 19:57:42 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:02:14 --> Config Class Initialized
INFO - 2020-09-25 20:02:14 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:02:14 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:02:14 --> Utf8 Class Initialized
INFO - 2020-09-25 20:02:14 --> URI Class Initialized
INFO - 2020-09-25 20:02:14 --> Router Class Initialized
INFO - 2020-09-25 20:02:14 --> Output Class Initialized
INFO - 2020-09-25 20:02:14 --> Security Class Initialized
DEBUG - 2020-09-25 20:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:02:14 --> Input Class Initialized
INFO - 2020-09-25 20:02:14 --> Language Class Initialized
INFO - 2020-09-25 20:02:14 --> Loader Class Initialized
INFO - 2020-09-25 20:02:14 --> Helper loaded: url_helper
INFO - 2020-09-25 20:02:14 --> Helper loaded: file_helper
INFO - 2020-09-25 20:02:14 --> Database Driver Class Initialized
INFO - 2020-09-25 20:02:14 --> Email Class Initialized
DEBUG - 2020-09-25 20:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:02:14 --> Controller Class Initialized
INFO - 2020-09-25 20:02:14 --> Model "Main_model" initialized
INFO - 2020-09-25 20:02:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:02:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 20:02:14 --> Final output sent to browser
DEBUG - 2020-09-25 20:02:14 --> Total execution time: 0.4458
INFO - 2020-09-25 20:02:15 --> Config Class Initialized
INFO - 2020-09-25 20:02:15 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:02:15 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:02:15 --> Utf8 Class Initialized
INFO - 2020-09-25 20:02:16 --> URI Class Initialized
INFO - 2020-09-25 20:02:16 --> Router Class Initialized
INFO - 2020-09-25 20:02:16 --> Output Class Initialized
INFO - 2020-09-25 20:02:16 --> Security Class Initialized
DEBUG - 2020-09-25 20:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:02:16 --> Input Class Initialized
INFO - 2020-09-25 20:02:16 --> Language Class Initialized
ERROR - 2020-09-25 20:02:16 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:02:22 --> Config Class Initialized
INFO - 2020-09-25 20:02:22 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:02:22 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:02:22 --> Utf8 Class Initialized
INFO - 2020-09-25 20:02:22 --> URI Class Initialized
INFO - 2020-09-25 20:02:22 --> Router Class Initialized
INFO - 2020-09-25 20:02:22 --> Output Class Initialized
INFO - 2020-09-25 20:02:22 --> Security Class Initialized
DEBUG - 2020-09-25 20:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:02:22 --> Input Class Initialized
INFO - 2020-09-25 20:02:22 --> Language Class Initialized
INFO - 2020-09-25 20:02:22 --> Loader Class Initialized
INFO - 2020-09-25 20:02:22 --> Helper loaded: url_helper
INFO - 2020-09-25 20:02:22 --> Helper loaded: file_helper
INFO - 2020-09-25 20:02:22 --> Database Driver Class Initialized
INFO - 2020-09-25 20:02:22 --> Email Class Initialized
DEBUG - 2020-09-25 20:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:02:22 --> Controller Class Initialized
INFO - 2020-09-25 20:02:22 --> Model "Main_model" initialized
INFO - 2020-09-25 20:02:22 --> Config Class Initialized
INFO - 2020-09-25 20:02:22 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:02:22 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:02:22 --> Utf8 Class Initialized
INFO - 2020-09-25 20:02:22 --> URI Class Initialized
INFO - 2020-09-25 20:02:22 --> Router Class Initialized
INFO - 2020-09-25 20:02:22 --> Output Class Initialized
INFO - 2020-09-25 20:02:22 --> Security Class Initialized
DEBUG - 2020-09-25 20:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:02:22 --> Input Class Initialized
INFO - 2020-09-25 20:02:22 --> Language Class Initialized
INFO - 2020-09-25 20:02:22 --> Loader Class Initialized
INFO - 2020-09-25 20:02:22 --> Helper loaded: url_helper
INFO - 2020-09-25 20:02:22 --> Helper loaded: file_helper
INFO - 2020-09-25 20:02:23 --> Database Driver Class Initialized
INFO - 2020-09-25 20:02:23 --> Email Class Initialized
DEBUG - 2020-09-25 20:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:02:23 --> Controller Class Initialized
INFO - 2020-09-25 20:02:23 --> Model "Main_model" initialized
INFO - 2020-09-25 20:02:23 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:02:23 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 20:02:23 --> Final output sent to browser
DEBUG - 2020-09-25 20:02:23 --> Total execution time: 0.3827
INFO - 2020-09-25 20:02:24 --> Config Class Initialized
INFO - 2020-09-25 20:02:24 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:02:24 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:02:24 --> Utf8 Class Initialized
INFO - 2020-09-25 20:02:24 --> URI Class Initialized
INFO - 2020-09-25 20:02:24 --> Router Class Initialized
INFO - 2020-09-25 20:02:24 --> Output Class Initialized
INFO - 2020-09-25 20:02:24 --> Security Class Initialized
DEBUG - 2020-09-25 20:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:02:24 --> Input Class Initialized
INFO - 2020-09-25 20:02:24 --> Language Class Initialized
ERROR - 2020-09-25 20:02:24 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:03:19 --> Config Class Initialized
INFO - 2020-09-25 20:03:19 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:03:19 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:03:19 --> Utf8 Class Initialized
INFO - 2020-09-25 20:03:19 --> URI Class Initialized
INFO - 2020-09-25 20:03:19 --> Router Class Initialized
INFO - 2020-09-25 20:03:19 --> Output Class Initialized
INFO - 2020-09-25 20:03:19 --> Security Class Initialized
DEBUG - 2020-09-25 20:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:03:19 --> Input Class Initialized
INFO - 2020-09-25 20:03:19 --> Language Class Initialized
INFO - 2020-09-25 20:03:19 --> Loader Class Initialized
INFO - 2020-09-25 20:03:19 --> Helper loaded: url_helper
INFO - 2020-09-25 20:03:19 --> Helper loaded: file_helper
INFO - 2020-09-25 20:03:19 --> Database Driver Class Initialized
INFO - 2020-09-25 20:03:19 --> Email Class Initialized
DEBUG - 2020-09-25 20:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:03:19 --> Controller Class Initialized
INFO - 2020-09-25 20:03:19 --> Model "Main_model" initialized
INFO - 2020-09-25 20:03:19 --> Config Class Initialized
INFO - 2020-09-25 20:03:19 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:03:19 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:03:19 --> Utf8 Class Initialized
INFO - 2020-09-25 20:03:19 --> URI Class Initialized
INFO - 2020-09-25 20:03:19 --> Router Class Initialized
INFO - 2020-09-25 20:03:19 --> Output Class Initialized
INFO - 2020-09-25 20:03:19 --> Security Class Initialized
DEBUG - 2020-09-25 20:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:03:19 --> Input Class Initialized
INFO - 2020-09-25 20:03:19 --> Language Class Initialized
INFO - 2020-09-25 20:03:19 --> Loader Class Initialized
INFO - 2020-09-25 20:03:19 --> Helper loaded: url_helper
INFO - 2020-09-25 20:03:19 --> Helper loaded: file_helper
INFO - 2020-09-25 20:03:19 --> Database Driver Class Initialized
INFO - 2020-09-25 20:03:19 --> Email Class Initialized
DEBUG - 2020-09-25 20:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:03:19 --> Controller Class Initialized
INFO - 2020-09-25 20:03:19 --> Model "Main_model" initialized
INFO - 2020-09-25 20:03:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:03:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 20:03:19 --> Final output sent to browser
DEBUG - 2020-09-25 20:03:19 --> Total execution time: 0.3659
INFO - 2020-09-25 20:03:20 --> Config Class Initialized
INFO - 2020-09-25 20:03:20 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:03:20 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:03:20 --> Utf8 Class Initialized
INFO - 2020-09-25 20:03:20 --> URI Class Initialized
INFO - 2020-09-25 20:03:20 --> Router Class Initialized
INFO - 2020-09-25 20:03:20 --> Output Class Initialized
INFO - 2020-09-25 20:03:20 --> Security Class Initialized
DEBUG - 2020-09-25 20:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:03:20 --> Input Class Initialized
INFO - 2020-09-25 20:03:20 --> Language Class Initialized
ERROR - 2020-09-25 20:03:20 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:25:59 --> Config Class Initialized
INFO - 2020-09-25 20:25:59 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:25:59 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:25:59 --> Utf8 Class Initialized
INFO - 2020-09-25 20:25:59 --> URI Class Initialized
INFO - 2020-09-25 20:25:59 --> Router Class Initialized
INFO - 2020-09-25 20:25:59 --> Output Class Initialized
INFO - 2020-09-25 20:25:59 --> Security Class Initialized
DEBUG - 2020-09-25 20:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:25:59 --> Input Class Initialized
INFO - 2020-09-25 20:25:59 --> Language Class Initialized
INFO - 2020-09-25 20:25:59 --> Loader Class Initialized
INFO - 2020-09-25 20:25:59 --> Helper loaded: url_helper
INFO - 2020-09-25 20:25:59 --> Helper loaded: file_helper
INFO - 2020-09-25 20:25:59 --> Database Driver Class Initialized
INFO - 2020-09-25 20:25:59 --> Email Class Initialized
DEBUG - 2020-09-25 20:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:26:00 --> Controller Class Initialized
INFO - 2020-09-25 20:26:00 --> Model "Main_model" initialized
INFO - 2020-09-25 20:26:00 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:26:00 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 20:26:00 --> Final output sent to browser
DEBUG - 2020-09-25 20:26:00 --> Total execution time: 0.4453
INFO - 2020-09-25 20:26:37 --> Config Class Initialized
INFO - 2020-09-25 20:26:37 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:26:37 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:26:37 --> Utf8 Class Initialized
INFO - 2020-09-25 20:26:37 --> URI Class Initialized
INFO - 2020-09-25 20:26:37 --> Router Class Initialized
INFO - 2020-09-25 20:26:37 --> Output Class Initialized
INFO - 2020-09-25 20:26:37 --> Security Class Initialized
DEBUG - 2020-09-25 20:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:26:37 --> Input Class Initialized
INFO - 2020-09-25 20:26:37 --> Language Class Initialized
INFO - 2020-09-25 20:26:37 --> Loader Class Initialized
INFO - 2020-09-25 20:26:37 --> Helper loaded: url_helper
INFO - 2020-09-25 20:26:37 --> Helper loaded: file_helper
INFO - 2020-09-25 20:26:37 --> Database Driver Class Initialized
INFO - 2020-09-25 20:26:37 --> Email Class Initialized
DEBUG - 2020-09-25 20:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:26:37 --> Controller Class Initialized
INFO - 2020-09-25 20:26:37 --> Model "Main_model" initialized
INFO - 2020-09-25 20:26:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-25 20:26:37 --> Severity: Notice --> Undefined variable: domains C:\xampp\htdocs\dmarc\application\views\domains.php 153
ERROR - 2020-09-25 20:26:37 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\dmarc\application\views\domains.php 153
ERROR - 2020-09-25 20:26:37 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\dmarc\application\views\domains.php 182
INFO - 2020-09-25 20:26:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:26:37 --> Final output sent to browser
DEBUG - 2020-09-25 20:26:37 --> Total execution time: 0.5861
INFO - 2020-09-25 20:27:20 --> Config Class Initialized
INFO - 2020-09-25 20:27:20 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:27:20 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:27:20 --> Utf8 Class Initialized
INFO - 2020-09-25 20:27:20 --> URI Class Initialized
INFO - 2020-09-25 20:27:20 --> Router Class Initialized
INFO - 2020-09-25 20:27:20 --> Output Class Initialized
INFO - 2020-09-25 20:27:20 --> Security Class Initialized
DEBUG - 2020-09-25 20:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:27:20 --> Input Class Initialized
INFO - 2020-09-25 20:27:20 --> Language Class Initialized
INFO - 2020-09-25 20:27:20 --> Loader Class Initialized
INFO - 2020-09-25 20:27:20 --> Helper loaded: url_helper
INFO - 2020-09-25 20:27:20 --> Helper loaded: file_helper
INFO - 2020-09-25 20:27:20 --> Database Driver Class Initialized
INFO - 2020-09-25 20:27:20 --> Email Class Initialized
DEBUG - 2020-09-25 20:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:27:20 --> Controller Class Initialized
INFO - 2020-09-25 20:27:20 --> Model "Main_model" initialized
INFO - 2020-09-25 20:27:20 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-25 20:27:20 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\dmarc\application\views\domains.php 182
INFO - 2020-09-25 20:27:20 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:27:20 --> Final output sent to browser
DEBUG - 2020-09-25 20:27:20 --> Total execution time: 0.4739
INFO - 2020-09-25 20:27:48 --> Config Class Initialized
INFO - 2020-09-25 20:27:48 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:27:48 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:27:48 --> Utf8 Class Initialized
INFO - 2020-09-25 20:27:48 --> URI Class Initialized
INFO - 2020-09-25 20:27:48 --> Router Class Initialized
INFO - 2020-09-25 20:27:48 --> Output Class Initialized
INFO - 2020-09-25 20:27:48 --> Security Class Initialized
DEBUG - 2020-09-25 20:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:27:48 --> Input Class Initialized
INFO - 2020-09-25 20:27:48 --> Language Class Initialized
INFO - 2020-09-25 20:27:48 --> Loader Class Initialized
INFO - 2020-09-25 20:27:48 --> Helper loaded: url_helper
INFO - 2020-09-25 20:27:48 --> Helper loaded: file_helper
INFO - 2020-09-25 20:27:48 --> Database Driver Class Initialized
INFO - 2020-09-25 20:27:48 --> Email Class Initialized
DEBUG - 2020-09-25 20:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:27:48 --> Controller Class Initialized
INFO - 2020-09-25 20:27:48 --> Model "Main_model" initialized
INFO - 2020-09-25 20:27:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:27:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:27:48 --> Final output sent to browser
DEBUG - 2020-09-25 20:27:49 --> Total execution time: 0.3765
INFO - 2020-09-25 20:27:58 --> Config Class Initialized
INFO - 2020-09-25 20:27:58 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:27:58 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:27:58 --> Utf8 Class Initialized
INFO - 2020-09-25 20:27:58 --> URI Class Initialized
INFO - 2020-09-25 20:27:58 --> Router Class Initialized
INFO - 2020-09-25 20:27:58 --> Output Class Initialized
INFO - 2020-09-25 20:27:58 --> Security Class Initialized
DEBUG - 2020-09-25 20:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:27:58 --> Input Class Initialized
INFO - 2020-09-25 20:27:58 --> Language Class Initialized
ERROR - 2020-09-25 20:27:58 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:28:33 --> Config Class Initialized
INFO - 2020-09-25 20:28:33 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:28:33 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:28:33 --> Utf8 Class Initialized
INFO - 2020-09-25 20:28:33 --> URI Class Initialized
INFO - 2020-09-25 20:28:33 --> Router Class Initialized
INFO - 2020-09-25 20:28:33 --> Output Class Initialized
INFO - 2020-09-25 20:28:33 --> Security Class Initialized
DEBUG - 2020-09-25 20:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:28:34 --> Input Class Initialized
INFO - 2020-09-25 20:28:34 --> Language Class Initialized
INFO - 2020-09-25 20:28:34 --> Loader Class Initialized
INFO - 2020-09-25 20:28:34 --> Helper loaded: url_helper
INFO - 2020-09-25 20:28:34 --> Helper loaded: file_helper
INFO - 2020-09-25 20:28:34 --> Database Driver Class Initialized
INFO - 2020-09-25 20:28:34 --> Email Class Initialized
DEBUG - 2020-09-25 20:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:28:34 --> Controller Class Initialized
INFO - 2020-09-25 20:28:34 --> Model "Main_model" initialized
INFO - 2020-09-25 20:28:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:28:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:28:34 --> Final output sent to browser
DEBUG - 2020-09-25 20:28:34 --> Total execution time: 0.4188
INFO - 2020-09-25 20:28:36 --> Config Class Initialized
INFO - 2020-09-25 20:28:36 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:28:36 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:28:36 --> Utf8 Class Initialized
INFO - 2020-09-25 20:28:36 --> URI Class Initialized
INFO - 2020-09-25 20:28:36 --> Router Class Initialized
INFO - 2020-09-25 20:28:36 --> Output Class Initialized
INFO - 2020-09-25 20:28:36 --> Security Class Initialized
DEBUG - 2020-09-25 20:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:28:36 --> Input Class Initialized
INFO - 2020-09-25 20:28:36 --> Language Class Initialized
ERROR - 2020-09-25 20:28:36 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:29:04 --> Config Class Initialized
INFO - 2020-09-25 20:29:04 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:29:04 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:29:04 --> Utf8 Class Initialized
INFO - 2020-09-25 20:29:04 --> URI Class Initialized
INFO - 2020-09-25 20:29:04 --> Router Class Initialized
INFO - 2020-09-25 20:29:04 --> Output Class Initialized
INFO - 2020-09-25 20:29:04 --> Security Class Initialized
DEBUG - 2020-09-25 20:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:29:04 --> Input Class Initialized
INFO - 2020-09-25 20:29:04 --> Language Class Initialized
INFO - 2020-09-25 20:29:04 --> Loader Class Initialized
INFO - 2020-09-25 20:29:04 --> Helper loaded: url_helper
INFO - 2020-09-25 20:29:04 --> Helper loaded: file_helper
INFO - 2020-09-25 20:29:04 --> Database Driver Class Initialized
INFO - 2020-09-25 20:29:04 --> Email Class Initialized
DEBUG - 2020-09-25 20:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:29:04 --> Controller Class Initialized
INFO - 2020-09-25 20:29:04 --> Model "Main_model" initialized
INFO - 2020-09-25 20:29:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:29:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:29:04 --> Final output sent to browser
DEBUG - 2020-09-25 20:29:04 --> Total execution time: 0.4079
INFO - 2020-09-25 20:29:05 --> Config Class Initialized
INFO - 2020-09-25 20:29:05 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:29:06 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:29:06 --> Utf8 Class Initialized
INFO - 2020-09-25 20:29:06 --> URI Class Initialized
INFO - 2020-09-25 20:29:06 --> Router Class Initialized
INFO - 2020-09-25 20:29:06 --> Output Class Initialized
INFO - 2020-09-25 20:29:06 --> Security Class Initialized
DEBUG - 2020-09-25 20:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:29:06 --> Input Class Initialized
INFO - 2020-09-25 20:29:06 --> Language Class Initialized
ERROR - 2020-09-25 20:29:06 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:30:07 --> Config Class Initialized
INFO - 2020-09-25 20:30:07 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:30:07 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:30:07 --> Utf8 Class Initialized
INFO - 2020-09-25 20:30:07 --> URI Class Initialized
INFO - 2020-09-25 20:30:07 --> Router Class Initialized
INFO - 2020-09-25 20:30:07 --> Output Class Initialized
INFO - 2020-09-25 20:30:07 --> Security Class Initialized
DEBUG - 2020-09-25 20:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:30:07 --> Input Class Initialized
INFO - 2020-09-25 20:30:07 --> Language Class Initialized
INFO - 2020-09-25 20:30:07 --> Loader Class Initialized
INFO - 2020-09-25 20:30:08 --> Helper loaded: url_helper
INFO - 2020-09-25 20:30:08 --> Helper loaded: file_helper
INFO - 2020-09-25 20:30:08 --> Database Driver Class Initialized
INFO - 2020-09-25 20:30:08 --> Email Class Initialized
DEBUG - 2020-09-25 20:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:30:08 --> Controller Class Initialized
INFO - 2020-09-25 20:30:08 --> Model "Main_model" initialized
INFO - 2020-09-25 20:30:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:30:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:30:08 --> Final output sent to browser
DEBUG - 2020-09-25 20:30:08 --> Total execution time: 0.5098
INFO - 2020-09-25 20:30:09 --> Config Class Initialized
INFO - 2020-09-25 20:30:09 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:30:10 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:30:10 --> Utf8 Class Initialized
INFO - 2020-09-25 20:30:10 --> URI Class Initialized
INFO - 2020-09-25 20:30:10 --> Router Class Initialized
INFO - 2020-09-25 20:30:10 --> Output Class Initialized
INFO - 2020-09-25 20:30:10 --> Security Class Initialized
DEBUG - 2020-09-25 20:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:30:10 --> Input Class Initialized
INFO - 2020-09-25 20:30:10 --> Language Class Initialized
ERROR - 2020-09-25 20:30:10 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:32:30 --> Config Class Initialized
INFO - 2020-09-25 20:32:30 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:32:30 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:32:30 --> Utf8 Class Initialized
INFO - 2020-09-25 20:32:30 --> URI Class Initialized
INFO - 2020-09-25 20:32:30 --> Router Class Initialized
INFO - 2020-09-25 20:32:30 --> Output Class Initialized
INFO - 2020-09-25 20:32:30 --> Security Class Initialized
DEBUG - 2020-09-25 20:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:32:30 --> Input Class Initialized
INFO - 2020-09-25 20:32:30 --> Language Class Initialized
INFO - 2020-09-25 20:32:30 --> Loader Class Initialized
INFO - 2020-09-25 20:32:30 --> Helper loaded: url_helper
INFO - 2020-09-25 20:32:30 --> Helper loaded: file_helper
INFO - 2020-09-25 20:32:30 --> Database Driver Class Initialized
INFO - 2020-09-25 20:32:30 --> Email Class Initialized
DEBUG - 2020-09-25 20:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:32:30 --> Controller Class Initialized
INFO - 2020-09-25 20:32:30 --> Model "Main_model" initialized
INFO - 2020-09-25 20:32:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:32:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:32:30 --> Final output sent to browser
DEBUG - 2020-09-25 20:32:30 --> Total execution time: 0.4352
INFO - 2020-09-25 20:32:32 --> Config Class Initialized
INFO - 2020-09-25 20:32:32 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:32:32 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:32:32 --> Utf8 Class Initialized
INFO - 2020-09-25 20:32:32 --> URI Class Initialized
INFO - 2020-09-25 20:32:32 --> Router Class Initialized
INFO - 2020-09-25 20:32:32 --> Output Class Initialized
INFO - 2020-09-25 20:32:32 --> Security Class Initialized
DEBUG - 2020-09-25 20:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:32:32 --> Input Class Initialized
INFO - 2020-09-25 20:32:32 --> Language Class Initialized
ERROR - 2020-09-25 20:32:32 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:33:12 --> Config Class Initialized
INFO - 2020-09-25 20:33:12 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:33:12 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:33:12 --> Utf8 Class Initialized
INFO - 2020-09-25 20:33:12 --> URI Class Initialized
INFO - 2020-09-25 20:33:12 --> Router Class Initialized
INFO - 2020-09-25 20:33:12 --> Output Class Initialized
INFO - 2020-09-25 20:33:12 --> Security Class Initialized
DEBUG - 2020-09-25 20:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:33:12 --> Input Class Initialized
INFO - 2020-09-25 20:33:12 --> Language Class Initialized
INFO - 2020-09-25 20:33:12 --> Loader Class Initialized
INFO - 2020-09-25 20:33:12 --> Helper loaded: url_helper
INFO - 2020-09-25 20:33:12 --> Helper loaded: file_helper
INFO - 2020-09-25 20:33:12 --> Database Driver Class Initialized
INFO - 2020-09-25 20:33:12 --> Email Class Initialized
DEBUG - 2020-09-25 20:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:33:12 --> Controller Class Initialized
INFO - 2020-09-25 20:33:12 --> Model "Main_model" initialized
INFO - 2020-09-25 20:33:12 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:33:12 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:33:12 --> Final output sent to browser
DEBUG - 2020-09-25 20:33:12 --> Total execution time: 0.4034
INFO - 2020-09-25 20:33:15 --> Config Class Initialized
INFO - 2020-09-25 20:33:15 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:33:15 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:33:15 --> Utf8 Class Initialized
INFO - 2020-09-25 20:33:15 --> URI Class Initialized
INFO - 2020-09-25 20:33:15 --> Router Class Initialized
INFO - 2020-09-25 20:33:15 --> Output Class Initialized
INFO - 2020-09-25 20:33:15 --> Security Class Initialized
DEBUG - 2020-09-25 20:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:33:15 --> Input Class Initialized
INFO - 2020-09-25 20:33:15 --> Language Class Initialized
ERROR - 2020-09-25 20:33:15 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:35:25 --> Config Class Initialized
INFO - 2020-09-25 20:35:25 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:35:25 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:35:25 --> Utf8 Class Initialized
INFO - 2020-09-25 20:35:25 --> URI Class Initialized
INFO - 2020-09-25 20:35:25 --> Router Class Initialized
INFO - 2020-09-25 20:35:25 --> Output Class Initialized
INFO - 2020-09-25 20:35:25 --> Security Class Initialized
DEBUG - 2020-09-25 20:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:35:25 --> Input Class Initialized
INFO - 2020-09-25 20:35:25 --> Language Class Initialized
INFO - 2020-09-25 20:35:25 --> Loader Class Initialized
INFO - 2020-09-25 20:35:25 --> Helper loaded: url_helper
INFO - 2020-09-25 20:35:26 --> Helper loaded: file_helper
INFO - 2020-09-25 20:35:26 --> Database Driver Class Initialized
INFO - 2020-09-25 20:35:26 --> Email Class Initialized
DEBUG - 2020-09-25 20:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:35:26 --> Controller Class Initialized
INFO - 2020-09-25 20:35:26 --> Model "Main_model" initialized
INFO - 2020-09-25 20:35:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:35:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:35:26 --> Final output sent to browser
DEBUG - 2020-09-25 20:35:26 --> Total execution time: 0.4316
INFO - 2020-09-25 20:35:27 --> Config Class Initialized
INFO - 2020-09-25 20:35:27 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:35:27 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:35:27 --> Utf8 Class Initialized
INFO - 2020-09-25 20:35:27 --> URI Class Initialized
INFO - 2020-09-25 20:35:27 --> Router Class Initialized
INFO - 2020-09-25 20:35:27 --> Output Class Initialized
INFO - 2020-09-25 20:35:27 --> Security Class Initialized
DEBUG - 2020-09-25 20:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:35:27 --> Input Class Initialized
INFO - 2020-09-25 20:35:27 --> Language Class Initialized
ERROR - 2020-09-25 20:35:27 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:36:13 --> Config Class Initialized
INFO - 2020-09-25 20:36:13 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:36:13 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:36:13 --> Utf8 Class Initialized
INFO - 2020-09-25 20:36:13 --> URI Class Initialized
INFO - 2020-09-25 20:36:13 --> Router Class Initialized
INFO - 2020-09-25 20:36:13 --> Output Class Initialized
INFO - 2020-09-25 20:36:13 --> Security Class Initialized
DEBUG - 2020-09-25 20:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:36:13 --> Input Class Initialized
INFO - 2020-09-25 20:36:13 --> Language Class Initialized
INFO - 2020-09-25 20:36:13 --> Loader Class Initialized
INFO - 2020-09-25 20:36:13 --> Helper loaded: url_helper
INFO - 2020-09-25 20:36:13 --> Helper loaded: file_helper
INFO - 2020-09-25 20:36:13 --> Database Driver Class Initialized
INFO - 2020-09-25 20:36:13 --> Email Class Initialized
DEBUG - 2020-09-25 20:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:36:13 --> Controller Class Initialized
INFO - 2020-09-25 20:36:13 --> Model "Main_model" initialized
INFO - 2020-09-25 20:36:13 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:36:13 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:36:13 --> Final output sent to browser
DEBUG - 2020-09-25 20:36:13 --> Total execution time: 0.4364
INFO - 2020-09-25 20:36:17 --> Config Class Initialized
INFO - 2020-09-25 20:36:17 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:36:17 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:36:17 --> Utf8 Class Initialized
INFO - 2020-09-25 20:36:17 --> URI Class Initialized
INFO - 2020-09-25 20:36:17 --> Router Class Initialized
INFO - 2020-09-25 20:36:18 --> Output Class Initialized
INFO - 2020-09-25 20:36:18 --> Security Class Initialized
DEBUG - 2020-09-25 20:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:36:18 --> Input Class Initialized
INFO - 2020-09-25 20:36:18 --> Language Class Initialized
ERROR - 2020-09-25 20:36:18 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:37:13 --> Config Class Initialized
INFO - 2020-09-25 20:37:13 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:37:13 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:37:13 --> Utf8 Class Initialized
INFO - 2020-09-25 20:37:13 --> URI Class Initialized
INFO - 2020-09-25 20:37:13 --> Router Class Initialized
INFO - 2020-09-25 20:37:13 --> Output Class Initialized
INFO - 2020-09-25 20:37:13 --> Security Class Initialized
DEBUG - 2020-09-25 20:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:37:13 --> Input Class Initialized
INFO - 2020-09-25 20:37:13 --> Language Class Initialized
INFO - 2020-09-25 20:37:13 --> Loader Class Initialized
INFO - 2020-09-25 20:37:13 --> Helper loaded: url_helper
INFO - 2020-09-25 20:37:13 --> Helper loaded: file_helper
INFO - 2020-09-25 20:37:13 --> Database Driver Class Initialized
INFO - 2020-09-25 20:37:13 --> Email Class Initialized
DEBUG - 2020-09-25 20:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:37:14 --> Controller Class Initialized
INFO - 2020-09-25 20:37:14 --> Model "Main_model" initialized
INFO - 2020-09-25 20:37:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-09-25 20:37:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\dmarc\application\views\domains.php 154
ERROR - 2020-09-25 20:37:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\dmarc\application\views\domains.php 154
INFO - 2020-09-25 20:37:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:37:14 --> Final output sent to browser
DEBUG - 2020-09-25 20:37:14 --> Total execution time: 0.4806
INFO - 2020-09-25 20:37:17 --> Config Class Initialized
INFO - 2020-09-25 20:37:17 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:37:17 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:37:17 --> Utf8 Class Initialized
INFO - 2020-09-25 20:37:17 --> URI Class Initialized
INFO - 2020-09-25 20:37:17 --> Router Class Initialized
INFO - 2020-09-25 20:37:17 --> Output Class Initialized
INFO - 2020-09-25 20:37:17 --> Security Class Initialized
DEBUG - 2020-09-25 20:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:37:17 --> Input Class Initialized
INFO - 2020-09-25 20:37:17 --> Language Class Initialized
ERROR - 2020-09-25 20:37:17 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:37:42 --> Config Class Initialized
INFO - 2020-09-25 20:37:42 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:37:42 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:37:43 --> Utf8 Class Initialized
INFO - 2020-09-25 20:37:43 --> URI Class Initialized
INFO - 2020-09-25 20:37:43 --> Router Class Initialized
INFO - 2020-09-25 20:37:43 --> Output Class Initialized
INFO - 2020-09-25 20:37:43 --> Security Class Initialized
DEBUG - 2020-09-25 20:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:37:43 --> Input Class Initialized
INFO - 2020-09-25 20:37:43 --> Language Class Initialized
INFO - 2020-09-25 20:37:43 --> Loader Class Initialized
INFO - 2020-09-25 20:37:43 --> Helper loaded: url_helper
INFO - 2020-09-25 20:37:43 --> Helper loaded: file_helper
INFO - 2020-09-25 20:37:43 --> Database Driver Class Initialized
INFO - 2020-09-25 20:37:43 --> Email Class Initialized
DEBUG - 2020-09-25 20:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:37:43 --> Controller Class Initialized
INFO - 2020-09-25 20:37:43 --> Model "Main_model" initialized
INFO - 2020-09-25 20:37:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:37:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:37:43 --> Final output sent to browser
DEBUG - 2020-09-25 20:37:43 --> Total execution time: 0.4421
INFO - 2020-09-25 20:37:44 --> Config Class Initialized
INFO - 2020-09-25 20:37:44 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:37:44 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:37:44 --> Utf8 Class Initialized
INFO - 2020-09-25 20:37:44 --> URI Class Initialized
INFO - 2020-09-25 20:37:44 --> Router Class Initialized
INFO - 2020-09-25 20:37:44 --> Output Class Initialized
INFO - 2020-09-25 20:37:44 --> Security Class Initialized
DEBUG - 2020-09-25 20:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:37:44 --> Input Class Initialized
INFO - 2020-09-25 20:37:44 --> Language Class Initialized
ERROR - 2020-09-25 20:37:44 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:38:47 --> Config Class Initialized
INFO - 2020-09-25 20:38:47 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:38:47 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:38:47 --> Utf8 Class Initialized
INFO - 2020-09-25 20:38:47 --> URI Class Initialized
INFO - 2020-09-25 20:38:47 --> Router Class Initialized
INFO - 2020-09-25 20:38:47 --> Output Class Initialized
INFO - 2020-09-25 20:38:47 --> Security Class Initialized
DEBUG - 2020-09-25 20:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:38:47 --> Input Class Initialized
INFO - 2020-09-25 20:38:47 --> Language Class Initialized
INFO - 2020-09-25 20:38:47 --> Loader Class Initialized
INFO - 2020-09-25 20:38:47 --> Helper loaded: url_helper
INFO - 2020-09-25 20:38:47 --> Helper loaded: file_helper
INFO - 2020-09-25 20:38:47 --> Database Driver Class Initialized
INFO - 2020-09-25 20:38:47 --> Email Class Initialized
DEBUG - 2020-09-25 20:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:38:47 --> Controller Class Initialized
INFO - 2020-09-25 20:38:47 --> Model "Main_model" initialized
INFO - 2020-09-25 20:38:47 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:38:47 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:38:47 --> Final output sent to browser
DEBUG - 2020-09-25 20:38:47 --> Total execution time: 0.4184
INFO - 2020-09-25 20:38:48 --> Config Class Initialized
INFO - 2020-09-25 20:38:49 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:38:49 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:38:49 --> Utf8 Class Initialized
INFO - 2020-09-25 20:38:49 --> URI Class Initialized
INFO - 2020-09-25 20:38:49 --> Router Class Initialized
INFO - 2020-09-25 20:38:49 --> Output Class Initialized
INFO - 2020-09-25 20:38:49 --> Security Class Initialized
DEBUG - 2020-09-25 20:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:38:49 --> Input Class Initialized
INFO - 2020-09-25 20:38:49 --> Language Class Initialized
ERROR - 2020-09-25 20:38:49 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-25 20:43:21 --> Config Class Initialized
INFO - 2020-09-25 20:43:21 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:43:21 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:43:21 --> Utf8 Class Initialized
INFO - 2020-09-25 20:43:21 --> URI Class Initialized
INFO - 2020-09-25 20:43:21 --> Router Class Initialized
INFO - 2020-09-25 20:43:21 --> Output Class Initialized
INFO - 2020-09-25 20:43:21 --> Security Class Initialized
DEBUG - 2020-09-25 20:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:43:21 --> Input Class Initialized
INFO - 2020-09-25 20:43:21 --> Language Class Initialized
INFO - 2020-09-25 20:43:21 --> Loader Class Initialized
INFO - 2020-09-25 20:43:21 --> Helper loaded: url_helper
INFO - 2020-09-25 20:43:21 --> Helper loaded: file_helper
INFO - 2020-09-25 20:43:21 --> Database Driver Class Initialized
INFO - 2020-09-25 20:43:21 --> Email Class Initialized
DEBUG - 2020-09-25 20:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:43:21 --> Controller Class Initialized
INFO - 2020-09-25 20:43:21 --> Model "Main_model" initialized
INFO - 2020-09-25 20:43:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:43:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:43:21 --> Final output sent to browser
DEBUG - 2020-09-25 20:43:21 --> Total execution time: 0.4154
INFO - 2020-09-25 20:46:22 --> Config Class Initialized
INFO - 2020-09-25 20:46:22 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:46:22 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:46:22 --> Utf8 Class Initialized
INFO - 2020-09-25 20:46:22 --> URI Class Initialized
INFO - 2020-09-25 20:46:22 --> Router Class Initialized
INFO - 2020-09-25 20:46:22 --> Output Class Initialized
INFO - 2020-09-25 20:46:22 --> Security Class Initialized
DEBUG - 2020-09-25 20:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:46:22 --> Input Class Initialized
INFO - 2020-09-25 20:46:22 --> Language Class Initialized
INFO - 2020-09-25 20:46:22 --> Loader Class Initialized
INFO - 2020-09-25 20:46:22 --> Helper loaded: url_helper
INFO - 2020-09-25 20:46:22 --> Helper loaded: file_helper
INFO - 2020-09-25 20:46:22 --> Database Driver Class Initialized
INFO - 2020-09-25 20:46:22 --> Email Class Initialized
DEBUG - 2020-09-25 20:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:46:22 --> Controller Class Initialized
INFO - 2020-09-25 20:46:22 --> Model "Main_model" initialized
INFO - 2020-09-25 20:46:22 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:46:22 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:46:22 --> Final output sent to browser
DEBUG - 2020-09-25 20:46:22 --> Total execution time: 0.4070
INFO - 2020-09-25 20:46:25 --> Config Class Initialized
INFO - 2020-09-25 20:46:25 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:46:25 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:46:25 --> Utf8 Class Initialized
INFO - 2020-09-25 20:46:25 --> URI Class Initialized
INFO - 2020-09-25 20:46:25 --> Router Class Initialized
INFO - 2020-09-25 20:46:25 --> Output Class Initialized
INFO - 2020-09-25 20:46:25 --> Security Class Initialized
DEBUG - 2020-09-25 20:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:46:25 --> Input Class Initialized
INFO - 2020-09-25 20:46:25 --> Language Class Initialized
INFO - 2020-09-25 20:46:25 --> Loader Class Initialized
INFO - 2020-09-25 20:46:25 --> Helper loaded: url_helper
INFO - 2020-09-25 20:46:25 --> Helper loaded: file_helper
INFO - 2020-09-25 20:46:25 --> Database Driver Class Initialized
INFO - 2020-09-25 20:46:25 --> Email Class Initialized
DEBUG - 2020-09-25 20:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:46:25 --> Controller Class Initialized
INFO - 2020-09-25 20:46:25 --> Model "Main_model" initialized
INFO - 2020-09-25 20:46:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:46:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-09-25 20:46:25 --> Final output sent to browser
DEBUG - 2020-09-25 20:46:25 --> Total execution time: 0.4499
INFO - 2020-09-25 20:55:27 --> Config Class Initialized
INFO - 2020-09-25 20:55:27 --> Hooks Class Initialized
DEBUG - 2020-09-25 20:55:27 --> UTF-8 Support Enabled
INFO - 2020-09-25 20:55:27 --> Utf8 Class Initialized
INFO - 2020-09-25 20:55:27 --> URI Class Initialized
INFO - 2020-09-25 20:55:27 --> Router Class Initialized
INFO - 2020-09-25 20:55:27 --> Output Class Initialized
INFO - 2020-09-25 20:55:27 --> Security Class Initialized
DEBUG - 2020-09-25 20:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 20:55:27 --> Input Class Initialized
INFO - 2020-09-25 20:55:27 --> Language Class Initialized
INFO - 2020-09-25 20:55:27 --> Loader Class Initialized
INFO - 2020-09-25 20:55:27 --> Helper loaded: url_helper
INFO - 2020-09-25 20:55:27 --> Helper loaded: file_helper
INFO - 2020-09-25 20:55:27 --> Database Driver Class Initialized
INFO - 2020-09-25 20:55:27 --> Email Class Initialized
DEBUG - 2020-09-25 20:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 20:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 20:55:27 --> Controller Class Initialized
INFO - 2020-09-25 20:55:27 --> Model "Main_model" initialized
INFO - 2020-09-25 20:55:27 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-25 20:55:27 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-09-25 20:55:27 --> Final output sent to browser
DEBUG - 2020-09-25 20:55:28 --> Total execution time: 0.4160
