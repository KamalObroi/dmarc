<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-05 09:06:20 --> Config Class Initialized
INFO - 2020-10-05 09:06:20 --> Hooks Class Initialized
DEBUG - 2020-10-05 09:06:20 --> UTF-8 Support Enabled
INFO - 2020-10-05 09:06:20 --> Utf8 Class Initialized
INFO - 2020-10-05 09:06:20 --> URI Class Initialized
DEBUG - 2020-10-05 09:06:20 --> No URI present. Default controller set.
INFO - 2020-10-05 09:06:20 --> Router Class Initialized
INFO - 2020-10-05 09:06:20 --> Output Class Initialized
INFO - 2020-10-05 09:06:21 --> Security Class Initialized
DEBUG - 2020-10-05 09:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 09:06:21 --> Input Class Initialized
INFO - 2020-10-05 09:06:21 --> Language Class Initialized
INFO - 2020-10-05 09:06:21 --> Loader Class Initialized
INFO - 2020-10-05 09:06:21 --> Helper loaded: url_helper
INFO - 2020-10-05 09:06:21 --> Helper loaded: file_helper
INFO - 2020-10-05 09:06:21 --> Database Driver Class Initialized
INFO - 2020-10-05 09:06:21 --> Email Class Initialized
DEBUG - 2020-10-05 09:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 09:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 09:06:21 --> Controller Class Initialized
INFO - 2020-10-05 09:06:21 --> Model "Main_model" initialized
INFO - 2020-10-05 09:06:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-10-05 09:06:21 --> Final output sent to browser
DEBUG - 2020-10-05 09:06:21 --> Total execution time: 1.1752
INFO - 2020-10-05 09:06:25 --> Config Class Initialized
INFO - 2020-10-05 09:06:25 --> Hooks Class Initialized
DEBUG - 2020-10-05 09:06:25 --> UTF-8 Support Enabled
INFO - 2020-10-05 09:06:25 --> Utf8 Class Initialized
INFO - 2020-10-05 09:06:25 --> URI Class Initialized
INFO - 2020-10-05 09:06:25 --> Router Class Initialized
INFO - 2020-10-05 09:06:25 --> Output Class Initialized
INFO - 2020-10-05 09:06:25 --> Security Class Initialized
DEBUG - 2020-10-05 09:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 09:06:25 --> Input Class Initialized
INFO - 2020-10-05 09:06:25 --> Language Class Initialized
INFO - 2020-10-05 09:06:25 --> Loader Class Initialized
INFO - 2020-10-05 09:06:25 --> Helper loaded: url_helper
INFO - 2020-10-05 09:06:25 --> Helper loaded: file_helper
INFO - 2020-10-05 09:06:25 --> Database Driver Class Initialized
INFO - 2020-10-05 09:06:25 --> Email Class Initialized
DEBUG - 2020-10-05 09:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 09:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 09:06:25 --> Controller Class Initialized
INFO - 2020-10-05 09:06:25 --> Model "Main_model" initialized
INFO - 2020-10-05 09:06:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-10-05 09:06:25 --> Final output sent to browser
DEBUG - 2020-10-05 09:06:25 --> Total execution time: 0.3231
INFO - 2020-10-05 09:06:30 --> Config Class Initialized
INFO - 2020-10-05 09:06:30 --> Hooks Class Initialized
DEBUG - 2020-10-05 09:06:30 --> UTF-8 Support Enabled
INFO - 2020-10-05 09:06:30 --> Utf8 Class Initialized
INFO - 2020-10-05 09:06:30 --> URI Class Initialized
INFO - 2020-10-05 09:06:30 --> Router Class Initialized
INFO - 2020-10-05 09:06:30 --> Output Class Initialized
INFO - 2020-10-05 09:06:30 --> Security Class Initialized
DEBUG - 2020-10-05 09:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 09:06:30 --> Input Class Initialized
INFO - 2020-10-05 09:06:30 --> Language Class Initialized
INFO - 2020-10-05 09:06:30 --> Loader Class Initialized
INFO - 2020-10-05 09:06:30 --> Helper loaded: url_helper
INFO - 2020-10-05 09:06:30 --> Helper loaded: file_helper
INFO - 2020-10-05 09:06:30 --> Database Driver Class Initialized
INFO - 2020-10-05 09:06:30 --> Email Class Initialized
DEBUG - 2020-10-05 09:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 09:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 09:06:30 --> Controller Class Initialized
INFO - 2020-10-05 09:06:30 --> Model "Main_model" initialized
INFO - 2020-10-05 09:06:30 --> Config Class Initialized
INFO - 2020-10-05 09:06:30 --> Hooks Class Initialized
DEBUG - 2020-10-05 09:06:30 --> UTF-8 Support Enabled
INFO - 2020-10-05 09:06:30 --> Utf8 Class Initialized
INFO - 2020-10-05 09:06:30 --> URI Class Initialized
INFO - 2020-10-05 09:06:30 --> Router Class Initialized
INFO - 2020-10-05 09:06:30 --> Output Class Initialized
INFO - 2020-10-05 09:06:30 --> Security Class Initialized
DEBUG - 2020-10-05 09:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 09:06:30 --> Input Class Initialized
INFO - 2020-10-05 09:06:30 --> Language Class Initialized
INFO - 2020-10-05 09:06:30 --> Loader Class Initialized
INFO - 2020-10-05 09:06:30 --> Helper loaded: url_helper
INFO - 2020-10-05 09:06:31 --> Helper loaded: file_helper
INFO - 2020-10-05 09:06:31 --> Database Driver Class Initialized
INFO - 2020-10-05 09:06:31 --> Email Class Initialized
DEBUG - 2020-10-05 09:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 09:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 09:06:31 --> Controller Class Initialized
INFO - 2020-10-05 09:06:31 --> Model "Main_model" initialized
INFO - 2020-10-05 09:06:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 09:06:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 09:06:31 --> Final output sent to browser
DEBUG - 2020-10-05 09:06:31 --> Total execution time: 0.3493
INFO - 2020-10-05 11:32:31 --> Config Class Initialized
INFO - 2020-10-05 11:32:31 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:32:31 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:32:31 --> Utf8 Class Initialized
INFO - 2020-10-05 11:32:31 --> URI Class Initialized
INFO - 2020-10-05 11:32:31 --> Router Class Initialized
INFO - 2020-10-05 11:32:31 --> Output Class Initialized
INFO - 2020-10-05 11:32:31 --> Security Class Initialized
DEBUG - 2020-10-05 11:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:32:31 --> Input Class Initialized
INFO - 2020-10-05 11:32:31 --> Language Class Initialized
INFO - 2020-10-05 11:32:31 --> Loader Class Initialized
INFO - 2020-10-05 11:32:31 --> Helper loaded: url_helper
INFO - 2020-10-05 11:32:31 --> Helper loaded: file_helper
INFO - 2020-10-05 11:32:31 --> Database Driver Class Initialized
INFO - 2020-10-05 11:32:31 --> Email Class Initialized
DEBUG - 2020-10-05 11:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:32:31 --> Controller Class Initialized
INFO - 2020-10-05 11:32:31 --> Model "Main_model" initialized
INFO - 2020-10-05 11:32:31 --> Config Class Initialized
INFO - 2020-10-05 11:32:31 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:32:31 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:32:31 --> Utf8 Class Initialized
INFO - 2020-10-05 11:32:31 --> URI Class Initialized
INFO - 2020-10-05 11:32:31 --> Router Class Initialized
INFO - 2020-10-05 11:32:31 --> Output Class Initialized
INFO - 2020-10-05 11:32:31 --> Security Class Initialized
DEBUG - 2020-10-05 11:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:32:31 --> Input Class Initialized
INFO - 2020-10-05 11:32:32 --> Language Class Initialized
INFO - 2020-10-05 11:32:32 --> Loader Class Initialized
INFO - 2020-10-05 11:32:32 --> Helper loaded: url_helper
INFO - 2020-10-05 11:32:32 --> Helper loaded: file_helper
INFO - 2020-10-05 11:32:32 --> Database Driver Class Initialized
INFO - 2020-10-05 11:32:32 --> Email Class Initialized
DEBUG - 2020-10-05 11:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:32:32 --> Controller Class Initialized
INFO - 2020-10-05 11:32:32 --> Model "Main_model" initialized
INFO - 2020-10-05 11:32:32 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-10-05 11:32:32 --> Final output sent to browser
DEBUG - 2020-10-05 11:32:32 --> Total execution time: 0.3282
INFO - 2020-10-05 11:32:34 --> Config Class Initialized
INFO - 2020-10-05 11:32:34 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:32:34 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:32:34 --> Utf8 Class Initialized
INFO - 2020-10-05 11:32:34 --> URI Class Initialized
INFO - 2020-10-05 11:32:34 --> Router Class Initialized
INFO - 2020-10-05 11:32:34 --> Output Class Initialized
INFO - 2020-10-05 11:32:34 --> Security Class Initialized
DEBUG - 2020-10-05 11:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:32:34 --> Input Class Initialized
INFO - 2020-10-05 11:32:34 --> Language Class Initialized
INFO - 2020-10-05 11:32:34 --> Loader Class Initialized
INFO - 2020-10-05 11:32:34 --> Helper loaded: url_helper
INFO - 2020-10-05 11:32:34 --> Helper loaded: file_helper
INFO - 2020-10-05 11:32:34 --> Database Driver Class Initialized
INFO - 2020-10-05 11:32:34 --> Email Class Initialized
DEBUG - 2020-10-05 11:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:32:34 --> Controller Class Initialized
INFO - 2020-10-05 11:32:34 --> Model "Main_model" initialized
INFO - 2020-10-05 11:32:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 11:32:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 11:32:34 --> Final output sent to browser
DEBUG - 2020-10-05 11:32:34 --> Total execution time: 0.3538
INFO - 2020-10-05 11:44:24 --> Config Class Initialized
INFO - 2020-10-05 11:44:24 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:44:25 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:44:25 --> Utf8 Class Initialized
INFO - 2020-10-05 11:44:25 --> URI Class Initialized
INFO - 2020-10-05 11:44:25 --> Router Class Initialized
INFO - 2020-10-05 11:44:25 --> Output Class Initialized
INFO - 2020-10-05 11:44:25 --> Security Class Initialized
DEBUG - 2020-10-05 11:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:44:25 --> Input Class Initialized
INFO - 2020-10-05 11:44:25 --> Language Class Initialized
INFO - 2020-10-05 11:44:25 --> Loader Class Initialized
INFO - 2020-10-05 11:44:25 --> Helper loaded: url_helper
INFO - 2020-10-05 11:44:25 --> Helper loaded: file_helper
INFO - 2020-10-05 11:44:25 --> Database Driver Class Initialized
INFO - 2020-10-05 11:44:25 --> Email Class Initialized
DEBUG - 2020-10-05 11:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:44:25 --> Controller Class Initialized
INFO - 2020-10-05 11:44:25 --> Model "Main_model" initialized
INFO - 2020-10-05 11:44:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 11:44:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 11:44:25 --> Final output sent to browser
DEBUG - 2020-10-05 11:44:25 --> Total execution time: 0.4215
INFO - 2020-10-05 11:44:28 --> Config Class Initialized
INFO - 2020-10-05 11:44:28 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:44:28 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:44:28 --> Utf8 Class Initialized
INFO - 2020-10-05 11:44:28 --> URI Class Initialized
INFO - 2020-10-05 11:44:28 --> Router Class Initialized
INFO - 2020-10-05 11:44:28 --> Output Class Initialized
INFO - 2020-10-05 11:44:29 --> Security Class Initialized
DEBUG - 2020-10-05 11:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:44:29 --> Input Class Initialized
INFO - 2020-10-05 11:44:29 --> Language Class Initialized
ERROR - 2020-10-05 11:44:29 --> 404 Page Not Found: Alertevents/index
INFO - 2020-10-05 11:45:18 --> Config Class Initialized
INFO - 2020-10-05 11:45:18 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:45:18 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:45:18 --> Utf8 Class Initialized
INFO - 2020-10-05 11:45:18 --> URI Class Initialized
INFO - 2020-10-05 11:45:18 --> Router Class Initialized
INFO - 2020-10-05 11:45:18 --> Output Class Initialized
INFO - 2020-10-05 11:45:18 --> Security Class Initialized
DEBUG - 2020-10-05 11:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:45:18 --> Input Class Initialized
INFO - 2020-10-05 11:45:18 --> Language Class Initialized
ERROR - 2020-10-05 11:45:18 --> 404 Page Not Found: Alertevents/index
INFO - 2020-10-05 11:45:20 --> Config Class Initialized
INFO - 2020-10-05 11:45:20 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:45:20 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:45:20 --> Utf8 Class Initialized
INFO - 2020-10-05 11:45:20 --> URI Class Initialized
INFO - 2020-10-05 11:45:20 --> Router Class Initialized
INFO - 2020-10-05 11:45:20 --> Output Class Initialized
INFO - 2020-10-05 11:45:20 --> Security Class Initialized
DEBUG - 2020-10-05 11:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:45:20 --> Input Class Initialized
INFO - 2020-10-05 11:45:20 --> Language Class Initialized
ERROR - 2020-10-05 11:45:20 --> 404 Page Not Found: Alertevents/index
INFO - 2020-10-05 11:46:01 --> Config Class Initialized
INFO - 2020-10-05 11:46:01 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:46:01 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:46:01 --> Utf8 Class Initialized
INFO - 2020-10-05 11:46:01 --> URI Class Initialized
INFO - 2020-10-05 11:46:01 --> Router Class Initialized
INFO - 2020-10-05 11:46:01 --> Output Class Initialized
INFO - 2020-10-05 11:46:01 --> Security Class Initialized
DEBUG - 2020-10-05 11:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:46:01 --> Input Class Initialized
INFO - 2020-10-05 11:46:01 --> Language Class Initialized
INFO - 2020-10-05 11:46:01 --> Loader Class Initialized
INFO - 2020-10-05 11:46:01 --> Helper loaded: url_helper
INFO - 2020-10-05 11:46:01 --> Helper loaded: file_helper
INFO - 2020-10-05 11:46:01 --> Database Driver Class Initialized
INFO - 2020-10-05 11:46:01 --> Email Class Initialized
DEBUG - 2020-10-05 11:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:46:01 --> Controller Class Initialized
INFO - 2020-10-05 11:46:01 --> Model "Main_model" initialized
INFO - 2020-10-05 11:46:01 --> Config Class Initialized
INFO - 2020-10-05 11:46:01 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:46:01 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:46:01 --> Utf8 Class Initialized
INFO - 2020-10-05 11:46:01 --> URI Class Initialized
INFO - 2020-10-05 11:46:01 --> Router Class Initialized
INFO - 2020-10-05 11:46:01 --> Output Class Initialized
INFO - 2020-10-05 11:46:01 --> Security Class Initialized
DEBUG - 2020-10-05 11:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:46:01 --> Input Class Initialized
INFO - 2020-10-05 11:46:01 --> Language Class Initialized
INFO - 2020-10-05 11:46:01 --> Loader Class Initialized
INFO - 2020-10-05 11:46:01 --> Helper loaded: url_helper
INFO - 2020-10-05 11:46:01 --> Helper loaded: file_helper
INFO - 2020-10-05 11:46:01 --> Database Driver Class Initialized
INFO - 2020-10-05 11:46:01 --> Email Class Initialized
DEBUG - 2020-10-05 11:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:46:01 --> Controller Class Initialized
INFO - 2020-10-05 11:46:01 --> Model "Main_model" initialized
INFO - 2020-10-05 11:46:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-10-05 11:46:01 --> Final output sent to browser
DEBUG - 2020-10-05 11:46:01 --> Total execution time: 0.3302
INFO - 2020-10-05 11:46:07 --> Config Class Initialized
INFO - 2020-10-05 11:46:07 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:46:07 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:46:08 --> Utf8 Class Initialized
INFO - 2020-10-05 11:46:08 --> URI Class Initialized
INFO - 2020-10-05 11:46:08 --> Router Class Initialized
INFO - 2020-10-05 11:46:08 --> Output Class Initialized
INFO - 2020-10-05 11:46:08 --> Security Class Initialized
DEBUG - 2020-10-05 11:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:46:08 --> Input Class Initialized
INFO - 2020-10-05 11:46:08 --> Language Class Initialized
INFO - 2020-10-05 11:46:08 --> Loader Class Initialized
INFO - 2020-10-05 11:46:08 --> Helper loaded: url_helper
INFO - 2020-10-05 11:46:08 --> Helper loaded: file_helper
INFO - 2020-10-05 11:46:08 --> Database Driver Class Initialized
INFO - 2020-10-05 11:46:08 --> Email Class Initialized
DEBUG - 2020-10-05 11:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:46:08 --> Controller Class Initialized
INFO - 2020-10-05 11:46:08 --> Model "Main_model" initialized
INFO - 2020-10-05 11:46:08 --> Config Class Initialized
INFO - 2020-10-05 11:46:08 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:46:08 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:46:08 --> Utf8 Class Initialized
INFO - 2020-10-05 11:46:08 --> URI Class Initialized
INFO - 2020-10-05 11:46:08 --> Router Class Initialized
INFO - 2020-10-05 11:46:08 --> Output Class Initialized
INFO - 2020-10-05 11:46:08 --> Security Class Initialized
DEBUG - 2020-10-05 11:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:46:08 --> Input Class Initialized
INFO - 2020-10-05 11:46:08 --> Language Class Initialized
INFO - 2020-10-05 11:46:08 --> Loader Class Initialized
INFO - 2020-10-05 11:46:08 --> Helper loaded: url_helper
INFO - 2020-10-05 11:46:08 --> Helper loaded: file_helper
INFO - 2020-10-05 11:46:08 --> Database Driver Class Initialized
INFO - 2020-10-05 11:46:08 --> Email Class Initialized
DEBUG - 2020-10-05 11:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:46:08 --> Controller Class Initialized
INFO - 2020-10-05 11:46:08 --> Model "Main_model" initialized
INFO - 2020-10-05 11:46:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 11:46:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 11:46:08 --> Final output sent to browser
DEBUG - 2020-10-05 11:46:08 --> Total execution time: 0.3389
INFO - 2020-10-05 11:46:11 --> Config Class Initialized
INFO - 2020-10-05 11:46:12 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:46:12 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:46:12 --> Utf8 Class Initialized
INFO - 2020-10-05 11:46:12 --> URI Class Initialized
INFO - 2020-10-05 11:46:12 --> Router Class Initialized
INFO - 2020-10-05 11:46:12 --> Output Class Initialized
INFO - 2020-10-05 11:46:12 --> Security Class Initialized
DEBUG - 2020-10-05 11:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:46:12 --> Input Class Initialized
INFO - 2020-10-05 11:46:12 --> Language Class Initialized
INFO - 2020-10-05 11:46:12 --> Loader Class Initialized
INFO - 2020-10-05 11:46:12 --> Helper loaded: url_helper
INFO - 2020-10-05 11:46:12 --> Helper loaded: file_helper
INFO - 2020-10-05 11:46:12 --> Database Driver Class Initialized
INFO - 2020-10-05 11:46:12 --> Email Class Initialized
DEBUG - 2020-10-05 11:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:46:12 --> Controller Class Initialized
INFO - 2020-10-05 11:46:12 --> Model "Main_model" initialized
INFO - 2020-10-05 11:46:12 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 11:46:12 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertevents.php
INFO - 2020-10-05 11:46:12 --> Final output sent to browser
DEBUG - 2020-10-05 11:46:12 --> Total execution time: 0.3631
INFO - 2020-10-05 11:51:58 --> Config Class Initialized
INFO - 2020-10-05 11:51:58 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:51:58 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:51:58 --> Utf8 Class Initialized
INFO - 2020-10-05 11:51:58 --> URI Class Initialized
INFO - 2020-10-05 11:51:58 --> Router Class Initialized
INFO - 2020-10-05 11:51:58 --> Output Class Initialized
INFO - 2020-10-05 11:51:58 --> Security Class Initialized
DEBUG - 2020-10-05 11:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:51:58 --> Input Class Initialized
INFO - 2020-10-05 11:51:58 --> Language Class Initialized
INFO - 2020-10-05 11:51:58 --> Loader Class Initialized
INFO - 2020-10-05 11:51:58 --> Helper loaded: url_helper
INFO - 2020-10-05 11:51:58 --> Helper loaded: file_helper
INFO - 2020-10-05 11:51:58 --> Database Driver Class Initialized
INFO - 2020-10-05 11:51:58 --> Email Class Initialized
DEBUG - 2020-10-05 11:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:51:58 --> Controller Class Initialized
INFO - 2020-10-05 11:51:58 --> Model "Main_model" initialized
INFO - 2020-10-05 11:51:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 11:51:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertevents.php
INFO - 2020-10-05 11:51:58 --> Final output sent to browser
DEBUG - 2020-10-05 11:51:58 --> Total execution time: 0.3691
INFO - 2020-10-05 11:52:04 --> Config Class Initialized
INFO - 2020-10-05 11:52:04 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:52:04 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:52:04 --> Utf8 Class Initialized
INFO - 2020-10-05 11:52:04 --> URI Class Initialized
INFO - 2020-10-05 11:52:04 --> Router Class Initialized
INFO - 2020-10-05 11:52:04 --> Output Class Initialized
INFO - 2020-10-05 11:52:04 --> Security Class Initialized
DEBUG - 2020-10-05 11:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:52:04 --> Input Class Initialized
INFO - 2020-10-05 11:52:04 --> Language Class Initialized
ERROR - 2020-10-05 11:52:04 --> 404 Page Not Found: Alertconfig/index
INFO - 2020-10-05 11:53:40 --> Config Class Initialized
INFO - 2020-10-05 11:53:40 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:53:40 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:53:40 --> Utf8 Class Initialized
INFO - 2020-10-05 11:53:40 --> URI Class Initialized
INFO - 2020-10-05 11:53:40 --> Router Class Initialized
INFO - 2020-10-05 11:53:40 --> Output Class Initialized
INFO - 2020-10-05 11:53:40 --> Security Class Initialized
DEBUG - 2020-10-05 11:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:53:40 --> Input Class Initialized
INFO - 2020-10-05 11:53:40 --> Language Class Initialized
INFO - 2020-10-05 11:53:40 --> Loader Class Initialized
INFO - 2020-10-05 11:53:40 --> Helper loaded: url_helper
INFO - 2020-10-05 11:53:40 --> Helper loaded: file_helper
INFO - 2020-10-05 11:53:40 --> Database Driver Class Initialized
INFO - 2020-10-05 11:53:40 --> Email Class Initialized
DEBUG - 2020-10-05 11:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:53:40 --> Controller Class Initialized
INFO - 2020-10-05 11:53:40 --> Model "Main_model" initialized
INFO - 2020-10-05 11:53:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 11:53:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 11:53:40 --> Final output sent to browser
DEBUG - 2020-10-05 11:53:40 --> Total execution time: 0.3900
INFO - 2020-10-05 11:56:08 --> Config Class Initialized
INFO - 2020-10-05 11:56:08 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:56:08 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:56:08 --> Utf8 Class Initialized
INFO - 2020-10-05 11:56:08 --> URI Class Initialized
INFO - 2020-10-05 11:56:08 --> Router Class Initialized
INFO - 2020-10-05 11:56:08 --> Output Class Initialized
INFO - 2020-10-05 11:56:08 --> Security Class Initialized
DEBUG - 2020-10-05 11:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:56:08 --> Input Class Initialized
INFO - 2020-10-05 11:56:08 --> Language Class Initialized
INFO - 2020-10-05 11:56:08 --> Loader Class Initialized
INFO - 2020-10-05 11:56:08 --> Helper loaded: url_helper
INFO - 2020-10-05 11:56:08 --> Helper loaded: file_helper
INFO - 2020-10-05 11:56:08 --> Database Driver Class Initialized
INFO - 2020-10-05 11:56:08 --> Email Class Initialized
DEBUG - 2020-10-05 11:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:56:08 --> Controller Class Initialized
INFO - 2020-10-05 11:56:08 --> Model "Main_model" initialized
INFO - 2020-10-05 11:56:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 11:56:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 11:56:08 --> Final output sent to browser
DEBUG - 2020-10-05 11:56:08 --> Total execution time: 0.3380
INFO - 2020-10-05 11:56:49 --> Config Class Initialized
INFO - 2020-10-05 11:56:49 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:56:49 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:56:49 --> Utf8 Class Initialized
INFO - 2020-10-05 11:56:49 --> URI Class Initialized
INFO - 2020-10-05 11:56:49 --> Router Class Initialized
INFO - 2020-10-05 11:56:49 --> Output Class Initialized
INFO - 2020-10-05 11:56:49 --> Security Class Initialized
DEBUG - 2020-10-05 11:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:56:49 --> Input Class Initialized
INFO - 2020-10-05 11:56:49 --> Language Class Initialized
INFO - 2020-10-05 11:56:50 --> Loader Class Initialized
INFO - 2020-10-05 11:56:50 --> Helper loaded: url_helper
INFO - 2020-10-05 11:56:50 --> Helper loaded: file_helper
INFO - 2020-10-05 11:56:50 --> Database Driver Class Initialized
INFO - 2020-10-05 11:56:50 --> Email Class Initialized
DEBUG - 2020-10-05 11:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:56:50 --> Controller Class Initialized
INFO - 2020-10-05 11:56:50 --> Model "Main_model" initialized
INFO - 2020-10-05 11:56:50 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 11:56:50 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 11:56:50 --> Final output sent to browser
DEBUG - 2020-10-05 11:56:50 --> Total execution time: 0.3685
INFO - 2020-10-05 11:56:52 --> Config Class Initialized
INFO - 2020-10-05 11:56:52 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:56:52 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:56:52 --> Utf8 Class Initialized
INFO - 2020-10-05 11:56:52 --> URI Class Initialized
INFO - 2020-10-05 11:56:52 --> Router Class Initialized
INFO - 2020-10-05 11:56:52 --> Output Class Initialized
INFO - 2020-10-05 11:56:52 --> Security Class Initialized
DEBUG - 2020-10-05 11:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:56:52 --> Input Class Initialized
INFO - 2020-10-05 11:56:52 --> Language Class Initialized
ERROR - 2020-10-05 11:56:52 --> 404 Page Not Found: Createalert/index
INFO - 2020-10-05 11:57:27 --> Config Class Initialized
INFO - 2020-10-05 11:57:27 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:57:27 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:57:27 --> Utf8 Class Initialized
INFO - 2020-10-05 11:57:27 --> URI Class Initialized
INFO - 2020-10-05 11:57:27 --> Router Class Initialized
INFO - 2020-10-05 11:57:27 --> Output Class Initialized
INFO - 2020-10-05 11:57:27 --> Security Class Initialized
DEBUG - 2020-10-05 11:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:57:27 --> Input Class Initialized
INFO - 2020-10-05 11:57:27 --> Language Class Initialized
INFO - 2020-10-05 11:57:27 --> Loader Class Initialized
INFO - 2020-10-05 11:57:27 --> Helper loaded: url_helper
INFO - 2020-10-05 11:57:27 --> Helper loaded: file_helper
INFO - 2020-10-05 11:57:28 --> Database Driver Class Initialized
INFO - 2020-10-05 11:57:28 --> Email Class Initialized
DEBUG - 2020-10-05 11:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:57:28 --> Controller Class Initialized
INFO - 2020-10-05 11:57:28 --> Model "Main_model" initialized
INFO - 2020-10-05 11:57:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 11:57:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 11:57:28 --> Final output sent to browser
DEBUG - 2020-10-05 11:57:28 --> Total execution time: 0.3663
INFO - 2020-10-05 11:58:26 --> Config Class Initialized
INFO - 2020-10-05 11:58:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:58:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:58:26 --> Utf8 Class Initialized
INFO - 2020-10-05 11:58:26 --> URI Class Initialized
INFO - 2020-10-05 11:58:26 --> Router Class Initialized
INFO - 2020-10-05 11:58:26 --> Output Class Initialized
INFO - 2020-10-05 11:58:26 --> Security Class Initialized
DEBUG - 2020-10-05 11:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:58:26 --> Input Class Initialized
INFO - 2020-10-05 11:58:26 --> Language Class Initialized
INFO - 2020-10-05 11:58:26 --> Loader Class Initialized
INFO - 2020-10-05 11:58:26 --> Helper loaded: url_helper
INFO - 2020-10-05 11:58:26 --> Helper loaded: file_helper
INFO - 2020-10-05 11:58:26 --> Database Driver Class Initialized
INFO - 2020-10-05 11:58:26 --> Email Class Initialized
DEBUG - 2020-10-05 11:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:58:26 --> Controller Class Initialized
INFO - 2020-10-05 11:58:26 --> Model "Main_model" initialized
INFO - 2020-10-05 11:58:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 11:58:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 11:58:26 --> Final output sent to browser
DEBUG - 2020-10-05 11:58:26 --> Total execution time: 0.3619
INFO - 2020-10-05 11:58:47 --> Config Class Initialized
INFO - 2020-10-05 11:58:47 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:58:47 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:58:47 --> Utf8 Class Initialized
INFO - 2020-10-05 11:58:47 --> URI Class Initialized
INFO - 2020-10-05 11:58:47 --> Router Class Initialized
INFO - 2020-10-05 11:58:47 --> Output Class Initialized
INFO - 2020-10-05 11:58:47 --> Security Class Initialized
DEBUG - 2020-10-05 11:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:58:47 --> Input Class Initialized
INFO - 2020-10-05 11:58:47 --> Language Class Initialized
INFO - 2020-10-05 11:58:47 --> Loader Class Initialized
INFO - 2020-10-05 11:58:47 --> Helper loaded: url_helper
INFO - 2020-10-05 11:58:47 --> Helper loaded: file_helper
INFO - 2020-10-05 11:58:47 --> Database Driver Class Initialized
INFO - 2020-10-05 11:58:47 --> Email Class Initialized
DEBUG - 2020-10-05 11:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 11:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:58:47 --> Controller Class Initialized
INFO - 2020-10-05 11:58:47 --> Model "Main_model" initialized
INFO - 2020-10-05 11:58:47 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 11:58:47 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 11:58:47 --> Final output sent to browser
DEBUG - 2020-10-05 11:58:47 --> Total execution time: 0.3534
INFO - 2020-10-05 11:58:52 --> Config Class Initialized
INFO - 2020-10-05 11:58:52 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:58:52 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:58:52 --> Utf8 Class Initialized
INFO - 2020-10-05 11:58:52 --> URI Class Initialized
INFO - 2020-10-05 11:58:52 --> Router Class Initialized
INFO - 2020-10-05 11:58:52 --> Output Class Initialized
INFO - 2020-10-05 11:58:52 --> Security Class Initialized
DEBUG - 2020-10-05 11:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:58:52 --> Input Class Initialized
INFO - 2020-10-05 11:58:52 --> Language Class Initialized
ERROR - 2020-10-05 11:58:52 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 12:01:29 --> Config Class Initialized
INFO - 2020-10-05 12:01:29 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:01:29 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:01:29 --> Utf8 Class Initialized
INFO - 2020-10-05 12:01:29 --> URI Class Initialized
INFO - 2020-10-05 12:01:29 --> Router Class Initialized
INFO - 2020-10-05 12:01:29 --> Output Class Initialized
INFO - 2020-10-05 12:01:29 --> Security Class Initialized
DEBUG - 2020-10-05 12:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:01:29 --> Input Class Initialized
INFO - 2020-10-05 12:01:29 --> Language Class Initialized
INFO - 2020-10-05 12:01:29 --> Loader Class Initialized
INFO - 2020-10-05 12:01:29 --> Helper loaded: url_helper
INFO - 2020-10-05 12:01:29 --> Helper loaded: file_helper
INFO - 2020-10-05 12:01:29 --> Database Driver Class Initialized
INFO - 2020-10-05 12:01:29 --> Email Class Initialized
DEBUG - 2020-10-05 12:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:01:29 --> Controller Class Initialized
INFO - 2020-10-05 12:01:29 --> Model "Main_model" initialized
INFO - 2020-10-05 12:01:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:01:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:01:29 --> Final output sent to browser
DEBUG - 2020-10-05 12:01:29 --> Total execution time: 0.3735
INFO - 2020-10-05 12:01:31 --> Config Class Initialized
INFO - 2020-10-05 12:01:31 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:01:31 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:01:31 --> Utf8 Class Initialized
INFO - 2020-10-05 12:01:31 --> URI Class Initialized
INFO - 2020-10-05 12:01:31 --> Router Class Initialized
INFO - 2020-10-05 12:01:31 --> Output Class Initialized
INFO - 2020-10-05 12:01:31 --> Security Class Initialized
DEBUG - 2020-10-05 12:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:01:31 --> Input Class Initialized
INFO - 2020-10-05 12:01:31 --> Language Class Initialized
ERROR - 2020-10-05 12:01:31 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 12:01:54 --> Config Class Initialized
INFO - 2020-10-05 12:01:54 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:01:54 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:01:54 --> Utf8 Class Initialized
INFO - 2020-10-05 12:01:54 --> URI Class Initialized
INFO - 2020-10-05 12:01:54 --> Router Class Initialized
INFO - 2020-10-05 12:01:54 --> Output Class Initialized
INFO - 2020-10-05 12:01:54 --> Security Class Initialized
DEBUG - 2020-10-05 12:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:01:54 --> Input Class Initialized
INFO - 2020-10-05 12:01:54 --> Language Class Initialized
INFO - 2020-10-05 12:01:54 --> Loader Class Initialized
INFO - 2020-10-05 12:01:54 --> Helper loaded: url_helper
INFO - 2020-10-05 12:01:54 --> Helper loaded: file_helper
INFO - 2020-10-05 12:01:54 --> Database Driver Class Initialized
INFO - 2020-10-05 12:01:54 --> Email Class Initialized
DEBUG - 2020-10-05 12:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:01:54 --> Controller Class Initialized
INFO - 2020-10-05 12:01:54 --> Model "Main_model" initialized
INFO - 2020-10-05 12:01:54 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:01:54 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:01:54 --> Final output sent to browser
DEBUG - 2020-10-05 12:01:54 --> Total execution time: 0.3818
INFO - 2020-10-05 12:01:55 --> Config Class Initialized
INFO - 2020-10-05 12:01:56 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:01:56 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:01:56 --> Utf8 Class Initialized
INFO - 2020-10-05 12:01:56 --> URI Class Initialized
INFO - 2020-10-05 12:01:56 --> Router Class Initialized
INFO - 2020-10-05 12:01:56 --> Output Class Initialized
INFO - 2020-10-05 12:01:56 --> Security Class Initialized
DEBUG - 2020-10-05 12:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:01:56 --> Input Class Initialized
INFO - 2020-10-05 12:01:56 --> Language Class Initialized
ERROR - 2020-10-05 12:01:56 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 12:02:24 --> Config Class Initialized
INFO - 2020-10-05 12:02:24 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:02:24 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:02:24 --> Utf8 Class Initialized
INFO - 2020-10-05 12:02:24 --> URI Class Initialized
INFO - 2020-10-05 12:02:24 --> Router Class Initialized
INFO - 2020-10-05 12:02:24 --> Output Class Initialized
INFO - 2020-10-05 12:02:24 --> Security Class Initialized
DEBUG - 2020-10-05 12:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:02:24 --> Input Class Initialized
INFO - 2020-10-05 12:02:24 --> Language Class Initialized
INFO - 2020-10-05 12:02:24 --> Loader Class Initialized
INFO - 2020-10-05 12:02:24 --> Helper loaded: url_helper
INFO - 2020-10-05 12:02:24 --> Helper loaded: file_helper
INFO - 2020-10-05 12:02:24 --> Database Driver Class Initialized
INFO - 2020-10-05 12:02:24 --> Email Class Initialized
DEBUG - 2020-10-05 12:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:02:24 --> Controller Class Initialized
INFO - 2020-10-05 12:02:24 --> Model "Main_model" initialized
INFO - 2020-10-05 12:02:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:02:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:02:24 --> Final output sent to browser
DEBUG - 2020-10-05 12:02:24 --> Total execution time: 0.3618
INFO - 2020-10-05 12:02:57 --> Config Class Initialized
INFO - 2020-10-05 12:02:57 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:02:57 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:02:57 --> Utf8 Class Initialized
INFO - 2020-10-05 12:02:57 --> URI Class Initialized
INFO - 2020-10-05 12:02:57 --> Router Class Initialized
INFO - 2020-10-05 12:02:57 --> Output Class Initialized
INFO - 2020-10-05 12:02:57 --> Security Class Initialized
DEBUG - 2020-10-05 12:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:02:57 --> Input Class Initialized
INFO - 2020-10-05 12:02:57 --> Language Class Initialized
INFO - 2020-10-05 12:02:58 --> Loader Class Initialized
INFO - 2020-10-05 12:02:58 --> Helper loaded: url_helper
INFO - 2020-10-05 12:02:58 --> Helper loaded: file_helper
INFO - 2020-10-05 12:02:58 --> Database Driver Class Initialized
INFO - 2020-10-05 12:02:58 --> Email Class Initialized
DEBUG - 2020-10-05 12:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:02:58 --> Controller Class Initialized
INFO - 2020-10-05 12:02:58 --> Model "Main_model" initialized
INFO - 2020-10-05 12:02:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:02:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:02:58 --> Final output sent to browser
DEBUG - 2020-10-05 12:02:58 --> Total execution time: 0.3839
INFO - 2020-10-05 12:03:13 --> Config Class Initialized
INFO - 2020-10-05 12:03:13 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:03:13 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:03:13 --> Utf8 Class Initialized
INFO - 2020-10-05 12:03:13 --> URI Class Initialized
INFO - 2020-10-05 12:03:13 --> Router Class Initialized
INFO - 2020-10-05 12:03:13 --> Output Class Initialized
INFO - 2020-10-05 12:03:13 --> Security Class Initialized
DEBUG - 2020-10-05 12:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:03:13 --> Input Class Initialized
INFO - 2020-10-05 12:03:14 --> Language Class Initialized
INFO - 2020-10-05 12:03:14 --> Loader Class Initialized
INFO - 2020-10-05 12:03:14 --> Helper loaded: url_helper
INFO - 2020-10-05 12:03:14 --> Helper loaded: file_helper
INFO - 2020-10-05 12:03:14 --> Database Driver Class Initialized
INFO - 2020-10-05 12:03:14 --> Email Class Initialized
DEBUG - 2020-10-05 12:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:03:14 --> Controller Class Initialized
INFO - 2020-10-05 12:03:14 --> Model "Main_model" initialized
INFO - 2020-10-05 12:03:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:03:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:03:14 --> Final output sent to browser
DEBUG - 2020-10-05 12:03:14 --> Total execution time: 0.3659
INFO - 2020-10-05 12:03:51 --> Config Class Initialized
INFO - 2020-10-05 12:03:51 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:03:51 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:03:51 --> Utf8 Class Initialized
INFO - 2020-10-05 12:03:51 --> URI Class Initialized
INFO - 2020-10-05 12:03:51 --> Router Class Initialized
INFO - 2020-10-05 12:03:51 --> Output Class Initialized
INFO - 2020-10-05 12:03:51 --> Security Class Initialized
DEBUG - 2020-10-05 12:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:03:51 --> Input Class Initialized
INFO - 2020-10-05 12:03:51 --> Language Class Initialized
INFO - 2020-10-05 12:03:51 --> Loader Class Initialized
INFO - 2020-10-05 12:03:51 --> Helper loaded: url_helper
INFO - 2020-10-05 12:03:51 --> Helper loaded: file_helper
INFO - 2020-10-05 12:03:51 --> Database Driver Class Initialized
INFO - 2020-10-05 12:03:51 --> Email Class Initialized
DEBUG - 2020-10-05 12:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:03:51 --> Controller Class Initialized
INFO - 2020-10-05 12:03:51 --> Model "Main_model" initialized
INFO - 2020-10-05 12:03:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:03:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:03:51 --> Final output sent to browser
DEBUG - 2020-10-05 12:03:51 --> Total execution time: 0.3711
INFO - 2020-10-05 12:04:01 --> Config Class Initialized
INFO - 2020-10-05 12:04:01 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:04:01 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:04:01 --> Utf8 Class Initialized
INFO - 2020-10-05 12:04:01 --> URI Class Initialized
INFO - 2020-10-05 12:04:01 --> Router Class Initialized
INFO - 2020-10-05 12:04:01 --> Output Class Initialized
INFO - 2020-10-05 12:04:01 --> Security Class Initialized
DEBUG - 2020-10-05 12:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:04:01 --> Input Class Initialized
INFO - 2020-10-05 12:04:01 --> Language Class Initialized
INFO - 2020-10-05 12:04:01 --> Loader Class Initialized
INFO - 2020-10-05 12:04:01 --> Helper loaded: url_helper
INFO - 2020-10-05 12:04:01 --> Helper loaded: file_helper
INFO - 2020-10-05 12:04:01 --> Database Driver Class Initialized
INFO - 2020-10-05 12:04:01 --> Email Class Initialized
DEBUG - 2020-10-05 12:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:04:01 --> Controller Class Initialized
INFO - 2020-10-05 12:04:01 --> Model "Main_model" initialized
INFO - 2020-10-05 12:04:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:04:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:04:01 --> Final output sent to browser
DEBUG - 2020-10-05 12:04:01 --> Total execution time: 0.3970
INFO - 2020-10-05 12:04:07 --> Config Class Initialized
INFO - 2020-10-05 12:04:07 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:04:07 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:04:07 --> Utf8 Class Initialized
INFO - 2020-10-05 12:04:07 --> URI Class Initialized
INFO - 2020-10-05 12:04:07 --> Router Class Initialized
INFO - 2020-10-05 12:04:07 --> Output Class Initialized
INFO - 2020-10-05 12:04:07 --> Security Class Initialized
DEBUG - 2020-10-05 12:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:04:07 --> Input Class Initialized
INFO - 2020-10-05 12:04:07 --> Language Class Initialized
INFO - 2020-10-05 12:04:07 --> Loader Class Initialized
INFO - 2020-10-05 12:04:07 --> Helper loaded: url_helper
INFO - 2020-10-05 12:04:07 --> Helper loaded: file_helper
INFO - 2020-10-05 12:04:07 --> Database Driver Class Initialized
INFO - 2020-10-05 12:04:07 --> Email Class Initialized
DEBUG - 2020-10-05 12:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:04:07 --> Controller Class Initialized
INFO - 2020-10-05 12:04:07 --> Model "Main_model" initialized
INFO - 2020-10-05 12:04:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:04:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:04:07 --> Final output sent to browser
DEBUG - 2020-10-05 12:04:07 --> Total execution time: 0.3674
INFO - 2020-10-05 12:04:20 --> Config Class Initialized
INFO - 2020-10-05 12:04:20 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:04:20 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:04:20 --> Utf8 Class Initialized
INFO - 2020-10-05 12:04:20 --> URI Class Initialized
INFO - 2020-10-05 12:04:20 --> Router Class Initialized
INFO - 2020-10-05 12:04:20 --> Output Class Initialized
INFO - 2020-10-05 12:04:20 --> Security Class Initialized
DEBUG - 2020-10-05 12:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:04:20 --> Input Class Initialized
INFO - 2020-10-05 12:04:20 --> Language Class Initialized
INFO - 2020-10-05 12:04:20 --> Loader Class Initialized
INFO - 2020-10-05 12:04:20 --> Helper loaded: url_helper
INFO - 2020-10-05 12:04:20 --> Helper loaded: file_helper
INFO - 2020-10-05 12:04:20 --> Database Driver Class Initialized
INFO - 2020-10-05 12:04:20 --> Email Class Initialized
DEBUG - 2020-10-05 12:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:04:20 --> Controller Class Initialized
INFO - 2020-10-05 12:04:20 --> Model "Main_model" initialized
INFO - 2020-10-05 12:04:20 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:04:20 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:04:20 --> Final output sent to browser
DEBUG - 2020-10-05 12:04:20 --> Total execution time: 0.4002
INFO - 2020-10-05 12:06:21 --> Config Class Initialized
INFO - 2020-10-05 12:06:21 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:06:21 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:06:21 --> Utf8 Class Initialized
INFO - 2020-10-05 12:06:21 --> URI Class Initialized
INFO - 2020-10-05 12:06:21 --> Router Class Initialized
INFO - 2020-10-05 12:06:21 --> Output Class Initialized
INFO - 2020-10-05 12:06:21 --> Security Class Initialized
DEBUG - 2020-10-05 12:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:06:21 --> Input Class Initialized
INFO - 2020-10-05 12:06:21 --> Language Class Initialized
INFO - 2020-10-05 12:06:21 --> Loader Class Initialized
INFO - 2020-10-05 12:06:21 --> Helper loaded: url_helper
INFO - 2020-10-05 12:06:21 --> Helper loaded: file_helper
INFO - 2020-10-05 12:06:21 --> Database Driver Class Initialized
INFO - 2020-10-05 12:06:21 --> Email Class Initialized
DEBUG - 2020-10-05 12:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:06:21 --> Controller Class Initialized
INFO - 2020-10-05 12:06:21 --> Model "Main_model" initialized
INFO - 2020-10-05 12:06:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:06:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-10-05 12:06:21 --> Final output sent to browser
DEBUG - 2020-10-05 12:06:21 --> Total execution time: 0.3559
INFO - 2020-10-05 12:06:31 --> Config Class Initialized
INFO - 2020-10-05 12:06:31 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:06:31 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:06:31 --> Utf8 Class Initialized
INFO - 2020-10-05 12:06:31 --> URI Class Initialized
INFO - 2020-10-05 12:06:31 --> Router Class Initialized
INFO - 2020-10-05 12:06:31 --> Output Class Initialized
INFO - 2020-10-05 12:06:31 --> Security Class Initialized
DEBUG - 2020-10-05 12:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:06:31 --> Input Class Initialized
INFO - 2020-10-05 12:06:31 --> Language Class Initialized
INFO - 2020-10-05 12:06:31 --> Loader Class Initialized
INFO - 2020-10-05 12:06:31 --> Helper loaded: url_helper
INFO - 2020-10-05 12:06:31 --> Helper loaded: file_helper
INFO - 2020-10-05 12:06:31 --> Database Driver Class Initialized
INFO - 2020-10-05 12:06:31 --> Email Class Initialized
DEBUG - 2020-10-05 12:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:06:31 --> Controller Class Initialized
INFO - 2020-10-05 12:06:31 --> Model "Main_model" initialized
INFO - 2020-10-05 12:06:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:06:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertevents.php
INFO - 2020-10-05 12:06:31 --> Final output sent to browser
DEBUG - 2020-10-05 12:06:31 --> Total execution time: 0.3817
INFO - 2020-10-05 12:06:33 --> Config Class Initialized
INFO - 2020-10-05 12:06:33 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:06:33 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:06:33 --> Utf8 Class Initialized
INFO - 2020-10-05 12:06:33 --> URI Class Initialized
INFO - 2020-10-05 12:06:33 --> Router Class Initialized
INFO - 2020-10-05 12:06:33 --> Output Class Initialized
INFO - 2020-10-05 12:06:33 --> Security Class Initialized
DEBUG - 2020-10-05 12:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:06:33 --> Input Class Initialized
INFO - 2020-10-05 12:06:33 --> Language Class Initialized
INFO - 2020-10-05 12:06:33 --> Loader Class Initialized
INFO - 2020-10-05 12:06:33 --> Helper loaded: url_helper
INFO - 2020-10-05 12:06:33 --> Helper loaded: file_helper
INFO - 2020-10-05 12:06:33 --> Database Driver Class Initialized
INFO - 2020-10-05 12:06:34 --> Email Class Initialized
DEBUG - 2020-10-05 12:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:06:34 --> Controller Class Initialized
INFO - 2020-10-05 12:06:34 --> Model "Main_model" initialized
INFO - 2020-10-05 12:06:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:06:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:06:34 --> Final output sent to browser
DEBUG - 2020-10-05 12:06:34 --> Total execution time: 0.3705
INFO - 2020-10-05 12:07:29 --> Config Class Initialized
INFO - 2020-10-05 12:07:29 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:07:29 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:07:29 --> Utf8 Class Initialized
INFO - 2020-10-05 12:07:29 --> URI Class Initialized
INFO - 2020-10-05 12:07:29 --> Router Class Initialized
INFO - 2020-10-05 12:07:29 --> Output Class Initialized
INFO - 2020-10-05 12:07:29 --> Security Class Initialized
DEBUG - 2020-10-05 12:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:07:29 --> Input Class Initialized
INFO - 2020-10-05 12:07:29 --> Language Class Initialized
INFO - 2020-10-05 12:07:29 --> Loader Class Initialized
INFO - 2020-10-05 12:07:29 --> Helper loaded: url_helper
INFO - 2020-10-05 12:07:29 --> Helper loaded: file_helper
INFO - 2020-10-05 12:07:29 --> Database Driver Class Initialized
INFO - 2020-10-05 12:07:29 --> Email Class Initialized
DEBUG - 2020-10-05 12:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:07:29 --> Controller Class Initialized
INFO - 2020-10-05 12:07:29 --> Model "Main_model" initialized
INFO - 2020-10-05 12:07:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:07:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:07:29 --> Final output sent to browser
DEBUG - 2020-10-05 12:07:29 --> Total execution time: 0.4103
INFO - 2020-10-05 12:07:35 --> Config Class Initialized
INFO - 2020-10-05 12:07:35 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:07:35 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:07:35 --> Utf8 Class Initialized
INFO - 2020-10-05 12:07:35 --> URI Class Initialized
INFO - 2020-10-05 12:07:35 --> Router Class Initialized
INFO - 2020-10-05 12:07:35 --> Output Class Initialized
INFO - 2020-10-05 12:07:35 --> Security Class Initialized
DEBUG - 2020-10-05 12:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:07:35 --> Input Class Initialized
INFO - 2020-10-05 12:07:35 --> Language Class Initialized
INFO - 2020-10-05 12:07:35 --> Loader Class Initialized
INFO - 2020-10-05 12:07:35 --> Helper loaded: url_helper
INFO - 2020-10-05 12:07:35 --> Helper loaded: file_helper
INFO - 2020-10-05 12:07:35 --> Database Driver Class Initialized
INFO - 2020-10-05 12:07:35 --> Email Class Initialized
DEBUG - 2020-10-05 12:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:07:35 --> Controller Class Initialized
INFO - 2020-10-05 12:07:35 --> Model "Main_model" initialized
INFO - 2020-10-05 12:07:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:07:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:07:35 --> Final output sent to browser
DEBUG - 2020-10-05 12:07:35 --> Total execution time: 0.3725
INFO - 2020-10-05 12:10:46 --> Config Class Initialized
INFO - 2020-10-05 12:10:46 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:10:46 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:10:46 --> Utf8 Class Initialized
INFO - 2020-10-05 12:10:46 --> URI Class Initialized
INFO - 2020-10-05 12:10:46 --> Router Class Initialized
INFO - 2020-10-05 12:10:46 --> Output Class Initialized
INFO - 2020-10-05 12:10:46 --> Security Class Initialized
DEBUG - 2020-10-05 12:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:10:46 --> Input Class Initialized
INFO - 2020-10-05 12:10:46 --> Language Class Initialized
INFO - 2020-10-05 12:10:46 --> Loader Class Initialized
INFO - 2020-10-05 12:10:46 --> Helper loaded: url_helper
INFO - 2020-10-05 12:10:46 --> Helper loaded: file_helper
INFO - 2020-10-05 12:10:46 --> Database Driver Class Initialized
INFO - 2020-10-05 12:10:46 --> Email Class Initialized
DEBUG - 2020-10-05 12:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:10:46 --> Controller Class Initialized
INFO - 2020-10-05 12:10:46 --> Model "Main_model" initialized
ERROR - 2020-10-05 12:10:46 --> Severity: Notice --> Undefined variable: uid C:\xampp\htdocs\dmarc\application\controllers\Home.php 35
INFO - 2020-10-05 12:10:46 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:10:46 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:10:46 --> Final output sent to browser
DEBUG - 2020-10-05 12:10:46 --> Total execution time: 0.4360
INFO - 2020-10-05 12:11:16 --> Config Class Initialized
INFO - 2020-10-05 12:11:16 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:11:16 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:11:16 --> Utf8 Class Initialized
INFO - 2020-10-05 12:11:16 --> URI Class Initialized
INFO - 2020-10-05 12:11:16 --> Router Class Initialized
INFO - 2020-10-05 12:11:16 --> Output Class Initialized
INFO - 2020-10-05 12:11:16 --> Security Class Initialized
DEBUG - 2020-10-05 12:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:11:16 --> Input Class Initialized
INFO - 2020-10-05 12:11:16 --> Language Class Initialized
INFO - 2020-10-05 12:11:16 --> Loader Class Initialized
INFO - 2020-10-05 12:11:16 --> Helper loaded: url_helper
INFO - 2020-10-05 12:11:16 --> Helper loaded: file_helper
INFO - 2020-10-05 12:11:16 --> Database Driver Class Initialized
INFO - 2020-10-05 12:11:16 --> Email Class Initialized
DEBUG - 2020-10-05 12:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:11:16 --> Controller Class Initialized
INFO - 2020-10-05 12:11:16 --> Model "Main_model" initialized
INFO - 2020-10-05 12:11:16 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:11:16 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:11:16 --> Final output sent to browser
DEBUG - 2020-10-05 12:11:16 --> Total execution time: 0.4099
INFO - 2020-10-05 12:11:59 --> Config Class Initialized
INFO - 2020-10-05 12:11:59 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:11:59 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:11:59 --> Utf8 Class Initialized
INFO - 2020-10-05 12:11:59 --> URI Class Initialized
INFO - 2020-10-05 12:11:59 --> Router Class Initialized
INFO - 2020-10-05 12:11:59 --> Output Class Initialized
INFO - 2020-10-05 12:11:59 --> Security Class Initialized
DEBUG - 2020-10-05 12:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:11:59 --> Input Class Initialized
INFO - 2020-10-05 12:11:59 --> Language Class Initialized
INFO - 2020-10-05 12:11:59 --> Loader Class Initialized
INFO - 2020-10-05 12:11:59 --> Helper loaded: url_helper
INFO - 2020-10-05 12:11:59 --> Helper loaded: file_helper
INFO - 2020-10-05 12:11:59 --> Database Driver Class Initialized
INFO - 2020-10-05 12:11:59 --> Email Class Initialized
DEBUG - 2020-10-05 12:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:11:59 --> Controller Class Initialized
INFO - 2020-10-05 12:11:59 --> Model "Main_model" initialized
INFO - 2020-10-05 12:11:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:11:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:11:59 --> Final output sent to browser
DEBUG - 2020-10-05 12:11:59 --> Total execution time: 0.3688
INFO - 2020-10-05 12:12:02 --> Config Class Initialized
INFO - 2020-10-05 12:12:02 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:12:02 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:12:02 --> Utf8 Class Initialized
INFO - 2020-10-05 12:12:02 --> URI Class Initialized
INFO - 2020-10-05 12:12:02 --> Router Class Initialized
INFO - 2020-10-05 12:12:02 --> Output Class Initialized
INFO - 2020-10-05 12:12:02 --> Security Class Initialized
DEBUG - 2020-10-05 12:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:12:02 --> Input Class Initialized
INFO - 2020-10-05 12:12:02 --> Language Class Initialized
INFO - 2020-10-05 12:12:02 --> Loader Class Initialized
INFO - 2020-10-05 12:12:02 --> Helper loaded: url_helper
INFO - 2020-10-05 12:12:02 --> Helper loaded: file_helper
INFO - 2020-10-05 12:12:02 --> Database Driver Class Initialized
INFO - 2020-10-05 12:12:02 --> Email Class Initialized
DEBUG - 2020-10-05 12:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:12:02 --> Controller Class Initialized
INFO - 2020-10-05 12:12:02 --> Model "Main_model" initialized
INFO - 2020-10-05 12:12:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:12:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:12:02 --> Final output sent to browser
DEBUG - 2020-10-05 12:12:02 --> Total execution time: 0.3720
INFO - 2020-10-05 12:12:14 --> Config Class Initialized
INFO - 2020-10-05 12:12:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:12:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:12:14 --> Utf8 Class Initialized
INFO - 2020-10-05 12:12:14 --> URI Class Initialized
INFO - 2020-10-05 12:12:14 --> Router Class Initialized
INFO - 2020-10-05 12:12:14 --> Output Class Initialized
INFO - 2020-10-05 12:12:14 --> Security Class Initialized
DEBUG - 2020-10-05 12:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:12:14 --> Input Class Initialized
INFO - 2020-10-05 12:12:15 --> Language Class Initialized
INFO - 2020-10-05 12:12:15 --> Loader Class Initialized
INFO - 2020-10-05 12:12:15 --> Helper loaded: url_helper
INFO - 2020-10-05 12:12:15 --> Helper loaded: file_helper
INFO - 2020-10-05 12:12:15 --> Database Driver Class Initialized
INFO - 2020-10-05 12:12:15 --> Email Class Initialized
DEBUG - 2020-10-05 12:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:12:15 --> Controller Class Initialized
INFO - 2020-10-05 12:12:15 --> Model "Main_model" initialized
INFO - 2020-10-05 12:12:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:12:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:12:15 --> Final output sent to browser
DEBUG - 2020-10-05 12:12:15 --> Total execution time: 0.4091
INFO - 2020-10-05 12:12:26 --> Config Class Initialized
INFO - 2020-10-05 12:12:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:12:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:12:26 --> Utf8 Class Initialized
INFO - 2020-10-05 12:12:26 --> URI Class Initialized
INFO - 2020-10-05 12:12:26 --> Router Class Initialized
INFO - 2020-10-05 12:12:26 --> Output Class Initialized
INFO - 2020-10-05 12:12:26 --> Security Class Initialized
DEBUG - 2020-10-05 12:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:12:26 --> Input Class Initialized
INFO - 2020-10-05 12:12:26 --> Language Class Initialized
INFO - 2020-10-05 12:12:27 --> Loader Class Initialized
INFO - 2020-10-05 12:12:27 --> Helper loaded: url_helper
INFO - 2020-10-05 12:12:27 --> Helper loaded: file_helper
INFO - 2020-10-05 12:12:27 --> Database Driver Class Initialized
INFO - 2020-10-05 12:12:27 --> Email Class Initialized
DEBUG - 2020-10-05 12:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:12:27 --> Controller Class Initialized
INFO - 2020-10-05 12:12:27 --> Model "Main_model" initialized
INFO - 2020-10-05 12:12:27 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:12:27 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:12:27 --> Final output sent to browser
DEBUG - 2020-10-05 12:12:27 --> Total execution time: 0.3810
INFO - 2020-10-05 12:12:37 --> Config Class Initialized
INFO - 2020-10-05 12:12:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:12:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:12:37 --> Utf8 Class Initialized
INFO - 2020-10-05 12:12:37 --> URI Class Initialized
INFO - 2020-10-05 12:12:37 --> Router Class Initialized
INFO - 2020-10-05 12:12:37 --> Output Class Initialized
INFO - 2020-10-05 12:12:37 --> Security Class Initialized
DEBUG - 2020-10-05 12:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:12:37 --> Input Class Initialized
INFO - 2020-10-05 12:12:37 --> Language Class Initialized
INFO - 2020-10-05 12:12:37 --> Loader Class Initialized
INFO - 2020-10-05 12:12:37 --> Helper loaded: url_helper
INFO - 2020-10-05 12:12:37 --> Helper loaded: file_helper
INFO - 2020-10-05 12:12:37 --> Database Driver Class Initialized
INFO - 2020-10-05 12:12:37 --> Email Class Initialized
DEBUG - 2020-10-05 12:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:12:37 --> Controller Class Initialized
INFO - 2020-10-05 12:12:37 --> Model "Main_model" initialized
INFO - 2020-10-05 12:12:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:12:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:12:37 --> Final output sent to browser
DEBUG - 2020-10-05 12:12:37 --> Total execution time: 0.3911
INFO - 2020-10-05 12:12:44 --> Config Class Initialized
INFO - 2020-10-05 12:12:44 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:12:44 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:12:44 --> Utf8 Class Initialized
INFO - 2020-10-05 12:12:44 --> URI Class Initialized
INFO - 2020-10-05 12:12:44 --> Router Class Initialized
INFO - 2020-10-05 12:12:44 --> Output Class Initialized
INFO - 2020-10-05 12:12:44 --> Security Class Initialized
DEBUG - 2020-10-05 12:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:12:44 --> Input Class Initialized
INFO - 2020-10-05 12:12:44 --> Language Class Initialized
INFO - 2020-10-05 12:12:44 --> Loader Class Initialized
INFO - 2020-10-05 12:12:44 --> Helper loaded: url_helper
INFO - 2020-10-05 12:12:44 --> Helper loaded: file_helper
INFO - 2020-10-05 12:12:44 --> Database Driver Class Initialized
INFO - 2020-10-05 12:12:44 --> Email Class Initialized
DEBUG - 2020-10-05 12:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:12:44 --> Controller Class Initialized
INFO - 2020-10-05 12:12:44 --> Model "Main_model" initialized
INFO - 2020-10-05 12:12:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:12:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:12:44 --> Final output sent to browser
DEBUG - 2020-10-05 12:12:44 --> Total execution time: 0.3883
INFO - 2020-10-05 12:12:55 --> Config Class Initialized
INFO - 2020-10-05 12:12:55 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:12:55 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:12:55 --> Utf8 Class Initialized
INFO - 2020-10-05 12:12:55 --> URI Class Initialized
INFO - 2020-10-05 12:12:55 --> Router Class Initialized
INFO - 2020-10-05 12:12:55 --> Output Class Initialized
INFO - 2020-10-05 12:12:55 --> Security Class Initialized
DEBUG - 2020-10-05 12:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:12:55 --> Input Class Initialized
INFO - 2020-10-05 12:12:55 --> Language Class Initialized
INFO - 2020-10-05 12:12:55 --> Loader Class Initialized
INFO - 2020-10-05 12:12:55 --> Helper loaded: url_helper
INFO - 2020-10-05 12:12:55 --> Helper loaded: file_helper
INFO - 2020-10-05 12:12:55 --> Database Driver Class Initialized
INFO - 2020-10-05 12:12:55 --> Email Class Initialized
DEBUG - 2020-10-05 12:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:12:55 --> Controller Class Initialized
INFO - 2020-10-05 12:12:55 --> Model "Main_model" initialized
INFO - 2020-10-05 12:12:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:12:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:12:55 --> Final output sent to browser
DEBUG - 2020-10-05 12:12:55 --> Total execution time: 0.4005
INFO - 2020-10-05 12:13:02 --> Config Class Initialized
INFO - 2020-10-05 12:13:02 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:13:02 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:13:02 --> Utf8 Class Initialized
INFO - 2020-10-05 12:13:02 --> URI Class Initialized
INFO - 2020-10-05 12:13:02 --> Router Class Initialized
INFO - 2020-10-05 12:13:02 --> Output Class Initialized
INFO - 2020-10-05 12:13:02 --> Security Class Initialized
DEBUG - 2020-10-05 12:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:13:02 --> Input Class Initialized
INFO - 2020-10-05 12:13:02 --> Language Class Initialized
INFO - 2020-10-05 12:13:02 --> Loader Class Initialized
INFO - 2020-10-05 12:13:02 --> Helper loaded: url_helper
INFO - 2020-10-05 12:13:02 --> Helper loaded: file_helper
INFO - 2020-10-05 12:13:02 --> Database Driver Class Initialized
INFO - 2020-10-05 12:13:02 --> Email Class Initialized
DEBUG - 2020-10-05 12:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:13:02 --> Controller Class Initialized
INFO - 2020-10-05 12:13:02 --> Model "Main_model" initialized
INFO - 2020-10-05 12:13:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:13:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertevents.php
INFO - 2020-10-05 12:13:02 --> Final output sent to browser
DEBUG - 2020-10-05 12:13:02 --> Total execution time: 0.3838
INFO - 2020-10-05 12:13:04 --> Config Class Initialized
INFO - 2020-10-05 12:13:04 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:13:04 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:13:04 --> Utf8 Class Initialized
INFO - 2020-10-05 12:13:04 --> URI Class Initialized
INFO - 2020-10-05 12:13:04 --> Router Class Initialized
INFO - 2020-10-05 12:13:04 --> Output Class Initialized
INFO - 2020-10-05 12:13:04 --> Security Class Initialized
DEBUG - 2020-10-05 12:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:13:04 --> Input Class Initialized
INFO - 2020-10-05 12:13:04 --> Language Class Initialized
INFO - 2020-10-05 12:13:04 --> Loader Class Initialized
INFO - 2020-10-05 12:13:04 --> Helper loaded: url_helper
INFO - 2020-10-05 12:13:04 --> Helper loaded: file_helper
INFO - 2020-10-05 12:13:04 --> Database Driver Class Initialized
INFO - 2020-10-05 12:13:04 --> Email Class Initialized
DEBUG - 2020-10-05 12:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:13:04 --> Controller Class Initialized
INFO - 2020-10-05 12:13:04 --> Model "Main_model" initialized
INFO - 2020-10-05 12:13:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:13:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:13:04 --> Final output sent to browser
DEBUG - 2020-10-05 12:13:05 --> Total execution time: 0.3800
INFO - 2020-10-05 12:13:08 --> Config Class Initialized
INFO - 2020-10-05 12:13:08 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:13:08 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:13:08 --> Utf8 Class Initialized
INFO - 2020-10-05 12:13:08 --> URI Class Initialized
INFO - 2020-10-05 12:13:08 --> Router Class Initialized
INFO - 2020-10-05 12:13:08 --> Output Class Initialized
INFO - 2020-10-05 12:13:08 --> Security Class Initialized
DEBUG - 2020-10-05 12:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:13:08 --> Input Class Initialized
INFO - 2020-10-05 12:13:08 --> Language Class Initialized
INFO - 2020-10-05 12:13:08 --> Loader Class Initialized
INFO - 2020-10-05 12:13:08 --> Helper loaded: url_helper
INFO - 2020-10-05 12:13:08 --> Helper loaded: file_helper
INFO - 2020-10-05 12:13:08 --> Database Driver Class Initialized
INFO - 2020-10-05 12:13:08 --> Email Class Initialized
DEBUG - 2020-10-05 12:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:13:08 --> Controller Class Initialized
INFO - 2020-10-05 12:13:08 --> Model "Main_model" initialized
INFO - 2020-10-05 12:13:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:13:08 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:13:08 --> Final output sent to browser
DEBUG - 2020-10-05 12:13:08 --> Total execution time: 0.3903
INFO - 2020-10-05 12:13:11 --> Config Class Initialized
INFO - 2020-10-05 12:13:11 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:13:11 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:13:11 --> Utf8 Class Initialized
INFO - 2020-10-05 12:13:11 --> URI Class Initialized
INFO - 2020-10-05 12:13:11 --> Router Class Initialized
INFO - 2020-10-05 12:13:11 --> Output Class Initialized
INFO - 2020-10-05 12:13:11 --> Security Class Initialized
DEBUG - 2020-10-05 12:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:13:11 --> Input Class Initialized
INFO - 2020-10-05 12:13:11 --> Language Class Initialized
INFO - 2020-10-05 12:13:11 --> Loader Class Initialized
INFO - 2020-10-05 12:13:11 --> Helper loaded: url_helper
INFO - 2020-10-05 12:13:11 --> Helper loaded: file_helper
INFO - 2020-10-05 12:13:11 --> Database Driver Class Initialized
INFO - 2020-10-05 12:13:11 --> Email Class Initialized
DEBUG - 2020-10-05 12:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:13:11 --> Controller Class Initialized
INFO - 2020-10-05 12:13:11 --> Model "Main_model" initialized
INFO - 2020-10-05 12:13:11 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:13:11 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domains.php
INFO - 2020-10-05 12:13:11 --> Final output sent to browser
DEBUG - 2020-10-05 12:13:12 --> Total execution time: 0.4256
INFO - 2020-10-05 12:13:14 --> Config Class Initialized
INFO - 2020-10-05 12:13:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:13:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:13:14 --> Utf8 Class Initialized
INFO - 2020-10-05 12:13:15 --> URI Class Initialized
INFO - 2020-10-05 12:13:15 --> Router Class Initialized
INFO - 2020-10-05 12:13:15 --> Output Class Initialized
INFO - 2020-10-05 12:13:15 --> Security Class Initialized
DEBUG - 2020-10-05 12:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:13:15 --> Input Class Initialized
INFO - 2020-10-05 12:13:15 --> Language Class Initialized
INFO - 2020-10-05 12:13:15 --> Loader Class Initialized
INFO - 2020-10-05 12:13:15 --> Helper loaded: url_helper
INFO - 2020-10-05 12:13:15 --> Helper loaded: file_helper
INFO - 2020-10-05 12:13:15 --> Database Driver Class Initialized
INFO - 2020-10-05 12:13:15 --> Email Class Initialized
DEBUG - 2020-10-05 12:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:13:15 --> Controller Class Initialized
INFO - 2020-10-05 12:13:15 --> Model "Main_model" initialized
INFO - 2020-10-05 12:13:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:13:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:13:15 --> Final output sent to browser
DEBUG - 2020-10-05 12:13:15 --> Total execution time: 0.3866
INFO - 2020-10-05 12:16:44 --> Config Class Initialized
INFO - 2020-10-05 12:16:44 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:16:44 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:16:44 --> Utf8 Class Initialized
INFO - 2020-10-05 12:16:44 --> URI Class Initialized
INFO - 2020-10-05 12:16:44 --> Router Class Initialized
INFO - 2020-10-05 12:16:44 --> Output Class Initialized
INFO - 2020-10-05 12:16:44 --> Security Class Initialized
DEBUG - 2020-10-05 12:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:16:44 --> Input Class Initialized
INFO - 2020-10-05 12:16:44 --> Config Class Initialized
INFO - 2020-10-05 12:16:44 --> Hooks Class Initialized
INFO - 2020-10-05 12:16:44 --> Language Class Initialized
DEBUG - 2020-10-05 12:16:44 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:16:44 --> Utf8 Class Initialized
INFO - 2020-10-05 12:16:44 --> URI Class Initialized
INFO - 2020-10-05 12:16:44 --> Router Class Initialized
INFO - 2020-10-05 12:16:44 --> Output Class Initialized
INFO - 2020-10-05 12:16:44 --> Security Class Initialized
DEBUG - 2020-10-05 12:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:16:44 --> Input Class Initialized
INFO - 2020-10-05 12:16:44 --> Language Class Initialized
INFO - 2020-10-05 12:16:45 --> Loader Class Initialized
INFO - 2020-10-05 12:16:45 --> Loader Class Initialized
INFO - 2020-10-05 12:16:45 --> Helper loaded: url_helper
INFO - 2020-10-05 12:16:45 --> Helper loaded: file_helper
INFO - 2020-10-05 12:16:45 --> Helper loaded: url_helper
INFO - 2020-10-05 12:16:45 --> Database Driver Class Initialized
INFO - 2020-10-05 12:16:45 --> Email Class Initialized
DEBUG - 2020-10-05 12:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:16:45 --> Helper loaded: file_helper
INFO - 2020-10-05 12:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:16:45 --> Controller Class Initialized
INFO - 2020-10-05 12:16:45 --> Model "Main_model" initialized
INFO - 2020-10-05 12:16:45 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:16:45 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:16:45 --> Final output sent to browser
DEBUG - 2020-10-05 12:16:45 --> Total execution time: 0.2608
INFO - 2020-10-05 12:16:45 --> Database Driver Class Initialized
INFO - 2020-10-05 12:16:45 --> Email Class Initialized
DEBUG - 2020-10-05 12:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:16:45 --> Controller Class Initialized
INFO - 2020-10-05 12:16:45 --> Model "Main_model" initialized
INFO - 2020-10-05 12:16:45 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:16:45 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:16:45 --> Final output sent to browser
DEBUG - 2020-10-05 12:16:45 --> Total execution time: 0.2407
INFO - 2020-10-05 12:17:54 --> Config Class Initialized
INFO - 2020-10-05 12:17:54 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:17:54 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:17:54 --> Utf8 Class Initialized
INFO - 2020-10-05 12:17:54 --> URI Class Initialized
INFO - 2020-10-05 12:17:55 --> Router Class Initialized
INFO - 2020-10-05 12:17:55 --> Output Class Initialized
INFO - 2020-10-05 12:17:55 --> Security Class Initialized
DEBUG - 2020-10-05 12:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:17:55 --> Input Class Initialized
INFO - 2020-10-05 12:17:55 --> Language Class Initialized
INFO - 2020-10-05 12:17:55 --> Loader Class Initialized
INFO - 2020-10-05 12:17:55 --> Helper loaded: url_helper
INFO - 2020-10-05 12:17:55 --> Helper loaded: file_helper
INFO - 2020-10-05 12:17:55 --> Database Driver Class Initialized
INFO - 2020-10-05 12:17:55 --> Email Class Initialized
DEBUG - 2020-10-05 12:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:17:55 --> Controller Class Initialized
INFO - 2020-10-05 12:17:55 --> Model "Main_model" initialized
INFO - 2020-10-05 12:17:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:17:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:17:55 --> Final output sent to browser
DEBUG - 2020-10-05 12:17:55 --> Total execution time: 0.3836
INFO - 2020-10-05 12:18:16 --> Config Class Initialized
INFO - 2020-10-05 12:18:16 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:18:16 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:18:16 --> Utf8 Class Initialized
INFO - 2020-10-05 12:18:16 --> URI Class Initialized
INFO - 2020-10-05 12:18:16 --> Router Class Initialized
INFO - 2020-10-05 12:18:16 --> Output Class Initialized
INFO - 2020-10-05 12:18:16 --> Security Class Initialized
DEBUG - 2020-10-05 12:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:18:17 --> Input Class Initialized
INFO - 2020-10-05 12:18:17 --> Language Class Initialized
INFO - 2020-10-05 12:18:17 --> Loader Class Initialized
INFO - 2020-10-05 12:18:17 --> Helper loaded: url_helper
INFO - 2020-10-05 12:18:17 --> Helper loaded: file_helper
INFO - 2020-10-05 12:18:17 --> Database Driver Class Initialized
INFO - 2020-10-05 12:18:17 --> Email Class Initialized
DEBUG - 2020-10-05 12:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:18:17 --> Controller Class Initialized
INFO - 2020-10-05 12:18:17 --> Model "Main_model" initialized
INFO - 2020-10-05 12:18:17 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:18:17 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:18:17 --> Final output sent to browser
DEBUG - 2020-10-05 12:18:17 --> Total execution time: 0.3901
INFO - 2020-10-05 12:18:26 --> Config Class Initialized
INFO - 2020-10-05 12:18:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:18:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:18:26 --> Utf8 Class Initialized
INFO - 2020-10-05 12:18:26 --> URI Class Initialized
INFO - 2020-10-05 12:18:26 --> Router Class Initialized
INFO - 2020-10-05 12:18:26 --> Output Class Initialized
INFO - 2020-10-05 12:18:26 --> Security Class Initialized
DEBUG - 2020-10-05 12:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:18:26 --> Input Class Initialized
INFO - 2020-10-05 12:18:26 --> Language Class Initialized
ERROR - 2020-10-05 12:18:26 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 12:19:06 --> Config Class Initialized
INFO - 2020-10-05 12:19:06 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:19:06 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:19:06 --> Utf8 Class Initialized
INFO - 2020-10-05 12:19:06 --> URI Class Initialized
INFO - 2020-10-05 12:19:06 --> Router Class Initialized
INFO - 2020-10-05 12:19:06 --> Output Class Initialized
INFO - 2020-10-05 12:19:06 --> Security Class Initialized
DEBUG - 2020-10-05 12:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:19:06 --> Input Class Initialized
INFO - 2020-10-05 12:19:06 --> Language Class Initialized
INFO - 2020-10-05 12:19:06 --> Loader Class Initialized
INFO - 2020-10-05 12:19:06 --> Helper loaded: url_helper
INFO - 2020-10-05 12:19:06 --> Helper loaded: file_helper
INFO - 2020-10-05 12:19:06 --> Database Driver Class Initialized
INFO - 2020-10-05 12:19:06 --> Email Class Initialized
DEBUG - 2020-10-05 12:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:19:06 --> Controller Class Initialized
INFO - 2020-10-05 12:19:06 --> Model "Main_model" initialized
INFO - 2020-10-05 12:19:06 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:19:06 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:19:06 --> Final output sent to browser
DEBUG - 2020-10-05 12:19:06 --> Total execution time: 0.4663
INFO - 2020-10-05 12:19:07 --> Config Class Initialized
INFO - 2020-10-05 12:19:07 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:19:07 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:19:07 --> Utf8 Class Initialized
INFO - 2020-10-05 12:19:07 --> URI Class Initialized
INFO - 2020-10-05 12:19:07 --> Router Class Initialized
INFO - 2020-10-05 12:19:07 --> Output Class Initialized
INFO - 2020-10-05 12:19:07 --> Security Class Initialized
DEBUG - 2020-10-05 12:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:19:07 --> Input Class Initialized
INFO - 2020-10-05 12:19:08 --> Language Class Initialized
ERROR - 2020-10-05 12:19:08 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 12:21:18 --> Config Class Initialized
INFO - 2020-10-05 12:21:18 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:21:18 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:21:18 --> Utf8 Class Initialized
INFO - 2020-10-05 12:21:18 --> URI Class Initialized
INFO - 2020-10-05 12:21:18 --> Router Class Initialized
INFO - 2020-10-05 12:21:18 --> Output Class Initialized
INFO - 2020-10-05 12:21:18 --> Security Class Initialized
DEBUG - 2020-10-05 12:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:21:18 --> Input Class Initialized
INFO - 2020-10-05 12:21:19 --> Language Class Initialized
INFO - 2020-10-05 12:21:19 --> Loader Class Initialized
INFO - 2020-10-05 12:21:19 --> Helper loaded: url_helper
INFO - 2020-10-05 12:21:19 --> Helper loaded: file_helper
INFO - 2020-10-05 12:21:19 --> Database Driver Class Initialized
INFO - 2020-10-05 12:21:19 --> Email Class Initialized
DEBUG - 2020-10-05 12:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:21:19 --> Controller Class Initialized
INFO - 2020-10-05 12:21:19 --> Model "Main_model" initialized
INFO - 2020-10-05 12:21:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:21:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:21:19 --> Final output sent to browser
DEBUG - 2020-10-05 12:21:19 --> Total execution time: 0.3922
INFO - 2020-10-05 12:26:25 --> Config Class Initialized
INFO - 2020-10-05 12:26:25 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:26:25 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:26:25 --> Utf8 Class Initialized
INFO - 2020-10-05 12:26:25 --> URI Class Initialized
INFO - 2020-10-05 12:26:25 --> Router Class Initialized
INFO - 2020-10-05 12:26:25 --> Output Class Initialized
INFO - 2020-10-05 12:26:25 --> Security Class Initialized
DEBUG - 2020-10-05 12:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:26:26 --> Input Class Initialized
INFO - 2020-10-05 12:26:26 --> Language Class Initialized
ERROR - 2020-10-05 12:26:26 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 12:31:04 --> Config Class Initialized
INFO - 2020-10-05 12:31:04 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:31:04 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:31:04 --> Utf8 Class Initialized
INFO - 2020-10-05 12:31:04 --> URI Class Initialized
INFO - 2020-10-05 12:31:04 --> Router Class Initialized
INFO - 2020-10-05 12:31:04 --> Output Class Initialized
INFO - 2020-10-05 12:31:04 --> Security Class Initialized
DEBUG - 2020-10-05 12:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:31:05 --> Input Class Initialized
INFO - 2020-10-05 12:31:05 --> Language Class Initialized
INFO - 2020-10-05 12:31:05 --> Loader Class Initialized
INFO - 2020-10-05 12:31:05 --> Helper loaded: url_helper
INFO - 2020-10-05 12:31:05 --> Helper loaded: file_helper
INFO - 2020-10-05 12:31:05 --> Database Driver Class Initialized
INFO - 2020-10-05 12:31:05 --> Email Class Initialized
DEBUG - 2020-10-05 12:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:31:05 --> Controller Class Initialized
INFO - 2020-10-05 12:31:05 --> Model "Main_model" initialized
INFO - 2020-10-05 12:31:05 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:31:05 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:31:05 --> Final output sent to browser
DEBUG - 2020-10-05 12:31:05 --> Total execution time: 0.4082
INFO - 2020-10-05 12:31:15 --> Config Class Initialized
INFO - 2020-10-05 12:31:15 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:31:15 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:31:15 --> Utf8 Class Initialized
INFO - 2020-10-05 12:31:16 --> URI Class Initialized
INFO - 2020-10-05 12:31:16 --> Router Class Initialized
INFO - 2020-10-05 12:31:16 --> Output Class Initialized
INFO - 2020-10-05 12:31:16 --> Security Class Initialized
DEBUG - 2020-10-05 12:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:31:16 --> Input Class Initialized
INFO - 2020-10-05 12:31:16 --> Language Class Initialized
INFO - 2020-10-05 12:31:16 --> Loader Class Initialized
INFO - 2020-10-05 12:31:16 --> Helper loaded: url_helper
INFO - 2020-10-05 12:31:16 --> Helper loaded: file_helper
INFO - 2020-10-05 12:31:16 --> Database Driver Class Initialized
INFO - 2020-10-05 12:31:16 --> Email Class Initialized
DEBUG - 2020-10-05 12:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:31:16 --> Controller Class Initialized
INFO - 2020-10-05 12:31:16 --> Model "Main_model" initialized
ERROR - 2020-10-05 12:31:16 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\dmarc\system\database\DB_driver.php 1471
ERROR - 2020-10-05 12:31:16 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `alerts` (`domains`, `domainame`, `severity`, `category`, `condition_no`, `condition_day`, `condition_text`, `uid`, `created_at`) VALUES (Array, '0', 'informational', 'emails', '200', '1', 'dmarc-capable', '23', '2020-10-05 12:31:16')
INFO - 2020-10-05 12:31:16 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-05 12:32:05 --> Config Class Initialized
INFO - 2020-10-05 12:32:05 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:32:05 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:32:06 --> Utf8 Class Initialized
INFO - 2020-10-05 12:32:06 --> URI Class Initialized
INFO - 2020-10-05 12:32:06 --> Router Class Initialized
INFO - 2020-10-05 12:32:06 --> Output Class Initialized
INFO - 2020-10-05 12:32:06 --> Security Class Initialized
DEBUG - 2020-10-05 12:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:32:06 --> Input Class Initialized
INFO - 2020-10-05 12:32:06 --> Language Class Initialized
INFO - 2020-10-05 12:32:06 --> Loader Class Initialized
INFO - 2020-10-05 12:32:06 --> Helper loaded: url_helper
INFO - 2020-10-05 12:32:06 --> Helper loaded: file_helper
INFO - 2020-10-05 12:32:06 --> Database Driver Class Initialized
INFO - 2020-10-05 12:32:06 --> Email Class Initialized
DEBUG - 2020-10-05 12:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:32:06 --> Controller Class Initialized
INFO - 2020-10-05 12:32:06 --> Model "Main_model" initialized
ERROR - 2020-10-05 12:32:06 --> Query error: Unknown column 'domainame' in 'field list' - Invalid query: INSERT INTO `alerts` (`domainame`, `severity`, `category`, `condition_no`, `condition_day`, `condition_text`, `uid`, `created_at`) VALUES ('0', 'informational', 'emails', '200', '1', 'dmarc-capable', '23', '2020-10-05 12:32:06')
INFO - 2020-10-05 12:32:06 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-05 12:32:53 --> Config Class Initialized
INFO - 2020-10-05 12:32:53 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:32:53 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:32:53 --> Utf8 Class Initialized
INFO - 2020-10-05 12:32:53 --> URI Class Initialized
INFO - 2020-10-05 12:32:53 --> Router Class Initialized
INFO - 2020-10-05 12:32:53 --> Output Class Initialized
INFO - 2020-10-05 12:32:53 --> Security Class Initialized
DEBUG - 2020-10-05 12:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:32:53 --> Input Class Initialized
INFO - 2020-10-05 12:32:53 --> Language Class Initialized
INFO - 2020-10-05 12:32:53 --> Loader Class Initialized
INFO - 2020-10-05 12:32:53 --> Helper loaded: url_helper
INFO - 2020-10-05 12:32:53 --> Helper loaded: file_helper
INFO - 2020-10-05 12:32:53 --> Database Driver Class Initialized
INFO - 2020-10-05 12:32:53 --> Email Class Initialized
DEBUG - 2020-10-05 12:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:32:53 --> Controller Class Initialized
INFO - 2020-10-05 12:32:53 --> Model "Main_model" initialized
INFO - 2020-10-05 12:32:53 --> Config Class Initialized
INFO - 2020-10-05 12:32:54 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:32:54 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:32:54 --> Utf8 Class Initialized
INFO - 2020-10-05 12:32:54 --> URI Class Initialized
INFO - 2020-10-05 12:32:54 --> Router Class Initialized
INFO - 2020-10-05 12:32:54 --> Output Class Initialized
INFO - 2020-10-05 12:32:54 --> Security Class Initialized
DEBUG - 2020-10-05 12:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:32:54 --> Input Class Initialized
INFO - 2020-10-05 12:32:54 --> Language Class Initialized
ERROR - 2020-10-05 12:32:54 --> 404 Page Not Found: Create_alert/index
INFO - 2020-10-05 12:32:56 --> Config Class Initialized
INFO - 2020-10-05 12:32:56 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:32:56 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:32:56 --> Utf8 Class Initialized
INFO - 2020-10-05 12:32:56 --> URI Class Initialized
INFO - 2020-10-05 12:32:56 --> Router Class Initialized
INFO - 2020-10-05 12:32:56 --> Output Class Initialized
INFO - 2020-10-05 12:32:56 --> Security Class Initialized
DEBUG - 2020-10-05 12:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:32:56 --> Input Class Initialized
INFO - 2020-10-05 12:32:56 --> Language Class Initialized
ERROR - 2020-10-05 12:32:56 --> 404 Page Not Found: Create_alert/index
INFO - 2020-10-05 12:32:58 --> Config Class Initialized
INFO - 2020-10-05 12:32:58 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:32:58 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:32:58 --> Utf8 Class Initialized
INFO - 2020-10-05 12:32:58 --> URI Class Initialized
INFO - 2020-10-05 12:32:58 --> Router Class Initialized
INFO - 2020-10-05 12:32:58 --> Output Class Initialized
INFO - 2020-10-05 12:32:58 --> Security Class Initialized
DEBUG - 2020-10-05 12:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:32:58 --> Input Class Initialized
INFO - 2020-10-05 12:32:58 --> Language Class Initialized
ERROR - 2020-10-05 12:32:58 --> 404 Page Not Found: Create_alert/index
INFO - 2020-10-05 12:33:16 --> Config Class Initialized
INFO - 2020-10-05 12:33:16 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:33:16 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:33:16 --> Utf8 Class Initialized
INFO - 2020-10-05 12:33:16 --> URI Class Initialized
INFO - 2020-10-05 12:33:16 --> Router Class Initialized
INFO - 2020-10-05 12:33:16 --> Output Class Initialized
INFO - 2020-10-05 12:33:16 --> Security Class Initialized
DEBUG - 2020-10-05 12:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:33:16 --> Input Class Initialized
INFO - 2020-10-05 12:33:16 --> Language Class Initialized
INFO - 2020-10-05 12:33:16 --> Loader Class Initialized
INFO - 2020-10-05 12:33:16 --> Helper loaded: url_helper
INFO - 2020-10-05 12:33:16 --> Helper loaded: file_helper
INFO - 2020-10-05 12:33:16 --> Database Driver Class Initialized
INFO - 2020-10-05 12:33:16 --> Email Class Initialized
DEBUG - 2020-10-05 12:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:33:16 --> Controller Class Initialized
INFO - 2020-10-05 12:33:16 --> Model "Main_model" initialized
INFO - 2020-10-05 12:33:18 --> Config Class Initialized
INFO - 2020-10-05 12:33:18 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:33:18 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:33:18 --> Utf8 Class Initialized
INFO - 2020-10-05 12:33:18 --> URI Class Initialized
INFO - 2020-10-05 12:33:18 --> Router Class Initialized
INFO - 2020-10-05 12:33:18 --> Output Class Initialized
INFO - 2020-10-05 12:33:18 --> Security Class Initialized
DEBUG - 2020-10-05 12:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:33:18 --> Input Class Initialized
INFO - 2020-10-05 12:33:18 --> Language Class Initialized
INFO - 2020-10-05 12:33:18 --> Loader Class Initialized
INFO - 2020-10-05 12:33:18 --> Helper loaded: url_helper
INFO - 2020-10-05 12:33:18 --> Helper loaded: file_helper
INFO - 2020-10-05 12:33:18 --> Database Driver Class Initialized
INFO - 2020-10-05 12:33:18 --> Email Class Initialized
DEBUG - 2020-10-05 12:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:33:18 --> Controller Class Initialized
INFO - 2020-10-05 12:33:18 --> Model "Main_model" initialized
INFO - 2020-10-05 12:33:20 --> Config Class Initialized
INFO - 2020-10-05 12:33:20 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:33:20 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:33:20 --> Utf8 Class Initialized
INFO - 2020-10-05 12:33:20 --> URI Class Initialized
INFO - 2020-10-05 12:33:20 --> Router Class Initialized
INFO - 2020-10-05 12:33:20 --> Output Class Initialized
INFO - 2020-10-05 12:33:20 --> Security Class Initialized
DEBUG - 2020-10-05 12:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:33:20 --> Input Class Initialized
INFO - 2020-10-05 12:33:20 --> Language Class Initialized
INFO - 2020-10-05 12:33:20 --> Loader Class Initialized
INFO - 2020-10-05 12:33:20 --> Helper loaded: url_helper
INFO - 2020-10-05 12:33:20 --> Helper loaded: file_helper
INFO - 2020-10-05 12:33:20 --> Database Driver Class Initialized
INFO - 2020-10-05 12:33:20 --> Email Class Initialized
DEBUG - 2020-10-05 12:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:33:20 --> Controller Class Initialized
INFO - 2020-10-05 12:33:20 --> Model "Main_model" initialized
INFO - 2020-10-05 12:33:24 --> Config Class Initialized
INFO - 2020-10-05 12:33:24 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:33:24 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:33:24 --> Utf8 Class Initialized
INFO - 2020-10-05 12:33:24 --> URI Class Initialized
INFO - 2020-10-05 12:33:24 --> Router Class Initialized
INFO - 2020-10-05 12:33:24 --> Output Class Initialized
INFO - 2020-10-05 12:33:24 --> Security Class Initialized
DEBUG - 2020-10-05 12:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:33:24 --> Input Class Initialized
INFO - 2020-10-05 12:33:24 --> Language Class Initialized
INFO - 2020-10-05 12:33:24 --> Loader Class Initialized
INFO - 2020-10-05 12:33:24 --> Helper loaded: url_helper
INFO - 2020-10-05 12:33:24 --> Helper loaded: file_helper
INFO - 2020-10-05 12:33:24 --> Database Driver Class Initialized
INFO - 2020-10-05 12:33:25 --> Email Class Initialized
DEBUG - 2020-10-05 12:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:33:25 --> Controller Class Initialized
INFO - 2020-10-05 12:33:25 --> Model "Main_model" initialized
INFO - 2020-10-05 12:33:43 --> Config Class Initialized
INFO - 2020-10-05 12:33:43 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:33:43 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:33:43 --> Utf8 Class Initialized
INFO - 2020-10-05 12:33:43 --> URI Class Initialized
INFO - 2020-10-05 12:33:43 --> Router Class Initialized
INFO - 2020-10-05 12:33:43 --> Output Class Initialized
INFO - 2020-10-05 12:33:43 --> Security Class Initialized
DEBUG - 2020-10-05 12:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:33:43 --> Input Class Initialized
INFO - 2020-10-05 12:33:43 --> Language Class Initialized
INFO - 2020-10-05 12:33:43 --> Loader Class Initialized
INFO - 2020-10-05 12:33:44 --> Helper loaded: url_helper
INFO - 2020-10-05 12:33:44 --> Helper loaded: file_helper
INFO - 2020-10-05 12:33:44 --> Database Driver Class Initialized
INFO - 2020-10-05 12:33:44 --> Email Class Initialized
DEBUG - 2020-10-05 12:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:33:44 --> Controller Class Initialized
INFO - 2020-10-05 12:33:44 --> Model "Main_model" initialized
INFO - 2020-10-05 12:33:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:33:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:33:44 --> Final output sent to browser
DEBUG - 2020-10-05 12:33:44 --> Total execution time: 0.3800
INFO - 2020-10-05 12:33:51 --> Config Class Initialized
INFO - 2020-10-05 12:33:51 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:33:51 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:33:51 --> Utf8 Class Initialized
INFO - 2020-10-05 12:33:51 --> URI Class Initialized
INFO - 2020-10-05 12:33:51 --> Router Class Initialized
INFO - 2020-10-05 12:33:51 --> Output Class Initialized
INFO - 2020-10-05 12:33:51 --> Security Class Initialized
DEBUG - 2020-10-05 12:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:33:51 --> Input Class Initialized
INFO - 2020-10-05 12:33:51 --> Language Class Initialized
INFO - 2020-10-05 12:33:51 --> Loader Class Initialized
INFO - 2020-10-05 12:33:51 --> Helper loaded: url_helper
INFO - 2020-10-05 12:33:51 --> Helper loaded: file_helper
INFO - 2020-10-05 12:33:51 --> Database Driver Class Initialized
INFO - 2020-10-05 12:33:51 --> Email Class Initialized
DEBUG - 2020-10-05 12:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:33:51 --> Controller Class Initialized
INFO - 2020-10-05 12:33:51 --> Model "Main_model" initialized
INFO - 2020-10-05 12:33:51 --> Config Class Initialized
INFO - 2020-10-05 12:33:51 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:33:51 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:33:51 --> Utf8 Class Initialized
INFO - 2020-10-05 12:33:51 --> URI Class Initialized
INFO - 2020-10-05 12:33:51 --> Router Class Initialized
INFO - 2020-10-05 12:33:51 --> Output Class Initialized
INFO - 2020-10-05 12:33:51 --> Security Class Initialized
DEBUG - 2020-10-05 12:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:33:51 --> Input Class Initialized
INFO - 2020-10-05 12:33:51 --> Language Class Initialized
INFO - 2020-10-05 12:33:51 --> Loader Class Initialized
INFO - 2020-10-05 12:33:51 --> Helper loaded: url_helper
INFO - 2020-10-05 12:33:51 --> Helper loaded: file_helper
INFO - 2020-10-05 12:33:51 --> Database Driver Class Initialized
INFO - 2020-10-05 12:33:51 --> Email Class Initialized
DEBUG - 2020-10-05 12:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:33:51 --> Controller Class Initialized
INFO - 2020-10-05 12:33:51 --> Model "Main_model" initialized
INFO - 2020-10-05 12:33:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:33:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:33:51 --> Final output sent to browser
DEBUG - 2020-10-05 12:33:51 --> Total execution time: 0.3855
INFO - 2020-10-05 12:33:58 --> Config Class Initialized
INFO - 2020-10-05 12:33:58 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:33:58 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:33:58 --> Utf8 Class Initialized
INFO - 2020-10-05 12:33:58 --> URI Class Initialized
INFO - 2020-10-05 12:33:58 --> Router Class Initialized
INFO - 2020-10-05 12:33:58 --> Output Class Initialized
INFO - 2020-10-05 12:33:59 --> Security Class Initialized
DEBUG - 2020-10-05 12:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:33:59 --> Input Class Initialized
INFO - 2020-10-05 12:33:59 --> Language Class Initialized
INFO - 2020-10-05 12:33:59 --> Loader Class Initialized
INFO - 2020-10-05 12:33:59 --> Helper loaded: url_helper
INFO - 2020-10-05 12:33:59 --> Helper loaded: file_helper
INFO - 2020-10-05 12:33:59 --> Database Driver Class Initialized
INFO - 2020-10-05 12:33:59 --> Email Class Initialized
DEBUG - 2020-10-05 12:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:33:59 --> Controller Class Initialized
INFO - 2020-10-05 12:33:59 --> Model "Main_model" initialized
INFO - 2020-10-05 12:33:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:33:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:33:59 --> Final output sent to browser
DEBUG - 2020-10-05 12:33:59 --> Total execution time: 0.3892
INFO - 2020-10-05 12:34:00 --> Config Class Initialized
INFO - 2020-10-05 12:34:00 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:34:00 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:34:00 --> Utf8 Class Initialized
INFO - 2020-10-05 12:34:00 --> URI Class Initialized
INFO - 2020-10-05 12:34:00 --> Router Class Initialized
INFO - 2020-10-05 12:34:00 --> Output Class Initialized
INFO - 2020-10-05 12:34:00 --> Security Class Initialized
DEBUG - 2020-10-05 12:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:34:01 --> Input Class Initialized
INFO - 2020-10-05 12:34:01 --> Language Class Initialized
INFO - 2020-10-05 12:34:01 --> Loader Class Initialized
INFO - 2020-10-05 12:34:01 --> Helper loaded: url_helper
INFO - 2020-10-05 12:34:01 --> Helper loaded: file_helper
INFO - 2020-10-05 12:34:01 --> Database Driver Class Initialized
INFO - 2020-10-05 12:34:01 --> Email Class Initialized
DEBUG - 2020-10-05 12:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:34:01 --> Controller Class Initialized
INFO - 2020-10-05 12:34:01 --> Model "Main_model" initialized
INFO - 2020-10-05 12:34:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:34:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:34:01 --> Final output sent to browser
DEBUG - 2020-10-05 12:34:01 --> Total execution time: 0.3767
INFO - 2020-10-05 12:34:28 --> Config Class Initialized
INFO - 2020-10-05 12:34:28 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:34:28 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:34:28 --> Utf8 Class Initialized
INFO - 2020-10-05 12:34:28 --> URI Class Initialized
INFO - 2020-10-05 12:34:28 --> Router Class Initialized
INFO - 2020-10-05 12:34:28 --> Output Class Initialized
INFO - 2020-10-05 12:34:28 --> Security Class Initialized
DEBUG - 2020-10-05 12:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:34:28 --> Input Class Initialized
INFO - 2020-10-05 12:34:28 --> Language Class Initialized
INFO - 2020-10-05 12:34:28 --> Loader Class Initialized
INFO - 2020-10-05 12:34:28 --> Helper loaded: url_helper
INFO - 2020-10-05 12:34:28 --> Helper loaded: file_helper
INFO - 2020-10-05 12:34:28 --> Database Driver Class Initialized
INFO - 2020-10-05 12:34:28 --> Email Class Initialized
DEBUG - 2020-10-05 12:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:34:28 --> Controller Class Initialized
INFO - 2020-10-05 12:34:28 --> Model "Main_model" initialized
INFO - 2020-10-05 12:34:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:34:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:34:29 --> Final output sent to browser
DEBUG - 2020-10-05 12:34:29 --> Total execution time: 0.4230
INFO - 2020-10-05 12:34:33 --> Config Class Initialized
INFO - 2020-10-05 12:34:33 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:34:33 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:34:33 --> Utf8 Class Initialized
INFO - 2020-10-05 12:34:33 --> URI Class Initialized
INFO - 2020-10-05 12:34:33 --> Router Class Initialized
INFO - 2020-10-05 12:34:33 --> Output Class Initialized
INFO - 2020-10-05 12:34:33 --> Security Class Initialized
DEBUG - 2020-10-05 12:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:34:33 --> Input Class Initialized
INFO - 2020-10-05 12:34:33 --> Language Class Initialized
ERROR - 2020-10-05 12:34:33 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 12:35:08 --> Config Class Initialized
INFO - 2020-10-05 12:35:09 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:35:09 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:35:09 --> Utf8 Class Initialized
INFO - 2020-10-05 12:35:09 --> URI Class Initialized
INFO - 2020-10-05 12:35:09 --> Router Class Initialized
INFO - 2020-10-05 12:35:09 --> Output Class Initialized
INFO - 2020-10-05 12:35:09 --> Security Class Initialized
DEBUG - 2020-10-05 12:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:35:09 --> Input Class Initialized
INFO - 2020-10-05 12:35:09 --> Language Class Initialized
INFO - 2020-10-05 12:35:09 --> Loader Class Initialized
INFO - 2020-10-05 12:35:09 --> Helper loaded: url_helper
INFO - 2020-10-05 12:35:09 --> Helper loaded: file_helper
INFO - 2020-10-05 12:35:09 --> Database Driver Class Initialized
INFO - 2020-10-05 12:35:09 --> Email Class Initialized
DEBUG - 2020-10-05 12:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:35:09 --> Controller Class Initialized
INFO - 2020-10-05 12:35:09 --> Model "Main_model" initialized
INFO - 2020-10-05 12:35:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:35:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:35:09 --> Final output sent to browser
DEBUG - 2020-10-05 12:35:09 --> Total execution time: 0.4195
INFO - 2020-10-05 12:35:10 --> Config Class Initialized
INFO - 2020-10-05 12:35:10 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:35:10 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:35:10 --> Utf8 Class Initialized
INFO - 2020-10-05 12:35:10 --> URI Class Initialized
INFO - 2020-10-05 12:35:10 --> Router Class Initialized
INFO - 2020-10-05 12:35:10 --> Output Class Initialized
INFO - 2020-10-05 12:35:10 --> Security Class Initialized
DEBUG - 2020-10-05 12:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:35:10 --> Input Class Initialized
INFO - 2020-10-05 12:35:10 --> Language Class Initialized
ERROR - 2020-10-05 12:35:10 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 12:35:19 --> Config Class Initialized
INFO - 2020-10-05 12:35:19 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:35:19 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:35:19 --> Utf8 Class Initialized
INFO - 2020-10-05 12:35:19 --> URI Class Initialized
INFO - 2020-10-05 12:35:19 --> Router Class Initialized
INFO - 2020-10-05 12:35:19 --> Output Class Initialized
INFO - 2020-10-05 12:35:19 --> Security Class Initialized
DEBUG - 2020-10-05 12:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:35:19 --> Input Class Initialized
INFO - 2020-10-05 12:35:19 --> Language Class Initialized
INFO - 2020-10-05 12:35:19 --> Loader Class Initialized
INFO - 2020-10-05 12:35:19 --> Helper loaded: url_helper
INFO - 2020-10-05 12:35:19 --> Helper loaded: file_helper
INFO - 2020-10-05 12:35:19 --> Database Driver Class Initialized
INFO - 2020-10-05 12:35:19 --> Email Class Initialized
DEBUG - 2020-10-05 12:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:35:19 --> Controller Class Initialized
INFO - 2020-10-05 12:35:19 --> Model "Main_model" initialized
INFO - 2020-10-05 12:35:19 --> Config Class Initialized
INFO - 2020-10-05 12:35:19 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:35:19 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:35:19 --> Utf8 Class Initialized
INFO - 2020-10-05 12:35:19 --> URI Class Initialized
INFO - 2020-10-05 12:35:19 --> Router Class Initialized
INFO - 2020-10-05 12:35:19 --> Output Class Initialized
INFO - 2020-10-05 12:35:19 --> Security Class Initialized
DEBUG - 2020-10-05 12:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:35:19 --> Input Class Initialized
INFO - 2020-10-05 12:35:19 --> Language Class Initialized
INFO - 2020-10-05 12:35:19 --> Loader Class Initialized
INFO - 2020-10-05 12:35:19 --> Helper loaded: url_helper
INFO - 2020-10-05 12:35:19 --> Helper loaded: file_helper
INFO - 2020-10-05 12:35:19 --> Database Driver Class Initialized
INFO - 2020-10-05 12:35:19 --> Email Class Initialized
DEBUG - 2020-10-05 12:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:35:19 --> Controller Class Initialized
INFO - 2020-10-05 12:35:19 --> Model "Main_model" initialized
INFO - 2020-10-05 12:35:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:35:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:35:19 --> Final output sent to browser
DEBUG - 2020-10-05 12:35:19 --> Total execution time: 0.3935
INFO - 2020-10-05 12:35:23 --> Config Class Initialized
INFO - 2020-10-05 12:35:23 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:35:23 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:35:23 --> Utf8 Class Initialized
INFO - 2020-10-05 12:35:23 --> URI Class Initialized
INFO - 2020-10-05 12:35:23 --> Router Class Initialized
INFO - 2020-10-05 12:35:23 --> Output Class Initialized
INFO - 2020-10-05 12:35:23 --> Security Class Initialized
DEBUG - 2020-10-05 12:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:35:23 --> Input Class Initialized
INFO - 2020-10-05 12:35:23 --> Language Class Initialized
INFO - 2020-10-05 12:35:23 --> Loader Class Initialized
INFO - 2020-10-05 12:35:23 --> Helper loaded: url_helper
INFO - 2020-10-05 12:35:23 --> Helper loaded: file_helper
INFO - 2020-10-05 12:35:23 --> Database Driver Class Initialized
INFO - 2020-10-05 12:35:23 --> Email Class Initialized
DEBUG - 2020-10-05 12:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:35:23 --> Controller Class Initialized
INFO - 2020-10-05 12:35:23 --> Model "Main_model" initialized
INFO - 2020-10-05 12:35:23 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:35:23 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:35:23 --> Final output sent to browser
DEBUG - 2020-10-05 12:35:23 --> Total execution time: 0.4279
INFO - 2020-10-05 12:38:55 --> Config Class Initialized
INFO - 2020-10-05 12:38:55 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:38:55 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:38:55 --> Utf8 Class Initialized
INFO - 2020-10-05 12:38:55 --> URI Class Initialized
INFO - 2020-10-05 12:38:55 --> Router Class Initialized
INFO - 2020-10-05 12:38:55 --> Output Class Initialized
INFO - 2020-10-05 12:38:55 --> Security Class Initialized
DEBUG - 2020-10-05 12:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:38:55 --> Input Class Initialized
INFO - 2020-10-05 12:38:55 --> Language Class Initialized
INFO - 2020-10-05 12:38:55 --> Loader Class Initialized
INFO - 2020-10-05 12:38:55 --> Helper loaded: url_helper
INFO - 2020-10-05 12:38:55 --> Helper loaded: file_helper
INFO - 2020-10-05 12:38:55 --> Database Driver Class Initialized
INFO - 2020-10-05 12:38:55 --> Email Class Initialized
DEBUG - 2020-10-05 12:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:38:55 --> Controller Class Initialized
INFO - 2020-10-05 12:38:55 --> Model "Main_model" initialized
INFO - 2020-10-05 12:38:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:38:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:38:55 --> Final output sent to browser
DEBUG - 2020-10-05 12:38:55 --> Total execution time: 0.4791
INFO - 2020-10-05 12:39:19 --> Config Class Initialized
INFO - 2020-10-05 12:39:19 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:39:19 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:39:19 --> Utf8 Class Initialized
INFO - 2020-10-05 12:39:19 --> URI Class Initialized
INFO - 2020-10-05 12:39:19 --> Router Class Initialized
INFO - 2020-10-05 12:39:19 --> Output Class Initialized
INFO - 2020-10-05 12:39:19 --> Security Class Initialized
DEBUG - 2020-10-05 12:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:39:19 --> Input Class Initialized
INFO - 2020-10-05 12:39:19 --> Language Class Initialized
INFO - 2020-10-05 12:39:19 --> Loader Class Initialized
INFO - 2020-10-05 12:39:19 --> Helper loaded: url_helper
INFO - 2020-10-05 12:39:19 --> Helper loaded: file_helper
INFO - 2020-10-05 12:39:19 --> Database Driver Class Initialized
INFO - 2020-10-05 12:39:19 --> Email Class Initialized
DEBUG - 2020-10-05 12:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:39:19 --> Controller Class Initialized
INFO - 2020-10-05 12:39:19 --> Model "Main_model" initialized
INFO - 2020-10-05 12:39:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:39:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:39:19 --> Final output sent to browser
DEBUG - 2020-10-05 12:39:19 --> Total execution time: 0.4059
INFO - 2020-10-05 12:40:13 --> Config Class Initialized
INFO - 2020-10-05 12:40:13 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:40:13 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:40:13 --> Utf8 Class Initialized
INFO - 2020-10-05 12:40:13 --> URI Class Initialized
INFO - 2020-10-05 12:40:13 --> Router Class Initialized
INFO - 2020-10-05 12:40:13 --> Output Class Initialized
INFO - 2020-10-05 12:40:13 --> Security Class Initialized
DEBUG - 2020-10-05 12:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:40:13 --> Input Class Initialized
INFO - 2020-10-05 12:40:13 --> Language Class Initialized
INFO - 2020-10-05 12:40:13 --> Loader Class Initialized
INFO - 2020-10-05 12:40:13 --> Helper loaded: url_helper
INFO - 2020-10-05 12:40:13 --> Helper loaded: file_helper
INFO - 2020-10-05 12:40:13 --> Database Driver Class Initialized
INFO - 2020-10-05 12:40:13 --> Email Class Initialized
DEBUG - 2020-10-05 12:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:40:13 --> Controller Class Initialized
INFO - 2020-10-05 12:40:13 --> Model "Main_model" initialized
INFO - 2020-10-05 12:40:13 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:40:13 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:40:13 --> Final output sent to browser
DEBUG - 2020-10-05 12:40:13 --> Total execution time: 0.4223
INFO - 2020-10-05 12:40:29 --> Config Class Initialized
INFO - 2020-10-05 12:40:29 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:40:29 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:40:29 --> Utf8 Class Initialized
INFO - 2020-10-05 12:40:29 --> URI Class Initialized
INFO - 2020-10-05 12:40:29 --> Router Class Initialized
INFO - 2020-10-05 12:40:29 --> Output Class Initialized
INFO - 2020-10-05 12:40:29 --> Security Class Initialized
DEBUG - 2020-10-05 12:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:40:29 --> Input Class Initialized
INFO - 2020-10-05 12:40:29 --> Language Class Initialized
INFO - 2020-10-05 12:40:29 --> Loader Class Initialized
INFO - 2020-10-05 12:40:29 --> Helper loaded: url_helper
INFO - 2020-10-05 12:40:29 --> Helper loaded: file_helper
INFO - 2020-10-05 12:40:30 --> Database Driver Class Initialized
INFO - 2020-10-05 12:40:30 --> Email Class Initialized
DEBUG - 2020-10-05 12:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:40:30 --> Controller Class Initialized
INFO - 2020-10-05 12:40:30 --> Model "Main_model" initialized
INFO - 2020-10-05 12:40:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:40:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:40:30 --> Final output sent to browser
DEBUG - 2020-10-05 12:40:30 --> Total execution time: 0.4149
INFO - 2020-10-05 12:43:38 --> Config Class Initialized
INFO - 2020-10-05 12:43:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:43:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:43:38 --> Utf8 Class Initialized
INFO - 2020-10-05 12:43:38 --> URI Class Initialized
INFO - 2020-10-05 12:43:38 --> Router Class Initialized
INFO - 2020-10-05 12:43:38 --> Output Class Initialized
INFO - 2020-10-05 12:43:38 --> Security Class Initialized
DEBUG - 2020-10-05 12:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:43:38 --> Input Class Initialized
INFO - 2020-10-05 12:43:38 --> Language Class Initialized
INFO - 2020-10-05 12:43:38 --> Loader Class Initialized
INFO - 2020-10-05 12:43:38 --> Helper loaded: url_helper
INFO - 2020-10-05 12:43:38 --> Helper loaded: file_helper
INFO - 2020-10-05 12:43:38 --> Database Driver Class Initialized
INFO - 2020-10-05 12:43:38 --> Email Class Initialized
DEBUG - 2020-10-05 12:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:43:39 --> Controller Class Initialized
INFO - 2020-10-05 12:43:39 --> Model "Main_model" initialized
INFO - 2020-10-05 12:43:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:43:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:43:39 --> Final output sent to browser
DEBUG - 2020-10-05 12:43:39 --> Total execution time: 0.4035
INFO - 2020-10-05 12:44:29 --> Config Class Initialized
INFO - 2020-10-05 12:44:29 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:44:29 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:44:29 --> Utf8 Class Initialized
INFO - 2020-10-05 12:44:29 --> URI Class Initialized
INFO - 2020-10-05 12:44:29 --> Router Class Initialized
INFO - 2020-10-05 12:44:29 --> Output Class Initialized
INFO - 2020-10-05 12:44:29 --> Security Class Initialized
DEBUG - 2020-10-05 12:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:44:29 --> Input Class Initialized
INFO - 2020-10-05 12:44:29 --> Language Class Initialized
INFO - 2020-10-05 12:44:29 --> Loader Class Initialized
INFO - 2020-10-05 12:44:29 --> Helper loaded: url_helper
INFO - 2020-10-05 12:44:29 --> Helper loaded: file_helper
INFO - 2020-10-05 12:44:29 --> Database Driver Class Initialized
INFO - 2020-10-05 12:44:29 --> Email Class Initialized
DEBUG - 2020-10-05 12:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:44:29 --> Controller Class Initialized
INFO - 2020-10-05 12:44:29 --> Model "Main_model" initialized
INFO - 2020-10-05 12:44:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:44:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:44:29 --> Final output sent to browser
DEBUG - 2020-10-05 12:44:29 --> Total execution time: 0.4707
INFO - 2020-10-05 12:44:54 --> Config Class Initialized
INFO - 2020-10-05 12:44:54 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:44:54 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:44:54 --> Utf8 Class Initialized
INFO - 2020-10-05 12:44:54 --> URI Class Initialized
INFO - 2020-10-05 12:44:54 --> Router Class Initialized
INFO - 2020-10-05 12:44:54 --> Output Class Initialized
INFO - 2020-10-05 12:44:54 --> Security Class Initialized
DEBUG - 2020-10-05 12:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:44:54 --> Input Class Initialized
INFO - 2020-10-05 12:44:54 --> Language Class Initialized
INFO - 2020-10-05 12:44:54 --> Loader Class Initialized
INFO - 2020-10-05 12:44:54 --> Helper loaded: url_helper
INFO - 2020-10-05 12:44:54 --> Helper loaded: file_helper
INFO - 2020-10-05 12:44:54 --> Database Driver Class Initialized
INFO - 2020-10-05 12:44:54 --> Email Class Initialized
DEBUG - 2020-10-05 12:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:44:54 --> Controller Class Initialized
INFO - 2020-10-05 12:44:54 --> Model "Main_model" initialized
INFO - 2020-10-05 12:44:54 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:44:54 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:44:54 --> Final output sent to browser
DEBUG - 2020-10-05 12:44:54 --> Total execution time: 0.4125
INFO - 2020-10-05 12:46:28 --> Config Class Initialized
INFO - 2020-10-05 12:46:28 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:46:28 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:46:28 --> Utf8 Class Initialized
INFO - 2020-10-05 12:46:28 --> URI Class Initialized
INFO - 2020-10-05 12:46:28 --> Router Class Initialized
INFO - 2020-10-05 12:46:28 --> Output Class Initialized
INFO - 2020-10-05 12:46:28 --> Security Class Initialized
DEBUG - 2020-10-05 12:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:46:28 --> Input Class Initialized
INFO - 2020-10-05 12:46:28 --> Language Class Initialized
INFO - 2020-10-05 12:46:28 --> Loader Class Initialized
INFO - 2020-10-05 12:46:28 --> Helper loaded: url_helper
INFO - 2020-10-05 12:46:28 --> Helper loaded: file_helper
INFO - 2020-10-05 12:46:28 --> Database Driver Class Initialized
INFO - 2020-10-05 12:46:28 --> Email Class Initialized
DEBUG - 2020-10-05 12:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:46:28 --> Controller Class Initialized
INFO - 2020-10-05 12:46:28 --> Model "Main_model" initialized
INFO - 2020-10-05 12:46:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:46:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:46:28 --> Final output sent to browser
DEBUG - 2020-10-05 12:46:28 --> Total execution time: 0.4626
INFO - 2020-10-05 12:46:31 --> Config Class Initialized
INFO - 2020-10-05 12:46:31 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:46:31 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:46:31 --> Utf8 Class Initialized
INFO - 2020-10-05 12:46:31 --> URI Class Initialized
INFO - 2020-10-05 12:46:32 --> Router Class Initialized
INFO - 2020-10-05 12:46:32 --> Output Class Initialized
INFO - 2020-10-05 12:46:32 --> Security Class Initialized
DEBUG - 2020-10-05 12:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:46:32 --> Input Class Initialized
INFO - 2020-10-05 12:46:32 --> Language Class Initialized
INFO - 2020-10-05 12:46:32 --> Loader Class Initialized
INFO - 2020-10-05 12:46:32 --> Helper loaded: url_helper
INFO - 2020-10-05 12:46:32 --> Helper loaded: file_helper
INFO - 2020-10-05 12:46:32 --> Database Driver Class Initialized
INFO - 2020-10-05 12:46:32 --> Email Class Initialized
DEBUG - 2020-10-05 12:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:46:32 --> Controller Class Initialized
INFO - 2020-10-05 12:46:32 --> Model "Main_model" initialized
INFO - 2020-10-05 12:46:32 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:46:32 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:46:32 --> Final output sent to browser
DEBUG - 2020-10-05 12:46:32 --> Total execution time: 0.4248
INFO - 2020-10-05 12:46:38 --> Config Class Initialized
INFO - 2020-10-05 12:46:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:46:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:46:38 --> Utf8 Class Initialized
INFO - 2020-10-05 12:46:38 --> URI Class Initialized
INFO - 2020-10-05 12:46:38 --> Router Class Initialized
INFO - 2020-10-05 12:46:38 --> Output Class Initialized
INFO - 2020-10-05 12:46:38 --> Security Class Initialized
DEBUG - 2020-10-05 12:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:46:38 --> Input Class Initialized
INFO - 2020-10-05 12:46:38 --> Language Class Initialized
INFO - 2020-10-05 12:46:38 --> Loader Class Initialized
INFO - 2020-10-05 12:46:38 --> Helper loaded: url_helper
INFO - 2020-10-05 12:46:38 --> Helper loaded: file_helper
INFO - 2020-10-05 12:46:38 --> Database Driver Class Initialized
INFO - 2020-10-05 12:46:38 --> Email Class Initialized
DEBUG - 2020-10-05 12:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:46:38 --> Controller Class Initialized
INFO - 2020-10-05 12:46:38 --> Model "Main_model" initialized
INFO - 2020-10-05 12:47:17 --> Config Class Initialized
INFO - 2020-10-05 12:47:17 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:47:17 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:47:17 --> Utf8 Class Initialized
INFO - 2020-10-05 12:47:17 --> URI Class Initialized
INFO - 2020-10-05 12:47:17 --> Router Class Initialized
INFO - 2020-10-05 12:47:17 --> Output Class Initialized
INFO - 2020-10-05 12:47:17 --> Security Class Initialized
DEBUG - 2020-10-05 12:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:47:17 --> Input Class Initialized
INFO - 2020-10-05 12:47:17 --> Language Class Initialized
INFO - 2020-10-05 12:47:17 --> Loader Class Initialized
INFO - 2020-10-05 12:47:17 --> Helper loaded: url_helper
INFO - 2020-10-05 12:47:17 --> Helper loaded: file_helper
INFO - 2020-10-05 12:47:17 --> Database Driver Class Initialized
INFO - 2020-10-05 12:47:17 --> Email Class Initialized
DEBUG - 2020-10-05 12:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:47:17 --> Controller Class Initialized
INFO - 2020-10-05 12:47:17 --> Model "Main_model" initialized
INFO - 2020-10-05 12:47:17 --> Config Class Initialized
INFO - 2020-10-05 12:47:17 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:47:17 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:47:17 --> Utf8 Class Initialized
INFO - 2020-10-05 12:47:17 --> URI Class Initialized
INFO - 2020-10-05 12:47:17 --> Router Class Initialized
INFO - 2020-10-05 12:47:17 --> Output Class Initialized
INFO - 2020-10-05 12:47:17 --> Security Class Initialized
DEBUG - 2020-10-05 12:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:47:17 --> Input Class Initialized
INFO - 2020-10-05 12:47:17 --> Language Class Initialized
INFO - 2020-10-05 12:47:17 --> Loader Class Initialized
INFO - 2020-10-05 12:47:17 --> Helper loaded: url_helper
INFO - 2020-10-05 12:47:17 --> Helper loaded: file_helper
INFO - 2020-10-05 12:47:17 --> Database Driver Class Initialized
INFO - 2020-10-05 12:47:17 --> Email Class Initialized
DEBUG - 2020-10-05 12:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:47:17 --> Controller Class Initialized
INFO - 2020-10-05 12:47:17 --> Model "Main_model" initialized
INFO - 2020-10-05 12:47:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:47:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 12:47:18 --> Final output sent to browser
DEBUG - 2020-10-05 12:47:18 --> Total execution time: 0.4136
INFO - 2020-10-05 12:47:21 --> Config Class Initialized
INFO - 2020-10-05 12:47:21 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:47:21 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:47:21 --> Utf8 Class Initialized
INFO - 2020-10-05 12:47:21 --> URI Class Initialized
INFO - 2020-10-05 12:47:21 --> Router Class Initialized
INFO - 2020-10-05 12:47:21 --> Output Class Initialized
INFO - 2020-10-05 12:47:21 --> Security Class Initialized
DEBUG - 2020-10-05 12:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:47:21 --> Input Class Initialized
INFO - 2020-10-05 12:47:21 --> Language Class Initialized
INFO - 2020-10-05 12:47:21 --> Loader Class Initialized
INFO - 2020-10-05 12:47:21 --> Helper loaded: url_helper
INFO - 2020-10-05 12:47:21 --> Helper loaded: file_helper
INFO - 2020-10-05 12:47:21 --> Database Driver Class Initialized
INFO - 2020-10-05 12:47:21 --> Email Class Initialized
DEBUG - 2020-10-05 12:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:47:21 --> Controller Class Initialized
INFO - 2020-10-05 12:47:21 --> Model "Main_model" initialized
INFO - 2020-10-05 12:47:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:47:21 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:47:21 --> Final output sent to browser
DEBUG - 2020-10-05 12:47:21 --> Total execution time: 0.4984
INFO - 2020-10-05 12:47:44 --> Config Class Initialized
INFO - 2020-10-05 12:47:44 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:47:44 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:47:44 --> Utf8 Class Initialized
INFO - 2020-10-05 12:47:44 --> URI Class Initialized
INFO - 2020-10-05 12:47:44 --> Router Class Initialized
INFO - 2020-10-05 12:47:44 --> Output Class Initialized
INFO - 2020-10-05 12:47:44 --> Security Class Initialized
DEBUG - 2020-10-05 12:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:47:44 --> Input Class Initialized
INFO - 2020-10-05 12:47:44 --> Language Class Initialized
INFO - 2020-10-05 12:47:44 --> Loader Class Initialized
INFO - 2020-10-05 12:47:44 --> Helper loaded: url_helper
INFO - 2020-10-05 12:47:44 --> Helper loaded: file_helper
INFO - 2020-10-05 12:47:44 --> Database Driver Class Initialized
INFO - 2020-10-05 12:47:44 --> Email Class Initialized
DEBUG - 2020-10-05 12:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:47:44 --> Controller Class Initialized
INFO - 2020-10-05 12:47:44 --> Model "Main_model" initialized
INFO - 2020-10-05 12:47:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:47:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:47:44 --> Final output sent to browser
DEBUG - 2020-10-05 12:47:44 --> Total execution time: 0.4341
INFO - 2020-10-05 12:48:01 --> Config Class Initialized
INFO - 2020-10-05 12:48:01 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:48:01 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:48:01 --> Utf8 Class Initialized
INFO - 2020-10-05 12:48:01 --> URI Class Initialized
INFO - 2020-10-05 12:48:01 --> Router Class Initialized
INFO - 2020-10-05 12:48:01 --> Output Class Initialized
INFO - 2020-10-05 12:48:01 --> Security Class Initialized
DEBUG - 2020-10-05 12:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:48:01 --> Input Class Initialized
INFO - 2020-10-05 12:48:01 --> Language Class Initialized
INFO - 2020-10-05 12:48:01 --> Loader Class Initialized
INFO - 2020-10-05 12:48:01 --> Helper loaded: url_helper
INFO - 2020-10-05 12:48:01 --> Helper loaded: file_helper
INFO - 2020-10-05 12:48:01 --> Database Driver Class Initialized
INFO - 2020-10-05 12:48:01 --> Email Class Initialized
DEBUG - 2020-10-05 12:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:48:01 --> Controller Class Initialized
INFO - 2020-10-05 12:48:01 --> Model "Main_model" initialized
INFO - 2020-10-05 12:48:01 --> Config Class Initialized
INFO - 2020-10-05 12:48:01 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:48:01 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:48:01 --> Utf8 Class Initialized
INFO - 2020-10-05 12:48:01 --> URI Class Initialized
INFO - 2020-10-05 12:48:01 --> Router Class Initialized
INFO - 2020-10-05 12:48:01 --> Output Class Initialized
INFO - 2020-10-05 12:48:01 --> Security Class Initialized
DEBUG - 2020-10-05 12:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:48:01 --> Input Class Initialized
INFO - 2020-10-05 12:48:01 --> Language Class Initialized
INFO - 2020-10-05 12:48:01 --> Loader Class Initialized
INFO - 2020-10-05 12:48:01 --> Helper loaded: url_helper
INFO - 2020-10-05 12:48:01 --> Helper loaded: file_helper
INFO - 2020-10-05 12:48:01 --> Database Driver Class Initialized
INFO - 2020-10-05 12:48:01 --> Email Class Initialized
DEBUG - 2020-10-05 12:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:48:01 --> Controller Class Initialized
INFO - 2020-10-05 12:48:02 --> Model "Main_model" initialized
INFO - 2020-10-05 12:48:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-10-05 12:48:02 --> Final output sent to browser
DEBUG - 2020-10-05 12:48:02 --> Total execution time: 0.3825
INFO - 2020-10-05 12:49:59 --> Config Class Initialized
INFO - 2020-10-05 12:49:59 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:49:59 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:49:59 --> Utf8 Class Initialized
INFO - 2020-10-05 12:49:59 --> URI Class Initialized
INFO - 2020-10-05 12:49:59 --> Router Class Initialized
INFO - 2020-10-05 12:49:59 --> Output Class Initialized
INFO - 2020-10-05 12:49:59 --> Security Class Initialized
DEBUG - 2020-10-05 12:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:49:59 --> Input Class Initialized
INFO - 2020-10-05 12:49:59 --> Language Class Initialized
INFO - 2020-10-05 12:49:59 --> Loader Class Initialized
INFO - 2020-10-05 12:49:59 --> Helper loaded: url_helper
INFO - 2020-10-05 12:49:59 --> Helper loaded: file_helper
INFO - 2020-10-05 12:49:59 --> Database Driver Class Initialized
INFO - 2020-10-05 12:49:59 --> Email Class Initialized
DEBUG - 2020-10-05 12:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:49:59 --> Controller Class Initialized
INFO - 2020-10-05 12:49:59 --> Model "Main_model" initialized
INFO - 2020-10-05 12:49:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:49:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 12:49:59 --> Final output sent to browser
DEBUG - 2020-10-05 12:49:59 --> Total execution time: 0.4158
INFO - 2020-10-05 12:54:38 --> Config Class Initialized
INFO - 2020-10-05 12:54:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:54:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:54:38 --> Utf8 Class Initialized
INFO - 2020-10-05 12:54:38 --> URI Class Initialized
INFO - 2020-10-05 12:54:38 --> Router Class Initialized
INFO - 2020-10-05 12:54:38 --> Output Class Initialized
INFO - 2020-10-05 12:54:38 --> Security Class Initialized
DEBUG - 2020-10-05 12:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:54:38 --> Input Class Initialized
INFO - 2020-10-05 12:54:38 --> Language Class Initialized
INFO - 2020-10-05 12:54:38 --> Loader Class Initialized
INFO - 2020-10-05 12:54:38 --> Helper loaded: url_helper
INFO - 2020-10-05 12:54:38 --> Helper loaded: file_helper
INFO - 2020-10-05 12:54:38 --> Database Driver Class Initialized
INFO - 2020-10-05 12:54:38 --> Email Class Initialized
DEBUG - 2020-10-05 12:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 12:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:54:38 --> Controller Class Initialized
INFO - 2020-10-05 12:54:38 --> Model "Main_model" initialized
INFO - 2020-10-05 12:54:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 12:54:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 12:54:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimi_lookup.php
INFO - 2020-10-05 12:54:38 --> Final output sent to browser
DEBUG - 2020-10-05 12:54:38 --> Total execution time: 0.4306
INFO - 2020-10-05 13:01:29 --> Config Class Initialized
INFO - 2020-10-05 13:01:29 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:01:29 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:01:29 --> Utf8 Class Initialized
INFO - 2020-10-05 13:01:29 --> URI Class Initialized
INFO - 2020-10-05 13:01:29 --> Router Class Initialized
INFO - 2020-10-05 13:01:29 --> Output Class Initialized
INFO - 2020-10-05 13:01:29 --> Security Class Initialized
DEBUG - 2020-10-05 13:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:01:29 --> Input Class Initialized
INFO - 2020-10-05 13:01:29 --> Language Class Initialized
INFO - 2020-10-05 13:01:29 --> Loader Class Initialized
INFO - 2020-10-05 13:01:29 --> Helper loaded: url_helper
INFO - 2020-10-05 13:01:29 --> Helper loaded: file_helper
INFO - 2020-10-05 13:01:29 --> Database Driver Class Initialized
INFO - 2020-10-05 13:01:29 --> Email Class Initialized
DEBUG - 2020-10-05 13:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:01:29 --> Controller Class Initialized
INFO - 2020-10-05 13:01:29 --> Model "Main_model" initialized
INFO - 2020-10-05 13:01:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:01:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 13:01:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 13:01:30 --> Final output sent to browser
DEBUG - 2020-10-05 13:01:30 --> Total execution time: 0.4395
INFO - 2020-10-05 13:01:38 --> Config Class Initialized
INFO - 2020-10-05 13:01:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:01:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:01:38 --> Utf8 Class Initialized
INFO - 2020-10-05 13:01:38 --> URI Class Initialized
INFO - 2020-10-05 13:01:38 --> Router Class Initialized
INFO - 2020-10-05 13:01:38 --> Output Class Initialized
INFO - 2020-10-05 13:01:38 --> Security Class Initialized
DEBUG - 2020-10-05 13:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:01:38 --> Input Class Initialized
INFO - 2020-10-05 13:01:38 --> Language Class Initialized
INFO - 2020-10-05 13:01:38 --> Loader Class Initialized
INFO - 2020-10-05 13:01:38 --> Helper loaded: url_helper
INFO - 2020-10-05 13:01:38 --> Helper loaded: file_helper
INFO - 2020-10-05 13:01:38 --> Database Driver Class Initialized
INFO - 2020-10-05 13:01:38 --> Email Class Initialized
DEBUG - 2020-10-05 13:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:01:38 --> Controller Class Initialized
INFO - 2020-10-05 13:01:38 --> Model "Main_model" initialized
INFO - 2020-10-05 13:01:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:01:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 13:01:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\adddomain.php
INFO - 2020-10-05 13:01:39 --> Final output sent to browser
DEBUG - 2020-10-05 13:01:39 --> Total execution time: 0.4253
INFO - 2020-10-05 13:01:49 --> Config Class Initialized
INFO - 2020-10-05 13:01:49 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:01:49 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:01:49 --> Utf8 Class Initialized
INFO - 2020-10-05 13:01:49 --> URI Class Initialized
INFO - 2020-10-05 13:01:49 --> Router Class Initialized
INFO - 2020-10-05 13:01:49 --> Output Class Initialized
INFO - 2020-10-05 13:01:49 --> Security Class Initialized
DEBUG - 2020-10-05 13:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:01:49 --> Input Class Initialized
INFO - 2020-10-05 13:01:49 --> Language Class Initialized
INFO - 2020-10-05 13:01:49 --> Loader Class Initialized
INFO - 2020-10-05 13:01:49 --> Helper loaded: url_helper
INFO - 2020-10-05 13:01:49 --> Helper loaded: file_helper
INFO - 2020-10-05 13:01:49 --> Database Driver Class Initialized
INFO - 2020-10-05 13:01:49 --> Email Class Initialized
DEBUG - 2020-10-05 13:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:01:49 --> Controller Class Initialized
INFO - 2020-10-05 13:01:49 --> Model "Main_model" initialized
INFO - 2020-10-05 13:01:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:01:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 13:01:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 13:01:49 --> Final output sent to browser
DEBUG - 2020-10-05 13:01:49 --> Total execution time: 0.4057
INFO - 2020-10-05 13:01:56 --> Config Class Initialized
INFO - 2020-10-05 13:01:56 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:01:56 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:01:56 --> Utf8 Class Initialized
INFO - 2020-10-05 13:01:56 --> URI Class Initialized
INFO - 2020-10-05 13:01:56 --> Router Class Initialized
INFO - 2020-10-05 13:01:56 --> Output Class Initialized
INFO - 2020-10-05 13:01:56 --> Security Class Initialized
DEBUG - 2020-10-05 13:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:01:56 --> Input Class Initialized
INFO - 2020-10-05 13:01:56 --> Language Class Initialized
INFO - 2020-10-05 13:01:56 --> Loader Class Initialized
INFO - 2020-10-05 13:01:56 --> Helper loaded: url_helper
INFO - 2020-10-05 13:01:56 --> Helper loaded: file_helper
INFO - 2020-10-05 13:01:56 --> Database Driver Class Initialized
INFO - 2020-10-05 13:01:56 --> Email Class Initialized
DEBUG - 2020-10-05 13:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:01:56 --> Controller Class Initialized
INFO - 2020-10-05 13:01:56 --> Model "Main_model" initialized
INFO - 2020-10-05 13:01:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:01:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-10-05 13:01:56 --> Final output sent to browser
DEBUG - 2020-10-05 13:01:56 --> Total execution time: 0.4173
INFO - 2020-10-05 13:01:58 --> Config Class Initialized
INFO - 2020-10-05 13:01:58 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:01:58 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:01:58 --> Utf8 Class Initialized
INFO - 2020-10-05 13:01:58 --> URI Class Initialized
INFO - 2020-10-05 13:01:58 --> Router Class Initialized
INFO - 2020-10-05 13:01:58 --> Output Class Initialized
INFO - 2020-10-05 13:01:58 --> Security Class Initialized
DEBUG - 2020-10-05 13:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:01:58 --> Input Class Initialized
INFO - 2020-10-05 13:01:58 --> Language Class Initialized
INFO - 2020-10-05 13:01:58 --> Loader Class Initialized
INFO - 2020-10-05 13:01:58 --> Helper loaded: url_helper
INFO - 2020-10-05 13:01:58 --> Helper loaded: file_helper
INFO - 2020-10-05 13:01:58 --> Database Driver Class Initialized
INFO - 2020-10-05 13:01:58 --> Email Class Initialized
DEBUG - 2020-10-05 13:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:01:58 --> Controller Class Initialized
INFO - 2020-10-05 13:01:58 --> Model "Main_model" initialized
INFO - 2020-10-05 13:01:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:01:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 13:01:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 13:01:58 --> Final output sent to browser
DEBUG - 2020-10-05 13:01:58 --> Total execution time: 0.4207
INFO - 2020-10-05 13:02:07 --> Config Class Initialized
INFO - 2020-10-05 13:02:07 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:07 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:07 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:07 --> URI Class Initialized
INFO - 2020-10-05 13:02:07 --> Router Class Initialized
INFO - 2020-10-05 13:02:07 --> Output Class Initialized
INFO - 2020-10-05 13:02:07 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:07 --> Input Class Initialized
INFO - 2020-10-05 13:02:07 --> Language Class Initialized
INFO - 2020-10-05 13:02:07 --> Loader Class Initialized
INFO - 2020-10-05 13:02:07 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:07 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:07 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:07 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:07 --> Controller Class Initialized
INFO - 2020-10-05 13:02:07 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:07 --> Config Class Initialized
INFO - 2020-10-05 13:02:07 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:07 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:07 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:07 --> URI Class Initialized
INFO - 2020-10-05 13:02:07 --> Router Class Initialized
INFO - 2020-10-05 13:02:07 --> Output Class Initialized
INFO - 2020-10-05 13:02:07 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:07 --> Input Class Initialized
INFO - 2020-10-05 13:02:07 --> Language Class Initialized
INFO - 2020-10-05 13:02:07 --> Loader Class Initialized
INFO - 2020-10-05 13:02:07 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:07 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:07 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:07 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:07 --> Controller Class Initialized
INFO - 2020-10-05 13:02:07 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:02:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-10-05 13:02:07 --> Final output sent to browser
DEBUG - 2020-10-05 13:02:07 --> Total execution time: 0.4170
INFO - 2020-10-05 13:02:11 --> Config Class Initialized
INFO - 2020-10-05 13:02:11 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:11 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:11 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:11 --> URI Class Initialized
INFO - 2020-10-05 13:02:11 --> Router Class Initialized
INFO - 2020-10-05 13:02:11 --> Output Class Initialized
INFO - 2020-10-05 13:02:11 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:11 --> Input Class Initialized
INFO - 2020-10-05 13:02:11 --> Language Class Initialized
INFO - 2020-10-05 13:02:11 --> Loader Class Initialized
INFO - 2020-10-05 13:02:11 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:11 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:11 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:11 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:12 --> Controller Class Initialized
INFO - 2020-10-05 13:02:12 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:12 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:02:12 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-10-05 13:02:12 --> Final output sent to browser
DEBUG - 2020-10-05 13:02:12 --> Total execution time: 0.4284
INFO - 2020-10-05 13:02:13 --> Config Class Initialized
INFO - 2020-10-05 13:02:13 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:13 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:13 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:13 --> URI Class Initialized
INFO - 2020-10-05 13:02:13 --> Router Class Initialized
INFO - 2020-10-05 13:02:13 --> Output Class Initialized
INFO - 2020-10-05 13:02:13 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:13 --> Input Class Initialized
INFO - 2020-10-05 13:02:13 --> Language Class Initialized
INFO - 2020-10-05 13:02:13 --> Loader Class Initialized
INFO - 2020-10-05 13:02:13 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:13 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:13 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:13 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:13 --> Controller Class Initialized
INFO - 2020-10-05 13:02:13 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:13 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:02:13 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 13:02:13 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 13:02:13 --> Final output sent to browser
DEBUG - 2020-10-05 13:02:13 --> Total execution time: 0.4441
INFO - 2020-10-05 13:02:15 --> Config Class Initialized
INFO - 2020-10-05 13:02:15 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:15 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:15 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:15 --> URI Class Initialized
INFO - 2020-10-05 13:02:15 --> Router Class Initialized
INFO - 2020-10-05 13:02:15 --> Output Class Initialized
INFO - 2020-10-05 13:02:15 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:15 --> Input Class Initialized
INFO - 2020-10-05 13:02:15 --> Language Class Initialized
INFO - 2020-10-05 13:02:15 --> Loader Class Initialized
INFO - 2020-10-05 13:02:16 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:16 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:16 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:16 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:16 --> Controller Class Initialized
INFO - 2020-10-05 13:02:16 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:16 --> Config Class Initialized
INFO - 2020-10-05 13:02:16 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:16 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:16 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:16 --> URI Class Initialized
INFO - 2020-10-05 13:02:16 --> Router Class Initialized
INFO - 2020-10-05 13:02:16 --> Output Class Initialized
INFO - 2020-10-05 13:02:16 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:16 --> Input Class Initialized
INFO - 2020-10-05 13:02:16 --> Language Class Initialized
INFO - 2020-10-05 13:02:16 --> Loader Class Initialized
INFO - 2020-10-05 13:02:16 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:16 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:16 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:16 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:16 --> Controller Class Initialized
INFO - 2020-10-05 13:02:16 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:16 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:02:16 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-10-05 13:02:16 --> Final output sent to browser
DEBUG - 2020-10-05 13:02:16 --> Total execution time: 0.4385
INFO - 2020-10-05 13:02:18 --> Config Class Initialized
INFO - 2020-10-05 13:02:18 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:18 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:18 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:18 --> URI Class Initialized
INFO - 2020-10-05 13:02:18 --> Router Class Initialized
INFO - 2020-10-05 13:02:18 --> Output Class Initialized
INFO - 2020-10-05 13:02:18 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:18 --> Input Class Initialized
INFO - 2020-10-05 13:02:18 --> Language Class Initialized
INFO - 2020-10-05 13:02:18 --> Loader Class Initialized
INFO - 2020-10-05 13:02:18 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:18 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:18 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:18 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:18 --> Controller Class Initialized
INFO - 2020-10-05 13:02:18 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:02:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-10-05 13:02:19 --> Final output sent to browser
DEBUG - 2020-10-05 13:02:19 --> Total execution time: 0.3955
INFO - 2020-10-05 13:02:21 --> Config Class Initialized
INFO - 2020-10-05 13:02:21 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:21 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:21 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:21 --> URI Class Initialized
INFO - 2020-10-05 13:02:21 --> Router Class Initialized
INFO - 2020-10-05 13:02:21 --> Output Class Initialized
INFO - 2020-10-05 13:02:21 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:21 --> Input Class Initialized
INFO - 2020-10-05 13:02:22 --> Language Class Initialized
INFO - 2020-10-05 13:02:22 --> Loader Class Initialized
INFO - 2020-10-05 13:02:22 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:22 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:22 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:22 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:22 --> Controller Class Initialized
INFO - 2020-10-05 13:02:22 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:22 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:02:22 --> File loaded: C:\xampp\htdocs\dmarc\application\views\signup.php
INFO - 2020-10-05 13:02:22 --> Final output sent to browser
DEBUG - 2020-10-05 13:02:22 --> Total execution time: 0.4235
INFO - 2020-10-05 13:02:24 --> Config Class Initialized
INFO - 2020-10-05 13:02:24 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:24 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:24 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:24 --> URI Class Initialized
INFO - 2020-10-05 13:02:24 --> Router Class Initialized
INFO - 2020-10-05 13:02:24 --> Output Class Initialized
INFO - 2020-10-05 13:02:24 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:24 --> Input Class Initialized
INFO - 2020-10-05 13:02:24 --> Language Class Initialized
INFO - 2020-10-05 13:02:24 --> Loader Class Initialized
INFO - 2020-10-05 13:02:24 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:24 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:24 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:24 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:24 --> Controller Class Initialized
INFO - 2020-10-05 13:02:24 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:02:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 13:02:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 13:02:24 --> Final output sent to browser
DEBUG - 2020-10-05 13:02:24 --> Total execution time: 0.4264
INFO - 2020-10-05 13:02:28 --> Config Class Initialized
INFO - 2020-10-05 13:02:28 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:28 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:28 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:29 --> URI Class Initialized
INFO - 2020-10-05 13:02:29 --> Router Class Initialized
INFO - 2020-10-05 13:02:29 --> Output Class Initialized
INFO - 2020-10-05 13:02:29 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:29 --> Input Class Initialized
INFO - 2020-10-05 13:02:29 --> Language Class Initialized
INFO - 2020-10-05 13:02:29 --> Loader Class Initialized
INFO - 2020-10-05 13:02:29 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:29 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:29 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:29 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:29 --> Controller Class Initialized
INFO - 2020-10-05 13:02:29 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:29 --> Config Class Initialized
INFO - 2020-10-05 13:02:29 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:29 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:29 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:29 --> URI Class Initialized
INFO - 2020-10-05 13:02:29 --> Router Class Initialized
INFO - 2020-10-05 13:02:29 --> Output Class Initialized
INFO - 2020-10-05 13:02:29 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:29 --> Input Class Initialized
INFO - 2020-10-05 13:02:29 --> Language Class Initialized
INFO - 2020-10-05 13:02:29 --> Loader Class Initialized
INFO - 2020-10-05 13:02:29 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:29 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:29 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:29 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:29 --> Controller Class Initialized
INFO - 2020-10-05 13:02:29 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:02:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-10-05 13:02:29 --> Final output sent to browser
DEBUG - 2020-10-05 13:02:29 --> Total execution time: 0.4202
INFO - 2020-10-05 13:02:31 --> Config Class Initialized
INFO - 2020-10-05 13:02:31 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:31 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:31 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:31 --> URI Class Initialized
INFO - 2020-10-05 13:02:31 --> Router Class Initialized
INFO - 2020-10-05 13:02:31 --> Output Class Initialized
INFO - 2020-10-05 13:02:31 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:31 --> Input Class Initialized
INFO - 2020-10-05 13:02:31 --> Language Class Initialized
INFO - 2020-10-05 13:02:31 --> Loader Class Initialized
INFO - 2020-10-05 13:02:31 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:31 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:31 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:31 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:31 --> Controller Class Initialized
INFO - 2020-10-05 13:02:31 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:02:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 13:02:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 13:02:31 --> Final output sent to browser
DEBUG - 2020-10-05 13:02:32 --> Total execution time: 0.4203
INFO - 2020-10-05 13:02:34 --> Config Class Initialized
INFO - 2020-10-05 13:02:34 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:34 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:34 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:34 --> URI Class Initialized
INFO - 2020-10-05 13:02:34 --> Router Class Initialized
INFO - 2020-10-05 13:02:34 --> Output Class Initialized
INFO - 2020-10-05 13:02:34 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:34 --> Input Class Initialized
INFO - 2020-10-05 13:02:34 --> Language Class Initialized
INFO - 2020-10-05 13:02:34 --> Loader Class Initialized
INFO - 2020-10-05 13:02:34 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:34 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:34 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:34 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:34 --> Controller Class Initialized
INFO - 2020-10-05 13:02:34 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:34 --> Config Class Initialized
INFO - 2020-10-05 13:02:34 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:34 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:34 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:34 --> URI Class Initialized
INFO - 2020-10-05 13:02:34 --> Router Class Initialized
INFO - 2020-10-05 13:02:34 --> Output Class Initialized
INFO - 2020-10-05 13:02:34 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:34 --> Input Class Initialized
INFO - 2020-10-05 13:02:35 --> Language Class Initialized
INFO - 2020-10-05 13:02:35 --> Loader Class Initialized
INFO - 2020-10-05 13:02:35 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:35 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:35 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:35 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:35 --> Controller Class Initialized
INFO - 2020-10-05 13:02:35 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:02:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-10-05 13:02:35 --> Final output sent to browser
DEBUG - 2020-10-05 13:02:35 --> Total execution time: 0.4021
INFO - 2020-10-05 13:02:38 --> Config Class Initialized
INFO - 2020-10-05 13:02:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:02:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:02:38 --> Utf8 Class Initialized
INFO - 2020-10-05 13:02:38 --> URI Class Initialized
INFO - 2020-10-05 13:02:38 --> Router Class Initialized
INFO - 2020-10-05 13:02:38 --> Output Class Initialized
INFO - 2020-10-05 13:02:38 --> Security Class Initialized
DEBUG - 2020-10-05 13:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:02:38 --> Input Class Initialized
INFO - 2020-10-05 13:02:38 --> Language Class Initialized
INFO - 2020-10-05 13:02:38 --> Loader Class Initialized
INFO - 2020-10-05 13:02:38 --> Helper loaded: url_helper
INFO - 2020-10-05 13:02:38 --> Helper loaded: file_helper
INFO - 2020-10-05 13:02:38 --> Database Driver Class Initialized
INFO - 2020-10-05 13:02:38 --> Email Class Initialized
DEBUG - 2020-10-05 13:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:02:38 --> Controller Class Initialized
INFO - 2020-10-05 13:02:38 --> Model "Main_model" initialized
INFO - 2020-10-05 13:02:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:02:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 13:02:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 13:02:38 --> Final output sent to browser
DEBUG - 2020-10-05 13:02:38 --> Total execution time: 0.4507
INFO - 2020-10-05 13:07:26 --> Config Class Initialized
INFO - 2020-10-05 13:07:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:07:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:07:26 --> Utf8 Class Initialized
INFO - 2020-10-05 13:07:26 --> URI Class Initialized
INFO - 2020-10-05 13:07:26 --> Router Class Initialized
INFO - 2020-10-05 13:07:26 --> Output Class Initialized
INFO - 2020-10-05 13:07:26 --> Security Class Initialized
DEBUG - 2020-10-05 13:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:07:26 --> Input Class Initialized
INFO - 2020-10-05 13:07:26 --> Language Class Initialized
INFO - 2020-10-05 13:07:26 --> Loader Class Initialized
INFO - 2020-10-05 13:07:26 --> Helper loaded: url_helper
INFO - 2020-10-05 13:07:26 --> Helper loaded: file_helper
INFO - 2020-10-05 13:07:26 --> Database Driver Class Initialized
INFO - 2020-10-05 13:07:26 --> Email Class Initialized
DEBUG - 2020-10-05 13:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:07:26 --> Controller Class Initialized
INFO - 2020-10-05 13:07:26 --> Model "Main_model" initialized
INFO - 2020-10-05 13:07:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:07:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 13:07:27 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 13:07:27 --> Final output sent to browser
DEBUG - 2020-10-05 13:07:27 --> Total execution time: 0.4693
INFO - 2020-10-05 13:07:38 --> Config Class Initialized
INFO - 2020-10-05 13:07:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:07:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:07:38 --> Utf8 Class Initialized
INFO - 2020-10-05 13:07:38 --> URI Class Initialized
INFO - 2020-10-05 13:07:38 --> Router Class Initialized
INFO - 2020-10-05 13:07:38 --> Output Class Initialized
INFO - 2020-10-05 13:07:38 --> Security Class Initialized
DEBUG - 2020-10-05 13:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:07:38 --> Input Class Initialized
INFO - 2020-10-05 13:07:38 --> Language Class Initialized
INFO - 2020-10-05 13:07:38 --> Loader Class Initialized
INFO - 2020-10-05 13:07:38 --> Helper loaded: url_helper
INFO - 2020-10-05 13:07:38 --> Helper loaded: file_helper
INFO - 2020-10-05 13:07:38 --> Database Driver Class Initialized
INFO - 2020-10-05 13:07:38 --> Email Class Initialized
DEBUG - 2020-10-05 13:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:07:38 --> Controller Class Initialized
INFO - 2020-10-05 13:07:38 --> Model "Main_model" initialized
DEBUG - 2020-10-05 13:07:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 13:07:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\mailTemplates/alertthanks.php
ERROR - 2020-10-05 13:07:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string C:\xampp\htdocs\dmarc\system\libraries\Email.php 677
INFO - 2020-10-05 13:07:40 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-05 13:07:40 --> Config Class Initialized
INFO - 2020-10-05 13:07:40 --> Hooks Class Initialized
DEBUG - 2020-10-05 13:07:40 --> UTF-8 Support Enabled
INFO - 2020-10-05 13:07:40 --> Utf8 Class Initialized
INFO - 2020-10-05 13:07:40 --> URI Class Initialized
INFO - 2020-10-05 13:07:40 --> Router Class Initialized
INFO - 2020-10-05 13:07:40 --> Output Class Initialized
INFO - 2020-10-05 13:07:40 --> Security Class Initialized
DEBUG - 2020-10-05 13:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 13:07:40 --> Input Class Initialized
INFO - 2020-10-05 13:07:40 --> Language Class Initialized
INFO - 2020-10-05 13:07:40 --> Loader Class Initialized
INFO - 2020-10-05 13:07:40 --> Helper loaded: url_helper
INFO - 2020-10-05 13:07:40 --> Helper loaded: file_helper
INFO - 2020-10-05 13:07:40 --> Database Driver Class Initialized
INFO - 2020-10-05 13:07:40 --> Email Class Initialized
DEBUG - 2020-10-05 13:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 13:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 13:07:40 --> Controller Class Initialized
INFO - 2020-10-05 13:07:40 --> Model "Main_model" initialized
INFO - 2020-10-05 13:07:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 13:07:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 13:07:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 13:07:40 --> Final output sent to browser
DEBUG - 2020-10-05 13:07:40 --> Total execution time: 0.4253
INFO - 2020-10-05 14:55:50 --> Config Class Initialized
INFO - 2020-10-05 14:55:50 --> Hooks Class Initialized
DEBUG - 2020-10-05 14:55:50 --> UTF-8 Support Enabled
INFO - 2020-10-05 14:55:50 --> Utf8 Class Initialized
INFO - 2020-10-05 14:55:50 --> URI Class Initialized
INFO - 2020-10-05 14:55:50 --> Router Class Initialized
INFO - 2020-10-05 14:55:50 --> Output Class Initialized
INFO - 2020-10-05 14:55:50 --> Security Class Initialized
DEBUG - 2020-10-05 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 14:55:50 --> Input Class Initialized
INFO - 2020-10-05 14:55:50 --> Language Class Initialized
INFO - 2020-10-05 14:55:50 --> Loader Class Initialized
INFO - 2020-10-05 14:55:50 --> Helper loaded: url_helper
INFO - 2020-10-05 14:55:50 --> Helper loaded: file_helper
INFO - 2020-10-05 14:55:50 --> Database Driver Class Initialized
INFO - 2020-10-05 14:55:50 --> Email Class Initialized
DEBUG - 2020-10-05 14:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 14:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 14:55:51 --> Controller Class Initialized
INFO - 2020-10-05 14:55:51 --> Model "Main_model" initialized
INFO - 2020-10-05 14:55:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 14:55:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 14:55:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 14:55:51 --> Final output sent to browser
DEBUG - 2020-10-05 14:55:51 --> Total execution time: 0.7566
INFO - 2020-10-05 14:55:57 --> Config Class Initialized
INFO - 2020-10-05 14:55:57 --> Hooks Class Initialized
DEBUG - 2020-10-05 14:55:57 --> UTF-8 Support Enabled
INFO - 2020-10-05 14:55:57 --> Utf8 Class Initialized
INFO - 2020-10-05 14:55:57 --> URI Class Initialized
INFO - 2020-10-05 14:55:57 --> Router Class Initialized
INFO - 2020-10-05 14:55:57 --> Output Class Initialized
INFO - 2020-10-05 14:55:57 --> Security Class Initialized
DEBUG - 2020-10-05 14:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 14:55:57 --> Input Class Initialized
INFO - 2020-10-05 14:55:57 --> Language Class Initialized
INFO - 2020-10-05 14:55:57 --> Loader Class Initialized
INFO - 2020-10-05 14:55:57 --> Helper loaded: url_helper
INFO - 2020-10-05 14:55:57 --> Helper loaded: file_helper
INFO - 2020-10-05 14:55:57 --> Database Driver Class Initialized
INFO - 2020-10-05 14:55:57 --> Email Class Initialized
DEBUG - 2020-10-05 14:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 14:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 14:55:57 --> Controller Class Initialized
INFO - 2020-10-05 14:55:57 --> Model "Main_model" initialized
INFO - 2020-10-05 14:55:57 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 14:55:57 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 14:55:57 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertevents.php
INFO - 2020-10-05 14:55:57 --> Final output sent to browser
DEBUG - 2020-10-05 14:55:57 --> Total execution time: 0.4566
INFO - 2020-10-05 14:56:00 --> Config Class Initialized
INFO - 2020-10-05 14:56:00 --> Hooks Class Initialized
DEBUG - 2020-10-05 14:56:00 --> UTF-8 Support Enabled
INFO - 2020-10-05 14:56:00 --> Utf8 Class Initialized
INFO - 2020-10-05 14:56:00 --> URI Class Initialized
INFO - 2020-10-05 14:56:00 --> Router Class Initialized
INFO - 2020-10-05 14:56:00 --> Output Class Initialized
INFO - 2020-10-05 14:56:00 --> Security Class Initialized
DEBUG - 2020-10-05 14:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 14:56:00 --> Input Class Initialized
INFO - 2020-10-05 14:56:00 --> Language Class Initialized
INFO - 2020-10-05 14:56:00 --> Loader Class Initialized
INFO - 2020-10-05 14:56:00 --> Helper loaded: url_helper
INFO - 2020-10-05 14:56:00 --> Helper loaded: file_helper
INFO - 2020-10-05 14:56:00 --> Database Driver Class Initialized
INFO - 2020-10-05 14:56:00 --> Email Class Initialized
DEBUG - 2020-10-05 14:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 14:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 14:56:00 --> Controller Class Initialized
INFO - 2020-10-05 14:56:00 --> Model "Main_model" initialized
INFO - 2020-10-05 14:56:00 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 14:56:00 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 14:56:00 --> File loaded: C:\xampp\htdocs\dmarc\application\views\alertconfig.php
INFO - 2020-10-05 14:56:01 --> Final output sent to browser
DEBUG - 2020-10-05 14:56:01 --> Total execution time: 0.5506
INFO - 2020-10-05 14:56:06 --> Config Class Initialized
INFO - 2020-10-05 14:56:06 --> Hooks Class Initialized
DEBUG - 2020-10-05 14:56:06 --> UTF-8 Support Enabled
INFO - 2020-10-05 14:56:06 --> Utf8 Class Initialized
INFO - 2020-10-05 14:56:06 --> URI Class Initialized
INFO - 2020-10-05 14:56:06 --> Router Class Initialized
INFO - 2020-10-05 14:56:06 --> Output Class Initialized
INFO - 2020-10-05 14:56:06 --> Security Class Initialized
DEBUG - 2020-10-05 14:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 14:56:06 --> Input Class Initialized
INFO - 2020-10-05 14:56:06 --> Language Class Initialized
INFO - 2020-10-05 14:56:06 --> Loader Class Initialized
INFO - 2020-10-05 14:56:06 --> Helper loaded: url_helper
INFO - 2020-10-05 14:56:06 --> Helper loaded: file_helper
INFO - 2020-10-05 14:56:06 --> Database Driver Class Initialized
INFO - 2020-10-05 14:56:06 --> Email Class Initialized
DEBUG - 2020-10-05 14:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 14:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 14:56:06 --> Controller Class Initialized
INFO - 2020-10-05 14:56:06 --> Model "Main_model" initialized
INFO - 2020-10-05 14:56:06 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 14:56:06 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 14:56:06 --> File loaded: C:\xampp\htdocs\dmarc\application\views\create_alert.php
INFO - 2020-10-05 14:56:06 --> Final output sent to browser
DEBUG - 2020-10-05 14:56:06 --> Total execution time: 0.4399
INFO - 2020-10-05 16:07:36 --> Config Class Initialized
INFO - 2020-10-05 16:07:36 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:07:36 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:07:36 --> Utf8 Class Initialized
INFO - 2020-10-05 16:07:36 --> URI Class Initialized
DEBUG - 2020-10-05 16:07:36 --> No URI present. Default controller set.
INFO - 2020-10-05 16:07:36 --> Router Class Initialized
INFO - 2020-10-05 16:07:36 --> Output Class Initialized
INFO - 2020-10-05 16:07:36 --> Security Class Initialized
DEBUG - 2020-10-05 16:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:07:37 --> Input Class Initialized
INFO - 2020-10-05 16:07:37 --> Language Class Initialized
INFO - 2020-10-05 16:07:37 --> Loader Class Initialized
INFO - 2020-10-05 16:07:37 --> Helper loaded: url_helper
INFO - 2020-10-05 16:07:37 --> Helper loaded: file_helper
INFO - 2020-10-05 16:07:37 --> Database Driver Class Initialized
INFO - 2020-10-05 16:07:37 --> Email Class Initialized
DEBUG - 2020-10-05 16:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:07:37 --> Controller Class Initialized
INFO - 2020-10-05 16:07:37 --> Model "Main_model" initialized
INFO - 2020-10-05 16:07:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:07:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-10-05 16:07:37 --> Final output sent to browser
DEBUG - 2020-10-05 16:07:37 --> Total execution time: 1.0960
INFO - 2020-10-05 16:07:40 --> Config Class Initialized
INFO - 2020-10-05 16:07:40 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:07:40 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:07:41 --> Utf8 Class Initialized
INFO - 2020-10-05 16:07:41 --> URI Class Initialized
INFO - 2020-10-05 16:07:41 --> Router Class Initialized
INFO - 2020-10-05 16:07:41 --> Output Class Initialized
INFO - 2020-10-05 16:07:41 --> Security Class Initialized
DEBUG - 2020-10-05 16:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:07:41 --> Input Class Initialized
INFO - 2020-10-05 16:07:41 --> Language Class Initialized
INFO - 2020-10-05 16:07:41 --> Loader Class Initialized
INFO - 2020-10-05 16:07:41 --> Helper loaded: url_helper
INFO - 2020-10-05 16:07:41 --> Helper loaded: file_helper
INFO - 2020-10-05 16:07:41 --> Database Driver Class Initialized
INFO - 2020-10-05 16:07:41 --> Email Class Initialized
DEBUG - 2020-10-05 16:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:07:41 --> Controller Class Initialized
INFO - 2020-10-05 16:07:41 --> Model "Main_model" initialized
INFO - 2020-10-05 16:07:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:07:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 16:07:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 16:07:41 --> Final output sent to browser
DEBUG - 2020-10-05 16:07:41 --> Total execution time: 0.4371
INFO - 2020-10-05 16:11:13 --> Config Class Initialized
INFO - 2020-10-05 16:11:13 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:11:13 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:11:13 --> Utf8 Class Initialized
INFO - 2020-10-05 16:11:13 --> URI Class Initialized
INFO - 2020-10-05 16:11:13 --> Router Class Initialized
INFO - 2020-10-05 16:11:13 --> Output Class Initialized
INFO - 2020-10-05 16:11:13 --> Security Class Initialized
DEBUG - 2020-10-05 16:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:11:13 --> Input Class Initialized
INFO - 2020-10-05 16:11:13 --> Language Class Initialized
INFO - 2020-10-05 16:11:13 --> Loader Class Initialized
INFO - 2020-10-05 16:11:13 --> Helper loaded: url_helper
INFO - 2020-10-05 16:11:13 --> Helper loaded: file_helper
INFO - 2020-10-05 16:11:13 --> Database Driver Class Initialized
INFO - 2020-10-05 16:11:14 --> Email Class Initialized
DEBUG - 2020-10-05 16:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:11:14 --> Controller Class Initialized
INFO - 2020-10-05 16:11:14 --> Model "Main_model" initialized
INFO - 2020-10-05 16:11:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:11:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 16:11:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 16:11:14 --> Final output sent to browser
DEBUG - 2020-10-05 16:11:14 --> Total execution time: 0.4522
INFO - 2020-10-05 16:11:47 --> Config Class Initialized
INFO - 2020-10-05 16:11:47 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:11:47 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:11:47 --> Utf8 Class Initialized
INFO - 2020-10-05 16:11:47 --> URI Class Initialized
INFO - 2020-10-05 16:11:47 --> Router Class Initialized
INFO - 2020-10-05 16:11:47 --> Output Class Initialized
INFO - 2020-10-05 16:11:47 --> Security Class Initialized
DEBUG - 2020-10-05 16:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:11:47 --> Input Class Initialized
INFO - 2020-10-05 16:11:47 --> Language Class Initialized
INFO - 2020-10-05 16:11:47 --> Loader Class Initialized
INFO - 2020-10-05 16:11:47 --> Helper loaded: url_helper
INFO - 2020-10-05 16:11:47 --> Helper loaded: file_helper
INFO - 2020-10-05 16:11:47 --> Database Driver Class Initialized
INFO - 2020-10-05 16:11:48 --> Email Class Initialized
DEBUG - 2020-10-05 16:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:11:48 --> Controller Class Initialized
INFO - 2020-10-05 16:11:48 --> Model "Main_model" initialized
INFO - 2020-10-05 16:11:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:11:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-10-05 16:11:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-10-05 16:11:48 --> Final output sent to browser
DEBUG - 2020-10-05 16:11:48 --> Total execution time: 0.5346
INFO - 2020-10-05 16:11:52 --> Config Class Initialized
INFO - 2020-10-05 16:11:52 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:11:52 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:11:52 --> Utf8 Class Initialized
INFO - 2020-10-05 16:11:52 --> URI Class Initialized
INFO - 2020-10-05 16:11:52 --> Router Class Initialized
INFO - 2020-10-05 16:11:52 --> Output Class Initialized
INFO - 2020-10-05 16:11:52 --> Security Class Initialized
DEBUG - 2020-10-05 16:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:11:52 --> Input Class Initialized
INFO - 2020-10-05 16:11:52 --> Language Class Initialized
INFO - 2020-10-05 16:11:52 --> Loader Class Initialized
INFO - 2020-10-05 16:11:52 --> Helper loaded: url_helper
INFO - 2020-10-05 16:11:52 --> Helper loaded: file_helper
INFO - 2020-10-05 16:11:52 --> Database Driver Class Initialized
INFO - 2020-10-05 16:11:52 --> Email Class Initialized
DEBUG - 2020-10-05 16:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:11:52 --> Controller Class Initialized
INFO - 2020-10-05 16:11:52 --> Model "Main_model" initialized
INFO - 2020-10-05 16:11:52 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:11:52 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:11:52 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:11:52 --> Final output sent to browser
DEBUG - 2020-10-05 16:11:52 --> Total execution time: 0.4607
INFO - 2020-10-05 16:12:01 --> Config Class Initialized
INFO - 2020-10-05 16:12:01 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:12:01 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:12:01 --> Utf8 Class Initialized
INFO - 2020-10-05 16:12:01 --> URI Class Initialized
INFO - 2020-10-05 16:12:01 --> Router Class Initialized
INFO - 2020-10-05 16:12:01 --> Output Class Initialized
INFO - 2020-10-05 16:12:01 --> Security Class Initialized
DEBUG - 2020-10-05 16:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:12:01 --> Input Class Initialized
INFO - 2020-10-05 16:12:01 --> Language Class Initialized
INFO - 2020-10-05 16:12:01 --> Loader Class Initialized
INFO - 2020-10-05 16:12:01 --> Helper loaded: url_helper
INFO - 2020-10-05 16:12:01 --> Helper loaded: file_helper
INFO - 2020-10-05 16:12:01 --> Database Driver Class Initialized
INFO - 2020-10-05 16:12:01 --> Email Class Initialized
DEBUG - 2020-10-05 16:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:12:01 --> Controller Class Initialized
INFO - 2020-10-05 16:12:01 --> Model "Main_model" initialized
INFO - 2020-10-05 16:12:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:12:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:12:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:12:01 --> Final output sent to browser
DEBUG - 2020-10-05 16:12:01 --> Total execution time: 0.4707
INFO - 2020-10-05 16:12:03 --> Config Class Initialized
INFO - 2020-10-05 16:12:03 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:12:03 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:12:03 --> Utf8 Class Initialized
INFO - 2020-10-05 16:12:03 --> URI Class Initialized
INFO - 2020-10-05 16:12:03 --> Router Class Initialized
INFO - 2020-10-05 16:12:03 --> Output Class Initialized
INFO - 2020-10-05 16:12:03 --> Security Class Initialized
DEBUG - 2020-10-05 16:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:12:03 --> Input Class Initialized
INFO - 2020-10-05 16:12:03 --> Language Class Initialized
INFO - 2020-10-05 16:12:03 --> Loader Class Initialized
INFO - 2020-10-05 16:12:03 --> Helper loaded: url_helper
INFO - 2020-10-05 16:12:03 --> Helper loaded: file_helper
INFO - 2020-10-05 16:12:03 --> Database Driver Class Initialized
INFO - 2020-10-05 16:12:03 --> Email Class Initialized
DEBUG - 2020-10-05 16:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:12:03 --> Controller Class Initialized
INFO - 2020-10-05 16:12:03 --> Model "Main_model" initialized
INFO - 2020-10-05 16:12:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:12:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:12:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:12:03 --> Final output sent to browser
DEBUG - 2020-10-05 16:12:03 --> Total execution time: 0.4560
INFO - 2020-10-05 16:12:09 --> Config Class Initialized
INFO - 2020-10-05 16:12:09 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:12:09 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:12:09 --> Utf8 Class Initialized
INFO - 2020-10-05 16:12:09 --> URI Class Initialized
INFO - 2020-10-05 16:12:09 --> Router Class Initialized
INFO - 2020-10-05 16:12:09 --> Output Class Initialized
INFO - 2020-10-05 16:12:09 --> Security Class Initialized
DEBUG - 2020-10-05 16:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:12:09 --> Input Class Initialized
INFO - 2020-10-05 16:12:09 --> Language Class Initialized
ERROR - 2020-10-05 16:12:09 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:12:19 --> Config Class Initialized
INFO - 2020-10-05 16:12:19 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:12:19 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:12:19 --> Utf8 Class Initialized
INFO - 2020-10-05 16:12:19 --> URI Class Initialized
INFO - 2020-10-05 16:12:19 --> Router Class Initialized
INFO - 2020-10-05 16:12:19 --> Output Class Initialized
INFO - 2020-10-05 16:12:19 --> Security Class Initialized
DEBUG - 2020-10-05 16:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:12:19 --> Input Class Initialized
INFO - 2020-10-05 16:12:19 --> Language Class Initialized
INFO - 2020-10-05 16:12:19 --> Loader Class Initialized
INFO - 2020-10-05 16:12:19 --> Helper loaded: url_helper
INFO - 2020-10-05 16:12:19 --> Helper loaded: file_helper
INFO - 2020-10-05 16:12:19 --> Database Driver Class Initialized
INFO - 2020-10-05 16:12:19 --> Email Class Initialized
DEBUG - 2020-10-05 16:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:12:19 --> Controller Class Initialized
INFO - 2020-10-05 16:12:19 --> Model "Main_model" initialized
INFO - 2020-10-05 16:12:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:12:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:12:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:12:19 --> Final output sent to browser
DEBUG - 2020-10-05 16:12:19 --> Total execution time: 0.4763
INFO - 2020-10-05 16:12:20 --> Config Class Initialized
INFO - 2020-10-05 16:12:20 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:12:20 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:12:20 --> Utf8 Class Initialized
INFO - 2020-10-05 16:12:20 --> URI Class Initialized
INFO - 2020-10-05 16:12:20 --> Router Class Initialized
INFO - 2020-10-05 16:12:20 --> Output Class Initialized
INFO - 2020-10-05 16:12:20 --> Security Class Initialized
DEBUG - 2020-10-05 16:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:12:20 --> Input Class Initialized
INFO - 2020-10-05 16:12:20 --> Language Class Initialized
ERROR - 2020-10-05 16:12:20 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:13:34 --> Config Class Initialized
INFO - 2020-10-05 16:13:34 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:13:34 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:13:34 --> Utf8 Class Initialized
INFO - 2020-10-05 16:13:34 --> URI Class Initialized
INFO - 2020-10-05 16:13:34 --> Router Class Initialized
INFO - 2020-10-05 16:13:34 --> Output Class Initialized
INFO - 2020-10-05 16:13:34 --> Security Class Initialized
DEBUG - 2020-10-05 16:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:13:34 --> Input Class Initialized
INFO - 2020-10-05 16:13:34 --> Language Class Initialized
INFO - 2020-10-05 16:13:34 --> Loader Class Initialized
INFO - 2020-10-05 16:13:34 --> Helper loaded: url_helper
INFO - 2020-10-05 16:13:34 --> Helper loaded: file_helper
INFO - 2020-10-05 16:13:34 --> Database Driver Class Initialized
INFO - 2020-10-05 16:13:34 --> Email Class Initialized
DEBUG - 2020-10-05 16:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:13:34 --> Controller Class Initialized
INFO - 2020-10-05 16:13:34 --> Model "Main_model" initialized
INFO - 2020-10-05 16:13:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:13:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:13:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:13:34 --> Final output sent to browser
DEBUG - 2020-10-05 16:13:34 --> Total execution time: 0.4952
INFO - 2020-10-05 16:13:35 --> Config Class Initialized
INFO - 2020-10-05 16:13:35 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:13:35 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:13:35 --> Utf8 Class Initialized
INFO - 2020-10-05 16:13:35 --> URI Class Initialized
INFO - 2020-10-05 16:13:35 --> Router Class Initialized
INFO - 2020-10-05 16:13:35 --> Output Class Initialized
INFO - 2020-10-05 16:13:35 --> Security Class Initialized
DEBUG - 2020-10-05 16:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:13:35 --> Input Class Initialized
INFO - 2020-10-05 16:13:35 --> Language Class Initialized
ERROR - 2020-10-05 16:13:35 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:13:50 --> Config Class Initialized
INFO - 2020-10-05 16:13:50 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:13:50 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:13:50 --> Utf8 Class Initialized
INFO - 2020-10-05 16:13:50 --> URI Class Initialized
INFO - 2020-10-05 16:13:50 --> Router Class Initialized
INFO - 2020-10-05 16:13:50 --> Output Class Initialized
INFO - 2020-10-05 16:13:50 --> Security Class Initialized
DEBUG - 2020-10-05 16:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:13:51 --> Input Class Initialized
INFO - 2020-10-05 16:13:51 --> Language Class Initialized
INFO - 2020-10-05 16:13:51 --> Loader Class Initialized
INFO - 2020-10-05 16:13:51 --> Helper loaded: url_helper
INFO - 2020-10-05 16:13:51 --> Helper loaded: file_helper
INFO - 2020-10-05 16:13:51 --> Database Driver Class Initialized
INFO - 2020-10-05 16:13:51 --> Email Class Initialized
DEBUG - 2020-10-05 16:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:13:51 --> Controller Class Initialized
INFO - 2020-10-05 16:13:51 --> Model "Main_model" initialized
INFO - 2020-10-05 16:13:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:13:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:13:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:13:51 --> Final output sent to browser
DEBUG - 2020-10-05 16:13:51 --> Total execution time: 0.4858
INFO - 2020-10-05 16:13:52 --> Config Class Initialized
INFO - 2020-10-05 16:13:52 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:13:52 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:13:52 --> Utf8 Class Initialized
INFO - 2020-10-05 16:13:52 --> URI Class Initialized
INFO - 2020-10-05 16:13:52 --> Router Class Initialized
INFO - 2020-10-05 16:13:52 --> Output Class Initialized
INFO - 2020-10-05 16:13:52 --> Security Class Initialized
DEBUG - 2020-10-05 16:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:13:52 --> Input Class Initialized
INFO - 2020-10-05 16:13:52 --> Language Class Initialized
ERROR - 2020-10-05 16:13:52 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:14:37 --> Config Class Initialized
INFO - 2020-10-05 16:14:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:14:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:14:37 --> Utf8 Class Initialized
INFO - 2020-10-05 16:14:37 --> URI Class Initialized
INFO - 2020-10-05 16:14:38 --> Router Class Initialized
INFO - 2020-10-05 16:14:38 --> Output Class Initialized
INFO - 2020-10-05 16:14:38 --> Security Class Initialized
DEBUG - 2020-10-05 16:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:14:38 --> Input Class Initialized
INFO - 2020-10-05 16:14:38 --> Language Class Initialized
INFO - 2020-10-05 16:14:38 --> Loader Class Initialized
INFO - 2020-10-05 16:14:38 --> Helper loaded: url_helper
INFO - 2020-10-05 16:14:38 --> Helper loaded: file_helper
INFO - 2020-10-05 16:14:38 --> Database Driver Class Initialized
INFO - 2020-10-05 16:14:38 --> Email Class Initialized
DEBUG - 2020-10-05 16:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:14:38 --> Controller Class Initialized
INFO - 2020-10-05 16:14:38 --> Model "Main_model" initialized
INFO - 2020-10-05 16:14:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:14:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:14:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:14:38 --> Final output sent to browser
DEBUG - 2020-10-05 16:14:38 --> Total execution time: 0.4971
INFO - 2020-10-05 16:14:39 --> Config Class Initialized
INFO - 2020-10-05 16:14:39 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:14:39 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:14:39 --> Utf8 Class Initialized
INFO - 2020-10-05 16:14:39 --> URI Class Initialized
INFO - 2020-10-05 16:14:39 --> Router Class Initialized
INFO - 2020-10-05 16:14:39 --> Output Class Initialized
INFO - 2020-10-05 16:14:39 --> Security Class Initialized
DEBUG - 2020-10-05 16:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:14:39 --> Input Class Initialized
INFO - 2020-10-05 16:14:39 --> Language Class Initialized
ERROR - 2020-10-05 16:14:39 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:14:44 --> Config Class Initialized
INFO - 2020-10-05 16:14:44 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:14:44 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:14:44 --> Utf8 Class Initialized
INFO - 2020-10-05 16:14:44 --> URI Class Initialized
INFO - 2020-10-05 16:14:44 --> Router Class Initialized
INFO - 2020-10-05 16:14:44 --> Output Class Initialized
INFO - 2020-10-05 16:14:44 --> Security Class Initialized
DEBUG - 2020-10-05 16:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:14:44 --> Input Class Initialized
INFO - 2020-10-05 16:14:44 --> Language Class Initialized
INFO - 2020-10-05 16:14:44 --> Loader Class Initialized
INFO - 2020-10-05 16:14:44 --> Helper loaded: url_helper
INFO - 2020-10-05 16:14:44 --> Helper loaded: file_helper
INFO - 2020-10-05 16:14:44 --> Database Driver Class Initialized
INFO - 2020-10-05 16:14:44 --> Email Class Initialized
DEBUG - 2020-10-05 16:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:14:44 --> Controller Class Initialized
INFO - 2020-10-05 16:14:44 --> Model "Main_model" initialized
INFO - 2020-10-05 16:14:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:14:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:14:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:14:44 --> Final output sent to browser
DEBUG - 2020-10-05 16:14:44 --> Total execution time: 0.4666
INFO - 2020-10-05 16:14:45 --> Config Class Initialized
INFO - 2020-10-05 16:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:14:45 --> Utf8 Class Initialized
INFO - 2020-10-05 16:14:45 --> URI Class Initialized
INFO - 2020-10-05 16:14:45 --> Router Class Initialized
INFO - 2020-10-05 16:14:46 --> Output Class Initialized
INFO - 2020-10-05 16:14:46 --> Security Class Initialized
DEBUG - 2020-10-05 16:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:14:46 --> Input Class Initialized
INFO - 2020-10-05 16:14:46 --> Language Class Initialized
ERROR - 2020-10-05 16:14:46 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:16:13 --> Config Class Initialized
INFO - 2020-10-05 16:16:13 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:16:13 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:16:13 --> Utf8 Class Initialized
INFO - 2020-10-05 16:16:13 --> URI Class Initialized
INFO - 2020-10-05 16:16:13 --> Router Class Initialized
INFO - 2020-10-05 16:16:13 --> Output Class Initialized
INFO - 2020-10-05 16:16:13 --> Security Class Initialized
DEBUG - 2020-10-05 16:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:16:13 --> Input Class Initialized
INFO - 2020-10-05 16:16:13 --> Language Class Initialized
INFO - 2020-10-05 16:16:13 --> Loader Class Initialized
INFO - 2020-10-05 16:16:13 --> Helper loaded: url_helper
INFO - 2020-10-05 16:16:13 --> Helper loaded: file_helper
INFO - 2020-10-05 16:16:13 --> Database Driver Class Initialized
INFO - 2020-10-05 16:16:13 --> Email Class Initialized
DEBUG - 2020-10-05 16:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:16:13 --> Controller Class Initialized
INFO - 2020-10-05 16:16:13 --> Model "Main_model" initialized
ERROR - 2020-10-05 16:16:13 --> Severity: Notice --> Undefined index: domainame C:\xampp\htdocs\dmarc\application\controllers\Home.php 32
INFO - 2020-10-05 16:16:13 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:16:13 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:16:13 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:16:13 --> Final output sent to browser
DEBUG - 2020-10-05 16:16:13 --> Total execution time: 0.5451
INFO - 2020-10-05 16:16:14 --> Config Class Initialized
INFO - 2020-10-05 16:16:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:16:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:16:14 --> Utf8 Class Initialized
INFO - 2020-10-05 16:16:14 --> URI Class Initialized
INFO - 2020-10-05 16:16:14 --> Router Class Initialized
INFO - 2020-10-05 16:16:14 --> Output Class Initialized
INFO - 2020-10-05 16:16:14 --> Security Class Initialized
DEBUG - 2020-10-05 16:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:16:14 --> Input Class Initialized
INFO - 2020-10-05 16:16:14 --> Language Class Initialized
ERROR - 2020-10-05 16:16:14 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:16:33 --> Config Class Initialized
INFO - 2020-10-05 16:16:33 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:16:33 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:16:33 --> Utf8 Class Initialized
INFO - 2020-10-05 16:16:33 --> URI Class Initialized
INFO - 2020-10-05 16:16:33 --> Router Class Initialized
INFO - 2020-10-05 16:16:33 --> Output Class Initialized
INFO - 2020-10-05 16:16:33 --> Security Class Initialized
DEBUG - 2020-10-05 16:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:16:33 --> Input Class Initialized
INFO - 2020-10-05 16:16:33 --> Language Class Initialized
INFO - 2020-10-05 16:16:33 --> Loader Class Initialized
INFO - 2020-10-05 16:16:33 --> Helper loaded: url_helper
INFO - 2020-10-05 16:16:33 --> Helper loaded: file_helper
INFO - 2020-10-05 16:16:33 --> Database Driver Class Initialized
INFO - 2020-10-05 16:16:33 --> Email Class Initialized
DEBUG - 2020-10-05 16:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:16:33 --> Controller Class Initialized
INFO - 2020-10-05 16:16:33 --> Model "Main_model" initialized
INFO - 2020-10-05 16:16:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:16:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:16:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:16:33 --> Final output sent to browser
DEBUG - 2020-10-05 16:16:33 --> Total execution time: 0.4721
INFO - 2020-10-05 16:16:35 --> Config Class Initialized
INFO - 2020-10-05 16:16:35 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:16:35 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:16:35 --> Utf8 Class Initialized
INFO - 2020-10-05 16:16:35 --> URI Class Initialized
INFO - 2020-10-05 16:16:35 --> Router Class Initialized
INFO - 2020-10-05 16:16:35 --> Output Class Initialized
INFO - 2020-10-05 16:16:35 --> Security Class Initialized
DEBUG - 2020-10-05 16:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:16:35 --> Input Class Initialized
INFO - 2020-10-05 16:16:35 --> Language Class Initialized
ERROR - 2020-10-05 16:16:35 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:16:37 --> Config Class Initialized
INFO - 2020-10-05 16:16:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:16:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:16:37 --> Utf8 Class Initialized
INFO - 2020-10-05 16:16:37 --> URI Class Initialized
INFO - 2020-10-05 16:16:37 --> Router Class Initialized
INFO - 2020-10-05 16:16:37 --> Output Class Initialized
INFO - 2020-10-05 16:16:37 --> Security Class Initialized
DEBUG - 2020-10-05 16:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:16:37 --> Input Class Initialized
INFO - 2020-10-05 16:16:37 --> Language Class Initialized
INFO - 2020-10-05 16:16:37 --> Loader Class Initialized
INFO - 2020-10-05 16:16:37 --> Helper loaded: url_helper
INFO - 2020-10-05 16:16:37 --> Helper loaded: file_helper
INFO - 2020-10-05 16:16:37 --> Database Driver Class Initialized
INFO - 2020-10-05 16:16:37 --> Email Class Initialized
DEBUG - 2020-10-05 16:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:16:37 --> Controller Class Initialized
INFO - 2020-10-05 16:16:37 --> Model "Main_model" initialized
INFO - 2020-10-05 16:16:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:16:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:16:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:16:37 --> Final output sent to browser
DEBUG - 2020-10-05 16:16:37 --> Total execution time: 0.4911
INFO - 2020-10-05 16:16:38 --> Config Class Initialized
INFO - 2020-10-05 16:16:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:16:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:16:38 --> Utf8 Class Initialized
INFO - 2020-10-05 16:16:38 --> URI Class Initialized
INFO - 2020-10-05 16:16:38 --> Router Class Initialized
INFO - 2020-10-05 16:16:38 --> Output Class Initialized
INFO - 2020-10-05 16:16:38 --> Security Class Initialized
DEBUG - 2020-10-05 16:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:16:38 --> Input Class Initialized
INFO - 2020-10-05 16:16:38 --> Language Class Initialized
ERROR - 2020-10-05 16:16:38 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:16:52 --> Config Class Initialized
INFO - 2020-10-05 16:16:52 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:16:52 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:16:52 --> Utf8 Class Initialized
INFO - 2020-10-05 16:16:52 --> URI Class Initialized
INFO - 2020-10-05 16:16:52 --> Router Class Initialized
INFO - 2020-10-05 16:16:52 --> Output Class Initialized
INFO - 2020-10-05 16:16:52 --> Security Class Initialized
DEBUG - 2020-10-05 16:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:16:52 --> Input Class Initialized
INFO - 2020-10-05 16:16:52 --> Language Class Initialized
INFO - 2020-10-05 16:16:52 --> Loader Class Initialized
INFO - 2020-10-05 16:16:52 --> Helper loaded: url_helper
INFO - 2020-10-05 16:16:52 --> Helper loaded: file_helper
INFO - 2020-10-05 16:16:52 --> Database Driver Class Initialized
INFO - 2020-10-05 16:16:52 --> Email Class Initialized
DEBUG - 2020-10-05 16:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:16:52 --> Controller Class Initialized
INFO - 2020-10-05 16:16:52 --> Model "Main_model" initialized
INFO - 2020-10-05 16:16:52 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:16:52 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:16:52 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:16:52 --> Final output sent to browser
DEBUG - 2020-10-05 16:16:52 --> Total execution time: 0.4725
INFO - 2020-10-05 16:16:53 --> Config Class Initialized
INFO - 2020-10-05 16:16:53 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:16:53 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:16:53 --> Utf8 Class Initialized
INFO - 2020-10-05 16:16:53 --> URI Class Initialized
INFO - 2020-10-05 16:16:53 --> Router Class Initialized
INFO - 2020-10-05 16:16:53 --> Output Class Initialized
INFO - 2020-10-05 16:16:53 --> Security Class Initialized
DEBUG - 2020-10-05 16:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:16:53 --> Input Class Initialized
INFO - 2020-10-05 16:16:53 --> Language Class Initialized
ERROR - 2020-10-05 16:16:53 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:17:16 --> Config Class Initialized
INFO - 2020-10-05 16:17:16 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:17:17 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:17:17 --> Utf8 Class Initialized
INFO - 2020-10-05 16:17:17 --> URI Class Initialized
INFO - 2020-10-05 16:17:17 --> Router Class Initialized
INFO - 2020-10-05 16:17:17 --> Output Class Initialized
INFO - 2020-10-05 16:17:17 --> Security Class Initialized
DEBUG - 2020-10-05 16:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:17:17 --> Input Class Initialized
INFO - 2020-10-05 16:17:17 --> Language Class Initialized
INFO - 2020-10-05 16:17:17 --> Loader Class Initialized
INFO - 2020-10-05 16:17:17 --> Helper loaded: url_helper
INFO - 2020-10-05 16:17:17 --> Helper loaded: file_helper
INFO - 2020-10-05 16:17:17 --> Database Driver Class Initialized
INFO - 2020-10-05 16:17:17 --> Email Class Initialized
DEBUG - 2020-10-05 16:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:17:17 --> Controller Class Initialized
INFO - 2020-10-05 16:17:17 --> Model "Main_model" initialized
INFO - 2020-10-05 16:17:38 --> Config Class Initialized
INFO - 2020-10-05 16:17:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:17:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:17:38 --> Utf8 Class Initialized
INFO - 2020-10-05 16:17:38 --> URI Class Initialized
INFO - 2020-10-05 16:17:38 --> Router Class Initialized
INFO - 2020-10-05 16:17:38 --> Output Class Initialized
INFO - 2020-10-05 16:17:38 --> Security Class Initialized
DEBUG - 2020-10-05 16:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:17:38 --> Input Class Initialized
INFO - 2020-10-05 16:17:38 --> Language Class Initialized
INFO - 2020-10-05 16:17:38 --> Loader Class Initialized
INFO - 2020-10-05 16:17:38 --> Helper loaded: url_helper
INFO - 2020-10-05 16:17:38 --> Helper loaded: file_helper
INFO - 2020-10-05 16:17:38 --> Database Driver Class Initialized
INFO - 2020-10-05 16:17:38 --> Email Class Initialized
DEBUG - 2020-10-05 16:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:17:38 --> Controller Class Initialized
INFO - 2020-10-05 16:17:38 --> Model "Main_model" initialized
INFO - 2020-10-05 16:17:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:17:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:17:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:17:38 --> Final output sent to browser
DEBUG - 2020-10-05 16:17:38 --> Total execution time: 0.5079
INFO - 2020-10-05 16:17:39 --> Config Class Initialized
INFO - 2020-10-05 16:17:39 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:17:39 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:17:39 --> Utf8 Class Initialized
INFO - 2020-10-05 16:17:39 --> URI Class Initialized
INFO - 2020-10-05 16:17:39 --> Router Class Initialized
INFO - 2020-10-05 16:17:39 --> Output Class Initialized
INFO - 2020-10-05 16:17:39 --> Security Class Initialized
DEBUG - 2020-10-05 16:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:17:39 --> Input Class Initialized
INFO - 2020-10-05 16:17:39 --> Language Class Initialized
ERROR - 2020-10-05 16:17:39 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:17:41 --> Config Class Initialized
INFO - 2020-10-05 16:17:41 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:17:41 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:17:41 --> Utf8 Class Initialized
INFO - 2020-10-05 16:17:41 --> URI Class Initialized
INFO - 2020-10-05 16:17:41 --> Router Class Initialized
INFO - 2020-10-05 16:17:41 --> Output Class Initialized
INFO - 2020-10-05 16:17:41 --> Security Class Initialized
DEBUG - 2020-10-05 16:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:17:41 --> Input Class Initialized
INFO - 2020-10-05 16:17:41 --> Language Class Initialized
INFO - 2020-10-05 16:17:41 --> Loader Class Initialized
INFO - 2020-10-05 16:17:41 --> Helper loaded: url_helper
INFO - 2020-10-05 16:17:41 --> Helper loaded: file_helper
INFO - 2020-10-05 16:17:41 --> Database Driver Class Initialized
INFO - 2020-10-05 16:17:41 --> Email Class Initialized
DEBUG - 2020-10-05 16:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:17:41 --> Controller Class Initialized
INFO - 2020-10-05 16:17:41 --> Model "Main_model" initialized
INFO - 2020-10-05 16:18:03 --> Config Class Initialized
INFO - 2020-10-05 16:18:03 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:18:03 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:18:03 --> Utf8 Class Initialized
INFO - 2020-10-05 16:18:03 --> URI Class Initialized
INFO - 2020-10-05 16:18:03 --> Router Class Initialized
INFO - 2020-10-05 16:18:03 --> Output Class Initialized
INFO - 2020-10-05 16:18:03 --> Security Class Initialized
DEBUG - 2020-10-05 16:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:18:03 --> Input Class Initialized
INFO - 2020-10-05 16:18:03 --> Language Class Initialized
INFO - 2020-10-05 16:18:03 --> Loader Class Initialized
INFO - 2020-10-05 16:18:03 --> Helper loaded: url_helper
INFO - 2020-10-05 16:18:03 --> Helper loaded: file_helper
INFO - 2020-10-05 16:18:03 --> Database Driver Class Initialized
INFO - 2020-10-05 16:18:03 --> Email Class Initialized
DEBUG - 2020-10-05 16:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:18:03 --> Controller Class Initialized
INFO - 2020-10-05 16:18:03 --> Model "Main_model" initialized
INFO - 2020-10-05 16:18:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:18:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:18:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:18:03 --> Final output sent to browser
DEBUG - 2020-10-05 16:18:03 --> Total execution time: 0.4862
INFO - 2020-10-05 16:18:04 --> Config Class Initialized
INFO - 2020-10-05 16:18:04 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:18:04 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:18:04 --> Utf8 Class Initialized
INFO - 2020-10-05 16:18:04 --> URI Class Initialized
INFO - 2020-10-05 16:18:04 --> Router Class Initialized
INFO - 2020-10-05 16:18:04 --> Output Class Initialized
INFO - 2020-10-05 16:18:04 --> Security Class Initialized
DEBUG - 2020-10-05 16:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:18:04 --> Input Class Initialized
INFO - 2020-10-05 16:18:04 --> Language Class Initialized
ERROR - 2020-10-05 16:18:04 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:18:18 --> Config Class Initialized
INFO - 2020-10-05 16:18:18 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:18:18 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:18:18 --> Utf8 Class Initialized
INFO - 2020-10-05 16:18:18 --> URI Class Initialized
INFO - 2020-10-05 16:18:18 --> Router Class Initialized
INFO - 2020-10-05 16:18:18 --> Output Class Initialized
INFO - 2020-10-05 16:18:18 --> Security Class Initialized
DEBUG - 2020-10-05 16:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:18:18 --> Input Class Initialized
INFO - 2020-10-05 16:18:18 --> Language Class Initialized
INFO - 2020-10-05 16:18:18 --> Loader Class Initialized
INFO - 2020-10-05 16:18:18 --> Helper loaded: url_helper
INFO - 2020-10-05 16:18:18 --> Helper loaded: file_helper
INFO - 2020-10-05 16:18:18 --> Database Driver Class Initialized
INFO - 2020-10-05 16:18:18 --> Email Class Initialized
DEBUG - 2020-10-05 16:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:18:18 --> Controller Class Initialized
INFO - 2020-10-05 16:18:18 --> Model "Main_model" initialized
INFO - 2020-10-05 16:26:33 --> Config Class Initialized
INFO - 2020-10-05 16:26:33 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:26:33 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:26:33 --> Utf8 Class Initialized
INFO - 2020-10-05 16:26:33 --> URI Class Initialized
INFO - 2020-10-05 16:26:33 --> Router Class Initialized
INFO - 2020-10-05 16:26:33 --> Output Class Initialized
INFO - 2020-10-05 16:26:33 --> Security Class Initialized
DEBUG - 2020-10-05 16:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:26:33 --> Input Class Initialized
INFO - 2020-10-05 16:26:33 --> Language Class Initialized
INFO - 2020-10-05 16:26:33 --> Loader Class Initialized
INFO - 2020-10-05 16:26:33 --> Helper loaded: url_helper
INFO - 2020-10-05 16:26:33 --> Helper loaded: file_helper
INFO - 2020-10-05 16:26:33 --> Database Driver Class Initialized
INFO - 2020-10-05 16:26:34 --> Email Class Initialized
DEBUG - 2020-10-05 16:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:26:34 --> Controller Class Initialized
INFO - 2020-10-05 16:26:34 --> Model "Main_model" initialized
INFO - 2020-10-05 16:26:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:26:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:26:34 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:26:34 --> Final output sent to browser
DEBUG - 2020-10-05 16:26:34 --> Total execution time: 0.5441
INFO - 2020-10-05 16:26:35 --> Config Class Initialized
INFO - 2020-10-05 16:26:35 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:26:35 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:26:35 --> Utf8 Class Initialized
INFO - 2020-10-05 16:26:35 --> URI Class Initialized
INFO - 2020-10-05 16:26:35 --> Router Class Initialized
INFO - 2020-10-05 16:26:35 --> Output Class Initialized
INFO - 2020-10-05 16:26:35 --> Security Class Initialized
DEBUG - 2020-10-05 16:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:26:35 --> Input Class Initialized
INFO - 2020-10-05 16:26:35 --> Language Class Initialized
ERROR - 2020-10-05 16:26:35 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:26:37 --> Config Class Initialized
INFO - 2020-10-05 16:26:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:26:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:26:37 --> Utf8 Class Initialized
INFO - 2020-10-05 16:26:37 --> URI Class Initialized
INFO - 2020-10-05 16:26:37 --> Router Class Initialized
INFO - 2020-10-05 16:26:37 --> Output Class Initialized
INFO - 2020-10-05 16:26:37 --> Security Class Initialized
DEBUG - 2020-10-05 16:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:26:37 --> Input Class Initialized
INFO - 2020-10-05 16:26:37 --> Language Class Initialized
INFO - 2020-10-05 16:26:37 --> Loader Class Initialized
INFO - 2020-10-05 16:26:37 --> Helper loaded: url_helper
INFO - 2020-10-05 16:26:37 --> Helper loaded: file_helper
INFO - 2020-10-05 16:26:37 --> Database Driver Class Initialized
INFO - 2020-10-05 16:26:37 --> Email Class Initialized
DEBUG - 2020-10-05 16:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:26:37 --> Controller Class Initialized
INFO - 2020-10-05 16:26:37 --> Model "Main_model" initialized
ERROR - 2020-10-05 16:27:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\dmarc\application\controllers\Home.php:23) C:\xampp\htdocs\dmarc\system\core\Common.php 570
ERROR - 2020-10-05 16:27:14 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\dmarc\application\controllers\Home.php 51
INFO - 2020-10-05 16:32:09 --> Config Class Initialized
INFO - 2020-10-05 16:32:09 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:32:09 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:32:09 --> Utf8 Class Initialized
INFO - 2020-10-05 16:32:09 --> URI Class Initialized
INFO - 2020-10-05 16:32:09 --> Router Class Initialized
INFO - 2020-10-05 16:32:09 --> Output Class Initialized
INFO - 2020-10-05 16:32:09 --> Security Class Initialized
DEBUG - 2020-10-05 16:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:32:09 --> Input Class Initialized
INFO - 2020-10-05 16:32:09 --> Language Class Initialized
INFO - 2020-10-05 16:32:09 --> Loader Class Initialized
INFO - 2020-10-05 16:32:09 --> Helper loaded: url_helper
INFO - 2020-10-05 16:32:09 --> Helper loaded: file_helper
INFO - 2020-10-05 16:32:09 --> Database Driver Class Initialized
INFO - 2020-10-05 16:32:09 --> Email Class Initialized
DEBUG - 2020-10-05 16:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:32:09 --> Controller Class Initialized
INFO - 2020-10-05 16:32:09 --> Model "Main_model" initialized
INFO - 2020-10-05 16:32:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:32:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:32:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:32:09 --> Final output sent to browser
DEBUG - 2020-10-05 16:32:09 --> Total execution time: 0.5002
INFO - 2020-10-05 16:32:12 --> Config Class Initialized
INFO - 2020-10-05 16:32:12 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:32:12 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:32:12 --> Utf8 Class Initialized
INFO - 2020-10-05 16:32:12 --> URI Class Initialized
INFO - 2020-10-05 16:32:12 --> Router Class Initialized
INFO - 2020-10-05 16:32:12 --> Output Class Initialized
INFO - 2020-10-05 16:32:12 --> Security Class Initialized
DEBUG - 2020-10-05 16:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:32:12 --> Input Class Initialized
INFO - 2020-10-05 16:32:12 --> Language Class Initialized
INFO - 2020-10-05 16:32:12 --> Loader Class Initialized
INFO - 2020-10-05 16:32:12 --> Helper loaded: url_helper
INFO - 2020-10-05 16:32:12 --> Helper loaded: file_helper
INFO - 2020-10-05 16:32:12 --> Database Driver Class Initialized
INFO - 2020-10-05 16:32:12 --> Email Class Initialized
DEBUG - 2020-10-05 16:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:32:13 --> Controller Class Initialized
INFO - 2020-10-05 16:32:13 --> Model "Main_model" initialized
INFO - 2020-10-05 16:32:25 --> Final output sent to browser
DEBUG - 2020-10-05 16:32:25 --> Total execution time: 13.1857
INFO - 2020-10-05 16:43:57 --> Config Class Initialized
INFO - 2020-10-05 16:43:57 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:43:57 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:43:57 --> Utf8 Class Initialized
INFO - 2020-10-05 16:43:57 --> URI Class Initialized
INFO - 2020-10-05 16:43:57 --> Router Class Initialized
INFO - 2020-10-05 16:43:57 --> Output Class Initialized
INFO - 2020-10-05 16:43:57 --> Security Class Initialized
DEBUG - 2020-10-05 16:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:43:57 --> Input Class Initialized
INFO - 2020-10-05 16:43:57 --> Language Class Initialized
INFO - 2020-10-05 16:43:57 --> Loader Class Initialized
INFO - 2020-10-05 16:43:57 --> Helper loaded: url_helper
INFO - 2020-10-05 16:43:57 --> Helper loaded: file_helper
INFO - 2020-10-05 16:43:57 --> Database Driver Class Initialized
INFO - 2020-10-05 16:43:57 --> Email Class Initialized
DEBUG - 2020-10-05 16:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:43:57 --> Controller Class Initialized
INFO - 2020-10-05 16:43:57 --> Model "Main_model" initialized
INFO - 2020-10-05 16:44:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:44:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-10-05 16:44:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php 123
INFO - 2020-10-05 16:44:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:44:07 --> Final output sent to browser
DEBUG - 2020-10-05 16:44:07 --> Total execution time: 9.7212
INFO - 2020-10-05 16:44:32 --> Config Class Initialized
INFO - 2020-10-05 16:44:32 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:44:32 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:44:32 --> Utf8 Class Initialized
INFO - 2020-10-05 16:44:32 --> URI Class Initialized
INFO - 2020-10-05 16:44:32 --> Router Class Initialized
INFO - 2020-10-05 16:44:32 --> Output Class Initialized
INFO - 2020-10-05 16:44:32 --> Security Class Initialized
DEBUG - 2020-10-05 16:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:44:32 --> Input Class Initialized
INFO - 2020-10-05 16:44:32 --> Language Class Initialized
INFO - 2020-10-05 16:44:32 --> Loader Class Initialized
INFO - 2020-10-05 16:44:32 --> Helper loaded: url_helper
INFO - 2020-10-05 16:44:32 --> Helper loaded: file_helper
INFO - 2020-10-05 16:44:32 --> Database Driver Class Initialized
INFO - 2020-10-05 16:44:32 --> Email Class Initialized
DEBUG - 2020-10-05 16:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:44:32 --> Controller Class Initialized
INFO - 2020-10-05 16:44:32 --> Model "Main_model" initialized
INFO - 2020-10-05 16:44:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:44:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-10-05 16:44:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php 124
INFO - 2020-10-05 16:44:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:44:49 --> Final output sent to browser
DEBUG - 2020-10-05 16:44:49 --> Total execution time: 16.6161
INFO - 2020-10-05 16:45:45 --> Config Class Initialized
INFO - 2020-10-05 16:45:45 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:45:45 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:45:45 --> Utf8 Class Initialized
INFO - 2020-10-05 16:45:45 --> URI Class Initialized
INFO - 2020-10-05 16:45:45 --> Router Class Initialized
INFO - 2020-10-05 16:45:45 --> Output Class Initialized
INFO - 2020-10-05 16:45:45 --> Security Class Initialized
DEBUG - 2020-10-05 16:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:45:45 --> Input Class Initialized
INFO - 2020-10-05 16:45:45 --> Language Class Initialized
INFO - 2020-10-05 16:45:45 --> Loader Class Initialized
INFO - 2020-10-05 16:45:45 --> Helper loaded: url_helper
INFO - 2020-10-05 16:45:45 --> Helper loaded: file_helper
INFO - 2020-10-05 16:45:45 --> Database Driver Class Initialized
INFO - 2020-10-05 16:45:45 --> Email Class Initialized
DEBUG - 2020-10-05 16:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:45:45 --> Controller Class Initialized
INFO - 2020-10-05 16:45:45 --> Model "Main_model" initialized
INFO - 2020-10-05 16:45:54 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:45:54 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:45:54 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:45:54 --> Final output sent to browser
DEBUG - 2020-10-05 16:45:54 --> Total execution time: 9.8062
INFO - 2020-10-05 16:48:05 --> Config Class Initialized
INFO - 2020-10-05 16:48:05 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:48:05 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:48:05 --> Utf8 Class Initialized
INFO - 2020-10-05 16:48:05 --> URI Class Initialized
INFO - 2020-10-05 16:48:05 --> Router Class Initialized
INFO - 2020-10-05 16:48:05 --> Output Class Initialized
INFO - 2020-10-05 16:48:05 --> Security Class Initialized
DEBUG - 2020-10-05 16:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:48:05 --> Input Class Initialized
INFO - 2020-10-05 16:48:05 --> Language Class Initialized
INFO - 2020-10-05 16:48:05 --> Loader Class Initialized
INFO - 2020-10-05 16:48:05 --> Helper loaded: url_helper
INFO - 2020-10-05 16:48:05 --> Helper loaded: file_helper
INFO - 2020-10-05 16:48:05 --> Database Driver Class Initialized
INFO - 2020-10-05 16:48:05 --> Email Class Initialized
DEBUG - 2020-10-05 16:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:48:05 --> Controller Class Initialized
INFO - 2020-10-05 16:48:05 --> Model "Main_model" initialized
INFO - 2020-10-05 16:48:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:48:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:48:14 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:48:14 --> Final output sent to browser
DEBUG - 2020-10-05 16:48:14 --> Total execution time: 9.7642
INFO - 2020-10-05 16:48:26 --> Config Class Initialized
INFO - 2020-10-05 16:48:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:48:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:48:26 --> Utf8 Class Initialized
INFO - 2020-10-05 16:48:26 --> URI Class Initialized
INFO - 2020-10-05 16:48:26 --> Router Class Initialized
INFO - 2020-10-05 16:48:26 --> Output Class Initialized
INFO - 2020-10-05 16:48:26 --> Security Class Initialized
DEBUG - 2020-10-05 16:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:48:26 --> Input Class Initialized
INFO - 2020-10-05 16:48:26 --> Language Class Initialized
ERROR - 2020-10-05 16:48:26 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 16:48:51 --> Config Class Initialized
INFO - 2020-10-05 16:48:51 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:48:51 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:48:51 --> Utf8 Class Initialized
INFO - 2020-10-05 16:48:51 --> URI Class Initialized
INFO - 2020-10-05 16:48:51 --> Router Class Initialized
INFO - 2020-10-05 16:48:51 --> Output Class Initialized
INFO - 2020-10-05 16:48:51 --> Security Class Initialized
DEBUG - 2020-10-05 16:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:48:51 --> Input Class Initialized
INFO - 2020-10-05 16:48:51 --> Language Class Initialized
INFO - 2020-10-05 16:48:51 --> Loader Class Initialized
INFO - 2020-10-05 16:48:52 --> Helper loaded: url_helper
INFO - 2020-10-05 16:48:52 --> Helper loaded: file_helper
INFO - 2020-10-05 16:48:52 --> Database Driver Class Initialized
INFO - 2020-10-05 16:48:52 --> Email Class Initialized
DEBUG - 2020-10-05 16:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:48:52 --> Controller Class Initialized
INFO - 2020-10-05 16:48:52 --> Model "Main_model" initialized
INFO - 2020-10-05 16:49:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:49:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:49:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:49:01 --> Final output sent to browser
DEBUG - 2020-10-05 16:49:01 --> Total execution time: 9.8108
INFO - 2020-10-05 16:49:45 --> Config Class Initialized
INFO - 2020-10-05 16:49:45 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:49:45 --> Utf8 Class Initialized
INFO - 2020-10-05 16:49:45 --> URI Class Initialized
INFO - 2020-10-05 16:49:45 --> Router Class Initialized
INFO - 2020-10-05 16:49:45 --> Output Class Initialized
INFO - 2020-10-05 16:49:45 --> Security Class Initialized
DEBUG - 2020-10-05 16:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:49:45 --> Input Class Initialized
INFO - 2020-10-05 16:49:45 --> Language Class Initialized
INFO - 2020-10-05 16:49:45 --> Loader Class Initialized
INFO - 2020-10-05 16:49:45 --> Helper loaded: url_helper
INFO - 2020-10-05 16:49:45 --> Helper loaded: file_helper
INFO - 2020-10-05 16:49:45 --> Database Driver Class Initialized
INFO - 2020-10-05 16:49:45 --> Email Class Initialized
DEBUG - 2020-10-05 16:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 16:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:49:45 --> Controller Class Initialized
INFO - 2020-10-05 16:49:45 --> Model "Main_model" initialized
INFO - 2020-10-05 16:49:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 16:49:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 16:49:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 16:49:55 --> Final output sent to browser
DEBUG - 2020-10-05 16:49:55 --> Total execution time: 9.7133
INFO - 2020-10-05 16:50:00 --> Config Class Initialized
INFO - 2020-10-05 16:50:00 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:50:01 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:50:01 --> Utf8 Class Initialized
INFO - 2020-10-05 16:50:01 --> URI Class Initialized
INFO - 2020-10-05 16:50:01 --> Router Class Initialized
INFO - 2020-10-05 16:50:01 --> Output Class Initialized
INFO - 2020-10-05 16:50:01 --> Security Class Initialized
DEBUG - 2020-10-05 16:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:50:01 --> Input Class Initialized
INFO - 2020-10-05 16:50:01 --> Language Class Initialized
ERROR - 2020-10-05 16:50:01 --> 404 Page Not Found: Domainscanner/index
INFO - 2020-10-05 17:06:04 --> Config Class Initialized
INFO - 2020-10-05 17:06:04 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:06:04 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:06:04 --> Utf8 Class Initialized
INFO - 2020-10-05 17:06:04 --> URI Class Initialized
INFO - 2020-10-05 17:06:04 --> Router Class Initialized
INFO - 2020-10-05 17:06:04 --> Output Class Initialized
INFO - 2020-10-05 17:06:04 --> Security Class Initialized
DEBUG - 2020-10-05 17:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:06:04 --> Input Class Initialized
INFO - 2020-10-05 17:06:04 --> Language Class Initialized
INFO - 2020-10-05 17:06:04 --> Loader Class Initialized
INFO - 2020-10-05 17:06:04 --> Helper loaded: url_helper
INFO - 2020-10-05 17:06:04 --> Helper loaded: file_helper
INFO - 2020-10-05 17:06:04 --> Database Driver Class Initialized
INFO - 2020-10-05 17:06:04 --> Email Class Initialized
DEBUG - 2020-10-05 17:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:06:04 --> Controller Class Initialized
INFO - 2020-10-05 17:06:04 --> Model "Main_model" initialized
INFO - 2020-10-05 17:06:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:06:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 17:06:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:06:04 --> Final output sent to browser
DEBUG - 2020-10-05 17:06:05 --> Total execution time: 0.5747
INFO - 2020-10-05 17:06:09 --> Config Class Initialized
INFO - 2020-10-05 17:06:09 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:06:09 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:06:09 --> Utf8 Class Initialized
INFO - 2020-10-05 17:06:09 --> URI Class Initialized
INFO - 2020-10-05 17:06:09 --> Router Class Initialized
INFO - 2020-10-05 17:06:09 --> Output Class Initialized
INFO - 2020-10-05 17:06:09 --> Security Class Initialized
DEBUG - 2020-10-05 17:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:06:09 --> Input Class Initialized
INFO - 2020-10-05 17:06:09 --> Language Class Initialized
INFO - 2020-10-05 17:06:09 --> Loader Class Initialized
INFO - 2020-10-05 17:06:09 --> Helper loaded: url_helper
INFO - 2020-10-05 17:06:09 --> Helper loaded: file_helper
INFO - 2020-10-05 17:06:09 --> Database Driver Class Initialized
INFO - 2020-10-05 17:06:09 --> Email Class Initialized
DEBUG - 2020-10-05 17:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:06:09 --> Controller Class Initialized
INFO - 2020-10-05 17:06:09 --> Model "Main_model" initialized
INFO - 2020-10-05 17:06:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:06:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 17:06:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainreputaiton.php
INFO - 2020-10-05 17:06:19 --> Final output sent to browser
DEBUG - 2020-10-05 17:06:19 --> Total execution time: 9.8861
INFO - 2020-10-05 17:06:56 --> Config Class Initialized
INFO - 2020-10-05 17:06:56 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:06:56 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:06:56 --> Utf8 Class Initialized
INFO - 2020-10-05 17:06:56 --> URI Class Initialized
INFO - 2020-10-05 17:06:56 --> Router Class Initialized
INFO - 2020-10-05 17:06:56 --> Output Class Initialized
INFO - 2020-10-05 17:06:56 --> Security Class Initialized
DEBUG - 2020-10-05 17:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:06:56 --> Input Class Initialized
INFO - 2020-10-05 17:06:56 --> Language Class Initialized
INFO - 2020-10-05 17:06:56 --> Loader Class Initialized
INFO - 2020-10-05 17:06:56 --> Helper loaded: url_helper
INFO - 2020-10-05 17:06:56 --> Helper loaded: file_helper
INFO - 2020-10-05 17:06:56 --> Database Driver Class Initialized
INFO - 2020-10-05 17:06:56 --> Email Class Initialized
DEBUG - 2020-10-05 17:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:06:56 --> Controller Class Initialized
INFO - 2020-10-05 17:06:56 --> Model "Main_model" initialized
INFO - 2020-10-05 17:06:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:06:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 17:06:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:06:56 --> Final output sent to browser
DEBUG - 2020-10-05 17:06:56 --> Total execution time: 0.4762
INFO - 2020-10-05 17:06:58 --> Config Class Initialized
INFO - 2020-10-05 17:06:58 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:06:58 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:06:58 --> Utf8 Class Initialized
INFO - 2020-10-05 17:06:58 --> URI Class Initialized
INFO - 2020-10-05 17:06:58 --> Router Class Initialized
INFO - 2020-10-05 17:06:58 --> Output Class Initialized
INFO - 2020-10-05 17:06:58 --> Security Class Initialized
DEBUG - 2020-10-05 17:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:06:58 --> Input Class Initialized
INFO - 2020-10-05 17:06:58 --> Language Class Initialized
INFO - 2020-10-05 17:06:58 --> Loader Class Initialized
INFO - 2020-10-05 17:06:58 --> Helper loaded: url_helper
INFO - 2020-10-05 17:06:58 --> Helper loaded: file_helper
INFO - 2020-10-05 17:06:58 --> Database Driver Class Initialized
INFO - 2020-10-05 17:06:58 --> Email Class Initialized
DEBUG - 2020-10-05 17:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:06:59 --> Controller Class Initialized
INFO - 2020-10-05 17:06:59 --> Model "Main_model" initialized
ERROR - 2020-10-05 17:06:59 --> Severity: Notice --> Undefined variable: selector C:\xampp\htdocs\dmarc\application\controllers\Home.php 40
ERROR - 2020-10-05 17:06:59 --> Severity: Warning --> dns_get_record(): DNS Query failed C:\xampp\htdocs\dmarc\application\controllers\Home.php 40
INFO - 2020-10-05 17:06:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:06:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 17:06:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:06:59 --> Final output sent to browser
DEBUG - 2020-10-05 17:06:59 --> Total execution time: 0.7036
INFO - 2020-10-05 17:07:24 --> Config Class Initialized
INFO - 2020-10-05 17:07:24 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:07:24 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:07:24 --> Utf8 Class Initialized
INFO - 2020-10-05 17:07:24 --> URI Class Initialized
INFO - 2020-10-05 17:07:24 --> Router Class Initialized
INFO - 2020-10-05 17:07:24 --> Output Class Initialized
INFO - 2020-10-05 17:07:24 --> Security Class Initialized
DEBUG - 2020-10-05 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:07:24 --> Input Class Initialized
INFO - 2020-10-05 17:07:24 --> Language Class Initialized
INFO - 2020-10-05 17:07:24 --> Loader Class Initialized
INFO - 2020-10-05 17:07:24 --> Helper loaded: url_helper
INFO - 2020-10-05 17:07:24 --> Helper loaded: file_helper
INFO - 2020-10-05 17:07:24 --> Database Driver Class Initialized
INFO - 2020-10-05 17:07:24 --> Email Class Initialized
DEBUG - 2020-10-05 17:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:07:24 --> Controller Class Initialized
INFO - 2020-10-05 17:07:24 --> Model "Main_model" initialized
INFO - 2020-10-05 17:07:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:07:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 17:07:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:07:25 --> Final output sent to browser
DEBUG - 2020-10-05 17:07:25 --> Total execution time: 0.5737
INFO - 2020-10-05 17:07:52 --> Config Class Initialized
INFO - 2020-10-05 17:07:52 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:07:52 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:07:52 --> Utf8 Class Initialized
INFO - 2020-10-05 17:07:52 --> URI Class Initialized
INFO - 2020-10-05 17:07:52 --> Router Class Initialized
INFO - 2020-10-05 17:07:52 --> Output Class Initialized
INFO - 2020-10-05 17:07:52 --> Security Class Initialized
DEBUG - 2020-10-05 17:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:07:52 --> Input Class Initialized
INFO - 2020-10-05 17:07:52 --> Language Class Initialized
ERROR - 2020-10-05 17:07:52 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 17:08:10 --> Config Class Initialized
INFO - 2020-10-05 17:08:10 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:08:10 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:08:10 --> Utf8 Class Initialized
INFO - 2020-10-05 17:08:10 --> URI Class Initialized
INFO - 2020-10-05 17:08:10 --> Router Class Initialized
INFO - 2020-10-05 17:08:10 --> Output Class Initialized
INFO - 2020-10-05 17:08:10 --> Security Class Initialized
DEBUG - 2020-10-05 17:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:08:10 --> Input Class Initialized
INFO - 2020-10-05 17:08:10 --> Language Class Initialized
INFO - 2020-10-05 17:08:10 --> Loader Class Initialized
INFO - 2020-10-05 17:08:10 --> Helper loaded: url_helper
INFO - 2020-10-05 17:08:10 --> Helper loaded: file_helper
INFO - 2020-10-05 17:08:10 --> Database Driver Class Initialized
INFO - 2020-10-05 17:08:10 --> Email Class Initialized
DEBUG - 2020-10-05 17:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:08:10 --> Controller Class Initialized
INFO - 2020-10-05 17:08:10 --> Model "Main_model" initialized
INFO - 2020-10-05 17:08:10 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:08:10 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 17:08:10 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:08:10 --> Final output sent to browser
DEBUG - 2020-10-05 17:08:10 --> Total execution time: 0.6370
INFO - 2020-10-05 17:08:19 --> Config Class Initialized
INFO - 2020-10-05 17:08:19 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:08:19 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:08:19 --> Utf8 Class Initialized
INFO - 2020-10-05 17:08:19 --> URI Class Initialized
INFO - 2020-10-05 17:08:19 --> Router Class Initialized
INFO - 2020-10-05 17:08:19 --> Output Class Initialized
INFO - 2020-10-05 17:08:19 --> Security Class Initialized
DEBUG - 2020-10-05 17:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:08:19 --> Input Class Initialized
INFO - 2020-10-05 17:08:19 --> Language Class Initialized
ERROR - 2020-10-05 17:08:19 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 17:08:41 --> Config Class Initialized
INFO - 2020-10-05 17:08:41 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:08:41 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:08:41 --> Utf8 Class Initialized
INFO - 2020-10-05 17:08:41 --> URI Class Initialized
INFO - 2020-10-05 17:08:41 --> Router Class Initialized
INFO - 2020-10-05 17:08:41 --> Output Class Initialized
INFO - 2020-10-05 17:08:41 --> Security Class Initialized
DEBUG - 2020-10-05 17:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:08:41 --> Input Class Initialized
INFO - 2020-10-05 17:08:41 --> Language Class Initialized
ERROR - 2020-10-05 17:08:41 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 17:12:57 --> Config Class Initialized
INFO - 2020-10-05 17:12:57 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:12:57 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:12:57 --> Utf8 Class Initialized
INFO - 2020-10-05 17:12:57 --> URI Class Initialized
INFO - 2020-10-05 17:12:58 --> Router Class Initialized
INFO - 2020-10-05 17:12:58 --> Output Class Initialized
INFO - 2020-10-05 17:12:58 --> Security Class Initialized
DEBUG - 2020-10-05 17:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:12:58 --> Input Class Initialized
INFO - 2020-10-05 17:12:58 --> Language Class Initialized
INFO - 2020-10-05 17:12:58 --> Loader Class Initialized
INFO - 2020-10-05 17:12:58 --> Helper loaded: url_helper
INFO - 2020-10-05 17:12:58 --> Helper loaded: file_helper
INFO - 2020-10-05 17:12:58 --> Database Driver Class Initialized
INFO - 2020-10-05 17:12:58 --> Email Class Initialized
DEBUG - 2020-10-05 17:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:12:58 --> Controller Class Initialized
INFO - 2020-10-05 17:12:58 --> Model "Main_model" initialized
INFO - 2020-10-05 17:12:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:12:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 17:12:58 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:12:58 --> Final output sent to browser
DEBUG - 2020-10-05 17:12:58 --> Total execution time: 0.9396
INFO - 2020-10-05 17:13:08 --> Config Class Initialized
INFO - 2020-10-05 17:13:08 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:13:08 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:13:09 --> Utf8 Class Initialized
INFO - 2020-10-05 17:13:09 --> URI Class Initialized
INFO - 2020-10-05 17:13:09 --> Router Class Initialized
INFO - 2020-10-05 17:13:09 --> Output Class Initialized
INFO - 2020-10-05 17:13:09 --> Security Class Initialized
DEBUG - 2020-10-05 17:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:13:09 --> Input Class Initialized
INFO - 2020-10-05 17:13:09 --> Language Class Initialized
ERROR - 2020-10-05 17:13:09 --> 404 Page Not Found: Resources/vendor
INFO - 2020-10-05 17:16:45 --> Config Class Initialized
INFO - 2020-10-05 17:16:45 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:16:45 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:16:45 --> Utf8 Class Initialized
INFO - 2020-10-05 17:16:45 --> URI Class Initialized
INFO - 2020-10-05 17:16:45 --> Router Class Initialized
INFO - 2020-10-05 17:16:45 --> Output Class Initialized
INFO - 2020-10-05 17:16:45 --> Security Class Initialized
DEBUG - 2020-10-05 17:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:16:45 --> Input Class Initialized
INFO - 2020-10-05 17:16:45 --> Language Class Initialized
INFO - 2020-10-05 17:16:45 --> Loader Class Initialized
INFO - 2020-10-05 17:16:45 --> Helper loaded: url_helper
INFO - 2020-10-05 17:16:45 --> Helper loaded: file_helper
INFO - 2020-10-05 17:16:45 --> Database Driver Class Initialized
INFO - 2020-10-05 17:16:46 --> Email Class Initialized
DEBUG - 2020-10-05 17:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:16:46 --> Controller Class Initialized
INFO - 2020-10-05 17:16:46 --> Model "Main_model" initialized
INFO - 2020-10-05 17:16:46 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:16:46 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 17:16:46 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:16:46 --> Final output sent to browser
DEBUG - 2020-10-05 17:16:46 --> Total execution time: 0.6035
INFO - 2020-10-05 17:17:01 --> Config Class Initialized
INFO - 2020-10-05 17:17:01 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:17:01 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:17:01 --> Utf8 Class Initialized
INFO - 2020-10-05 17:17:01 --> URI Class Initialized
INFO - 2020-10-05 17:17:01 --> Router Class Initialized
INFO - 2020-10-05 17:17:01 --> Output Class Initialized
INFO - 2020-10-05 17:17:01 --> Security Class Initialized
DEBUG - 2020-10-05 17:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:17:01 --> Input Class Initialized
INFO - 2020-10-05 17:17:01 --> Language Class Initialized
INFO - 2020-10-05 17:17:01 --> Loader Class Initialized
INFO - 2020-10-05 17:17:01 --> Helper loaded: url_helper
INFO - 2020-10-05 17:17:01 --> Helper loaded: file_helper
INFO - 2020-10-05 17:17:01 --> Database Driver Class Initialized
INFO - 2020-10-05 17:17:01 --> Email Class Initialized
DEBUG - 2020-10-05 17:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:17:01 --> Controller Class Initialized
INFO - 2020-10-05 17:17:01 --> Model "Main_model" initialized
INFO - 2020-10-05 17:17:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:17:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-10-05 17:17:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\dmarc\application\views\domainscanner.php 152
INFO - 2020-10-05 17:17:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:17:02 --> Final output sent to browser
DEBUG - 2020-10-05 17:17:02 --> Total execution time: 1.6759
INFO - 2020-10-05 17:18:28 --> Config Class Initialized
INFO - 2020-10-05 17:18:28 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:18:28 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:18:28 --> Utf8 Class Initialized
INFO - 2020-10-05 17:18:28 --> URI Class Initialized
INFO - 2020-10-05 17:18:28 --> Router Class Initialized
INFO - 2020-10-05 17:18:28 --> Output Class Initialized
INFO - 2020-10-05 17:18:28 --> Security Class Initialized
DEBUG - 2020-10-05 17:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:18:28 --> Input Class Initialized
INFO - 2020-10-05 17:18:28 --> Language Class Initialized
INFO - 2020-10-05 17:18:28 --> Loader Class Initialized
INFO - 2020-10-05 17:18:28 --> Helper loaded: url_helper
INFO - 2020-10-05 17:18:28 --> Helper loaded: file_helper
INFO - 2020-10-05 17:18:28 --> Database Driver Class Initialized
INFO - 2020-10-05 17:18:28 --> Email Class Initialized
DEBUG - 2020-10-05 17:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:18:28 --> Controller Class Initialized
INFO - 2020-10-05 17:18:28 --> Model "Main_model" initialized
INFO - 2020-10-05 17:18:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:18:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 17:18:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-10-05 17:18:28 --> Final output sent to browser
DEBUG - 2020-10-05 17:18:28 --> Total execution time: 0.5588
INFO - 2020-10-05 17:18:33 --> Config Class Initialized
INFO - 2020-10-05 17:18:33 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:18:33 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:18:33 --> Utf8 Class Initialized
INFO - 2020-10-05 17:18:33 --> URI Class Initialized
INFO - 2020-10-05 17:18:33 --> Router Class Initialized
INFO - 2020-10-05 17:18:33 --> Output Class Initialized
INFO - 2020-10-05 17:18:33 --> Security Class Initialized
DEBUG - 2020-10-05 17:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:18:33 --> Input Class Initialized
INFO - 2020-10-05 17:18:33 --> Language Class Initialized
INFO - 2020-10-05 17:18:33 --> Loader Class Initialized
INFO - 2020-10-05 17:18:33 --> Helper loaded: url_helper
INFO - 2020-10-05 17:18:33 --> Helper loaded: file_helper
INFO - 2020-10-05 17:18:33 --> Database Driver Class Initialized
INFO - 2020-10-05 17:18:33 --> Email Class Initialized
DEBUG - 2020-10-05 17:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:18:33 --> Controller Class Initialized
INFO - 2020-10-05 17:18:33 --> Model "Main_model" initialized
INFO - 2020-10-05 17:18:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:18:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 17:18:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:18:33 --> Final output sent to browser
DEBUG - 2020-10-05 17:18:33 --> Total execution time: 0.4879
INFO - 2020-10-05 17:18:36 --> Config Class Initialized
INFO - 2020-10-05 17:18:36 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:18:36 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:18:36 --> Utf8 Class Initialized
INFO - 2020-10-05 17:18:36 --> URI Class Initialized
INFO - 2020-10-05 17:18:36 --> Router Class Initialized
INFO - 2020-10-05 17:18:36 --> Output Class Initialized
INFO - 2020-10-05 17:18:36 --> Security Class Initialized
DEBUG - 2020-10-05 17:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:18:36 --> Input Class Initialized
INFO - 2020-10-05 17:18:36 --> Language Class Initialized
INFO - 2020-10-05 17:18:36 --> Loader Class Initialized
INFO - 2020-10-05 17:18:36 --> Helper loaded: url_helper
INFO - 2020-10-05 17:18:36 --> Helper loaded: file_helper
INFO - 2020-10-05 17:18:36 --> Database Driver Class Initialized
INFO - 2020-10-05 17:18:36 --> Email Class Initialized
DEBUG - 2020-10-05 17:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:18:36 --> Controller Class Initialized
INFO - 2020-10-05 17:18:37 --> Model "Main_model" initialized
INFO - 2020-10-05 17:18:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:18:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-10-05 17:18:37 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\dmarc\application\views\domainscanner.php 152
INFO - 2020-10-05 17:18:37 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:18:37 --> Final output sent to browser
DEBUG - 2020-10-05 17:18:37 --> Total execution time: 0.7187
INFO - 2020-10-05 17:19:24 --> Config Class Initialized
INFO - 2020-10-05 17:19:24 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:19:24 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:19:24 --> Utf8 Class Initialized
INFO - 2020-10-05 17:19:24 --> URI Class Initialized
INFO - 2020-10-05 17:19:24 --> Router Class Initialized
INFO - 2020-10-05 17:19:24 --> Output Class Initialized
INFO - 2020-10-05 17:19:24 --> Security Class Initialized
DEBUG - 2020-10-05 17:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:19:24 --> Input Class Initialized
INFO - 2020-10-05 17:19:24 --> Language Class Initialized
INFO - 2020-10-05 17:19:24 --> Loader Class Initialized
INFO - 2020-10-05 17:19:24 --> Helper loaded: url_helper
INFO - 2020-10-05 17:19:24 --> Helper loaded: file_helper
INFO - 2020-10-05 17:19:24 --> Database Driver Class Initialized
INFO - 2020-10-05 17:19:24 --> Email Class Initialized
DEBUG - 2020-10-05 17:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:19:24 --> Controller Class Initialized
INFO - 2020-10-05 17:19:24 --> Model "Main_model" initialized
INFO - 2020-10-05 17:19:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:19:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
ERROR - 2020-10-05 17:19:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\dmarc\application\views\domainscanner.php 153
INFO - 2020-10-05 17:19:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:19:25 --> Final output sent to browser
DEBUG - 2020-10-05 17:19:25 --> Total execution time: 0.5621
INFO - 2020-10-05 17:19:58 --> Config Class Initialized
INFO - 2020-10-05 17:19:58 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:19:58 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:19:58 --> Utf8 Class Initialized
INFO - 2020-10-05 17:19:58 --> URI Class Initialized
INFO - 2020-10-05 17:19:58 --> Router Class Initialized
INFO - 2020-10-05 17:19:58 --> Output Class Initialized
INFO - 2020-10-05 17:19:58 --> Security Class Initialized
DEBUG - 2020-10-05 17:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:19:58 --> Input Class Initialized
INFO - 2020-10-05 17:19:58 --> Language Class Initialized
INFO - 2020-10-05 17:19:58 --> Loader Class Initialized
INFO - 2020-10-05 17:19:58 --> Helper loaded: url_helper
INFO - 2020-10-05 17:19:58 --> Helper loaded: file_helper
INFO - 2020-10-05 17:19:59 --> Database Driver Class Initialized
INFO - 2020-10-05 17:19:59 --> Email Class Initialized
DEBUG - 2020-10-05 17:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:19:59 --> Controller Class Initialized
INFO - 2020-10-05 17:19:59 --> Model "Main_model" initialized
INFO - 2020-10-05 17:19:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:19:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 17:19:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:19:59 --> Final output sent to browser
DEBUG - 2020-10-05 17:19:59 --> Total execution time: 0.5644
INFO - 2020-10-05 17:20:07 --> Config Class Initialized
INFO - 2020-10-05 17:20:07 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:20:07 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:20:07 --> Utf8 Class Initialized
INFO - 2020-10-05 17:20:07 --> URI Class Initialized
INFO - 2020-10-05 17:20:07 --> Router Class Initialized
INFO - 2020-10-05 17:20:07 --> Output Class Initialized
INFO - 2020-10-05 17:20:07 --> Security Class Initialized
DEBUG - 2020-10-05 17:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:20:07 --> Input Class Initialized
INFO - 2020-10-05 17:20:07 --> Language Class Initialized
INFO - 2020-10-05 17:20:07 --> Loader Class Initialized
INFO - 2020-10-05 17:20:07 --> Helper loaded: url_helper
INFO - 2020-10-05 17:20:07 --> Helper loaded: file_helper
INFO - 2020-10-05 17:20:07 --> Database Driver Class Initialized
INFO - 2020-10-05 17:20:07 --> Email Class Initialized
DEBUG - 2020-10-05 17:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:20:07 --> Controller Class Initialized
INFO - 2020-10-05 17:20:07 --> Model "Main_model" initialized
INFO - 2020-10-05 17:20:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:20:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 17:20:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:20:07 --> Final output sent to browser
DEBUG - 2020-10-05 17:20:07 --> Total execution time: 0.5471
INFO - 2020-10-05 17:20:14 --> Config Class Initialized
INFO - 2020-10-05 17:20:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:20:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:20:14 --> Utf8 Class Initialized
INFO - 2020-10-05 17:20:14 --> URI Class Initialized
INFO - 2020-10-05 17:20:14 --> Router Class Initialized
INFO - 2020-10-05 17:20:14 --> Output Class Initialized
INFO - 2020-10-05 17:20:14 --> Security Class Initialized
DEBUG - 2020-10-05 17:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:20:14 --> Input Class Initialized
INFO - 2020-10-05 17:20:14 --> Language Class Initialized
INFO - 2020-10-05 17:20:14 --> Loader Class Initialized
INFO - 2020-10-05 17:20:14 --> Helper loaded: url_helper
INFO - 2020-10-05 17:20:14 --> Helper loaded: file_helper
INFO - 2020-10-05 17:20:14 --> Database Driver Class Initialized
INFO - 2020-10-05 17:20:14 --> Email Class Initialized
DEBUG - 2020-10-05 17:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-05 17:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:20:15 --> Controller Class Initialized
INFO - 2020-10-05 17:20:15 --> Model "Main_model" initialized
INFO - 2020-10-05 17:20:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-05 17:20:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-05 17:20:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\domainscanner.php
INFO - 2020-10-05 17:20:15 --> Final output sent to browser
DEBUG - 2020-10-05 17:20:15 --> Total execution time: 0.7081
