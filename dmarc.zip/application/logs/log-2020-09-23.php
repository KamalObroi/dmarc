<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-23 09:05:31 --> Config Class Initialized
INFO - 2020-09-23 09:05:31 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:05:31 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:05:31 --> Utf8 Class Initialized
INFO - 2020-09-23 09:05:31 --> URI Class Initialized
INFO - 2020-09-23 09:05:31 --> Router Class Initialized
INFO - 2020-09-23 09:05:31 --> Output Class Initialized
INFO - 2020-09-23 09:05:31 --> Security Class Initialized
DEBUG - 2020-09-23 09:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:05:31 --> Input Class Initialized
INFO - 2020-09-23 09:05:31 --> Language Class Initialized
INFO - 2020-09-23 09:05:31 --> Loader Class Initialized
INFO - 2020-09-23 09:05:31 --> Helper loaded: url_helper
INFO - 2020-09-23 09:05:31 --> Helper loaded: file_helper
INFO - 2020-09-23 09:05:31 --> Database Driver Class Initialized
INFO - 2020-09-23 09:05:31 --> Email Class Initialized
DEBUG - 2020-09-23 09:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:05:31 --> Controller Class Initialized
INFO - 2020-09-23 09:05:31 --> Model "Main_model" initialized
INFO - 2020-09-23 09:05:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:05:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:05:31 --> Final output sent to browser
DEBUG - 2020-09-23 09:05:31 --> Total execution time: 0.2958
INFO - 2020-09-23 09:05:33 --> Config Class Initialized
INFO - 2020-09-23 09:05:33 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:05:33 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:05:33 --> Utf8 Class Initialized
INFO - 2020-09-23 09:05:33 --> URI Class Initialized
INFO - 2020-09-23 09:05:33 --> Router Class Initialized
INFO - 2020-09-23 09:05:33 --> Output Class Initialized
INFO - 2020-09-23 09:05:33 --> Security Class Initialized
DEBUG - 2020-09-23 09:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:05:33 --> Input Class Initialized
INFO - 2020-09-23 09:05:33 --> Language Class Initialized
INFO - 2020-09-23 09:05:33 --> Loader Class Initialized
INFO - 2020-09-23 09:05:33 --> Helper loaded: url_helper
INFO - 2020-09-23 09:05:33 --> Helper loaded: file_helper
INFO - 2020-09-23 09:05:33 --> Database Driver Class Initialized
INFO - 2020-09-23 09:05:33 --> Email Class Initialized
DEBUG - 2020-09-23 09:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:05:33 --> Controller Class Initialized
INFO - 2020-09-23 09:05:33 --> Model "Main_model" initialized
INFO - 2020-09-23 09:05:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:05:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:05:33 --> Final output sent to browser
DEBUG - 2020-09-23 09:05:33 --> Total execution time: 0.3199
INFO - 2020-09-23 09:05:34 --> Config Class Initialized
INFO - 2020-09-23 09:05:35 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:05:35 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:05:35 --> Utf8 Class Initialized
INFO - 2020-09-23 09:05:35 --> URI Class Initialized
INFO - 2020-09-23 09:05:35 --> Router Class Initialized
INFO - 2020-09-23 09:05:35 --> Output Class Initialized
INFO - 2020-09-23 09:05:35 --> Security Class Initialized
DEBUG - 2020-09-23 09:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:05:35 --> Input Class Initialized
INFO - 2020-09-23 09:05:35 --> Language Class Initialized
INFO - 2020-09-23 09:05:35 --> Loader Class Initialized
INFO - 2020-09-23 09:05:35 --> Helper loaded: url_helper
INFO - 2020-09-23 09:05:35 --> Helper loaded: file_helper
INFO - 2020-09-23 09:05:35 --> Database Driver Class Initialized
INFO - 2020-09-23 09:05:35 --> Email Class Initialized
DEBUG - 2020-09-23 09:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:05:35 --> Controller Class Initialized
INFO - 2020-09-23 09:05:35 --> Model "Main_model" initialized
INFO - 2020-09-23 09:05:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:05:35 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:05:35 --> Final output sent to browser
DEBUG - 2020-09-23 09:05:35 --> Total execution time: 0.3103
INFO - 2020-09-23 09:05:36 --> Config Class Initialized
INFO - 2020-09-23 09:05:36 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:05:36 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:05:36 --> Utf8 Class Initialized
INFO - 2020-09-23 09:05:36 --> URI Class Initialized
INFO - 2020-09-23 09:05:36 --> Router Class Initialized
INFO - 2020-09-23 09:05:36 --> Output Class Initialized
INFO - 2020-09-23 09:05:36 --> Security Class Initialized
DEBUG - 2020-09-23 09:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:05:36 --> Input Class Initialized
INFO - 2020-09-23 09:05:36 --> Language Class Initialized
INFO - 2020-09-23 09:05:36 --> Loader Class Initialized
INFO - 2020-09-23 09:05:36 --> Helper loaded: url_helper
INFO - 2020-09-23 09:05:36 --> Helper loaded: file_helper
INFO - 2020-09-23 09:05:36 --> Database Driver Class Initialized
INFO - 2020-09-23 09:05:36 --> Email Class Initialized
DEBUG - 2020-09-23 09:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:05:36 --> Controller Class Initialized
INFO - 2020-09-23 09:05:36 --> Model "Main_model" initialized
INFO - 2020-09-23 09:05:36 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:05:36 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:05:36 --> Final output sent to browser
DEBUG - 2020-09-23 09:05:36 --> Total execution time: 0.3193
INFO - 2020-09-23 09:05:40 --> Config Class Initialized
INFO - 2020-09-23 09:05:40 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:05:40 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:05:40 --> Utf8 Class Initialized
INFO - 2020-09-23 09:05:40 --> URI Class Initialized
DEBUG - 2020-09-23 09:05:40 --> No URI present. Default controller set.
INFO - 2020-09-23 09:05:40 --> Router Class Initialized
INFO - 2020-09-23 09:05:40 --> Output Class Initialized
INFO - 2020-09-23 09:05:40 --> Security Class Initialized
DEBUG - 2020-09-23 09:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:05:40 --> Input Class Initialized
INFO - 2020-09-23 09:05:40 --> Language Class Initialized
INFO - 2020-09-23 09:05:40 --> Loader Class Initialized
INFO - 2020-09-23 09:05:40 --> Helper loaded: url_helper
INFO - 2020-09-23 09:05:40 --> Helper loaded: file_helper
INFO - 2020-09-23 09:05:40 --> Database Driver Class Initialized
INFO - 2020-09-23 09:05:40 --> Email Class Initialized
DEBUG - 2020-09-23 09:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:05:41 --> Controller Class Initialized
INFO - 2020-09-23 09:05:41 --> Model "Main_model" initialized
INFO - 2020-09-23 09:05:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-23 09:05:41 --> Final output sent to browser
DEBUG - 2020-09-23 09:05:41 --> Total execution time: 0.3227
INFO - 2020-09-23 09:05:44 --> Config Class Initialized
INFO - 2020-09-23 09:05:44 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:05:44 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:05:44 --> Utf8 Class Initialized
INFO - 2020-09-23 09:05:44 --> URI Class Initialized
INFO - 2020-09-23 09:05:44 --> Router Class Initialized
INFO - 2020-09-23 09:05:44 --> Output Class Initialized
INFO - 2020-09-23 09:05:44 --> Security Class Initialized
DEBUG - 2020-09-23 09:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:05:44 --> Input Class Initialized
INFO - 2020-09-23 09:05:44 --> Language Class Initialized
INFO - 2020-09-23 09:05:44 --> Loader Class Initialized
INFO - 2020-09-23 09:05:44 --> Helper loaded: url_helper
INFO - 2020-09-23 09:05:44 --> Helper loaded: file_helper
INFO - 2020-09-23 09:05:44 --> Database Driver Class Initialized
INFO - 2020-09-23 09:05:44 --> Email Class Initialized
DEBUG - 2020-09-23 09:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:05:44 --> Controller Class Initialized
INFO - 2020-09-23 09:05:44 --> Model "Main_model" initialized
INFO - 2020-09-23 09:05:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-09-23 09:05:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-09-23 09:05:44 --> Final output sent to browser
DEBUG - 2020-09-23 09:05:44 --> Total execution time: 0.3473
INFO - 2020-09-23 09:05:47 --> Config Class Initialized
INFO - 2020-09-23 09:05:47 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:05:47 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:05:47 --> Utf8 Class Initialized
INFO - 2020-09-23 09:05:47 --> URI Class Initialized
INFO - 2020-09-23 09:05:47 --> Router Class Initialized
INFO - 2020-09-23 09:05:47 --> Output Class Initialized
INFO - 2020-09-23 09:05:47 --> Security Class Initialized
DEBUG - 2020-09-23 09:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:05:47 --> Input Class Initialized
INFO - 2020-09-23 09:05:47 --> Language Class Initialized
INFO - 2020-09-23 09:05:47 --> Loader Class Initialized
INFO - 2020-09-23 09:05:47 --> Helper loaded: url_helper
INFO - 2020-09-23 09:05:47 --> Helper loaded: file_helper
INFO - 2020-09-23 09:05:47 --> Database Driver Class Initialized
INFO - 2020-09-23 09:05:47 --> Email Class Initialized
DEBUG - 2020-09-23 09:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:05:47 --> Controller Class Initialized
INFO - 2020-09-23 09:05:48 --> Model "Main_model" initialized
INFO - 2020-09-23 09:05:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:05:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:05:48 --> Final output sent to browser
DEBUG - 2020-09-23 09:05:48 --> Total execution time: 0.3319
INFO - 2020-09-23 09:06:39 --> Config Class Initialized
INFO - 2020-09-23 09:06:39 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:06:39 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:06:39 --> Utf8 Class Initialized
INFO - 2020-09-23 09:06:39 --> URI Class Initialized
INFO - 2020-09-23 09:06:39 --> Router Class Initialized
INFO - 2020-09-23 09:06:39 --> Output Class Initialized
INFO - 2020-09-23 09:06:39 --> Security Class Initialized
DEBUG - 2020-09-23 09:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:06:39 --> Input Class Initialized
INFO - 2020-09-23 09:06:39 --> Language Class Initialized
INFO - 2020-09-23 09:06:39 --> Loader Class Initialized
INFO - 2020-09-23 09:06:39 --> Helper loaded: url_helper
INFO - 2020-09-23 09:06:39 --> Helper loaded: file_helper
INFO - 2020-09-23 09:06:39 --> Database Driver Class Initialized
INFO - 2020-09-23 09:06:39 --> Email Class Initialized
DEBUG - 2020-09-23 09:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:06:39 --> Controller Class Initialized
INFO - 2020-09-23 09:06:39 --> Model "Main_model" initialized
INFO - 2020-09-23 09:06:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:06:39 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:06:39 --> Final output sent to browser
DEBUG - 2020-09-23 09:06:39 --> Total execution time: 0.3292
INFO - 2020-09-23 09:06:40 --> Config Class Initialized
INFO - 2020-09-23 09:06:40 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:06:41 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:06:41 --> Utf8 Class Initialized
INFO - 2020-09-23 09:06:41 --> URI Class Initialized
INFO - 2020-09-23 09:06:41 --> Router Class Initialized
INFO - 2020-09-23 09:06:41 --> Output Class Initialized
INFO - 2020-09-23 09:06:41 --> Security Class Initialized
DEBUG - 2020-09-23 09:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:06:41 --> Input Class Initialized
INFO - 2020-09-23 09:06:41 --> Language Class Initialized
INFO - 2020-09-23 09:06:41 --> Loader Class Initialized
INFO - 2020-09-23 09:06:41 --> Helper loaded: url_helper
INFO - 2020-09-23 09:06:41 --> Helper loaded: file_helper
INFO - 2020-09-23 09:06:41 --> Database Driver Class Initialized
INFO - 2020-09-23 09:06:41 --> Email Class Initialized
DEBUG - 2020-09-23 09:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:06:41 --> Controller Class Initialized
INFO - 2020-09-23 09:06:41 --> Model "Main_model" initialized
INFO - 2020-09-23 09:06:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:06:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:06:41 --> Final output sent to browser
DEBUG - 2020-09-23 09:06:41 --> Total execution time: 0.3725
INFO - 2020-09-23 09:06:55 --> Config Class Initialized
INFO - 2020-09-23 09:06:55 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:06:55 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:06:55 --> Utf8 Class Initialized
INFO - 2020-09-23 09:06:55 --> URI Class Initialized
INFO - 2020-09-23 09:06:55 --> Router Class Initialized
INFO - 2020-09-23 09:06:55 --> Output Class Initialized
INFO - 2020-09-23 09:06:55 --> Security Class Initialized
DEBUG - 2020-09-23 09:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:06:55 --> Input Class Initialized
INFO - 2020-09-23 09:06:55 --> Language Class Initialized
INFO - 2020-09-23 09:06:55 --> Loader Class Initialized
INFO - 2020-09-23 09:06:55 --> Helper loaded: url_helper
INFO - 2020-09-23 09:06:55 --> Helper loaded: file_helper
INFO - 2020-09-23 09:06:55 --> Database Driver Class Initialized
INFO - 2020-09-23 09:06:55 --> Email Class Initialized
DEBUG - 2020-09-23 09:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:06:55 --> Controller Class Initialized
INFO - 2020-09-23 09:06:55 --> Model "Main_model" initialized
INFO - 2020-09-23 09:06:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:06:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:06:55 --> Final output sent to browser
DEBUG - 2020-09-23 09:06:55 --> Total execution time: 0.3604
INFO - 2020-09-23 09:06:56 --> Config Class Initialized
INFO - 2020-09-23 09:06:56 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:06:56 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:06:56 --> Utf8 Class Initialized
INFO - 2020-09-23 09:06:56 --> URI Class Initialized
INFO - 2020-09-23 09:06:56 --> Router Class Initialized
INFO - 2020-09-23 09:06:56 --> Output Class Initialized
INFO - 2020-09-23 09:06:56 --> Security Class Initialized
DEBUG - 2020-09-23 09:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:06:56 --> Input Class Initialized
INFO - 2020-09-23 09:06:56 --> Language Class Initialized
INFO - 2020-09-23 09:06:56 --> Loader Class Initialized
INFO - 2020-09-23 09:06:56 --> Helper loaded: url_helper
INFO - 2020-09-23 09:06:56 --> Helper loaded: file_helper
INFO - 2020-09-23 09:06:56 --> Database Driver Class Initialized
INFO - 2020-09-23 09:06:56 --> Email Class Initialized
DEBUG - 2020-09-23 09:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:06:56 --> Controller Class Initialized
INFO - 2020-09-23 09:06:56 --> Model "Main_model" initialized
INFO - 2020-09-23 09:06:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-09-23 09:06:56 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-09-23 09:06:56 --> Final output sent to browser
DEBUG - 2020-09-23 09:06:56 --> Total execution time: 0.3272
INFO - 2020-09-23 09:07:00 --> Config Class Initialized
INFO - 2020-09-23 09:07:00 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:07:00 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:07:00 --> Utf8 Class Initialized
INFO - 2020-09-23 09:07:00 --> URI Class Initialized
INFO - 2020-09-23 09:07:00 --> Router Class Initialized
INFO - 2020-09-23 09:07:00 --> Output Class Initialized
INFO - 2020-09-23 09:07:00 --> Security Class Initialized
DEBUG - 2020-09-23 09:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:07:00 --> Input Class Initialized
INFO - 2020-09-23 09:07:00 --> Language Class Initialized
INFO - 2020-09-23 09:07:00 --> Loader Class Initialized
INFO - 2020-09-23 09:07:00 --> Helper loaded: url_helper
INFO - 2020-09-23 09:07:00 --> Helper loaded: file_helper
INFO - 2020-09-23 09:07:00 --> Database Driver Class Initialized
INFO - 2020-09-23 09:07:00 --> Email Class Initialized
DEBUG - 2020-09-23 09:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:07:00 --> Controller Class Initialized
INFO - 2020-09-23 09:07:00 --> Model "Main_model" initialized
INFO - 2020-09-23 09:07:00 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:07:00 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:07:00 --> Final output sent to browser
DEBUG - 2020-09-23 09:07:00 --> Total execution time: 0.3382
INFO - 2020-09-23 09:07:02 --> Config Class Initialized
INFO - 2020-09-23 09:07:02 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:07:02 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:07:02 --> Utf8 Class Initialized
INFO - 2020-09-23 09:07:02 --> URI Class Initialized
INFO - 2020-09-23 09:07:02 --> Router Class Initialized
INFO - 2020-09-23 09:07:02 --> Output Class Initialized
INFO - 2020-09-23 09:07:02 --> Security Class Initialized
DEBUG - 2020-09-23 09:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:07:02 --> Input Class Initialized
INFO - 2020-09-23 09:07:02 --> Language Class Initialized
INFO - 2020-09-23 09:07:03 --> Loader Class Initialized
INFO - 2020-09-23 09:07:03 --> Helper loaded: url_helper
INFO - 2020-09-23 09:07:03 --> Helper loaded: file_helper
INFO - 2020-09-23 09:07:03 --> Database Driver Class Initialized
INFO - 2020-09-23 09:07:03 --> Email Class Initialized
DEBUG - 2020-09-23 09:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:07:03 --> Controller Class Initialized
INFO - 2020-09-23 09:07:03 --> Model "Main_model" initialized
INFO - 2020-09-23 09:07:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:07:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:07:03 --> Final output sent to browser
DEBUG - 2020-09-23 09:07:03 --> Total execution time: 0.3829
INFO - 2020-09-23 09:07:26 --> Config Class Initialized
INFO - 2020-09-23 09:07:26 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:07:26 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:07:26 --> Utf8 Class Initialized
INFO - 2020-09-23 09:07:26 --> URI Class Initialized
INFO - 2020-09-23 09:07:26 --> Router Class Initialized
INFO - 2020-09-23 09:07:26 --> Output Class Initialized
INFO - 2020-09-23 09:07:26 --> Security Class Initialized
DEBUG - 2020-09-23 09:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:07:26 --> Input Class Initialized
INFO - 2020-09-23 09:07:26 --> Language Class Initialized
INFO - 2020-09-23 09:07:26 --> Loader Class Initialized
INFO - 2020-09-23 09:07:26 --> Helper loaded: url_helper
INFO - 2020-09-23 09:07:26 --> Helper loaded: file_helper
INFO - 2020-09-23 09:07:26 --> Database Driver Class Initialized
INFO - 2020-09-23 09:07:26 --> Email Class Initialized
DEBUG - 2020-09-23 09:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:07:26 --> Controller Class Initialized
INFO - 2020-09-23 09:07:26 --> Model "Main_model" initialized
INFO - 2020-09-23 09:07:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:07:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:07:26 --> Final output sent to browser
DEBUG - 2020-09-23 09:07:26 --> Total execution time: 0.3603
INFO - 2020-09-23 09:07:33 --> Config Class Initialized
INFO - 2020-09-23 09:07:33 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:07:33 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:07:33 --> Utf8 Class Initialized
INFO - 2020-09-23 09:07:33 --> URI Class Initialized
INFO - 2020-09-23 09:07:33 --> Router Class Initialized
INFO - 2020-09-23 09:07:33 --> Output Class Initialized
INFO - 2020-09-23 09:07:33 --> Security Class Initialized
DEBUG - 2020-09-23 09:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:07:33 --> Input Class Initialized
INFO - 2020-09-23 09:07:33 --> Language Class Initialized
INFO - 2020-09-23 09:07:33 --> Loader Class Initialized
INFO - 2020-09-23 09:07:33 --> Helper loaded: url_helper
INFO - 2020-09-23 09:07:33 --> Helper loaded: file_helper
INFO - 2020-09-23 09:07:33 --> Database Driver Class Initialized
INFO - 2020-09-23 09:07:33 --> Email Class Initialized
DEBUG - 2020-09-23 09:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:07:33 --> Controller Class Initialized
INFO - 2020-09-23 09:07:33 --> Model "Main_model" initialized
INFO - 2020-09-23 09:07:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:07:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:07:33 --> Final output sent to browser
DEBUG - 2020-09-23 09:07:33 --> Total execution time: 0.4058
INFO - 2020-09-23 09:07:43 --> Config Class Initialized
INFO - 2020-09-23 09:07:43 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:07:44 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:07:44 --> Utf8 Class Initialized
INFO - 2020-09-23 09:07:44 --> URI Class Initialized
INFO - 2020-09-23 09:07:44 --> Router Class Initialized
INFO - 2020-09-23 09:07:44 --> Output Class Initialized
INFO - 2020-09-23 09:07:44 --> Security Class Initialized
DEBUG - 2020-09-23 09:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:07:44 --> Input Class Initialized
INFO - 2020-09-23 09:07:44 --> Language Class Initialized
INFO - 2020-09-23 09:07:44 --> Loader Class Initialized
INFO - 2020-09-23 09:07:44 --> Helper loaded: url_helper
INFO - 2020-09-23 09:07:44 --> Helper loaded: file_helper
INFO - 2020-09-23 09:07:44 --> Database Driver Class Initialized
INFO - 2020-09-23 09:07:44 --> Email Class Initialized
DEBUG - 2020-09-23 09:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:07:44 --> Controller Class Initialized
INFO - 2020-09-23 09:07:44 --> Model "Main_model" initialized
INFO - 2020-09-23 09:07:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:07:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:07:44 --> Final output sent to browser
DEBUG - 2020-09-23 09:07:44 --> Total execution time: 0.3756
INFO - 2020-09-23 09:07:47 --> Config Class Initialized
INFO - 2020-09-23 09:07:47 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:07:47 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:07:47 --> Utf8 Class Initialized
INFO - 2020-09-23 09:07:47 --> URI Class Initialized
INFO - 2020-09-23 09:07:47 --> Router Class Initialized
INFO - 2020-09-23 09:07:47 --> Output Class Initialized
INFO - 2020-09-23 09:07:47 --> Security Class Initialized
DEBUG - 2020-09-23 09:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:07:48 --> Input Class Initialized
INFO - 2020-09-23 09:07:48 --> Language Class Initialized
INFO - 2020-09-23 09:07:48 --> Loader Class Initialized
INFO - 2020-09-23 09:07:48 --> Helper loaded: url_helper
INFO - 2020-09-23 09:07:48 --> Helper loaded: file_helper
INFO - 2020-09-23 09:07:48 --> Database Driver Class Initialized
INFO - 2020-09-23 09:07:48 --> Email Class Initialized
DEBUG - 2020-09-23 09:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:07:48 --> Controller Class Initialized
INFO - 2020-09-23 09:07:48 --> Model "Main_model" initialized
INFO - 2020-09-23 09:07:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:07:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:07:48 --> Final output sent to browser
DEBUG - 2020-09-23 09:07:48 --> Total execution time: 0.3981
INFO - 2020-09-23 09:08:45 --> Config Class Initialized
INFO - 2020-09-23 09:08:45 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:08:45 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:08:45 --> Utf8 Class Initialized
INFO - 2020-09-23 09:08:45 --> URI Class Initialized
INFO - 2020-09-23 09:08:45 --> Router Class Initialized
INFO - 2020-09-23 09:08:45 --> Output Class Initialized
INFO - 2020-09-23 09:08:45 --> Security Class Initialized
DEBUG - 2020-09-23 09:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:08:45 --> Input Class Initialized
INFO - 2020-09-23 09:08:45 --> Language Class Initialized
INFO - 2020-09-23 09:08:45 --> Loader Class Initialized
INFO - 2020-09-23 09:08:45 --> Helper loaded: url_helper
INFO - 2020-09-23 09:08:45 --> Helper loaded: file_helper
INFO - 2020-09-23 09:08:45 --> Database Driver Class Initialized
INFO - 2020-09-23 09:08:45 --> Email Class Initialized
DEBUG - 2020-09-23 09:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:08:45 --> Controller Class Initialized
INFO - 2020-09-23 09:08:45 --> Model "Main_model" initialized
INFO - 2020-09-23 09:08:45 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:08:45 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:08:45 --> Final output sent to browser
DEBUG - 2020-09-23 09:08:45 --> Total execution time: 0.3499
INFO - 2020-09-23 09:08:48 --> Config Class Initialized
INFO - 2020-09-23 09:08:48 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:08:48 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:08:48 --> Utf8 Class Initialized
INFO - 2020-09-23 09:08:48 --> URI Class Initialized
INFO - 2020-09-23 09:08:48 --> Router Class Initialized
INFO - 2020-09-23 09:08:48 --> Output Class Initialized
INFO - 2020-09-23 09:08:48 --> Security Class Initialized
DEBUG - 2020-09-23 09:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:08:48 --> Input Class Initialized
INFO - 2020-09-23 09:08:48 --> Language Class Initialized
INFO - 2020-09-23 09:08:48 --> Loader Class Initialized
INFO - 2020-09-23 09:08:48 --> Helper loaded: url_helper
INFO - 2020-09-23 09:08:48 --> Helper loaded: file_helper
INFO - 2020-09-23 09:08:48 --> Database Driver Class Initialized
INFO - 2020-09-23 09:08:48 --> Email Class Initialized
DEBUG - 2020-09-23 09:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:08:48 --> Controller Class Initialized
INFO - 2020-09-23 09:08:48 --> Model "Main_model" initialized
INFO - 2020-09-23 09:08:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:08:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:08:48 --> Final output sent to browser
DEBUG - 2020-09-23 09:08:48 --> Total execution time: 0.3366
INFO - 2020-09-23 09:08:59 --> Config Class Initialized
INFO - 2020-09-23 09:08:59 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:08:59 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:08:59 --> Utf8 Class Initialized
INFO - 2020-09-23 09:08:59 --> URI Class Initialized
INFO - 2020-09-23 09:08:59 --> Router Class Initialized
INFO - 2020-09-23 09:08:59 --> Output Class Initialized
INFO - 2020-09-23 09:08:59 --> Security Class Initialized
DEBUG - 2020-09-23 09:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:08:59 --> Input Class Initialized
INFO - 2020-09-23 09:08:59 --> Language Class Initialized
ERROR - 2020-09-23 09:08:59 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:14:38 --> Config Class Initialized
INFO - 2020-09-23 09:14:38 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:14:38 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:14:38 --> Utf8 Class Initialized
INFO - 2020-09-23 09:14:38 --> URI Class Initialized
INFO - 2020-09-23 09:14:38 --> Router Class Initialized
INFO - 2020-09-23 09:14:38 --> Output Class Initialized
INFO - 2020-09-23 09:14:38 --> Security Class Initialized
DEBUG - 2020-09-23 09:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:14:38 --> Input Class Initialized
INFO - 2020-09-23 09:14:38 --> Language Class Initialized
INFO - 2020-09-23 09:14:38 --> Loader Class Initialized
INFO - 2020-09-23 09:14:38 --> Helper loaded: url_helper
INFO - 2020-09-23 09:14:38 --> Helper loaded: file_helper
INFO - 2020-09-23 09:14:38 --> Database Driver Class Initialized
INFO - 2020-09-23 09:14:38 --> Email Class Initialized
DEBUG - 2020-09-23 09:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:14:38 --> Controller Class Initialized
INFO - 2020-09-23 09:14:38 --> Model "Main_model" initialized
INFO - 2020-09-23 09:14:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:14:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:14:38 --> Final output sent to browser
DEBUG - 2020-09-23 09:14:38 --> Total execution time: 0.4702
INFO - 2020-09-23 09:14:45 --> Config Class Initialized
INFO - 2020-09-23 09:14:45 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:14:45 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:14:45 --> Utf8 Class Initialized
INFO - 2020-09-23 09:14:45 --> URI Class Initialized
INFO - 2020-09-23 09:14:45 --> Router Class Initialized
INFO - 2020-09-23 09:14:45 --> Output Class Initialized
INFO - 2020-09-23 09:14:45 --> Security Class Initialized
DEBUG - 2020-09-23 09:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:14:45 --> Input Class Initialized
INFO - 2020-09-23 09:14:45 --> Language Class Initialized
ERROR - 2020-09-23 09:14:45 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:17:33 --> Config Class Initialized
INFO - 2020-09-23 09:17:33 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:17:33 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:17:33 --> Utf8 Class Initialized
INFO - 2020-09-23 09:17:33 --> URI Class Initialized
INFO - 2020-09-23 09:17:33 --> Router Class Initialized
INFO - 2020-09-23 09:17:33 --> Output Class Initialized
INFO - 2020-09-23 09:17:33 --> Security Class Initialized
DEBUG - 2020-09-23 09:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:17:33 --> Input Class Initialized
INFO - 2020-09-23 09:17:33 --> Language Class Initialized
INFO - 2020-09-23 09:17:33 --> Loader Class Initialized
INFO - 2020-09-23 09:17:33 --> Helper loaded: url_helper
INFO - 2020-09-23 09:17:33 --> Helper loaded: file_helper
INFO - 2020-09-23 09:17:33 --> Database Driver Class Initialized
INFO - 2020-09-23 09:17:33 --> Email Class Initialized
DEBUG - 2020-09-23 09:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:17:33 --> Controller Class Initialized
INFO - 2020-09-23 09:17:33 --> Model "Main_model" initialized
INFO - 2020-09-23 09:17:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:17:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:17:33 --> Final output sent to browser
DEBUG - 2020-09-23 09:17:33 --> Total execution time: 0.3648
INFO - 2020-09-23 09:17:34 --> Config Class Initialized
INFO - 2020-09-23 09:17:34 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:17:34 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:17:34 --> Utf8 Class Initialized
INFO - 2020-09-23 09:17:34 --> URI Class Initialized
INFO - 2020-09-23 09:17:34 --> Router Class Initialized
INFO - 2020-09-23 09:17:34 --> Output Class Initialized
INFO - 2020-09-23 09:17:34 --> Security Class Initialized
DEBUG - 2020-09-23 09:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:17:34 --> Input Class Initialized
INFO - 2020-09-23 09:17:34 --> Language Class Initialized
ERROR - 2020-09-23 09:17:34 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:17:38 --> Config Class Initialized
INFO - 2020-09-23 09:17:38 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:17:38 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:17:38 --> Utf8 Class Initialized
INFO - 2020-09-23 09:17:38 --> URI Class Initialized
INFO - 2020-09-23 09:17:38 --> Router Class Initialized
INFO - 2020-09-23 09:17:38 --> Output Class Initialized
INFO - 2020-09-23 09:17:38 --> Security Class Initialized
DEBUG - 2020-09-23 09:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:17:38 --> Input Class Initialized
INFO - 2020-09-23 09:17:38 --> Language Class Initialized
INFO - 2020-09-23 09:17:38 --> Loader Class Initialized
INFO - 2020-09-23 09:17:38 --> Helper loaded: url_helper
INFO - 2020-09-23 09:17:38 --> Helper loaded: file_helper
INFO - 2020-09-23 09:17:38 --> Database Driver Class Initialized
INFO - 2020-09-23 09:17:38 --> Email Class Initialized
DEBUG - 2020-09-23 09:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:17:38 --> Controller Class Initialized
INFO - 2020-09-23 09:17:38 --> Model "Main_model" initialized
INFO - 2020-09-23 09:17:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:17:38 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:17:38 --> Final output sent to browser
DEBUG - 2020-09-23 09:17:38 --> Total execution time: 0.3365
INFO - 2020-09-23 09:17:43 --> Config Class Initialized
INFO - 2020-09-23 09:17:43 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:17:43 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:17:43 --> Utf8 Class Initialized
INFO - 2020-09-23 09:17:43 --> URI Class Initialized
INFO - 2020-09-23 09:17:43 --> Router Class Initialized
INFO - 2020-09-23 09:17:43 --> Output Class Initialized
INFO - 2020-09-23 09:17:43 --> Security Class Initialized
DEBUG - 2020-09-23 09:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:17:43 --> Input Class Initialized
INFO - 2020-09-23 09:17:43 --> Language Class Initialized
INFO - 2020-09-23 09:17:43 --> Loader Class Initialized
INFO - 2020-09-23 09:17:43 --> Helper loaded: url_helper
INFO - 2020-09-23 09:17:43 --> Helper loaded: file_helper
INFO - 2020-09-23 09:17:43 --> Database Driver Class Initialized
INFO - 2020-09-23 09:17:43 --> Email Class Initialized
DEBUG - 2020-09-23 09:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:17:43 --> Controller Class Initialized
INFO - 2020-09-23 09:17:43 --> Model "Main_model" initialized
INFO - 2020-09-23 09:17:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:17:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:17:43 --> Final output sent to browser
DEBUG - 2020-09-23 09:17:43 --> Total execution time: 0.3685
INFO - 2020-09-23 09:22:36 --> Config Class Initialized
INFO - 2020-09-23 09:22:36 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:22:36 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:22:36 --> Utf8 Class Initialized
INFO - 2020-09-23 09:22:36 --> URI Class Initialized
INFO - 2020-09-23 09:22:36 --> Router Class Initialized
INFO - 2020-09-23 09:22:36 --> Output Class Initialized
INFO - 2020-09-23 09:22:36 --> Security Class Initialized
DEBUG - 2020-09-23 09:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:22:36 --> Input Class Initialized
INFO - 2020-09-23 09:22:36 --> Language Class Initialized
INFO - 2020-09-23 09:22:36 --> Loader Class Initialized
INFO - 2020-09-23 09:22:36 --> Helper loaded: url_helper
INFO - 2020-09-23 09:22:36 --> Helper loaded: file_helper
INFO - 2020-09-23 09:22:36 --> Database Driver Class Initialized
INFO - 2020-09-23 09:22:36 --> Email Class Initialized
DEBUG - 2020-09-23 09:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:22:36 --> Controller Class Initialized
INFO - 2020-09-23 09:22:36 --> Model "Main_model" initialized
INFO - 2020-09-23 09:22:36 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:22:36 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:22:36 --> Final output sent to browser
DEBUG - 2020-09-23 09:22:36 --> Total execution time: 0.3344
INFO - 2020-09-23 09:22:39 --> Config Class Initialized
INFO - 2020-09-23 09:22:39 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:22:39 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:22:39 --> Utf8 Class Initialized
INFO - 2020-09-23 09:22:40 --> URI Class Initialized
INFO - 2020-09-23 09:22:40 --> Router Class Initialized
INFO - 2020-09-23 09:22:40 --> Output Class Initialized
INFO - 2020-09-23 09:22:40 --> Security Class Initialized
DEBUG - 2020-09-23 09:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:22:40 --> Input Class Initialized
INFO - 2020-09-23 09:22:40 --> Language Class Initialized
INFO - 2020-09-23 09:22:40 --> Loader Class Initialized
INFO - 2020-09-23 09:22:40 --> Helper loaded: url_helper
INFO - 2020-09-23 09:22:40 --> Helper loaded: file_helper
INFO - 2020-09-23 09:22:40 --> Database Driver Class Initialized
INFO - 2020-09-23 09:22:40 --> Email Class Initialized
DEBUG - 2020-09-23 09:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:22:40 --> Controller Class Initialized
INFO - 2020-09-23 09:22:40 --> Model "Main_model" initialized
INFO - 2020-09-23 09:22:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:22:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:22:40 --> Final output sent to browser
DEBUG - 2020-09-23 09:22:40 --> Total execution time: 0.3935
INFO - 2020-09-23 09:23:24 --> Config Class Initialized
INFO - 2020-09-23 09:23:24 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:23:24 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:23:24 --> Utf8 Class Initialized
INFO - 2020-09-23 09:23:24 --> URI Class Initialized
INFO - 2020-09-23 09:23:24 --> Router Class Initialized
INFO - 2020-09-23 09:23:24 --> Output Class Initialized
INFO - 2020-09-23 09:23:24 --> Security Class Initialized
DEBUG - 2020-09-23 09:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:23:24 --> Input Class Initialized
INFO - 2020-09-23 09:23:24 --> Language Class Initialized
INFO - 2020-09-23 09:23:24 --> Loader Class Initialized
INFO - 2020-09-23 09:23:24 --> Helper loaded: url_helper
INFO - 2020-09-23 09:23:24 --> Helper loaded: file_helper
INFO - 2020-09-23 09:23:24 --> Database Driver Class Initialized
INFO - 2020-09-23 09:23:24 --> Email Class Initialized
DEBUG - 2020-09-23 09:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:23:24 --> Controller Class Initialized
INFO - 2020-09-23 09:23:24 --> Model "Main_model" initialized
INFO - 2020-09-23 09:23:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:23:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:23:24 --> Final output sent to browser
DEBUG - 2020-09-23 09:23:24 --> Total execution time: 0.3469
INFO - 2020-09-23 09:23:27 --> Config Class Initialized
INFO - 2020-09-23 09:23:27 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:23:27 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:23:27 --> Utf8 Class Initialized
INFO - 2020-09-23 09:23:27 --> URI Class Initialized
INFO - 2020-09-23 09:23:27 --> Router Class Initialized
INFO - 2020-09-23 09:23:27 --> Output Class Initialized
INFO - 2020-09-23 09:23:27 --> Security Class Initialized
DEBUG - 2020-09-23 09:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:23:27 --> Input Class Initialized
INFO - 2020-09-23 09:23:27 --> Language Class Initialized
INFO - 2020-09-23 09:23:27 --> Loader Class Initialized
INFO - 2020-09-23 09:23:27 --> Helper loaded: url_helper
INFO - 2020-09-23 09:23:27 --> Helper loaded: file_helper
INFO - 2020-09-23 09:23:27 --> Database Driver Class Initialized
INFO - 2020-09-23 09:23:27 --> Email Class Initialized
DEBUG - 2020-09-23 09:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:23:27 --> Controller Class Initialized
INFO - 2020-09-23 09:23:27 --> Model "Main_model" initialized
INFO - 2020-09-23 09:23:27 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:23:27 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:23:27 --> Final output sent to browser
DEBUG - 2020-09-23 09:23:27 --> Total execution time: 0.4022
INFO - 2020-09-23 09:25:03 --> Config Class Initialized
INFO - 2020-09-23 09:25:03 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:25:03 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:25:03 --> Utf8 Class Initialized
INFO - 2020-09-23 09:25:03 --> URI Class Initialized
INFO - 2020-09-23 09:25:03 --> Router Class Initialized
INFO - 2020-09-23 09:25:03 --> Output Class Initialized
INFO - 2020-09-23 09:25:03 --> Security Class Initialized
DEBUG - 2020-09-23 09:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:25:03 --> Input Class Initialized
INFO - 2020-09-23 09:25:03 --> Language Class Initialized
INFO - 2020-09-23 09:25:03 --> Loader Class Initialized
INFO - 2020-09-23 09:25:03 --> Helper loaded: url_helper
INFO - 2020-09-23 09:25:03 --> Helper loaded: file_helper
INFO - 2020-09-23 09:25:03 --> Database Driver Class Initialized
INFO - 2020-09-23 09:25:03 --> Email Class Initialized
DEBUG - 2020-09-23 09:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:25:03 --> Controller Class Initialized
INFO - 2020-09-23 09:25:03 --> Model "Main_model" initialized
INFO - 2020-09-23 09:25:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:25:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:25:03 --> Final output sent to browser
DEBUG - 2020-09-23 09:25:03 --> Total execution time: 0.3571
INFO - 2020-09-23 09:25:06 --> Config Class Initialized
INFO - 2020-09-23 09:25:06 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:25:06 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:25:06 --> Utf8 Class Initialized
INFO - 2020-09-23 09:25:06 --> URI Class Initialized
INFO - 2020-09-23 09:25:06 --> Router Class Initialized
INFO - 2020-09-23 09:25:06 --> Output Class Initialized
INFO - 2020-09-23 09:25:06 --> Security Class Initialized
DEBUG - 2020-09-23 09:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:25:07 --> Input Class Initialized
INFO - 2020-09-23 09:25:07 --> Language Class Initialized
INFO - 2020-09-23 09:25:07 --> Loader Class Initialized
INFO - 2020-09-23 09:25:07 --> Helper loaded: url_helper
INFO - 2020-09-23 09:25:07 --> Helper loaded: file_helper
INFO - 2020-09-23 09:25:07 --> Database Driver Class Initialized
INFO - 2020-09-23 09:25:07 --> Email Class Initialized
DEBUG - 2020-09-23 09:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:25:07 --> Controller Class Initialized
INFO - 2020-09-23 09:25:07 --> Model "Main_model" initialized
INFO - 2020-09-23 09:25:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:25:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:25:07 --> Final output sent to browser
DEBUG - 2020-09-23 09:25:07 --> Total execution time: 0.4111
INFO - 2020-09-23 09:25:45 --> Config Class Initialized
INFO - 2020-09-23 09:25:45 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:25:45 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:25:45 --> Utf8 Class Initialized
INFO - 2020-09-23 09:25:45 --> URI Class Initialized
INFO - 2020-09-23 09:25:45 --> Router Class Initialized
INFO - 2020-09-23 09:25:45 --> Output Class Initialized
INFO - 2020-09-23 09:25:45 --> Security Class Initialized
DEBUG - 2020-09-23 09:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:25:45 --> Input Class Initialized
INFO - 2020-09-23 09:25:45 --> Language Class Initialized
INFO - 2020-09-23 09:25:45 --> Loader Class Initialized
INFO - 2020-09-23 09:25:45 --> Helper loaded: url_helper
INFO - 2020-09-23 09:25:45 --> Helper loaded: file_helper
INFO - 2020-09-23 09:25:45 --> Database Driver Class Initialized
INFO - 2020-09-23 09:25:45 --> Email Class Initialized
DEBUG - 2020-09-23 09:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:25:45 --> Controller Class Initialized
INFO - 2020-09-23 09:25:45 --> Model "Main_model" initialized
INFO - 2020-09-23 09:25:46 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:25:46 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:25:46 --> Final output sent to browser
DEBUG - 2020-09-23 09:25:46 --> Total execution time: 1.0032
INFO - 2020-09-23 09:26:26 --> Config Class Initialized
INFO - 2020-09-23 09:26:26 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:26:26 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:26:26 --> Utf8 Class Initialized
INFO - 2020-09-23 09:26:26 --> URI Class Initialized
INFO - 2020-09-23 09:26:26 --> Router Class Initialized
INFO - 2020-09-23 09:26:26 --> Output Class Initialized
INFO - 2020-09-23 09:26:26 --> Security Class Initialized
DEBUG - 2020-09-23 09:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:26:26 --> Input Class Initialized
INFO - 2020-09-23 09:26:26 --> Language Class Initialized
INFO - 2020-09-23 09:26:26 --> Loader Class Initialized
INFO - 2020-09-23 09:26:26 --> Helper loaded: url_helper
INFO - 2020-09-23 09:26:26 --> Helper loaded: file_helper
INFO - 2020-09-23 09:26:26 --> Database Driver Class Initialized
INFO - 2020-09-23 09:26:26 --> Email Class Initialized
DEBUG - 2020-09-23 09:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:26:26 --> Controller Class Initialized
INFO - 2020-09-23 09:26:26 --> Model "Main_model" initialized
INFO - 2020-09-23 09:26:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:26:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:26:26 --> Final output sent to browser
DEBUG - 2020-09-23 09:26:26 --> Total execution time: 0.4207
INFO - 2020-09-23 09:26:29 --> Config Class Initialized
INFO - 2020-09-23 09:26:29 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:26:30 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:26:30 --> Utf8 Class Initialized
INFO - 2020-09-23 09:26:30 --> URI Class Initialized
INFO - 2020-09-23 09:26:30 --> Router Class Initialized
INFO - 2020-09-23 09:26:30 --> Output Class Initialized
INFO - 2020-09-23 09:26:30 --> Security Class Initialized
DEBUG - 2020-09-23 09:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:26:30 --> Input Class Initialized
INFO - 2020-09-23 09:26:30 --> Language Class Initialized
INFO - 2020-09-23 09:26:30 --> Loader Class Initialized
INFO - 2020-09-23 09:26:30 --> Helper loaded: url_helper
INFO - 2020-09-23 09:26:30 --> Helper loaded: file_helper
INFO - 2020-09-23 09:26:30 --> Database Driver Class Initialized
INFO - 2020-09-23 09:26:30 --> Email Class Initialized
DEBUG - 2020-09-23 09:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:26:30 --> Controller Class Initialized
INFO - 2020-09-23 09:26:30 --> Model "Main_model" initialized
INFO - 2020-09-23 09:26:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:26:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:26:30 --> Final output sent to browser
DEBUG - 2020-09-23 09:26:30 --> Total execution time: 0.4143
INFO - 2020-09-23 09:27:40 --> Config Class Initialized
INFO - 2020-09-23 09:27:40 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:27:40 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:27:40 --> Utf8 Class Initialized
INFO - 2020-09-23 09:27:40 --> URI Class Initialized
INFO - 2020-09-23 09:27:40 --> Router Class Initialized
INFO - 2020-09-23 09:27:41 --> Output Class Initialized
INFO - 2020-09-23 09:27:41 --> Security Class Initialized
DEBUG - 2020-09-23 09:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:27:41 --> Input Class Initialized
INFO - 2020-09-23 09:27:41 --> Language Class Initialized
INFO - 2020-09-23 09:27:41 --> Loader Class Initialized
INFO - 2020-09-23 09:27:41 --> Helper loaded: url_helper
INFO - 2020-09-23 09:27:41 --> Helper loaded: file_helper
INFO - 2020-09-23 09:27:41 --> Database Driver Class Initialized
INFO - 2020-09-23 09:27:41 --> Email Class Initialized
DEBUG - 2020-09-23 09:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:27:41 --> Controller Class Initialized
INFO - 2020-09-23 09:27:41 --> Model "Main_model" initialized
INFO - 2020-09-23 09:27:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:27:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:27:41 --> Final output sent to browser
DEBUG - 2020-09-23 09:27:41 --> Total execution time: 0.4185
INFO - 2020-09-23 09:28:24 --> Config Class Initialized
INFO - 2020-09-23 09:28:24 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:28:24 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:28:24 --> Utf8 Class Initialized
INFO - 2020-09-23 09:28:24 --> URI Class Initialized
INFO - 2020-09-23 09:28:24 --> Router Class Initialized
INFO - 2020-09-23 09:28:24 --> Output Class Initialized
INFO - 2020-09-23 09:28:24 --> Security Class Initialized
DEBUG - 2020-09-23 09:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:28:24 --> Input Class Initialized
INFO - 2020-09-23 09:28:24 --> Language Class Initialized
INFO - 2020-09-23 09:28:24 --> Loader Class Initialized
INFO - 2020-09-23 09:28:24 --> Helper loaded: url_helper
INFO - 2020-09-23 09:28:24 --> Helper loaded: file_helper
INFO - 2020-09-23 09:28:24 --> Database Driver Class Initialized
INFO - 2020-09-23 09:28:24 --> Email Class Initialized
DEBUG - 2020-09-23 09:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:28:25 --> Controller Class Initialized
INFO - 2020-09-23 09:28:25 --> Model "Main_model" initialized
INFO - 2020-09-23 09:28:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:28:25 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:28:25 --> Final output sent to browser
DEBUG - 2020-09-23 09:28:25 --> Total execution time: 0.4372
INFO - 2020-09-23 09:28:28 --> Config Class Initialized
INFO - 2020-09-23 09:28:28 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:28:28 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:28:28 --> Utf8 Class Initialized
INFO - 2020-09-23 09:28:28 --> URI Class Initialized
INFO - 2020-09-23 09:28:28 --> Router Class Initialized
INFO - 2020-09-23 09:28:28 --> Output Class Initialized
INFO - 2020-09-23 09:28:28 --> Security Class Initialized
DEBUG - 2020-09-23 09:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:28:28 --> Input Class Initialized
INFO - 2020-09-23 09:28:28 --> Language Class Initialized
INFO - 2020-09-23 09:28:28 --> Loader Class Initialized
INFO - 2020-09-23 09:28:28 --> Helper loaded: url_helper
INFO - 2020-09-23 09:28:29 --> Helper loaded: file_helper
INFO - 2020-09-23 09:28:29 --> Database Driver Class Initialized
INFO - 2020-09-23 09:28:29 --> Email Class Initialized
DEBUG - 2020-09-23 09:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:28:29 --> Controller Class Initialized
INFO - 2020-09-23 09:28:29 --> Model "Main_model" initialized
INFO - 2020-09-23 09:28:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:28:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:28:29 --> Final output sent to browser
DEBUG - 2020-09-23 09:28:29 --> Total execution time: 0.4381
INFO - 2020-09-23 09:28:39 --> Config Class Initialized
INFO - 2020-09-23 09:28:39 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:28:39 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:28:39 --> Utf8 Class Initialized
INFO - 2020-09-23 09:28:39 --> URI Class Initialized
INFO - 2020-09-23 09:28:39 --> Router Class Initialized
INFO - 2020-09-23 09:28:39 --> Output Class Initialized
INFO - 2020-09-23 09:28:39 --> Security Class Initialized
DEBUG - 2020-09-23 09:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:28:39 --> Input Class Initialized
INFO - 2020-09-23 09:28:39 --> Language Class Initialized
INFO - 2020-09-23 09:28:39 --> Loader Class Initialized
INFO - 2020-09-23 09:28:39 --> Helper loaded: url_helper
INFO - 2020-09-23 09:28:39 --> Helper loaded: file_helper
INFO - 2020-09-23 09:28:39 --> Database Driver Class Initialized
INFO - 2020-09-23 09:28:40 --> Email Class Initialized
DEBUG - 2020-09-23 09:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:28:40 --> Controller Class Initialized
INFO - 2020-09-23 09:28:40 --> Model "Main_model" initialized
INFO - 2020-09-23 09:28:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:28:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:28:40 --> Final output sent to browser
DEBUG - 2020-09-23 09:28:40 --> Total execution time: 0.5219
INFO - 2020-09-23 09:29:39 --> Config Class Initialized
INFO - 2020-09-23 09:29:39 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:29:39 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:29:39 --> Utf8 Class Initialized
INFO - 2020-09-23 09:29:39 --> URI Class Initialized
INFO - 2020-09-23 09:29:39 --> Router Class Initialized
INFO - 2020-09-23 09:29:39 --> Output Class Initialized
INFO - 2020-09-23 09:29:39 --> Security Class Initialized
DEBUG - 2020-09-23 09:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:29:39 --> Input Class Initialized
INFO - 2020-09-23 09:29:39 --> Language Class Initialized
INFO - 2020-09-23 09:29:39 --> Loader Class Initialized
INFO - 2020-09-23 09:29:39 --> Helper loaded: url_helper
INFO - 2020-09-23 09:29:39 --> Helper loaded: file_helper
INFO - 2020-09-23 09:29:40 --> Database Driver Class Initialized
INFO - 2020-09-23 09:29:40 --> Email Class Initialized
DEBUG - 2020-09-23 09:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:29:40 --> Controller Class Initialized
INFO - 2020-09-23 09:29:40 --> Model "Main_model" initialized
INFO - 2020-09-23 09:29:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:29:40 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-23 09:29:40 --> Final output sent to browser
DEBUG - 2020-09-23 09:29:40 --> Total execution time: 0.4667
INFO - 2020-09-23 09:29:57 --> Config Class Initialized
INFO - 2020-09-23 09:29:57 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:29:57 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:29:57 --> Utf8 Class Initialized
INFO - 2020-09-23 09:29:57 --> URI Class Initialized
INFO - 2020-09-23 09:29:57 --> Router Class Initialized
INFO - 2020-09-23 09:29:57 --> Output Class Initialized
INFO - 2020-09-23 09:29:57 --> Security Class Initialized
DEBUG - 2020-09-23 09:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:29:57 --> Input Class Initialized
INFO - 2020-09-23 09:29:57 --> Language Class Initialized
INFO - 2020-09-23 09:29:57 --> Loader Class Initialized
INFO - 2020-09-23 09:29:57 --> Helper loaded: url_helper
INFO - 2020-09-23 09:29:57 --> Helper loaded: file_helper
INFO - 2020-09-23 09:29:57 --> Database Driver Class Initialized
INFO - 2020-09-23 09:29:57 --> Email Class Initialized
DEBUG - 2020-09-23 09:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:29:57 --> Controller Class Initialized
INFO - 2020-09-23 09:29:57 --> Model "Main_model" initialized
INFO - 2020-09-23 09:29:57 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:29:57 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:29:57 --> Final output sent to browser
DEBUG - 2020-09-23 09:29:57 --> Total execution time: 0.3743
INFO - 2020-09-23 09:38:54 --> Config Class Initialized
INFO - 2020-09-23 09:38:54 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:38:54 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:38:54 --> Utf8 Class Initialized
INFO - 2020-09-23 09:38:54 --> URI Class Initialized
INFO - 2020-09-23 09:38:54 --> Router Class Initialized
INFO - 2020-09-23 09:38:54 --> Output Class Initialized
INFO - 2020-09-23 09:38:54 --> Security Class Initialized
DEBUG - 2020-09-23 09:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:38:55 --> Input Class Initialized
INFO - 2020-09-23 09:38:55 --> Language Class Initialized
INFO - 2020-09-23 09:38:55 --> Loader Class Initialized
INFO - 2020-09-23 09:38:55 --> Helper loaded: url_helper
INFO - 2020-09-23 09:38:55 --> Helper loaded: file_helper
INFO - 2020-09-23 09:38:55 --> Database Driver Class Initialized
INFO - 2020-09-23 09:38:55 --> Email Class Initialized
DEBUG - 2020-09-23 09:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:38:55 --> Controller Class Initialized
INFO - 2020-09-23 09:38:55 --> Model "Main_model" initialized
INFO - 2020-09-23 09:38:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:38:55 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:38:55 --> Final output sent to browser
DEBUG - 2020-09-23 09:38:55 --> Total execution time: 0.5187
INFO - 2020-09-23 09:39:08 --> Config Class Initialized
INFO - 2020-09-23 09:39:08 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:39:08 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:39:08 --> Utf8 Class Initialized
INFO - 2020-09-23 09:39:08 --> URI Class Initialized
INFO - 2020-09-23 09:39:08 --> Router Class Initialized
INFO - 2020-09-23 09:39:08 --> Output Class Initialized
INFO - 2020-09-23 09:39:08 --> Security Class Initialized
DEBUG - 2020-09-23 09:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:39:08 --> Input Class Initialized
INFO - 2020-09-23 09:39:08 --> Language Class Initialized
ERROR - 2020-09-23 09:39:08 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:40:09 --> Config Class Initialized
INFO - 2020-09-23 09:40:09 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:40:09 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:40:09 --> Utf8 Class Initialized
INFO - 2020-09-23 09:40:09 --> URI Class Initialized
INFO - 2020-09-23 09:40:09 --> Router Class Initialized
INFO - 2020-09-23 09:40:09 --> Output Class Initialized
INFO - 2020-09-23 09:40:09 --> Security Class Initialized
DEBUG - 2020-09-23 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:40:09 --> Input Class Initialized
INFO - 2020-09-23 09:40:09 --> Language Class Initialized
INFO - 2020-09-23 09:40:09 --> Loader Class Initialized
INFO - 2020-09-23 09:40:09 --> Helper loaded: url_helper
INFO - 2020-09-23 09:40:09 --> Helper loaded: file_helper
INFO - 2020-09-23 09:40:09 --> Database Driver Class Initialized
INFO - 2020-09-23 09:40:09 --> Email Class Initialized
DEBUG - 2020-09-23 09:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:40:09 --> Controller Class Initialized
INFO - 2020-09-23 09:40:09 --> Model "Main_model" initialized
INFO - 2020-09-23 09:40:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:40:09 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:40:09 --> Final output sent to browser
DEBUG - 2020-09-23 09:40:09 --> Total execution time: 0.4323
INFO - 2020-09-23 09:40:11 --> Config Class Initialized
INFO - 2020-09-23 09:40:11 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:40:11 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:40:11 --> Utf8 Class Initialized
INFO - 2020-09-23 09:40:11 --> URI Class Initialized
INFO - 2020-09-23 09:40:11 --> Router Class Initialized
INFO - 2020-09-23 09:40:11 --> Output Class Initialized
INFO - 2020-09-23 09:40:11 --> Security Class Initialized
DEBUG - 2020-09-23 09:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:40:11 --> Input Class Initialized
INFO - 2020-09-23 09:40:11 --> Language Class Initialized
ERROR - 2020-09-23 09:40:11 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:40:25 --> Config Class Initialized
INFO - 2020-09-23 09:40:25 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:40:25 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:40:25 --> Utf8 Class Initialized
INFO - 2020-09-23 09:40:25 --> URI Class Initialized
INFO - 2020-09-23 09:40:25 --> Router Class Initialized
INFO - 2020-09-23 09:40:25 --> Output Class Initialized
INFO - 2020-09-23 09:40:25 --> Security Class Initialized
DEBUG - 2020-09-23 09:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:40:25 --> Input Class Initialized
INFO - 2020-09-23 09:40:25 --> Language Class Initialized
ERROR - 2020-09-23 09:40:25 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:42:17 --> Config Class Initialized
INFO - 2020-09-23 09:42:17 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:42:17 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:42:17 --> Utf8 Class Initialized
INFO - 2020-09-23 09:42:17 --> URI Class Initialized
INFO - 2020-09-23 09:42:17 --> Router Class Initialized
INFO - 2020-09-23 09:42:17 --> Output Class Initialized
INFO - 2020-09-23 09:42:17 --> Security Class Initialized
DEBUG - 2020-09-23 09:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:42:17 --> Input Class Initialized
INFO - 2020-09-23 09:42:17 --> Language Class Initialized
INFO - 2020-09-23 09:42:17 --> Loader Class Initialized
INFO - 2020-09-23 09:42:17 --> Helper loaded: url_helper
INFO - 2020-09-23 09:42:17 --> Helper loaded: file_helper
INFO - 2020-09-23 09:42:17 --> Database Driver Class Initialized
INFO - 2020-09-23 09:42:17 --> Email Class Initialized
DEBUG - 2020-09-23 09:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:42:17 --> Controller Class Initialized
INFO - 2020-09-23 09:42:17 --> Model "Main_model" initialized
INFO - 2020-09-23 09:42:17 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:42:17 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:42:17 --> Final output sent to browser
DEBUG - 2020-09-23 09:42:17 --> Total execution time: 0.4711
INFO - 2020-09-23 09:42:18 --> Config Class Initialized
INFO - 2020-09-23 09:42:18 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:42:18 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:42:18 --> Utf8 Class Initialized
INFO - 2020-09-23 09:42:18 --> URI Class Initialized
INFO - 2020-09-23 09:42:18 --> Router Class Initialized
INFO - 2020-09-23 09:42:18 --> Output Class Initialized
INFO - 2020-09-23 09:42:18 --> Security Class Initialized
DEBUG - 2020-09-23 09:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:42:18 --> Input Class Initialized
INFO - 2020-09-23 09:42:18 --> Language Class Initialized
ERROR - 2020-09-23 09:42:18 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:42:48 --> Config Class Initialized
INFO - 2020-09-23 09:42:48 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:42:48 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:42:49 --> Utf8 Class Initialized
INFO - 2020-09-23 09:42:49 --> URI Class Initialized
INFO - 2020-09-23 09:42:49 --> Router Class Initialized
INFO - 2020-09-23 09:42:49 --> Output Class Initialized
INFO - 2020-09-23 09:42:49 --> Security Class Initialized
DEBUG - 2020-09-23 09:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:42:49 --> Input Class Initialized
INFO - 2020-09-23 09:42:49 --> Language Class Initialized
INFO - 2020-09-23 09:42:49 --> Loader Class Initialized
INFO - 2020-09-23 09:42:49 --> Helper loaded: url_helper
INFO - 2020-09-23 09:42:49 --> Helper loaded: file_helper
INFO - 2020-09-23 09:42:49 --> Database Driver Class Initialized
INFO - 2020-09-23 09:42:49 --> Email Class Initialized
DEBUG - 2020-09-23 09:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:42:49 --> Controller Class Initialized
INFO - 2020-09-23 09:42:49 --> Model "Main_model" initialized
INFO - 2020-09-23 09:42:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:42:49 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:42:49 --> Final output sent to browser
DEBUG - 2020-09-23 09:42:49 --> Total execution time: 0.3896
INFO - 2020-09-23 09:42:50 --> Config Class Initialized
INFO - 2020-09-23 09:42:50 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:42:50 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:42:50 --> Utf8 Class Initialized
INFO - 2020-09-23 09:42:50 --> URI Class Initialized
INFO - 2020-09-23 09:42:50 --> Router Class Initialized
INFO - 2020-09-23 09:42:50 --> Output Class Initialized
INFO - 2020-09-23 09:42:50 --> Security Class Initialized
DEBUG - 2020-09-23 09:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:42:50 --> Input Class Initialized
INFO - 2020-09-23 09:42:50 --> Language Class Initialized
ERROR - 2020-09-23 09:42:50 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:43:15 --> Config Class Initialized
INFO - 2020-09-23 09:43:15 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:43:15 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:43:15 --> Utf8 Class Initialized
INFO - 2020-09-23 09:43:15 --> URI Class Initialized
INFO - 2020-09-23 09:43:15 --> Router Class Initialized
INFO - 2020-09-23 09:43:15 --> Output Class Initialized
INFO - 2020-09-23 09:43:15 --> Security Class Initialized
DEBUG - 2020-09-23 09:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:43:15 --> Input Class Initialized
INFO - 2020-09-23 09:43:15 --> Language Class Initialized
INFO - 2020-09-23 09:43:15 --> Loader Class Initialized
INFO - 2020-09-23 09:43:15 --> Helper loaded: url_helper
INFO - 2020-09-23 09:43:15 --> Helper loaded: file_helper
INFO - 2020-09-23 09:43:15 --> Database Driver Class Initialized
INFO - 2020-09-23 09:43:15 --> Email Class Initialized
DEBUG - 2020-09-23 09:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:43:15 --> Controller Class Initialized
INFO - 2020-09-23 09:43:15 --> Model "Main_model" initialized
INFO - 2020-09-23 09:43:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:43:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:43:15 --> Final output sent to browser
DEBUG - 2020-09-23 09:43:15 --> Total execution time: 0.4508
INFO - 2020-09-23 09:43:24 --> Config Class Initialized
INFO - 2020-09-23 09:43:24 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:43:24 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:43:24 --> Utf8 Class Initialized
INFO - 2020-09-23 09:43:24 --> URI Class Initialized
INFO - 2020-09-23 09:43:24 --> Router Class Initialized
INFO - 2020-09-23 09:43:24 --> Output Class Initialized
INFO - 2020-09-23 09:43:24 --> Security Class Initialized
DEBUG - 2020-09-23 09:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:43:24 --> Input Class Initialized
INFO - 2020-09-23 09:43:24 --> Language Class Initialized
ERROR - 2020-09-23 09:43:24 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:44:01 --> Config Class Initialized
INFO - 2020-09-23 09:44:01 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:44:01 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:44:01 --> Utf8 Class Initialized
INFO - 2020-09-23 09:44:01 --> URI Class Initialized
INFO - 2020-09-23 09:44:01 --> Router Class Initialized
INFO - 2020-09-23 09:44:01 --> Output Class Initialized
INFO - 2020-09-23 09:44:01 --> Security Class Initialized
DEBUG - 2020-09-23 09:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:44:01 --> Input Class Initialized
INFO - 2020-09-23 09:44:01 --> Language Class Initialized
INFO - 2020-09-23 09:44:01 --> Loader Class Initialized
INFO - 2020-09-23 09:44:01 --> Helper loaded: url_helper
INFO - 2020-09-23 09:44:01 --> Helper loaded: file_helper
INFO - 2020-09-23 09:44:01 --> Database Driver Class Initialized
INFO - 2020-09-23 09:44:01 --> Email Class Initialized
DEBUG - 2020-09-23 09:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:44:01 --> Controller Class Initialized
INFO - 2020-09-23 09:44:01 --> Model "Main_model" initialized
INFO - 2020-09-23 09:44:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:44:01 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:44:01 --> Final output sent to browser
DEBUG - 2020-09-23 09:44:01 --> Total execution time: 0.4738
INFO - 2020-09-23 09:44:03 --> Config Class Initialized
INFO - 2020-09-23 09:44:03 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:44:03 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:44:03 --> Utf8 Class Initialized
INFO - 2020-09-23 09:44:03 --> URI Class Initialized
INFO - 2020-09-23 09:44:03 --> Router Class Initialized
INFO - 2020-09-23 09:44:03 --> Output Class Initialized
INFO - 2020-09-23 09:44:03 --> Security Class Initialized
DEBUG - 2020-09-23 09:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:44:03 --> Input Class Initialized
INFO - 2020-09-23 09:44:03 --> Language Class Initialized
ERROR - 2020-09-23 09:44:03 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:44:11 --> Config Class Initialized
INFO - 2020-09-23 09:44:11 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:44:11 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:44:11 --> Utf8 Class Initialized
INFO - 2020-09-23 09:44:11 --> URI Class Initialized
INFO - 2020-09-23 09:44:11 --> Router Class Initialized
INFO - 2020-09-23 09:44:11 --> Output Class Initialized
INFO - 2020-09-23 09:44:11 --> Security Class Initialized
DEBUG - 2020-09-23 09:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:44:11 --> Input Class Initialized
INFO - 2020-09-23 09:44:11 --> Language Class Initialized
ERROR - 2020-09-23 09:44:11 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:44:40 --> Config Class Initialized
INFO - 2020-09-23 09:44:41 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:44:41 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:44:41 --> Utf8 Class Initialized
INFO - 2020-09-23 09:44:41 --> URI Class Initialized
INFO - 2020-09-23 09:44:41 --> Router Class Initialized
INFO - 2020-09-23 09:44:41 --> Output Class Initialized
INFO - 2020-09-23 09:44:41 --> Security Class Initialized
DEBUG - 2020-09-23 09:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:44:41 --> Input Class Initialized
INFO - 2020-09-23 09:44:41 --> Language Class Initialized
INFO - 2020-09-23 09:44:41 --> Loader Class Initialized
INFO - 2020-09-23 09:44:41 --> Helper loaded: url_helper
INFO - 2020-09-23 09:44:41 --> Helper loaded: file_helper
INFO - 2020-09-23 09:44:41 --> Database Driver Class Initialized
INFO - 2020-09-23 09:44:41 --> Email Class Initialized
DEBUG - 2020-09-23 09:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:44:41 --> Controller Class Initialized
INFO - 2020-09-23 09:44:41 --> Model "Main_model" initialized
INFO - 2020-09-23 09:44:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:44:41 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:44:41 --> Final output sent to browser
DEBUG - 2020-09-23 09:44:41 --> Total execution time: 0.4191
INFO - 2020-09-23 09:44:42 --> Config Class Initialized
INFO - 2020-09-23 09:44:42 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:44:42 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:44:42 --> Utf8 Class Initialized
INFO - 2020-09-23 09:44:42 --> URI Class Initialized
INFO - 2020-09-23 09:44:42 --> Router Class Initialized
INFO - 2020-09-23 09:44:42 --> Output Class Initialized
INFO - 2020-09-23 09:44:42 --> Security Class Initialized
DEBUG - 2020-09-23 09:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:44:42 --> Input Class Initialized
INFO - 2020-09-23 09:44:42 --> Language Class Initialized
ERROR - 2020-09-23 09:44:42 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:44:51 --> Config Class Initialized
INFO - 2020-09-23 09:44:51 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:44:51 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:44:51 --> Utf8 Class Initialized
INFO - 2020-09-23 09:44:51 --> URI Class Initialized
INFO - 2020-09-23 09:44:51 --> Router Class Initialized
INFO - 2020-09-23 09:44:51 --> Output Class Initialized
INFO - 2020-09-23 09:44:51 --> Security Class Initialized
DEBUG - 2020-09-23 09:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:44:51 --> Input Class Initialized
INFO - 2020-09-23 09:44:51 --> Language Class Initialized
INFO - 2020-09-23 09:44:51 --> Loader Class Initialized
INFO - 2020-09-23 09:44:51 --> Helper loaded: url_helper
INFO - 2020-09-23 09:44:51 --> Helper loaded: file_helper
INFO - 2020-09-23 09:44:51 --> Database Driver Class Initialized
INFO - 2020-09-23 09:44:51 --> Email Class Initialized
DEBUG - 2020-09-23 09:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:44:51 --> Controller Class Initialized
INFO - 2020-09-23 09:44:51 --> Model "Main_model" initialized
INFO - 2020-09-23 09:44:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:44:51 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:44:51 --> Final output sent to browser
DEBUG - 2020-09-23 09:44:51 --> Total execution time: 0.4468
INFO - 2020-09-23 09:44:53 --> Config Class Initialized
INFO - 2020-09-23 09:44:53 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:44:53 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:44:53 --> Utf8 Class Initialized
INFO - 2020-09-23 09:44:53 --> URI Class Initialized
INFO - 2020-09-23 09:44:53 --> Router Class Initialized
INFO - 2020-09-23 09:44:53 --> Output Class Initialized
INFO - 2020-09-23 09:44:53 --> Security Class Initialized
DEBUG - 2020-09-23 09:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:44:53 --> Input Class Initialized
INFO - 2020-09-23 09:44:53 --> Language Class Initialized
ERROR - 2020-09-23 09:44:53 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:46:45 --> Config Class Initialized
INFO - 2020-09-23 09:46:45 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:46:45 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:46:45 --> Utf8 Class Initialized
INFO - 2020-09-23 09:46:45 --> URI Class Initialized
INFO - 2020-09-23 09:46:45 --> Router Class Initialized
INFO - 2020-09-23 09:46:45 --> Output Class Initialized
INFO - 2020-09-23 09:46:45 --> Security Class Initialized
DEBUG - 2020-09-23 09:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:46:45 --> Input Class Initialized
INFO - 2020-09-23 09:46:45 --> Language Class Initialized
INFO - 2020-09-23 09:46:45 --> Loader Class Initialized
INFO - 2020-09-23 09:46:45 --> Helper loaded: url_helper
INFO - 2020-09-23 09:46:45 --> Helper loaded: file_helper
INFO - 2020-09-23 09:46:45 --> Database Driver Class Initialized
INFO - 2020-09-23 09:46:45 --> Email Class Initialized
DEBUG - 2020-09-23 09:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:46:45 --> Controller Class Initialized
INFO - 2020-09-23 09:46:45 --> Model "Main_model" initialized
INFO - 2020-09-23 09:46:45 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:46:45 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:46:45 --> Final output sent to browser
DEBUG - 2020-09-23 09:46:45 --> Total execution time: 0.4590
INFO - 2020-09-23 09:46:52 --> Config Class Initialized
INFO - 2020-09-23 09:46:52 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:46:52 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:46:52 --> Utf8 Class Initialized
INFO - 2020-09-23 09:46:52 --> URI Class Initialized
INFO - 2020-09-23 09:46:52 --> Router Class Initialized
INFO - 2020-09-23 09:46:52 --> Output Class Initialized
INFO - 2020-09-23 09:46:52 --> Security Class Initialized
DEBUG - 2020-09-23 09:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:46:52 --> Input Class Initialized
INFO - 2020-09-23 09:46:52 --> Language Class Initialized
ERROR - 2020-09-23 09:46:52 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:47:17 --> Config Class Initialized
INFO - 2020-09-23 09:47:17 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:47:17 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:47:17 --> Utf8 Class Initialized
INFO - 2020-09-23 09:47:17 --> URI Class Initialized
INFO - 2020-09-23 09:47:17 --> Router Class Initialized
INFO - 2020-09-23 09:47:17 --> Output Class Initialized
INFO - 2020-09-23 09:47:17 --> Security Class Initialized
DEBUG - 2020-09-23 09:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:47:17 --> Input Class Initialized
INFO - 2020-09-23 09:47:17 --> Language Class Initialized
INFO - 2020-09-23 09:47:17 --> Loader Class Initialized
INFO - 2020-09-23 09:47:17 --> Helper loaded: url_helper
INFO - 2020-09-23 09:47:17 --> Helper loaded: file_helper
INFO - 2020-09-23 09:47:17 --> Database Driver Class Initialized
INFO - 2020-09-23 09:47:17 --> Email Class Initialized
DEBUG - 2020-09-23 09:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:47:17 --> Controller Class Initialized
INFO - 2020-09-23 09:47:17 --> Model "Main_model" initialized
INFO - 2020-09-23 09:47:17 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:47:17 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:47:17 --> Final output sent to browser
DEBUG - 2020-09-23 09:47:17 --> Total execution time: 0.4455
INFO - 2020-09-23 09:47:19 --> Config Class Initialized
INFO - 2020-09-23 09:47:19 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:47:19 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:47:19 --> Utf8 Class Initialized
INFO - 2020-09-23 09:47:19 --> URI Class Initialized
INFO - 2020-09-23 09:47:19 --> Router Class Initialized
INFO - 2020-09-23 09:47:19 --> Output Class Initialized
INFO - 2020-09-23 09:47:19 --> Security Class Initialized
DEBUG - 2020-09-23 09:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:47:19 --> Input Class Initialized
INFO - 2020-09-23 09:47:19 --> Language Class Initialized
ERROR - 2020-09-23 09:47:19 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:47:43 --> Config Class Initialized
INFO - 2020-09-23 09:47:43 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:47:43 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:47:43 --> Utf8 Class Initialized
INFO - 2020-09-23 09:47:43 --> URI Class Initialized
INFO - 2020-09-23 09:47:43 --> Router Class Initialized
INFO - 2020-09-23 09:47:43 --> Output Class Initialized
INFO - 2020-09-23 09:47:43 --> Security Class Initialized
DEBUG - 2020-09-23 09:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:47:43 --> Input Class Initialized
INFO - 2020-09-23 09:47:43 --> Language Class Initialized
INFO - 2020-09-23 09:47:43 --> Loader Class Initialized
INFO - 2020-09-23 09:47:43 --> Helper loaded: url_helper
INFO - 2020-09-23 09:47:43 --> Helper loaded: file_helper
INFO - 2020-09-23 09:47:43 --> Database Driver Class Initialized
INFO - 2020-09-23 09:47:43 --> Email Class Initialized
DEBUG - 2020-09-23 09:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:47:43 --> Controller Class Initialized
INFO - 2020-09-23 09:47:43 --> Model "Main_model" initialized
INFO - 2020-09-23 09:47:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:47:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:47:43 --> Final output sent to browser
DEBUG - 2020-09-23 09:47:43 --> Total execution time: 0.4033
INFO - 2020-09-23 09:47:49 --> Config Class Initialized
INFO - 2020-09-23 09:47:49 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:47:49 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:47:49 --> Utf8 Class Initialized
INFO - 2020-09-23 09:47:49 --> URI Class Initialized
INFO - 2020-09-23 09:47:49 --> Router Class Initialized
INFO - 2020-09-23 09:47:49 --> Output Class Initialized
INFO - 2020-09-23 09:47:49 --> Security Class Initialized
DEBUG - 2020-09-23 09:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:47:50 --> Input Class Initialized
INFO - 2020-09-23 09:47:50 --> Language Class Initialized
ERROR - 2020-09-23 09:47:50 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 09:49:10 --> Config Class Initialized
INFO - 2020-09-23 09:49:10 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:49:10 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:49:10 --> Utf8 Class Initialized
INFO - 2020-09-23 09:49:10 --> URI Class Initialized
INFO - 2020-09-23 09:49:10 --> Router Class Initialized
INFO - 2020-09-23 09:49:10 --> Output Class Initialized
INFO - 2020-09-23 09:49:10 --> Security Class Initialized
DEBUG - 2020-09-23 09:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:49:10 --> Input Class Initialized
INFO - 2020-09-23 09:49:11 --> Language Class Initialized
INFO - 2020-09-23 09:49:11 --> Loader Class Initialized
INFO - 2020-09-23 09:49:11 --> Helper loaded: url_helper
INFO - 2020-09-23 09:49:11 --> Helper loaded: file_helper
INFO - 2020-09-23 09:49:11 --> Database Driver Class Initialized
INFO - 2020-09-23 09:49:11 --> Email Class Initialized
DEBUG - 2020-09-23 09:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:49:11 --> Controller Class Initialized
INFO - 2020-09-23 09:49:11 --> Model "Main_model" initialized
INFO - 2020-09-23 09:49:11 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 09:49:11 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 09:49:11 --> Final output sent to browser
DEBUG - 2020-09-23 09:49:11 --> Total execution time: 0.4027
INFO - 2020-09-23 10:53:32 --> Config Class Initialized
INFO - 2020-09-23 10:53:32 --> Hooks Class Initialized
DEBUG - 2020-09-23 10:53:32 --> UTF-8 Support Enabled
INFO - 2020-09-23 10:53:32 --> Utf8 Class Initialized
INFO - 2020-09-23 10:53:32 --> URI Class Initialized
INFO - 2020-09-23 10:53:32 --> Router Class Initialized
INFO - 2020-09-23 10:53:32 --> Output Class Initialized
INFO - 2020-09-23 10:53:32 --> Security Class Initialized
DEBUG - 2020-09-23 10:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 10:53:32 --> Input Class Initialized
INFO - 2020-09-23 10:53:32 --> Language Class Initialized
ERROR - 2020-09-23 10:53:32 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 10:54:44 --> Config Class Initialized
INFO - 2020-09-23 10:54:44 --> Hooks Class Initialized
DEBUG - 2020-09-23 10:54:44 --> UTF-8 Support Enabled
INFO - 2020-09-23 10:54:44 --> Utf8 Class Initialized
INFO - 2020-09-23 10:54:44 --> URI Class Initialized
INFO - 2020-09-23 10:54:44 --> Router Class Initialized
INFO - 2020-09-23 10:54:44 --> Output Class Initialized
INFO - 2020-09-23 10:54:44 --> Security Class Initialized
DEBUG - 2020-09-23 10:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 10:54:45 --> Input Class Initialized
INFO - 2020-09-23 10:54:45 --> Language Class Initialized
INFO - 2020-09-23 10:54:45 --> Loader Class Initialized
INFO - 2020-09-23 10:54:45 --> Helper loaded: url_helper
INFO - 2020-09-23 10:54:45 --> Helper loaded: file_helper
INFO - 2020-09-23 10:54:45 --> Database Driver Class Initialized
INFO - 2020-09-23 10:54:45 --> Email Class Initialized
DEBUG - 2020-09-23 10:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 10:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 10:54:45 --> Controller Class Initialized
INFO - 2020-09-23 10:54:45 --> Model "Main_model" initialized
INFO - 2020-09-23 10:54:45 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 10:54:45 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 10:54:45 --> Final output sent to browser
DEBUG - 2020-09-23 10:54:45 --> Total execution time: 0.4105
INFO - 2020-09-23 10:54:46 --> Config Class Initialized
INFO - 2020-09-23 10:54:46 --> Hooks Class Initialized
DEBUG - 2020-09-23 10:54:46 --> UTF-8 Support Enabled
INFO - 2020-09-23 10:54:46 --> Utf8 Class Initialized
INFO - 2020-09-23 10:54:46 --> URI Class Initialized
INFO - 2020-09-23 10:54:46 --> Router Class Initialized
INFO - 2020-09-23 10:54:46 --> Output Class Initialized
INFO - 2020-09-23 10:54:46 --> Security Class Initialized
DEBUG - 2020-09-23 10:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 10:54:46 --> Input Class Initialized
INFO - 2020-09-23 10:54:46 --> Language Class Initialized
ERROR - 2020-09-23 10:54:46 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 10:58:29 --> Config Class Initialized
INFO - 2020-09-23 10:58:29 --> Hooks Class Initialized
DEBUG - 2020-09-23 10:58:29 --> UTF-8 Support Enabled
INFO - 2020-09-23 10:58:29 --> Utf8 Class Initialized
INFO - 2020-09-23 10:58:29 --> URI Class Initialized
INFO - 2020-09-23 10:58:29 --> Router Class Initialized
INFO - 2020-09-23 10:58:29 --> Output Class Initialized
INFO - 2020-09-23 10:58:29 --> Security Class Initialized
DEBUG - 2020-09-23 10:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 10:58:29 --> Input Class Initialized
INFO - 2020-09-23 10:58:29 --> Language Class Initialized
ERROR - 2020-09-23 10:58:29 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 11:06:52 --> Config Class Initialized
INFO - 2020-09-23 11:06:52 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:06:52 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:06:52 --> Utf8 Class Initialized
INFO - 2020-09-23 11:06:52 --> URI Class Initialized
INFO - 2020-09-23 11:06:52 --> Router Class Initialized
INFO - 2020-09-23 11:06:52 --> Output Class Initialized
INFO - 2020-09-23 11:06:52 --> Security Class Initialized
DEBUG - 2020-09-23 11:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:06:52 --> Input Class Initialized
INFO - 2020-09-23 11:06:52 --> Language Class Initialized
INFO - 2020-09-23 11:06:52 --> Loader Class Initialized
INFO - 2020-09-23 11:06:52 --> Helper loaded: url_helper
INFO - 2020-09-23 11:06:52 --> Helper loaded: file_helper
INFO - 2020-09-23 11:06:52 --> Database Driver Class Initialized
INFO - 2020-09-23 11:06:52 --> Email Class Initialized
DEBUG - 2020-09-23 11:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:06:52 --> Controller Class Initialized
INFO - 2020-09-23 11:06:52 --> Model "Main_model" initialized
INFO - 2020-09-23 11:06:52 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 11:06:52 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 11:06:52 --> Final output sent to browser
DEBUG - 2020-09-23 11:06:52 --> Total execution time: 0.3966
INFO - 2020-09-23 11:08:33 --> Config Class Initialized
INFO - 2020-09-23 11:08:33 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:08:33 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:08:33 --> Utf8 Class Initialized
INFO - 2020-09-23 11:08:33 --> URI Class Initialized
INFO - 2020-09-23 11:08:33 --> Router Class Initialized
INFO - 2020-09-23 11:08:33 --> Output Class Initialized
INFO - 2020-09-23 11:08:33 --> Security Class Initialized
DEBUG - 2020-09-23 11:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:08:33 --> Input Class Initialized
INFO - 2020-09-23 11:08:33 --> Language Class Initialized
ERROR - 2020-09-23 11:08:33 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 11:13:22 --> Config Class Initialized
INFO - 2020-09-23 11:13:22 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:13:22 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:13:22 --> Utf8 Class Initialized
INFO - 2020-09-23 11:13:22 --> URI Class Initialized
INFO - 2020-09-23 11:13:22 --> Router Class Initialized
INFO - 2020-09-23 11:13:22 --> Output Class Initialized
INFO - 2020-09-23 11:13:22 --> Security Class Initialized
DEBUG - 2020-09-23 11:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:13:22 --> Input Class Initialized
INFO - 2020-09-23 11:13:22 --> Language Class Initialized
INFO - 2020-09-23 11:13:22 --> Loader Class Initialized
INFO - 2020-09-23 11:13:22 --> Helper loaded: url_helper
INFO - 2020-09-23 11:13:22 --> Helper loaded: file_helper
INFO - 2020-09-23 11:13:22 --> Database Driver Class Initialized
INFO - 2020-09-23 11:13:22 --> Email Class Initialized
DEBUG - 2020-09-23 11:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:13:22 --> Controller Class Initialized
INFO - 2020-09-23 11:13:22 --> Model "Main_model" initialized
INFO - 2020-09-23 11:13:22 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 11:13:22 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 11:13:22 --> Final output sent to browser
DEBUG - 2020-09-23 11:13:22 --> Total execution time: 0.4422
INFO - 2020-09-23 11:13:24 --> Config Class Initialized
INFO - 2020-09-23 11:13:24 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:13:24 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:13:24 --> Utf8 Class Initialized
INFO - 2020-09-23 11:13:24 --> URI Class Initialized
INFO - 2020-09-23 11:13:24 --> Router Class Initialized
INFO - 2020-09-23 11:13:24 --> Output Class Initialized
INFO - 2020-09-23 11:13:24 --> Security Class Initialized
DEBUG - 2020-09-23 11:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:13:24 --> Input Class Initialized
INFO - 2020-09-23 11:13:24 --> Language Class Initialized
ERROR - 2020-09-23 11:13:24 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 11:14:26 --> Config Class Initialized
INFO - 2020-09-23 11:14:26 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:14:26 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:14:26 --> Utf8 Class Initialized
INFO - 2020-09-23 11:14:26 --> URI Class Initialized
INFO - 2020-09-23 11:14:26 --> Router Class Initialized
INFO - 2020-09-23 11:14:26 --> Output Class Initialized
INFO - 2020-09-23 11:14:26 --> Security Class Initialized
DEBUG - 2020-09-23 11:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:14:26 --> Input Class Initialized
INFO - 2020-09-23 11:14:26 --> Language Class Initialized
INFO - 2020-09-23 11:14:26 --> Loader Class Initialized
INFO - 2020-09-23 11:14:26 --> Helper loaded: url_helper
INFO - 2020-09-23 11:14:26 --> Helper loaded: file_helper
INFO - 2020-09-23 11:14:26 --> Database Driver Class Initialized
INFO - 2020-09-23 11:14:26 --> Email Class Initialized
DEBUG - 2020-09-23 11:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:14:26 --> Controller Class Initialized
INFO - 2020-09-23 11:14:26 --> Model "Main_model" initialized
INFO - 2020-09-23 11:14:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 11:14:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 11:14:26 --> Final output sent to browser
DEBUG - 2020-09-23 11:14:26 --> Total execution time: 0.4652
INFO - 2020-09-23 11:18:24 --> Config Class Initialized
INFO - 2020-09-23 11:18:24 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:18:24 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:18:24 --> Utf8 Class Initialized
INFO - 2020-09-23 11:18:24 --> URI Class Initialized
INFO - 2020-09-23 11:18:24 --> Router Class Initialized
INFO - 2020-09-23 11:18:24 --> Output Class Initialized
INFO - 2020-09-23 11:18:24 --> Security Class Initialized
DEBUG - 2020-09-23 11:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:18:24 --> Input Class Initialized
INFO - 2020-09-23 11:18:24 --> Language Class Initialized
INFO - 2020-09-23 11:18:24 --> Loader Class Initialized
INFO - 2020-09-23 11:18:24 --> Helper loaded: url_helper
INFO - 2020-09-23 11:18:24 --> Helper loaded: file_helper
INFO - 2020-09-23 11:18:24 --> Database Driver Class Initialized
INFO - 2020-09-23 11:18:24 --> Email Class Initialized
DEBUG - 2020-09-23 11:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:18:24 --> Controller Class Initialized
INFO - 2020-09-23 11:18:24 --> Model "Main_model" initialized
INFO - 2020-09-23 11:18:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 11:18:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 11:18:24 --> Final output sent to browser
DEBUG - 2020-09-23 11:18:24 --> Total execution time: 0.4084
INFO - 2020-09-23 11:18:28 --> Config Class Initialized
INFO - 2020-09-23 11:18:28 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:18:28 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:18:28 --> Utf8 Class Initialized
INFO - 2020-09-23 11:18:28 --> URI Class Initialized
INFO - 2020-09-23 11:18:28 --> Router Class Initialized
INFO - 2020-09-23 11:18:28 --> Output Class Initialized
INFO - 2020-09-23 11:18:28 --> Security Class Initialized
DEBUG - 2020-09-23 11:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:18:28 --> Input Class Initialized
INFO - 2020-09-23 11:18:28 --> Language Class Initialized
INFO - 2020-09-23 11:18:28 --> Loader Class Initialized
INFO - 2020-09-23 11:18:28 --> Helper loaded: url_helper
INFO - 2020-09-23 11:18:28 --> Helper loaded: file_helper
INFO - 2020-09-23 11:18:28 --> Database Driver Class Initialized
INFO - 2020-09-23 11:18:28 --> Email Class Initialized
DEBUG - 2020-09-23 11:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:18:28 --> Controller Class Initialized
INFO - 2020-09-23 11:18:28 --> Model "Main_model" initialized
INFO - 2020-09-23 11:18:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 11:18:28 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 11:18:28 --> Final output sent to browser
DEBUG - 2020-09-23 11:18:29 --> Total execution time: 0.3871
INFO - 2020-09-23 11:18:53 --> Config Class Initialized
INFO - 2020-09-23 11:18:53 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:18:53 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:18:53 --> Utf8 Class Initialized
INFO - 2020-09-23 11:18:53 --> URI Class Initialized
INFO - 2020-09-23 11:18:53 --> Router Class Initialized
INFO - 2020-09-23 11:18:53 --> Output Class Initialized
INFO - 2020-09-23 11:18:53 --> Security Class Initialized
DEBUG - 2020-09-23 11:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:18:53 --> Input Class Initialized
INFO - 2020-09-23 11:18:53 --> Language Class Initialized
ERROR - 2020-09-23 11:18:53 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-23 11:24:02 --> Config Class Initialized
INFO - 2020-09-23 11:24:02 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:24:02 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:24:02 --> Utf8 Class Initialized
INFO - 2020-09-23 11:24:02 --> URI Class Initialized
INFO - 2020-09-23 11:24:02 --> Router Class Initialized
INFO - 2020-09-23 11:24:02 --> Output Class Initialized
INFO - 2020-09-23 11:24:02 --> Security Class Initialized
DEBUG - 2020-09-23 11:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:24:02 --> Input Class Initialized
INFO - 2020-09-23 11:24:02 --> Language Class Initialized
INFO - 2020-09-23 11:24:02 --> Loader Class Initialized
INFO - 2020-09-23 11:24:02 --> Helper loaded: url_helper
INFO - 2020-09-23 11:24:02 --> Helper loaded: file_helper
INFO - 2020-09-23 11:24:02 --> Database Driver Class Initialized
INFO - 2020-09-23 11:24:02 --> Email Class Initialized
DEBUG - 2020-09-23 11:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:24:03 --> Controller Class Initialized
INFO - 2020-09-23 11:24:03 --> Model "Main_model" initialized
INFO - 2020-09-23 11:24:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 11:24:03 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 11:24:03 --> Final output sent to browser
DEBUG - 2020-09-23 11:24:03 --> Total execution time: 0.4463
INFO - 2020-09-23 11:24:58 --> Config Class Initialized
INFO - 2020-09-23 11:24:58 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:24:58 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:24:58 --> Utf8 Class Initialized
INFO - 2020-09-23 11:24:58 --> URI Class Initialized
INFO - 2020-09-23 11:24:58 --> Router Class Initialized
INFO - 2020-09-23 11:24:58 --> Output Class Initialized
INFO - 2020-09-23 11:24:58 --> Security Class Initialized
DEBUG - 2020-09-23 11:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:24:58 --> Input Class Initialized
INFO - 2020-09-23 11:24:58 --> Language Class Initialized
INFO - 2020-09-23 11:24:58 --> Loader Class Initialized
INFO - 2020-09-23 11:24:58 --> Helper loaded: url_helper
INFO - 2020-09-23 11:24:59 --> Helper loaded: file_helper
INFO - 2020-09-23 11:24:59 --> Database Driver Class Initialized
INFO - 2020-09-23 11:24:59 --> Email Class Initialized
DEBUG - 2020-09-23 11:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:24:59 --> Controller Class Initialized
INFO - 2020-09-23 11:24:59 --> Model "Main_model" initialized
INFO - 2020-09-23 11:24:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 11:24:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 11:24:59 --> Final output sent to browser
DEBUG - 2020-09-23 11:24:59 --> Total execution time: 0.4058
INFO - 2020-09-23 11:39:25 --> Config Class Initialized
INFO - 2020-09-23 11:39:25 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:39:25 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:39:25 --> Utf8 Class Initialized
INFO - 2020-09-23 11:39:25 --> URI Class Initialized
INFO - 2020-09-23 11:39:25 --> Router Class Initialized
INFO - 2020-09-23 11:39:25 --> Output Class Initialized
INFO - 2020-09-23 11:39:25 --> Security Class Initialized
DEBUG - 2020-09-23 11:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:39:25 --> Input Class Initialized
INFO - 2020-09-23 11:39:25 --> Language Class Initialized
INFO - 2020-09-23 11:39:25 --> Loader Class Initialized
INFO - 2020-09-23 11:39:25 --> Helper loaded: url_helper
INFO - 2020-09-23 11:39:25 --> Helper loaded: file_helper
INFO - 2020-09-23 11:39:25 --> Database Driver Class Initialized
INFO - 2020-09-23 11:39:26 --> Email Class Initialized
DEBUG - 2020-09-23 11:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:39:26 --> Controller Class Initialized
INFO - 2020-09-23 11:39:26 --> Model "Main_model" initialized
INFO - 2020-09-23 11:39:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 11:39:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-23 11:39:26 --> Final output sent to browser
DEBUG - 2020-09-23 11:39:26 --> Total execution time: 0.4101
INFO - 2020-09-23 11:39:31 --> Config Class Initialized
INFO - 2020-09-23 11:39:31 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:39:31 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:39:31 --> Utf8 Class Initialized
INFO - 2020-09-23 11:39:31 --> URI Class Initialized
INFO - 2020-09-23 11:39:31 --> Router Class Initialized
INFO - 2020-09-23 11:39:31 --> Output Class Initialized
INFO - 2020-09-23 11:39:31 --> Security Class Initialized
DEBUG - 2020-09-23 11:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:39:31 --> Input Class Initialized
INFO - 2020-09-23 11:39:31 --> Language Class Initialized
INFO - 2020-09-23 11:39:31 --> Loader Class Initialized
INFO - 2020-09-23 11:39:31 --> Helper loaded: url_helper
INFO - 2020-09-23 11:39:31 --> Helper loaded: file_helper
INFO - 2020-09-23 11:39:31 --> Database Driver Class Initialized
INFO - 2020-09-23 11:39:31 --> Email Class Initialized
DEBUG - 2020-09-23 11:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:39:31 --> Controller Class Initialized
INFO - 2020-09-23 11:39:31 --> Model "Main_model" initialized
INFO - 2020-09-23 11:39:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-23 11:39:31 --> File loaded: C:\xampp\htdocs\dmarc\application\views\spf_lookup.php
INFO - 2020-09-23 11:39:31 --> Final output sent to browser
DEBUG - 2020-09-23 11:39:31 --> Total execution time: 0.3951
INFO - 2020-09-23 11:39:35 --> Config Class Initialized
INFO - 2020-09-23 11:39:35 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:39:35 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:39:35 --> Utf8 Class Initialized
INFO - 2020-09-23 11:39:35 --> URI Class Initialized
INFO - 2020-09-23 11:39:35 --> Router Class Initialized
INFO - 2020-09-23 11:39:35 --> Output Class Initialized
INFO - 2020-09-23 11:39:35 --> Security Class Initialized
DEBUG - 2020-09-23 11:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:39:35 --> Input Class Initialized
INFO - 2020-09-23 11:39:35 --> Language Class Initialized
INFO - 2020-09-23 11:39:35 --> Loader Class Initialized
INFO - 2020-09-23 11:39:35 --> Helper loaded: url_helper
INFO - 2020-09-23 11:39:35 --> Helper loaded: file_helper
INFO - 2020-09-23 11:39:35 --> Database Driver Class Initialized
INFO - 2020-09-23 11:39:35 --> Email Class Initialized
DEBUG - 2020-09-23 11:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:39:35 --> Controller Class Initialized
INFO - 2020-09-23 11:39:35 --> Model "Main_model" initialized
ERROR - 2020-09-23 11:39:35 --> Severity: Warning --> dns_get_record(): Type '251721779' not supported C:\xampp\htdocs\dmarc\application\controllers\Home.php 34
INFO - 2020-09-23 11:43:19 --> Config Class Initialized
INFO - 2020-09-23 11:43:19 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:43:19 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:43:19 --> Utf8 Class Initialized
INFO - 2020-09-23 11:43:19 --> URI Class Initialized
INFO - 2020-09-23 11:43:19 --> Router Class Initialized
INFO - 2020-09-23 11:43:19 --> Output Class Initialized
INFO - 2020-09-23 11:43:19 --> Security Class Initialized
DEBUG - 2020-09-23 11:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:43:19 --> Input Class Initialized
INFO - 2020-09-23 11:43:19 --> Language Class Initialized
INFO - 2020-09-23 11:43:19 --> Loader Class Initialized
INFO - 2020-09-23 11:43:19 --> Helper loaded: url_helper
INFO - 2020-09-23 11:43:19 --> Helper loaded: file_helper
INFO - 2020-09-23 11:43:19 --> Database Driver Class Initialized
INFO - 2020-09-23 11:43:19 --> Email Class Initialized
DEBUG - 2020-09-23 11:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:43:19 --> Controller Class Initialized
INFO - 2020-09-23 11:43:19 --> Model "Main_model" initialized
INFO - 2020-09-23 11:43:22 --> Config Class Initialized
INFO - 2020-09-23 11:43:22 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:43:22 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:43:22 --> Utf8 Class Initialized
INFO - 2020-09-23 11:43:22 --> URI Class Initialized
INFO - 2020-09-23 11:43:22 --> Router Class Initialized
INFO - 2020-09-23 11:43:22 --> Output Class Initialized
INFO - 2020-09-23 11:43:22 --> Security Class Initialized
DEBUG - 2020-09-23 11:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:43:22 --> Input Class Initialized
INFO - 2020-09-23 11:43:22 --> Language Class Initialized
INFO - 2020-09-23 11:43:22 --> Loader Class Initialized
INFO - 2020-09-23 11:43:22 --> Helper loaded: url_helper
INFO - 2020-09-23 11:43:22 --> Helper loaded: file_helper
INFO - 2020-09-23 11:43:22 --> Database Driver Class Initialized
INFO - 2020-09-23 11:43:22 --> Email Class Initialized
DEBUG - 2020-09-23 11:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:43:22 --> Controller Class Initialized
INFO - 2020-09-23 11:43:22 --> Model "Main_model" initialized
INFO - 2020-09-23 11:45:15 --> Config Class Initialized
INFO - 2020-09-23 11:45:15 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:45:15 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:45:15 --> Utf8 Class Initialized
INFO - 2020-09-23 11:45:15 --> URI Class Initialized
INFO - 2020-09-23 11:45:15 --> Router Class Initialized
INFO - 2020-09-23 11:45:15 --> Output Class Initialized
INFO - 2020-09-23 11:45:15 --> Security Class Initialized
DEBUG - 2020-09-23 11:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:45:15 --> Input Class Initialized
INFO - 2020-09-23 11:45:15 --> Language Class Initialized
INFO - 2020-09-23 11:45:15 --> Loader Class Initialized
INFO - 2020-09-23 11:45:15 --> Helper loaded: url_helper
INFO - 2020-09-23 11:45:15 --> Helper loaded: file_helper
INFO - 2020-09-23 11:45:15 --> Database Driver Class Initialized
INFO - 2020-09-23 11:45:15 --> Email Class Initialized
DEBUG - 2020-09-23 11:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:45:15 --> Controller Class Initialized
INFO - 2020-09-23 11:45:15 --> Model "Main_model" initialized
INFO - 2020-09-23 11:45:17 --> Config Class Initialized
INFO - 2020-09-23 11:45:17 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:45:17 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:45:17 --> Utf8 Class Initialized
INFO - 2020-09-23 11:45:17 --> URI Class Initialized
INFO - 2020-09-23 11:45:17 --> Router Class Initialized
INFO - 2020-09-23 11:45:17 --> Output Class Initialized
INFO - 2020-09-23 11:45:17 --> Security Class Initialized
DEBUG - 2020-09-23 11:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:45:17 --> Input Class Initialized
INFO - 2020-09-23 11:45:18 --> Language Class Initialized
INFO - 2020-09-23 11:45:18 --> Loader Class Initialized
INFO - 2020-09-23 11:45:18 --> Helper loaded: url_helper
INFO - 2020-09-23 11:45:18 --> Helper loaded: file_helper
INFO - 2020-09-23 11:45:18 --> Database Driver Class Initialized
INFO - 2020-09-23 11:45:18 --> Email Class Initialized
DEBUG - 2020-09-23 11:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:45:18 --> Controller Class Initialized
INFO - 2020-09-23 11:45:18 --> Model "Main_model" initialized
INFO - 2020-09-23 11:46:21 --> Config Class Initialized
INFO - 2020-09-23 11:46:21 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:46:21 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:46:21 --> Utf8 Class Initialized
INFO - 2020-09-23 11:46:21 --> URI Class Initialized
INFO - 2020-09-23 11:46:21 --> Router Class Initialized
INFO - 2020-09-23 11:46:21 --> Output Class Initialized
INFO - 2020-09-23 11:46:21 --> Security Class Initialized
DEBUG - 2020-09-23 11:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:46:21 --> Input Class Initialized
INFO - 2020-09-23 11:46:21 --> Language Class Initialized
INFO - 2020-09-23 11:46:21 --> Loader Class Initialized
INFO - 2020-09-23 11:46:21 --> Helper loaded: url_helper
INFO - 2020-09-23 11:46:21 --> Helper loaded: file_helper
INFO - 2020-09-23 11:46:21 --> Database Driver Class Initialized
INFO - 2020-09-23 11:46:21 --> Email Class Initialized
DEBUG - 2020-09-23 11:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:46:22 --> Controller Class Initialized
INFO - 2020-09-23 11:46:22 --> Model "Main_model" initialized
INFO - 2020-09-23 11:46:23 --> Config Class Initialized
INFO - 2020-09-23 11:46:24 --> Hooks Class Initialized
DEBUG - 2020-09-23 11:46:24 --> UTF-8 Support Enabled
INFO - 2020-09-23 11:46:24 --> Utf8 Class Initialized
INFO - 2020-09-23 11:46:24 --> URI Class Initialized
INFO - 2020-09-23 11:46:24 --> Router Class Initialized
INFO - 2020-09-23 11:46:24 --> Output Class Initialized
INFO - 2020-09-23 11:46:24 --> Security Class Initialized
DEBUG - 2020-09-23 11:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 11:46:24 --> Input Class Initialized
INFO - 2020-09-23 11:46:24 --> Language Class Initialized
INFO - 2020-09-23 11:46:24 --> Loader Class Initialized
INFO - 2020-09-23 11:46:24 --> Helper loaded: url_helper
INFO - 2020-09-23 11:46:24 --> Helper loaded: file_helper
INFO - 2020-09-23 11:46:24 --> Database Driver Class Initialized
INFO - 2020-09-23 11:46:24 --> Email Class Initialized
DEBUG - 2020-09-23 11:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 11:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 11:46:24 --> Controller Class Initialized
INFO - 2020-09-23 11:46:24 --> Model "Main_model" initialized
