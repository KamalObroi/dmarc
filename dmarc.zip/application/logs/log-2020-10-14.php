<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-14 15:24:59 --> Config Class Initialized
INFO - 2020-10-14 15:24:59 --> Hooks Class Initialized
DEBUG - 2020-10-14 15:24:59 --> UTF-8 Support Enabled
INFO - 2020-10-14 15:24:59 --> Utf8 Class Initialized
INFO - 2020-10-14 15:24:59 --> URI Class Initialized
INFO - 2020-10-14 15:24:59 --> Router Class Initialized
INFO - 2020-10-14 15:24:59 --> Output Class Initialized
INFO - 2020-10-14 15:25:00 --> Security Class Initialized
DEBUG - 2020-10-14 15:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 15:25:00 --> Input Class Initialized
INFO - 2020-10-14 15:25:00 --> Language Class Initialized
INFO - 2020-10-14 15:25:00 --> Loader Class Initialized
INFO - 2020-10-14 15:25:00 --> Helper loaded: url_helper
INFO - 2020-10-14 15:25:00 --> Helper loaded: file_helper
INFO - 2020-10-14 15:25:00 --> Database Driver Class Initialized
INFO - 2020-10-14 15:25:00 --> Email Class Initialized
DEBUG - 2020-10-14 15:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-14 15:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 15:25:00 --> Controller Class Initialized
INFO - 2020-10-14 15:25:00 --> Model "Main_model" initialized
INFO - 2020-10-14 15:25:00 --> File loaded: C:\xampp\htdocs\dmarc\application\views\main_menu.php
INFO - 2020-10-14 15:25:00 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-10-14 15:25:00 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-10-14 15:25:00 --> Final output sent to browser
DEBUG - 2020-10-14 15:25:00 --> Total execution time: 1.2335
