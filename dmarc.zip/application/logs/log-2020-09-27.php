<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-27 21:05:47 --> Config Class Initialized
INFO - 2020-09-27 21:05:47 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:05:47 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:05:47 --> Utf8 Class Initialized
INFO - 2020-09-27 21:05:47 --> URI Class Initialized
DEBUG - 2020-09-27 21:05:47 --> No URI present. Default controller set.
INFO - 2020-09-27 21:05:47 --> Router Class Initialized
INFO - 2020-09-27 21:05:47 --> Output Class Initialized
INFO - 2020-09-27 21:05:47 --> Security Class Initialized
DEBUG - 2020-09-27 21:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:05:47 --> Input Class Initialized
INFO - 2020-09-27 21:05:47 --> Language Class Initialized
INFO - 2020-09-27 21:05:48 --> Loader Class Initialized
INFO - 2020-09-27 21:05:48 --> Helper loaded: url_helper
INFO - 2020-09-27 21:05:48 --> Helper loaded: file_helper
INFO - 2020-09-27 21:05:48 --> Database Driver Class Initialized
INFO - 2020-09-27 21:05:48 --> Email Class Initialized
DEBUG - 2020-09-27 21:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:05:48 --> Controller Class Initialized
INFO - 2020-09-27 21:05:48 --> Model "Main_model" initialized
INFO - 2020-09-27 21:05:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\home.php
INFO - 2020-09-27 21:05:48 --> Final output sent to browser
DEBUG - 2020-09-27 21:05:48 --> Total execution time: 1.2681
INFO - 2020-09-27 21:06:24 --> Config Class Initialized
INFO - 2020-09-27 21:06:24 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:06:24 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:06:24 --> Utf8 Class Initialized
INFO - 2020-09-27 21:06:24 --> URI Class Initialized
INFO - 2020-09-27 21:06:24 --> Router Class Initialized
INFO - 2020-09-27 21:06:24 --> Output Class Initialized
INFO - 2020-09-27 21:06:24 --> Security Class Initialized
DEBUG - 2020-09-27 21:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:06:24 --> Input Class Initialized
INFO - 2020-09-27 21:06:24 --> Language Class Initialized
INFO - 2020-09-27 21:06:24 --> Loader Class Initialized
INFO - 2020-09-27 21:06:24 --> Helper loaded: url_helper
INFO - 2020-09-27 21:06:24 --> Helper loaded: file_helper
INFO - 2020-09-27 21:06:24 --> Database Driver Class Initialized
INFO - 2020-09-27 21:06:24 --> Email Class Initialized
DEBUG - 2020-09-27 21:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:06:24 --> Controller Class Initialized
INFO - 2020-09-27 21:06:24 --> Model "Main_model" initialized
INFO - 2020-09-27 21:06:24 --> File loaded: C:\xampp\htdocs\dmarc\application\views\login.php
INFO - 2020-09-27 21:06:24 --> Final output sent to browser
DEBUG - 2020-09-27 21:06:24 --> Total execution time: 0.3299
INFO - 2020-09-27 21:06:28 --> Config Class Initialized
INFO - 2020-09-27 21:06:28 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:06:28 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:06:28 --> Utf8 Class Initialized
INFO - 2020-09-27 21:06:28 --> URI Class Initialized
INFO - 2020-09-27 21:06:28 --> Router Class Initialized
INFO - 2020-09-27 21:06:28 --> Output Class Initialized
INFO - 2020-09-27 21:06:28 --> Security Class Initialized
DEBUG - 2020-09-27 21:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:06:28 --> Input Class Initialized
INFO - 2020-09-27 21:06:28 --> Language Class Initialized
INFO - 2020-09-27 21:06:28 --> Loader Class Initialized
INFO - 2020-09-27 21:06:28 --> Helper loaded: url_helper
INFO - 2020-09-27 21:06:28 --> Helper loaded: file_helper
INFO - 2020-09-27 21:06:28 --> Database Driver Class Initialized
INFO - 2020-09-27 21:06:29 --> Email Class Initialized
DEBUG - 2020-09-27 21:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:06:29 --> Controller Class Initialized
INFO - 2020-09-27 21:06:29 --> Model "Main_model" initialized
INFO - 2020-09-27 21:06:29 --> Config Class Initialized
INFO - 2020-09-27 21:06:29 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:06:29 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:06:29 --> Utf8 Class Initialized
INFO - 2020-09-27 21:06:29 --> URI Class Initialized
INFO - 2020-09-27 21:06:29 --> Router Class Initialized
INFO - 2020-09-27 21:06:29 --> Output Class Initialized
INFO - 2020-09-27 21:06:29 --> Security Class Initialized
DEBUG - 2020-09-27 21:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:06:29 --> Input Class Initialized
INFO - 2020-09-27 21:06:29 --> Language Class Initialized
INFO - 2020-09-27 21:06:29 --> Loader Class Initialized
INFO - 2020-09-27 21:06:29 --> Helper loaded: url_helper
INFO - 2020-09-27 21:06:29 --> Helper loaded: file_helper
INFO - 2020-09-27 21:06:29 --> Database Driver Class Initialized
INFO - 2020-09-27 21:06:29 --> Email Class Initialized
DEBUG - 2020-09-27 21:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:06:29 --> Controller Class Initialized
INFO - 2020-09-27 21:06:29 --> Model "Main_model" initialized
INFO - 2020-09-27 21:06:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\menu.php
INFO - 2020-09-27 21:06:29 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dashboard.php
INFO - 2020-09-27 21:06:29 --> Final output sent to browser
DEBUG - 2020-09-27 21:06:29 --> Total execution time: 0.3344
INFO - 2020-09-27 21:06:43 --> Config Class Initialized
INFO - 2020-09-27 21:06:43 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:06:43 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:06:43 --> Utf8 Class Initialized
INFO - 2020-09-27 21:06:43 --> URI Class Initialized
INFO - 2020-09-27 21:06:43 --> Router Class Initialized
INFO - 2020-09-27 21:06:43 --> Output Class Initialized
INFO - 2020-09-27 21:06:43 --> Security Class Initialized
DEBUG - 2020-09-27 21:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:06:43 --> Input Class Initialized
INFO - 2020-09-27 21:06:43 --> Language Class Initialized
INFO - 2020-09-27 21:06:43 --> Loader Class Initialized
INFO - 2020-09-27 21:06:43 --> Helper loaded: url_helper
INFO - 2020-09-27 21:06:43 --> Helper loaded: file_helper
INFO - 2020-09-27 21:06:43 --> Database Driver Class Initialized
INFO - 2020-09-27 21:06:43 --> Email Class Initialized
DEBUG - 2020-09-27 21:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:06:43 --> Controller Class Initialized
INFO - 2020-09-27 21:06:43 --> Model "Main_model" initialized
INFO - 2020-09-27 21:06:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:06:43 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-27 21:06:43 --> Final output sent to browser
DEBUG - 2020-09-27 21:06:43 --> Total execution time: 0.3321
INFO - 2020-09-27 21:07:27 --> Config Class Initialized
INFO - 2020-09-27 21:07:27 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:07:27 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:07:27 --> Utf8 Class Initialized
INFO - 2020-09-27 21:07:27 --> URI Class Initialized
INFO - 2020-09-27 21:07:27 --> Router Class Initialized
INFO - 2020-09-27 21:07:27 --> Output Class Initialized
INFO - 2020-09-27 21:07:27 --> Security Class Initialized
DEBUG - 2020-09-27 21:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:07:27 --> Input Class Initialized
INFO - 2020-09-27 21:07:27 --> Language Class Initialized
INFO - 2020-09-27 21:07:27 --> Loader Class Initialized
INFO - 2020-09-27 21:07:27 --> Helper loaded: url_helper
INFO - 2020-09-27 21:07:27 --> Helper loaded: file_helper
INFO - 2020-09-27 21:07:27 --> Database Driver Class Initialized
INFO - 2020-09-27 21:07:27 --> Email Class Initialized
DEBUG - 2020-09-27 21:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:07:27 --> Controller Class Initialized
INFO - 2020-09-27 21:07:27 --> Model "Main_model" initialized
INFO - 2020-09-27 21:07:27 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:07:27 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-27 21:07:27 --> Final output sent to browser
DEBUG - 2020-09-27 21:07:27 --> Total execution time: 0.3222
INFO - 2020-09-27 21:07:30 --> Config Class Initialized
INFO - 2020-09-27 21:07:30 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:07:30 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:07:30 --> Utf8 Class Initialized
INFO - 2020-09-27 21:07:30 --> URI Class Initialized
INFO - 2020-09-27 21:07:30 --> Router Class Initialized
INFO - 2020-09-27 21:07:30 --> Output Class Initialized
INFO - 2020-09-27 21:07:30 --> Security Class Initialized
DEBUG - 2020-09-27 21:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:07:30 --> Input Class Initialized
INFO - 2020-09-27 21:07:30 --> Language Class Initialized
INFO - 2020-09-27 21:07:30 --> Loader Class Initialized
INFO - 2020-09-27 21:07:30 --> Helper loaded: url_helper
INFO - 2020-09-27 21:07:30 --> Helper loaded: file_helper
INFO - 2020-09-27 21:07:30 --> Database Driver Class Initialized
INFO - 2020-09-27 21:07:30 --> Email Class Initialized
DEBUG - 2020-09-27 21:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:07:30 --> Controller Class Initialized
INFO - 2020-09-27 21:07:30 --> Model "Main_model" initialized
INFO - 2020-09-27 21:07:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:07:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-27 21:07:30 --> Final output sent to browser
DEBUG - 2020-09-27 21:07:30 --> Total execution time: 0.3301
INFO - 2020-09-27 21:07:33 --> Config Class Initialized
INFO - 2020-09-27 21:07:33 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:07:33 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:07:33 --> Utf8 Class Initialized
INFO - 2020-09-27 21:07:33 --> URI Class Initialized
INFO - 2020-09-27 21:07:33 --> Router Class Initialized
INFO - 2020-09-27 21:07:33 --> Output Class Initialized
INFO - 2020-09-27 21:07:33 --> Security Class Initialized
DEBUG - 2020-09-27 21:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:07:33 --> Input Class Initialized
INFO - 2020-09-27 21:07:33 --> Language Class Initialized
ERROR - 2020-09-27 21:07:33 --> 404 Page Not Found: Bimirecordgenerator/index
INFO - 2020-09-27 21:07:46 --> Config Class Initialized
INFO - 2020-09-27 21:07:46 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:07:46 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:07:46 --> Utf8 Class Initialized
INFO - 2020-09-27 21:07:46 --> URI Class Initialized
INFO - 2020-09-27 21:07:46 --> Router Class Initialized
INFO - 2020-09-27 21:07:46 --> Output Class Initialized
INFO - 2020-09-27 21:07:46 --> Security Class Initialized
DEBUG - 2020-09-27 21:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:07:46 --> Input Class Initialized
INFO - 2020-09-27 21:07:46 --> Language Class Initialized
INFO - 2020-09-27 21:07:46 --> Loader Class Initialized
INFO - 2020-09-27 21:07:46 --> Helper loaded: url_helper
INFO - 2020-09-27 21:07:46 --> Helper loaded: file_helper
INFO - 2020-09-27 21:07:46 --> Database Driver Class Initialized
INFO - 2020-09-27 21:07:46 --> Email Class Initialized
DEBUG - 2020-09-27 21:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:07:46 --> Controller Class Initialized
INFO - 2020-09-27 21:07:46 --> Model "Main_model" initialized
INFO - 2020-09-27 21:07:46 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:07:46 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-27 21:07:46 --> Final output sent to browser
DEBUG - 2020-09-27 21:07:46 --> Total execution time: 0.3287
INFO - 2020-09-27 21:07:49 --> Config Class Initialized
INFO - 2020-09-27 21:07:49 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:07:49 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:07:49 --> Utf8 Class Initialized
INFO - 2020-09-27 21:07:49 --> URI Class Initialized
INFO - 2020-09-27 21:07:49 --> Router Class Initialized
INFO - 2020-09-27 21:07:49 --> Output Class Initialized
INFO - 2020-09-27 21:07:50 --> Security Class Initialized
DEBUG - 2020-09-27 21:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:07:50 --> Input Class Initialized
INFO - 2020-09-27 21:07:50 --> Language Class Initialized
INFO - 2020-09-27 21:07:50 --> Loader Class Initialized
INFO - 2020-09-27 21:07:50 --> Helper loaded: url_helper
INFO - 2020-09-27 21:07:50 --> Helper loaded: file_helper
INFO - 2020-09-27 21:07:50 --> Database Driver Class Initialized
INFO - 2020-09-27 21:07:50 --> Email Class Initialized
DEBUG - 2020-09-27 21:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:07:50 --> Controller Class Initialized
INFO - 2020-09-27 21:07:50 --> Model "Main_model" initialized
INFO - 2020-09-27 21:07:50 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:07:50 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimi_lookup.php
INFO - 2020-09-27 21:07:50 --> Final output sent to browser
DEBUG - 2020-09-27 21:07:50 --> Total execution time: 0.3916
INFO - 2020-09-27 21:09:30 --> Config Class Initialized
INFO - 2020-09-27 21:09:30 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:09:30 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:09:30 --> Utf8 Class Initialized
INFO - 2020-09-27 21:09:30 --> URI Class Initialized
INFO - 2020-09-27 21:09:30 --> Router Class Initialized
INFO - 2020-09-27 21:09:30 --> Output Class Initialized
INFO - 2020-09-27 21:09:30 --> Security Class Initialized
DEBUG - 2020-09-27 21:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:09:30 --> Input Class Initialized
INFO - 2020-09-27 21:09:30 --> Language Class Initialized
INFO - 2020-09-27 21:09:30 --> Loader Class Initialized
INFO - 2020-09-27 21:09:30 --> Helper loaded: url_helper
INFO - 2020-09-27 21:09:30 --> Helper loaded: file_helper
INFO - 2020-09-27 21:09:30 --> Database Driver Class Initialized
INFO - 2020-09-27 21:09:30 --> Email Class Initialized
DEBUG - 2020-09-27 21:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:09:30 --> Controller Class Initialized
INFO - 2020-09-27 21:09:30 --> Model "Main_model" initialized
INFO - 2020-09-27 21:09:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:09:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimi_lookup.php
INFO - 2020-09-27 21:09:30 --> Final output sent to browser
DEBUG - 2020-09-27 21:09:30 --> Total execution time: 0.3995
INFO - 2020-09-27 21:09:59 --> Config Class Initialized
INFO - 2020-09-27 21:09:59 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:09:59 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:09:59 --> Utf8 Class Initialized
INFO - 2020-09-27 21:09:59 --> URI Class Initialized
INFO - 2020-09-27 21:09:59 --> Router Class Initialized
INFO - 2020-09-27 21:09:59 --> Output Class Initialized
INFO - 2020-09-27 21:09:59 --> Security Class Initialized
DEBUG - 2020-09-27 21:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:09:59 --> Input Class Initialized
INFO - 2020-09-27 21:09:59 --> Language Class Initialized
INFO - 2020-09-27 21:09:59 --> Loader Class Initialized
INFO - 2020-09-27 21:09:59 --> Helper loaded: url_helper
INFO - 2020-09-27 21:09:59 --> Helper loaded: file_helper
INFO - 2020-09-27 21:09:59 --> Database Driver Class Initialized
INFO - 2020-09-27 21:09:59 --> Email Class Initialized
DEBUG - 2020-09-27 21:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:09:59 --> Controller Class Initialized
INFO - 2020-09-27 21:09:59 --> Model "Main_model" initialized
INFO - 2020-09-27 21:09:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:09:59 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimi_lookup.php
INFO - 2020-09-27 21:09:59 --> Final output sent to browser
DEBUG - 2020-09-27 21:09:59 --> Total execution time: 0.3433
INFO - 2020-09-27 21:10:15 --> Config Class Initialized
INFO - 2020-09-27 21:10:15 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:10:15 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:10:15 --> Utf8 Class Initialized
INFO - 2020-09-27 21:10:15 --> URI Class Initialized
INFO - 2020-09-27 21:10:15 --> Router Class Initialized
INFO - 2020-09-27 21:10:15 --> Output Class Initialized
INFO - 2020-09-27 21:10:15 --> Security Class Initialized
DEBUG - 2020-09-27 21:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:10:15 --> Input Class Initialized
INFO - 2020-09-27 21:10:15 --> Language Class Initialized
INFO - 2020-09-27 21:10:15 --> Loader Class Initialized
INFO - 2020-09-27 21:10:15 --> Helper loaded: url_helper
INFO - 2020-09-27 21:10:15 --> Helper loaded: file_helper
INFO - 2020-09-27 21:10:15 --> Database Driver Class Initialized
INFO - 2020-09-27 21:10:15 --> Email Class Initialized
DEBUG - 2020-09-27 21:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:10:15 --> Controller Class Initialized
INFO - 2020-09-27 21:10:15 --> Model "Main_model" initialized
INFO - 2020-09-27 21:10:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:10:15 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimi_lookup.php
INFO - 2020-09-27 21:10:15 --> Final output sent to browser
DEBUG - 2020-09-27 21:10:15 --> Total execution time: 0.3810
INFO - 2020-09-27 21:17:16 --> Config Class Initialized
INFO - 2020-09-27 21:17:16 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:17:16 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:17:16 --> Utf8 Class Initialized
INFO - 2020-09-27 21:17:16 --> URI Class Initialized
INFO - 2020-09-27 21:17:16 --> Router Class Initialized
INFO - 2020-09-27 21:17:16 --> Output Class Initialized
INFO - 2020-09-27 21:17:16 --> Security Class Initialized
DEBUG - 2020-09-27 21:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:17:16 --> Input Class Initialized
INFO - 2020-09-27 21:17:17 --> Language Class Initialized
INFO - 2020-09-27 21:17:17 --> Loader Class Initialized
INFO - 2020-09-27 21:17:17 --> Helper loaded: url_helper
INFO - 2020-09-27 21:17:17 --> Helper loaded: file_helper
INFO - 2020-09-27 21:17:17 --> Database Driver Class Initialized
INFO - 2020-09-27 21:17:17 --> Email Class Initialized
DEBUG - 2020-09-27 21:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:17:17 --> Controller Class Initialized
INFO - 2020-09-27 21:17:17 --> Model "Main_model" initialized
INFO - 2020-09-27 21:17:17 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:17:17 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimi_lookup.php
INFO - 2020-09-27 21:17:17 --> Final output sent to browser
DEBUG - 2020-09-27 21:17:17 --> Total execution time: 0.3667
INFO - 2020-09-27 21:20:48 --> Config Class Initialized
INFO - 2020-09-27 21:20:48 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:20:48 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:20:48 --> Utf8 Class Initialized
INFO - 2020-09-27 21:20:48 --> URI Class Initialized
INFO - 2020-09-27 21:20:48 --> Router Class Initialized
INFO - 2020-09-27 21:20:48 --> Output Class Initialized
INFO - 2020-09-27 21:20:48 --> Security Class Initialized
DEBUG - 2020-09-27 21:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:20:48 --> Input Class Initialized
INFO - 2020-09-27 21:20:48 --> Language Class Initialized
INFO - 2020-09-27 21:20:48 --> Loader Class Initialized
INFO - 2020-09-27 21:20:48 --> Helper loaded: url_helper
INFO - 2020-09-27 21:20:48 --> Helper loaded: file_helper
INFO - 2020-09-27 21:20:48 --> Database Driver Class Initialized
INFO - 2020-09-27 21:20:48 --> Email Class Initialized
DEBUG - 2020-09-27 21:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:20:48 --> Controller Class Initialized
INFO - 2020-09-27 21:20:48 --> Model "Main_model" initialized
INFO - 2020-09-27 21:20:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:20:48 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarc_lookup.php
INFO - 2020-09-27 21:20:48 --> Final output sent to browser
DEBUG - 2020-09-27 21:20:48 --> Total execution time: 0.4408
INFO - 2020-09-27 21:20:57 --> Config Class Initialized
INFO - 2020-09-27 21:20:57 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:20:57 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:20:57 --> Utf8 Class Initialized
INFO - 2020-09-27 21:20:57 --> URI Class Initialized
INFO - 2020-09-27 21:20:57 --> Router Class Initialized
INFO - 2020-09-27 21:20:57 --> Output Class Initialized
INFO - 2020-09-27 21:20:57 --> Security Class Initialized
DEBUG - 2020-09-27 21:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:20:57 --> Input Class Initialized
INFO - 2020-09-27 21:20:57 --> Language Class Initialized
INFO - 2020-09-27 21:20:57 --> Loader Class Initialized
INFO - 2020-09-27 21:20:57 --> Helper loaded: url_helper
INFO - 2020-09-27 21:20:57 --> Helper loaded: file_helper
INFO - 2020-09-27 21:20:57 --> Database Driver Class Initialized
INFO - 2020-09-27 21:20:57 --> Email Class Initialized
DEBUG - 2020-09-27 21:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:20:57 --> Controller Class Initialized
INFO - 2020-09-27 21:20:57 --> Model "Main_model" initialized
INFO - 2020-09-27 21:20:57 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:20:57 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimi_lookup.php
INFO - 2020-09-27 21:20:57 --> Final output sent to browser
DEBUG - 2020-09-27 21:20:57 --> Total execution time: 0.4002
INFO - 2020-09-27 21:21:01 --> Config Class Initialized
INFO - 2020-09-27 21:21:01 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:21:01 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:21:01 --> Utf8 Class Initialized
INFO - 2020-09-27 21:21:01 --> URI Class Initialized
INFO - 2020-09-27 21:21:01 --> Router Class Initialized
INFO - 2020-09-27 21:21:01 --> Output Class Initialized
INFO - 2020-09-27 21:21:01 --> Security Class Initialized
DEBUG - 2020-09-27 21:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:21:02 --> Input Class Initialized
INFO - 2020-09-27 21:21:02 --> Language Class Initialized
INFO - 2020-09-27 21:21:02 --> Loader Class Initialized
INFO - 2020-09-27 21:21:02 --> Helper loaded: url_helper
INFO - 2020-09-27 21:21:02 --> Helper loaded: file_helper
INFO - 2020-09-27 21:21:02 --> Database Driver Class Initialized
INFO - 2020-09-27 21:21:02 --> Email Class Initialized
DEBUG - 2020-09-27 21:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:21:02 --> Controller Class Initialized
INFO - 2020-09-27 21:21:02 --> Model "Main_model" initialized
INFO - 2020-09-27 21:21:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:21:02 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimi_lookup.php
INFO - 2020-09-27 21:21:02 --> Final output sent to browser
DEBUG - 2020-09-27 21:21:02 --> Total execution time: 0.4807
INFO - 2020-09-27 21:22:22 --> Config Class Initialized
INFO - 2020-09-27 21:22:22 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:22:22 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:22:22 --> Utf8 Class Initialized
INFO - 2020-09-27 21:22:22 --> URI Class Initialized
INFO - 2020-09-27 21:22:22 --> Router Class Initialized
INFO - 2020-09-27 21:22:22 --> Output Class Initialized
INFO - 2020-09-27 21:22:22 --> Security Class Initialized
DEBUG - 2020-09-27 21:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:22:22 --> Input Class Initialized
INFO - 2020-09-27 21:22:22 --> Language Class Initialized
INFO - 2020-09-27 21:22:22 --> Loader Class Initialized
INFO - 2020-09-27 21:22:22 --> Helper loaded: url_helper
INFO - 2020-09-27 21:22:22 --> Helper loaded: file_helper
INFO - 2020-09-27 21:22:22 --> Database Driver Class Initialized
INFO - 2020-09-27 21:22:22 --> Email Class Initialized
DEBUG - 2020-09-27 21:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:22:23 --> Controller Class Initialized
INFO - 2020-09-27 21:22:23 --> Model "Main_model" initialized
INFO - 2020-09-27 21:22:23 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:22:23 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimi_lookup.php
INFO - 2020-09-27 21:22:23 --> Final output sent to browser
DEBUG - 2020-09-27 21:22:23 --> Total execution time: 0.4852
INFO - 2020-09-27 21:23:21 --> Config Class Initialized
INFO - 2020-09-27 21:23:21 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:23:21 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:23:21 --> Utf8 Class Initialized
INFO - 2020-09-27 21:23:21 --> URI Class Initialized
INFO - 2020-09-27 21:23:21 --> Router Class Initialized
INFO - 2020-09-27 21:23:21 --> Output Class Initialized
INFO - 2020-09-27 21:23:21 --> Security Class Initialized
DEBUG - 2020-09-27 21:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:23:22 --> Input Class Initialized
INFO - 2020-09-27 21:23:22 --> Language Class Initialized
ERROR - 2020-09-27 21:23:22 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-27 21:23:51 --> Config Class Initialized
INFO - 2020-09-27 21:23:51 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:23:51 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:23:51 --> Utf8 Class Initialized
INFO - 2020-09-27 21:23:51 --> URI Class Initialized
INFO - 2020-09-27 21:23:51 --> Router Class Initialized
INFO - 2020-09-27 21:23:51 --> Output Class Initialized
INFO - 2020-09-27 21:23:51 --> Security Class Initialized
DEBUG - 2020-09-27 21:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:23:51 --> Input Class Initialized
INFO - 2020-09-27 21:23:51 --> Language Class Initialized
INFO - 2020-09-27 21:23:51 --> Loader Class Initialized
INFO - 2020-09-27 21:23:51 --> Helper loaded: url_helper
INFO - 2020-09-27 21:23:52 --> Helper loaded: file_helper
INFO - 2020-09-27 21:23:52 --> Database Driver Class Initialized
INFO - 2020-09-27 21:23:52 --> Email Class Initialized
DEBUG - 2020-09-27 21:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:23:52 --> Controller Class Initialized
INFO - 2020-09-27 21:23:52 --> Model "Main_model" initialized
INFO - 2020-09-27 21:23:52 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:23:52 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimi_lookup.php
INFO - 2020-09-27 21:23:52 --> Final output sent to browser
DEBUG - 2020-09-27 21:23:52 --> Total execution time: 0.4075
INFO - 2020-09-27 21:24:00 --> Config Class Initialized
INFO - 2020-09-27 21:24:00 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:24:00 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:24:00 --> Utf8 Class Initialized
INFO - 2020-09-27 21:24:00 --> URI Class Initialized
INFO - 2020-09-27 21:24:00 --> Router Class Initialized
INFO - 2020-09-27 21:24:00 --> Output Class Initialized
INFO - 2020-09-27 21:24:00 --> Security Class Initialized
DEBUG - 2020-09-27 21:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:24:00 --> Input Class Initialized
INFO - 2020-09-27 21:24:00 --> Language Class Initialized
INFO - 2020-09-27 21:24:00 --> Loader Class Initialized
INFO - 2020-09-27 21:24:00 --> Helper loaded: url_helper
INFO - 2020-09-27 21:24:00 --> Helper loaded: file_helper
INFO - 2020-09-27 21:24:00 --> Database Driver Class Initialized
INFO - 2020-09-27 21:24:00 --> Email Class Initialized
DEBUG - 2020-09-27 21:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:24:00 --> Controller Class Initialized
INFO - 2020-09-27 21:24:00 --> Model "Main_model" initialized
INFO - 2020-09-27 21:24:00 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:24:00 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-27 21:24:00 --> Final output sent to browser
DEBUG - 2020-09-27 21:24:00 --> Total execution time: 0.3652
INFO - 2020-09-27 21:26:44 --> Config Class Initialized
INFO - 2020-09-27 21:26:44 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:26:44 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:26:44 --> Utf8 Class Initialized
INFO - 2020-09-27 21:26:44 --> URI Class Initialized
INFO - 2020-09-27 21:26:44 --> Router Class Initialized
INFO - 2020-09-27 21:26:44 --> Output Class Initialized
INFO - 2020-09-27 21:26:44 --> Security Class Initialized
DEBUG - 2020-09-27 21:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:26:44 --> Input Class Initialized
INFO - 2020-09-27 21:26:44 --> Language Class Initialized
INFO - 2020-09-27 21:26:44 --> Loader Class Initialized
INFO - 2020-09-27 21:26:44 --> Helper loaded: url_helper
INFO - 2020-09-27 21:26:44 --> Helper loaded: file_helper
INFO - 2020-09-27 21:26:44 --> Database Driver Class Initialized
INFO - 2020-09-27 21:26:44 --> Email Class Initialized
DEBUG - 2020-09-27 21:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:26:44 --> Controller Class Initialized
INFO - 2020-09-27 21:26:44 --> Model "Main_model" initialized
INFO - 2020-09-27 21:26:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:26:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-27 21:26:44 --> Final output sent to browser
DEBUG - 2020-09-27 21:26:44 --> Total execution time: 0.3890
INFO - 2020-09-27 21:26:47 --> Config Class Initialized
INFO - 2020-09-27 21:26:47 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:26:47 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:26:47 --> Utf8 Class Initialized
INFO - 2020-09-27 21:26:47 --> URI Class Initialized
INFO - 2020-09-27 21:26:47 --> Router Class Initialized
INFO - 2020-09-27 21:26:47 --> Output Class Initialized
INFO - 2020-09-27 21:26:47 --> Security Class Initialized
DEBUG - 2020-09-27 21:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:26:47 --> Input Class Initialized
INFO - 2020-09-27 21:26:47 --> Language Class Initialized
INFO - 2020-09-27 21:26:47 --> Loader Class Initialized
INFO - 2020-09-27 21:26:47 --> Helper loaded: url_helper
INFO - 2020-09-27 21:26:47 --> Helper loaded: file_helper
INFO - 2020-09-27 21:26:47 --> Database Driver Class Initialized
INFO - 2020-09-27 21:26:47 --> Email Class Initialized
DEBUG - 2020-09-27 21:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:26:47 --> Controller Class Initialized
INFO - 2020-09-27 21:26:47 --> Model "Main_model" initialized
INFO - 2020-09-27 21:26:47 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:26:47 --> File loaded: C:\xampp\htdocs\dmarc\application\views\dmarcrecordgenerator.php
INFO - 2020-09-27 21:26:47 --> Final output sent to browser
DEBUG - 2020-09-27 21:26:47 --> Total execution time: 0.3749
INFO - 2020-09-27 21:27:19 --> Config Class Initialized
INFO - 2020-09-27 21:27:19 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:27:19 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:27:19 --> Utf8 Class Initialized
INFO - 2020-09-27 21:27:19 --> URI Class Initialized
INFO - 2020-09-27 21:27:19 --> Router Class Initialized
INFO - 2020-09-27 21:27:19 --> Output Class Initialized
INFO - 2020-09-27 21:27:19 --> Security Class Initialized
DEBUG - 2020-09-27 21:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:27:19 --> Input Class Initialized
INFO - 2020-09-27 21:27:19 --> Language Class Initialized
INFO - 2020-09-27 21:27:19 --> Loader Class Initialized
INFO - 2020-09-27 21:27:19 --> Helper loaded: url_helper
INFO - 2020-09-27 21:27:19 --> Helper loaded: file_helper
INFO - 2020-09-27 21:27:19 --> Database Driver Class Initialized
INFO - 2020-09-27 21:27:19 --> Email Class Initialized
DEBUG - 2020-09-27 21:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:27:19 --> Controller Class Initialized
INFO - 2020-09-27 21:27:19 --> Model "Main_model" initialized
INFO - 2020-09-27 21:27:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:27:19 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimirecordgenerator.php
INFO - 2020-09-27 21:27:19 --> Final output sent to browser
DEBUG - 2020-09-27 21:27:19 --> Total execution time: 0.3806
INFO - 2020-09-27 21:28:06 --> Config Class Initialized
INFO - 2020-09-27 21:28:06 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:28:06 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:28:06 --> Utf8 Class Initialized
INFO - 2020-09-27 21:28:06 --> URI Class Initialized
INFO - 2020-09-27 21:28:06 --> Router Class Initialized
INFO - 2020-09-27 21:28:06 --> Output Class Initialized
INFO - 2020-09-27 21:28:06 --> Security Class Initialized
DEBUG - 2020-09-27 21:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:28:06 --> Input Class Initialized
INFO - 2020-09-27 21:28:06 --> Language Class Initialized
INFO - 2020-09-27 21:28:06 --> Loader Class Initialized
INFO - 2020-09-27 21:28:06 --> Helper loaded: url_helper
INFO - 2020-09-27 21:28:06 --> Helper loaded: file_helper
INFO - 2020-09-27 21:28:06 --> Database Driver Class Initialized
INFO - 2020-09-27 21:28:06 --> Email Class Initialized
DEBUG - 2020-09-27 21:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:28:06 --> Controller Class Initialized
INFO - 2020-09-27 21:28:06 --> Model "Main_model" initialized
INFO - 2020-09-27 21:28:06 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:28:06 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimirecordgenerator.php
INFO - 2020-09-27 21:28:06 --> Final output sent to browser
DEBUG - 2020-09-27 21:28:06 --> Total execution time: 0.3702
INFO - 2020-09-27 21:28:17 --> Config Class Initialized
INFO - 2020-09-27 21:28:17 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:28:17 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:28:17 --> Utf8 Class Initialized
INFO - 2020-09-27 21:28:17 --> URI Class Initialized
INFO - 2020-09-27 21:28:17 --> Router Class Initialized
INFO - 2020-09-27 21:28:17 --> Output Class Initialized
INFO - 2020-09-27 21:28:17 --> Security Class Initialized
DEBUG - 2020-09-27 21:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:28:18 --> Input Class Initialized
INFO - 2020-09-27 21:28:18 --> Language Class Initialized
INFO - 2020-09-27 21:28:18 --> Loader Class Initialized
INFO - 2020-09-27 21:28:18 --> Helper loaded: url_helper
INFO - 2020-09-27 21:28:18 --> Helper loaded: file_helper
INFO - 2020-09-27 21:28:18 --> Database Driver Class Initialized
INFO - 2020-09-27 21:28:18 --> Email Class Initialized
DEBUG - 2020-09-27 21:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:28:18 --> Controller Class Initialized
INFO - 2020-09-27 21:28:18 --> Model "Main_model" initialized
INFO - 2020-09-27 21:28:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:28:18 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimirecordgenerator.php
INFO - 2020-09-27 21:28:18 --> Final output sent to browser
DEBUG - 2020-09-27 21:28:18 --> Total execution time: 0.3934
INFO - 2020-09-27 21:35:11 --> Config Class Initialized
INFO - 2020-09-27 21:35:11 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:35:11 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:35:11 --> Utf8 Class Initialized
INFO - 2020-09-27 21:35:11 --> URI Class Initialized
INFO - 2020-09-27 21:35:11 --> Router Class Initialized
INFO - 2020-09-27 21:35:11 --> Output Class Initialized
INFO - 2020-09-27 21:35:11 --> Security Class Initialized
DEBUG - 2020-09-27 21:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:35:11 --> Input Class Initialized
INFO - 2020-09-27 21:35:11 --> Language Class Initialized
INFO - 2020-09-27 21:35:11 --> Loader Class Initialized
INFO - 2020-09-27 21:35:11 --> Helper loaded: url_helper
INFO - 2020-09-27 21:35:11 --> Helper loaded: file_helper
INFO - 2020-09-27 21:35:11 --> Database Driver Class Initialized
INFO - 2020-09-27 21:35:11 --> Email Class Initialized
DEBUG - 2020-09-27 21:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:35:11 --> Controller Class Initialized
INFO - 2020-09-27 21:35:11 --> Model "Main_model" initialized
INFO - 2020-09-27 21:35:11 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:35:11 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimirecordgenerator.php
INFO - 2020-09-27 21:35:11 --> Final output sent to browser
DEBUG - 2020-09-27 21:35:11 --> Total execution time: 0.3784
INFO - 2020-09-27 21:35:18 --> Config Class Initialized
INFO - 2020-09-27 21:35:18 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:35:18 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:35:18 --> Utf8 Class Initialized
INFO - 2020-09-27 21:35:18 --> URI Class Initialized
INFO - 2020-09-27 21:35:18 --> Router Class Initialized
INFO - 2020-09-27 21:35:18 --> Output Class Initialized
INFO - 2020-09-27 21:35:18 --> Security Class Initialized
DEBUG - 2020-09-27 21:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:35:18 --> Input Class Initialized
INFO - 2020-09-27 21:35:18 --> Language Class Initialized
ERROR - 2020-09-27 21:35:18 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-27 21:35:26 --> Config Class Initialized
INFO - 2020-09-27 21:35:26 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:35:26 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:35:26 --> Utf8 Class Initialized
INFO - 2020-09-27 21:35:26 --> URI Class Initialized
INFO - 2020-09-27 21:35:26 --> Router Class Initialized
INFO - 2020-09-27 21:35:26 --> Output Class Initialized
INFO - 2020-09-27 21:35:26 --> Security Class Initialized
DEBUG - 2020-09-27 21:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:35:26 --> Input Class Initialized
INFO - 2020-09-27 21:35:26 --> Language Class Initialized
INFO - 2020-09-27 21:35:26 --> Loader Class Initialized
INFO - 2020-09-27 21:35:26 --> Helper loaded: url_helper
INFO - 2020-09-27 21:35:26 --> Helper loaded: file_helper
INFO - 2020-09-27 21:35:26 --> Database Driver Class Initialized
INFO - 2020-09-27 21:35:26 --> Email Class Initialized
DEBUG - 2020-09-27 21:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:35:26 --> Controller Class Initialized
INFO - 2020-09-27 21:35:26 --> Model "Main_model" initialized
INFO - 2020-09-27 21:35:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:35:26 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimirecordgenerator.php
INFO - 2020-09-27 21:35:26 --> Final output sent to browser
DEBUG - 2020-09-27 21:35:26 --> Total execution time: 0.3754
INFO - 2020-09-27 21:35:27 --> Config Class Initialized
INFO - 2020-09-27 21:35:27 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:35:27 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:35:27 --> Utf8 Class Initialized
INFO - 2020-09-27 21:35:27 --> URI Class Initialized
INFO - 2020-09-27 21:35:27 --> Router Class Initialized
INFO - 2020-09-27 21:35:27 --> Output Class Initialized
INFO - 2020-09-27 21:35:27 --> Security Class Initialized
DEBUG - 2020-09-27 21:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:35:27 --> Input Class Initialized
INFO - 2020-09-27 21:35:27 --> Language Class Initialized
ERROR - 2020-09-27 21:35:27 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-27 21:36:29 --> Config Class Initialized
INFO - 2020-09-27 21:36:29 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:36:29 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:36:29 --> Utf8 Class Initialized
INFO - 2020-09-27 21:36:29 --> URI Class Initialized
INFO - 2020-09-27 21:36:29 --> Router Class Initialized
INFO - 2020-09-27 21:36:29 --> Output Class Initialized
INFO - 2020-09-27 21:36:29 --> Security Class Initialized
DEBUG - 2020-09-27 21:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:36:29 --> Input Class Initialized
INFO - 2020-09-27 21:36:29 --> Language Class Initialized
INFO - 2020-09-27 21:36:29 --> Loader Class Initialized
INFO - 2020-09-27 21:36:29 --> Helper loaded: url_helper
INFO - 2020-09-27 21:36:29 --> Helper loaded: file_helper
INFO - 2020-09-27 21:36:29 --> Database Driver Class Initialized
INFO - 2020-09-27 21:36:29 --> Email Class Initialized
DEBUG - 2020-09-27 21:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:36:30 --> Controller Class Initialized
INFO - 2020-09-27 21:36:30 --> Model "Main_model" initialized
INFO - 2020-09-27 21:36:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:36:30 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimirecordgenerator.php
INFO - 2020-09-27 21:36:30 --> Final output sent to browser
DEBUG - 2020-09-27 21:36:30 --> Total execution time: 0.3943
INFO - 2020-09-27 21:36:31 --> Config Class Initialized
INFO - 2020-09-27 21:36:31 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:36:31 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:36:31 --> Utf8 Class Initialized
INFO - 2020-09-27 21:36:31 --> URI Class Initialized
INFO - 2020-09-27 21:36:31 --> Router Class Initialized
INFO - 2020-09-27 21:36:31 --> Output Class Initialized
INFO - 2020-09-27 21:36:31 --> Security Class Initialized
DEBUG - 2020-09-27 21:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:36:31 --> Input Class Initialized
INFO - 2020-09-27 21:36:31 --> Language Class Initialized
ERROR - 2020-09-27 21:36:31 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-27 21:39:43 --> Config Class Initialized
INFO - 2020-09-27 21:39:43 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:39:43 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:39:43 --> Utf8 Class Initialized
INFO - 2020-09-27 21:39:43 --> URI Class Initialized
INFO - 2020-09-27 21:39:43 --> Router Class Initialized
INFO - 2020-09-27 21:39:44 --> Output Class Initialized
INFO - 2020-09-27 21:39:44 --> Security Class Initialized
DEBUG - 2020-09-27 21:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:39:44 --> Input Class Initialized
INFO - 2020-09-27 21:39:44 --> Language Class Initialized
INFO - 2020-09-27 21:39:44 --> Loader Class Initialized
INFO - 2020-09-27 21:39:44 --> Helper loaded: url_helper
INFO - 2020-09-27 21:39:44 --> Helper loaded: file_helper
INFO - 2020-09-27 21:39:44 --> Database Driver Class Initialized
INFO - 2020-09-27 21:39:44 --> Email Class Initialized
DEBUG - 2020-09-27 21:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:39:44 --> Controller Class Initialized
INFO - 2020-09-27 21:39:44 --> Model "Main_model" initialized
INFO - 2020-09-27 21:39:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:39:44 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimirecordgenerator.php
INFO - 2020-09-27 21:39:44 --> Final output sent to browser
DEBUG - 2020-09-27 21:39:44 --> Total execution time: 0.4123
INFO - 2020-09-27 21:39:46 --> Config Class Initialized
INFO - 2020-09-27 21:39:46 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:39:46 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:39:46 --> Utf8 Class Initialized
INFO - 2020-09-27 21:39:46 --> URI Class Initialized
INFO - 2020-09-27 21:39:46 --> Router Class Initialized
INFO - 2020-09-27 21:39:46 --> Output Class Initialized
INFO - 2020-09-27 21:39:46 --> Security Class Initialized
DEBUG - 2020-09-27 21:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:39:46 --> Input Class Initialized
INFO - 2020-09-27 21:39:46 --> Language Class Initialized
ERROR - 2020-09-27 21:39:46 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-27 21:40:04 --> Config Class Initialized
INFO - 2020-09-27 21:40:04 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:40:04 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:40:04 --> Utf8 Class Initialized
INFO - 2020-09-27 21:40:04 --> URI Class Initialized
INFO - 2020-09-27 21:40:04 --> Router Class Initialized
INFO - 2020-09-27 21:40:04 --> Output Class Initialized
INFO - 2020-09-27 21:40:04 --> Security Class Initialized
DEBUG - 2020-09-27 21:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:40:04 --> Input Class Initialized
INFO - 2020-09-27 21:40:04 --> Language Class Initialized
INFO - 2020-09-27 21:40:04 --> Loader Class Initialized
INFO - 2020-09-27 21:40:04 --> Helper loaded: url_helper
INFO - 2020-09-27 21:40:04 --> Helper loaded: file_helper
INFO - 2020-09-27 21:40:04 --> Database Driver Class Initialized
INFO - 2020-09-27 21:40:04 --> Email Class Initialized
DEBUG - 2020-09-27 21:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:40:04 --> Controller Class Initialized
INFO - 2020-09-27 21:40:04 --> Model "Main_model" initialized
INFO - 2020-09-27 21:40:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:40:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimirecordgenerator.php
INFO - 2020-09-27 21:40:04 --> Final output sent to browser
DEBUG - 2020-09-27 21:40:04 --> Total execution time: 0.4152
INFO - 2020-09-27 21:40:05 --> Config Class Initialized
INFO - 2020-09-27 21:40:05 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:40:05 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:40:05 --> Utf8 Class Initialized
INFO - 2020-09-27 21:40:05 --> URI Class Initialized
INFO - 2020-09-27 21:40:05 --> Router Class Initialized
INFO - 2020-09-27 21:40:05 --> Output Class Initialized
INFO - 2020-09-27 21:40:05 --> Security Class Initialized
DEBUG - 2020-09-27 21:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:40:05 --> Input Class Initialized
INFO - 2020-09-27 21:40:05 --> Language Class Initialized
ERROR - 2020-09-27 21:40:05 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-27 21:41:03 --> Config Class Initialized
INFO - 2020-09-27 21:41:03 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:41:03 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:41:03 --> Utf8 Class Initialized
INFO - 2020-09-27 21:41:03 --> URI Class Initialized
INFO - 2020-09-27 21:41:03 --> Router Class Initialized
INFO - 2020-09-27 21:41:04 --> Output Class Initialized
INFO - 2020-09-27 21:41:04 --> Security Class Initialized
DEBUG - 2020-09-27 21:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:41:04 --> Input Class Initialized
INFO - 2020-09-27 21:41:04 --> Language Class Initialized
INFO - 2020-09-27 21:41:04 --> Loader Class Initialized
INFO - 2020-09-27 21:41:04 --> Helper loaded: url_helper
INFO - 2020-09-27 21:41:04 --> Helper loaded: file_helper
INFO - 2020-09-27 21:41:04 --> Database Driver Class Initialized
INFO - 2020-09-27 21:41:04 --> Email Class Initialized
DEBUG - 2020-09-27 21:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:41:04 --> Controller Class Initialized
INFO - 2020-09-27 21:41:04 --> Model "Main_model" initialized
INFO - 2020-09-27 21:41:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:41:04 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimirecordgenerator.php
INFO - 2020-09-27 21:41:04 --> Final output sent to browser
DEBUG - 2020-09-27 21:41:04 --> Total execution time: 0.4289
INFO - 2020-09-27 21:41:05 --> Config Class Initialized
INFO - 2020-09-27 21:41:05 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:41:05 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:41:05 --> Utf8 Class Initialized
INFO - 2020-09-27 21:41:05 --> URI Class Initialized
INFO - 2020-09-27 21:41:05 --> Router Class Initialized
INFO - 2020-09-27 21:41:05 --> Output Class Initialized
INFO - 2020-09-27 21:41:05 --> Security Class Initialized
DEBUG - 2020-09-27 21:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:41:05 --> Input Class Initialized
INFO - 2020-09-27 21:41:05 --> Language Class Initialized
ERROR - 2020-09-27 21:41:05 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-27 21:42:33 --> Config Class Initialized
INFO - 2020-09-27 21:42:33 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:42:33 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:42:33 --> Utf8 Class Initialized
INFO - 2020-09-27 21:42:33 --> URI Class Initialized
INFO - 2020-09-27 21:42:33 --> Router Class Initialized
INFO - 2020-09-27 21:42:33 --> Output Class Initialized
INFO - 2020-09-27 21:42:33 --> Security Class Initialized
DEBUG - 2020-09-27 21:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:42:33 --> Input Class Initialized
INFO - 2020-09-27 21:42:33 --> Language Class Initialized
INFO - 2020-09-27 21:42:33 --> Loader Class Initialized
INFO - 2020-09-27 21:42:33 --> Helper loaded: url_helper
INFO - 2020-09-27 21:42:33 --> Helper loaded: file_helper
INFO - 2020-09-27 21:42:33 --> Database Driver Class Initialized
INFO - 2020-09-27 21:42:33 --> Email Class Initialized
DEBUG - 2020-09-27 21:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:42:33 --> Controller Class Initialized
INFO - 2020-09-27 21:42:33 --> Model "Main_model" initialized
INFO - 2020-09-27 21:42:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:42:33 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimirecordgenerator.php
INFO - 2020-09-27 21:42:33 --> Final output sent to browser
DEBUG - 2020-09-27 21:42:33 --> Total execution time: 0.4411
INFO - 2020-09-27 21:42:35 --> Config Class Initialized
INFO - 2020-09-27 21:42:35 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:42:35 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:42:35 --> Utf8 Class Initialized
INFO - 2020-09-27 21:42:35 --> URI Class Initialized
INFO - 2020-09-27 21:42:35 --> Router Class Initialized
INFO - 2020-09-27 21:42:35 --> Output Class Initialized
INFO - 2020-09-27 21:42:35 --> Security Class Initialized
DEBUG - 2020-09-27 21:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:42:35 --> Input Class Initialized
INFO - 2020-09-27 21:42:35 --> Language Class Initialized
ERROR - 2020-09-27 21:42:35 --> 404 Page Not Found: Resources/vendor
INFO - 2020-09-27 21:44:06 --> Config Class Initialized
INFO - 2020-09-27 21:44:06 --> Hooks Class Initialized
DEBUG - 2020-09-27 21:44:06 --> UTF-8 Support Enabled
INFO - 2020-09-27 21:44:06 --> Utf8 Class Initialized
INFO - 2020-09-27 21:44:06 --> URI Class Initialized
INFO - 2020-09-27 21:44:06 --> Router Class Initialized
INFO - 2020-09-27 21:44:06 --> Output Class Initialized
INFO - 2020-09-27 21:44:06 --> Security Class Initialized
DEBUG - 2020-09-27 21:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-27 21:44:06 --> Input Class Initialized
INFO - 2020-09-27 21:44:06 --> Language Class Initialized
INFO - 2020-09-27 21:44:06 --> Loader Class Initialized
INFO - 2020-09-27 21:44:06 --> Helper loaded: url_helper
INFO - 2020-09-27 21:44:06 --> Helper loaded: file_helper
INFO - 2020-09-27 21:44:07 --> Database Driver Class Initialized
INFO - 2020-09-27 21:44:07 --> Email Class Initialized
DEBUG - 2020-09-27 21:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-27 21:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-27 21:44:07 --> Controller Class Initialized
INFO - 2020-09-27 21:44:07 --> Model "Main_model" initialized
INFO - 2020-09-27 21:44:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\innermenu.php
INFO - 2020-09-27 21:44:07 --> File loaded: C:\xampp\htdocs\dmarc\application\views\bimirecordgenerator.php
INFO - 2020-09-27 21:44:07 --> Final output sent to browser
DEBUG - 2020-09-27 21:44:07 --> Total execution time: 0.4030
