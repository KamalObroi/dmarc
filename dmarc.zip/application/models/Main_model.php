<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main_model extends CI_Model {

	public function __construct(){

     parent::__construct();
     $this->load->database();
    }
    function isEmailExists($username){
    	$this->db->select('*');
	    $this->db->from('users');
	    $this->db->where('email', $username );
	    $query = $this->db->get();	    
	    if($query->num_rows() > 0){	        
	        return TRUE;
	    }
	    return FALSE;
    }
    function getUserDomains($uid){
    	$this->db->select('*');
	    $this->db->from('domains');
	    $this->db->where('uid',$uid);
	    $query = $this->db->get();	    
	    if($query->num_rows() > 0){
	        return $query->result();;
	    }
	    return array();
    }
    function getAlertDomains($uid){
    	$this->db->select('*');
	    $this->db->from('alerts');
	    $this->db->where('uid',$uid);
	    $query = $this->db->get();	    
	    if($query->num_rows() > 0){
	        return $query->result();;
	    }
	    return array();
    }
    function isUserDomainExists($domain,$uid){
    	$this->db->select('*');
	    $this->db->from('domains');
	    $this->db->where('domain', $domain );
	    $this->db->where('uid',$uid);
	    $query = $this->db->get();	    
	    if($query->num_rows() > 0){
	        return TRUE;
	    }
	    return FALSE;
    }
    function isUserExists($username,$password){
    	$this->db->select('*');
	    $this->db->from('users');
	    $this->db->where('email', $username );
	    $this->db->where('password',sha1($password));
	    $query = $this->db->get();	    
	    if($query->num_rows() > 0){
	        $row = $query->row_array();
	        return $row;
	    }
	    return FALSE;
    }
	function getUsers(){
		$response = array(); 
		$this->db->select('*');
		$q = $this->db->get('users');
		$response = $q->result_array();
		return $response;
	}
	function insertDomain($domainarray){				
		return $this->db->insert('domains',$domainarray);
	}
	function insertUser($userArray){				
		return $this->db->insert('users',$userArray);
	}
	function insertUserAlert($data){
		return $this->db->insert('alerts',$data);
	}
}